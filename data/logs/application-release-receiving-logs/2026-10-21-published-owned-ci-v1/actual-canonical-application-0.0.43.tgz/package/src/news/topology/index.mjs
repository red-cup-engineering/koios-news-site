import { readingAs } from "@red-cup-engineering/computer-data-engineering-services-section/four";

/** A JSON value — the metadata/object payload carried by news carriers.
 * The content domain owns its own JSON type; it borrows none from the agent
 * fleet. */

/** Deterministic id from a value: a slugged JSON serialization, truncated.
 * Pure and content-local — the news domain carries no agent-fleet
 * dependency, only a hash over its own carriers. */
function stableId(value, length = 16) {
  return JSON.stringify(value)
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, length) || "item";
}

/**
 * The newsroom desks: the named editorial offices a story passes through -
 * assignment, research, writing, editing, standards, publishing.
 */

/**
 * The output shape of a news item: wire, article, brief, profile, explainer, or
 * custom.
 */

/**
 * A claim's reading, from the four readings (SignCell): the reading a
 * news cell carries (absurd, potential, active, stable).
 */

/**
 * A single claim cell: a predicate and object, with optional citation and the
 * witnesses who claimed or contrarily claimed it.
 */

/**
 * The lossy projection of a claim-state onto a subject: claims partitioned by
 * reading into potential, active, and stable cells, with an optional time
 * marker. The documented LOSSY view of ClaimStateBundle kept for the wire
 * surfaces.
 */

/**
 * A write request against a subject's claims: the subject, a map of
 * predicate-to-value claims, and the citation backing them.
 */

/**
 * One stage of the editorial lifecycle: its status, the gate predicate that
 * clears it, and a human label.
 */

/**
 * The resolved editorial lifecycle: its ordered stages, the status and gate
 * atoms, the publishing status, and lookups from a status to its index or gate.
 */

/**
 * The full editorial-gate judgment for a subject: its current status, whether
 * it is publishable, and every lifecycle gate with its reading,
 * cleared/contested/rejected flags, and witnessing evidence.
 */

/**
 * A coverage beat: its keyword, optional near-keywords, optional domain, and
 * optional metadata.
 */

/**
 * A news source definition: an id, the adapter that fetches it, an optional
 * query, url, max item count, and metadata.
 */

/**
 * A single observation drawn from a source: its id, originating sourceId, url
 * and title, with optional summary, authors, published date, categories,
 * reading, and metadata.
 */

/**
 * A proposed story: its id, beat, headline and angle, the source observations
 * it draws on, its output format, and optional metadata.
 */

/**
 * A desk's ruling on a story: the storyId, the desk, the pass/fail/hold/revise
 * status, and optional reason, timestamp, author, and evidence.
 */

// The news desks (agent-fleet offices) and the assignment/project work
// builders are AGENCY, not content — they live in services/newsroom, which
// specializes this content core onto the agent fleet.

/**
 * The frozen registry of news predicate paths: maps each news concept (beat,
 * keyword, source, headline, body, angle, editorial-decision, codecs, and so
 * on) to its predicate path tuple.
 */
export const NEWS_PREDICATES = Object.freeze({
  beat: ["news", "beat"],
  keyword: ["news", "keyword"],
  nearKeyword: ["news", "near-keyword"],
  source: ["news", "source"],
  sourceUrl: ["news", "source-url"],
  headline: ["news", "headline"],
  summary: ["news", "summary"],
  body: ["news", "body"],
  angle: ["news", "angle"],
  drawsOn: ["news", "draws-on"],
  editorialDecision: ["news", "editorial-decision"],
  publishedAt: ["news", "published-at"],
  ninjs: ["news", "codec", "ninjs"],
  iptc: ["news", "codec", "iptc"],
});

/**
 * The predicate atom under which a subject's current publication status cell is
 * stored.
 */
export const STATUS_PREDICATE = "status";
/** The object value marking a cleared editorial gate. */
export const GATE_PASS = "pass";
/** The object value marking a failed editorial gate. */
export const GATE_FAIL = "fail";
/** The status and gate atom for the published lifecycle stage. */
export const PUBLISHED = "published";

/**
 * The default editorial lifecycle stages: assigned, reported, fact-checked,
 * copy-edited, standards-cleared, and published.
 */
export const DEFAULT_LIFECYCLE = Object.freeze([
  Object.freeze({ status: "assigned", gate: "assigned", label: "Assigned" }),
  Object.freeze({ status: "reported", gate: "reported", label: "Reported" }),
  Object.freeze({ status: "fact-checked", gate: "fact-checked", label: "Fact-checked" }),
  Object.freeze({ status: "copy-edited", gate: "copy-edited", label: "Copy-edited" }),
  Object.freeze({ status: "standards-cleared", gate: "standards-cleared", label: "Standards-cleared" }),
  Object.freeze({ status: PUBLISHED, gate: PUBLISHED, label: "Published" }),
]);

/**
 * Build a resolved Lifecycle from stage specs: normalizes each stage
 * (defaulting gate and label to the status), checks statuses are unique, fixes
 * the publish status, and returns the frozen lifecycle with index and gate
 * lookups. Throws TypeError on no stages, a missing status, duplicate statuses,
 * or a publishStatus outside the lifecycle.
 */
export function lifecycle(stages = DEFAULT_LIFECYCLE, opts = {}) {
  if (stages.length === 0) throw new TypeError("lifecycle needs at least one stage");
  const normalized = Object.freeze(stages.map((stage, index) => {
    if (!stage.status) throw new TypeError(`lifecycle stage ${index} needs status`);
    return Object.freeze({ status: stage.status, gate: stage.gate ?? stage.status, label: stage.label ?? stage.status });
  }));
  const statuses = normalized.map((stage) => stage.status);
  if (new Set(statuses).size !== statuses.length) throw new TypeError("lifecycle statuses must be unique");
  const publishStatus = opts.publishStatus ?? statuses.at(-1);
  if (!statuses.includes(publishStatus)) throw new TypeError("publishStatus must be in lifecycle");
  const byStatus = new Map(statuses.map((status, index) => [status, index]));
  return Object.freeze({
    stages: normalized,
    statuses: Object.freeze(statuses),
    gates: Object.freeze(normalized.map((stage) => stage.gate)),
    publishStatus,
    indexOf: (status) => byStatus.get(status) ?? -1,
    gateFor: (status) => {
      const index = byStatus.get(status);
      return index === undefined ? undefined : normalized[index]?.gate;
    },
  });
}

/**
 * The set of predicates the news domain manages internally: the status
 * predicate together with every lifecycle gate.
 */
export function internalPredicates(lc = lifecycle()) {
  return new Set([STATUS_PREDICATE, ...lc.gates]);
}

/**
 * The subject's current publication status: the last string-valued status cell
 * among its potential claims, or null if none.
 */
export function currentPublicationStatus(claimSet) {
  let status = null;
  for (const cell of claimSet.potential ?? []) {
    if (cell.predicate === STATUS_PREDICATE && typeof cell.object === "string") status = cell.object;
  }
  return status;
}

/**
 * The reading of a gate over a claim set: stable if any stable cell carries the
 * gate, absurd if no cell does, potential if any potential cell is not a fail,
 * otherwise active.
 */
export function editorialGateReading(claimSet, gate) {
  if ((claimSet.stable ?? []).some((cell) => cell.predicate === gate)) return "stable";
  const potential = (claimSet.potential ?? []).filter((cell) => cell.predicate === gate);
  const active = (claimSet.active ?? []).filter((cell) => cell.predicate === gate);
  if (potential.length === 0 && active.length === 0) return "absurd";
  if (potential.some((cell) => cell.object !== GATE_FAIL)) return "potential";
  return "active";
}

/**
 * The boolean shadow of the editorial-gate judgment (way 5: the classical
 * case is the degenerate case). The PRIMARY judgments are the carriers:
 * `editorialGateReport` (every gate with its reading and evidence) and
 * `firstBlockingEditorialGate` (the obstruction, or null). This shadow is a
 * rendering-edge convenience exported only for compatibility with its
 * existing consumers (`services/newsroom`, `services/newswire`), which use
 * it exactly as a rendering-edge count/filter. New callers should take the
 * carrier, not the shadow: the shadow forgets WHICH gate blocked and WHO
 * witnessed it. Exported by alias below so the boundary documents the
 * collapse instead of presenting it as a judgment (invariant A1).
 */
function readyForPublicationShadow(claimSet, lc = lifecycle()) {
  const status = currentPublicationStatus(claimSet);
  if (!status || lc.indexOf(status) < lc.indexOf(lc.publishStatus)) return false;
  const publishIndex = lc.indexOf(lc.publishStatus);
  return lc.stages.slice(0, publishIndex + 1).every((stage) => editorialGateReading(claimSet, stage.gate) === "potential");
}

export { readyForPublicationShadow as isReadyForPublication };

/**
 * The witnesses backing a gate over a claim set: the deduplicated citations
 * from potential and active cells plus the claimedBy and contraryClaimedBy
 * witnesses from stable cells.
 */
export function editorialGateEvidence(claimSet, gate) {
  const evidence = [];
  const push = (value) => {
    for (const witness of witnessList(value)) if (!evidence.includes(witness)) evidence.push(witness);
  };
  for (const cell of claimSet.potential ?? []) if (cell.predicate === gate) push(cell.citation);
  for (const cell of claimSet.active ?? []) if (cell.predicate === gate) push(cell.citation);
  for (const cell of claimSet.stable ?? []) {
    if (cell.predicate !== gate) continue;
    push(cell.claimedBy);
    push(cell.contraryClaimedBy);
  }
  return Object.freeze(evidence);
}

/**
 * The GateReport for a claim set: the subject, its current status, its
 * publishable shadow, and every lifecycle gate with its reading,
 * cleared/contested/rejected flags, and evidence.
 */
export function editorialGateReport(claimSet, lc = lifecycle()) {
  return Object.freeze({
    subject: claimSet.subject,
    status: currentPublicationStatus(claimSet),
    publishable: readyForPublicationShadow(claimSet, lc),
    gates: Object.freeze(lc.stages.map((stage) => {
      const reading = editorialGateReading(claimSet, stage.gate);
      return Object.freeze({
        status: stage.status,
        gate: stage.gate,
        label: stage.label,
        reading,
        cleared: reading === "potential",
        contested: reading === "stable",
        rejected: reading === "active",
        evidence: editorialGateEvidence(claimSet, stage.gate),
      });
    })),
  });
}

/**
 * The first uncleared gate in the report - the obstruction to publication - or
 * null when every gate is cleared.
 */
export function firstBlockingEditorialGate(claimSet, lc = lifecycle()) {
  return editorialGateReport(claimSet, lc).gates.find((gate) => !gate.cleared) ?? null;
}

/**
 * Normalize a beat input into a frozen NewsBeat: requires a non-empty keyword,
 * trims near-keywords and domain, and copies metadata. Throws TypeError on
 * empty text fields.
 */
export function newsBeat(input) {
  return Object.freeze({
    keyword: requireText(input.keyword, "beat keyword"),
    ...(input.nearKeywords === undefined ? {} : { nearKeywords: Object.freeze(input.nearKeywords.map((value) => requireText(value, "near keyword"))) }),
    ...(input.domain === undefined ? {} : { domain: requireText(input.domain, "beat domain") }),
    ...(input.metadata === undefined ? {} : { metadata: Object.freeze({ ...input.metadata }) }),
  });
}

/**
 * The subject path for a beat: the frozen tuple ["news", "beat", slug] from a
 * beat or its keyword.
 */
export function beatSubject(beat) {
  const keyword = typeof beat === "string" ? beat : beat.keyword;
  return Object.freeze(["news", "beat", slug(keyword)]);
}

/**
 * The subject path for a story: the frozen tuple ["news", "story", slug] from a
 * required story id.
 */
export function storySubject(id) {
  return Object.freeze(["news", "story", slug(requireText(id, "story id"))]);
}

/**
 * The subject path for a source: the frozen tuple ["news", "source", slug] from
 * a required source id.
 */
export function sourceSubject(id) {
  return Object.freeze(["news", "source", slug(requireText(id, "source id"))]);
}

/**
 * Normalize a source input into a frozen NewsSource: requires non-empty id and
 * adapter, trims optional query and url, and copies max and metadata. Throws
 * TypeError on empty required text.
 */
export function newsSource(input) {
  return Object.freeze({
    id: requireText(input.id, "source id"),
    adapter: requireText(input.adapter, "source adapter"),
    ...(input.query === undefined ? {} : { query: requireText(input.query, "source query") }),
    ...(input.url === undefined ? {} : { url: requireText(input.url, "source url") }),
    ...(input.max === undefined ? {} : { max: input.max }),
    ...(input.metadata === undefined ? {} : { metadata: Object.freeze({ ...input.metadata }) }),
  });
}

/**
 * Normalize an observation into a frozen NewsSourceObservation: derives a
 * stable id from sourceId, url, and title when none is given, requires
 * non-empty sourceId, url, and title, normalizes any reading, and copies the
 * optional fields.
 */
export function sourceObservation(input) {
  const id = input.id ?? `observation:${stableId([input.sourceId, input.url, input.title])}`;
  return Object.freeze({
    id,
    sourceId: requireText(input.sourceId, "observation sourceId"),
    url: requireText(input.url, "observation url"),
    title: requireText(input.title, "observation title"),
    ...(input.summary === undefined ? {} : { summary: input.summary }),
    ...(input.authors === undefined ? {} : { authors: Object.freeze([...input.authors]) }),
    ...(input.published === undefined ? {} : { published: input.published }),
    ...(input.categories === undefined ? {} : { categories: Object.freeze([...input.categories]) }),
    ...(input.reading === undefined ? {} : { reading: readingAs("knowledge", input.reading) }),
    ...(input.metadata === undefined ? {} : { metadata: Object.freeze({ ...input.metadata }) }),
  });
}

/**
 * Normalize a story input into a frozen NewsStoryCandidate: normalizes its beat
 * and source observations, derives an id from the headline, angle, or source
 * urls when none is given, and requires non-empty headline and angle.
 */
export function storyCandidate(input) {
  const beat = newsBeat(input.beat);
  const sources = Object.freeze(input.sources.map((source) => sourceObservation(source)));
  const id = input.id ?? slug(input.headline || input.angle || stableId(sources.map((source) => source.url)));
  return Object.freeze({
    id,
    beat,
    headline: requireText(input.headline, "story headline"),
    angle: requireText(input.angle, "story angle"),
    sources,
    format: input.format,
    ...(input.metadata === undefined ? {} : { metadata: Object.freeze({ ...input.metadata }) }),
  });
}

/**
 * Normalize a decision input into a frozen NewsEditorialDecision: requires a
 * non-empty storyId, keeps the desk and status, and copies the optional reason,
 * timestamp, author, and evidence.
 */
export function editorialDecision(input) {
  return Object.freeze({
    storyId: requireText(input.storyId, "decision storyId"),
    desk: input.desk,
    status: input.status,
    ...(input.reason === undefined ? {} : { reason: input.reason }),
    ...(input.at === undefined ? {} : { at: input.at }),
    ...(input.by === undefined ? {} : { by: input.by }),
    ...(input.evidence === undefined ? {} : { evidence: Object.freeze([...input.evidence]) }),
  });
}

/**
 * The gate cell for a decision: the frozen [desk, "pass"|"fail"] tuple,
 * collapsing any non-pass status to fail.
 */
export function decisionGate(decision) {
  const normalized = editorialDecision(decision);
  return Object.freeze([normalized.desk, normalized.status === "pass" ? "pass" : "fail"]);
}

/**
 * The news domain's public slugger: lowercases, strips diacritics, and joins
 * the value into a hyphenated atom, returning "item" when empty.
 */
export function newsSlug(value) {
  return slug(value);
}

function slug(value) {
  return String(value ?? "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "item";
}

function witnessList(value) {
  if (value === undefined || value === null) return [];
  return Array.isArray(value) ? value.map(String) : [String(value)];
}

function requireText(value, path) {
  if (typeof value !== "string" || value.trim() === "") throw new TypeError(`${path} must be a non-empty string`);
  return value.trim();
}

// — The enriched claim carrier and the cable (claim.mts, cable.mts). —

export {
  assertClaimStateBundle,
  effectiveClaims,
  correctionClaims,
  withCorrection,

} from "./claim.mjs";

export {
  assertNewsCable,
  cableBaseUrl,
  wireBaseUrl,
  routeRequest,

} from "./cable.mjs";

// — The assertion round-trip: writes ↔ assertion trace ↔ claim sets
// (assertions.mts), the carrier's serialization over SignCell evidence. —

export {
  toJsonValue,
  write,
  clearGate,
  stableJsonKey,
  traceEntryId,
  assertionFromClaim,
  assertionsFromWrites,
  claimSetsFromTrace,

} from "./assertions.mjs";
