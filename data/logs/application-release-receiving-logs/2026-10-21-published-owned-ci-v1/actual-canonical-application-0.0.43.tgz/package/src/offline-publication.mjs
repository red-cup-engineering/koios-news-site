import {articleQuality,editorialProductFor} from "./article-quality.mjs";
import editorialCatalog from "../policy/law/editorial-treatment-catalog.json" with {type:"json"};
import {verifyManuscriptEvidence} from "@red-cup-engineering/content-mill-newsroom-services-section/evidence";
import { createHash } from "node:crypto";
import { closeSync, cpSync, existsSync, fsyncSync, lstatSync, mkdirSync, mkdtempSync, openSync, readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { tmpdir } from "node:os";

import { buildProperty, parsePost } from "@causeway-services/koios-news-site/build";
import { consumePublicationAuthority, verifyPublicationAuthority } from "@causeway-services/editorial-publication-authority";
import { sha256Digest, sha256Hex } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity";

const MARKER = ".koios-routine-publication-current";
const EDITORIAL_CONTRACT = "ni:///sha-256;GTSsfC0lmcjPLQvtlGmYwLJLCa9pirz1d8oUqRweioo";
const isRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const bytewiseNameOrder = (left, right) => Buffer.compare(Buffer.from(left.name, "utf8"), Buffer.from(right.name, "utf8"));

function readJson(path, label) {
  try { return JSON.parse(readFileSync(path, "utf8")); }
  catch (error) { throw new Error(`${label} is not readable JSON: ${error.message}`); }
}
function fsyncDirectory(path) {
  const descriptor = openSync(path, "r");
  try { fsyncSync(descriptor); }
  finally { closeSync(descriptor); }
}
// The tracked corpus is deliberately never mutated by a routine publication
// (see the receipt's transition.sourceMutated invariant), so a post's own
// `draft: true` front matter never durably flips. Without a separate durable
// record of what has already been routine-published, every later candidate's
// readPosts(work) sees only {corpus draft:false files} union {this one job's
// flipped draft} and silently drops every previously published post from its
// freshly regenerated sitemap/feed/homepage/archive, even though that post's
// individual page keeps being served from stale production-baseline
// carry-forward. This ledger closes that gap: every successful candidate
// records its own promoted post here, and every later candidate copies the
// whole ledger into its own working corpus before building, so discovery
// surfaces regenerate atomically with every post that has ever gone live.
function publishedLedgerDir(replayRoot) { return join(resolve(replayRoot), "published"); }
/**
 * List every durably recorded previously-published post as `{relative,
 * path}` entries ready to seed a routine-publication working corpus.
 *
 * @param {string} [replayRoot] Absolute replay root; entries are empty when
 *   omitted or when no post has been recorded there yet.
 * @returns {readonly {relative: string, path: string}[]}
 * @throws {Error} When the ledger directory exists but is not a real
 *   directory, or contains a symlinked entry.
 */
export function listPublishedLedgerEntries(replayRoot) {
  if (typeof replayRoot !== "string" || replayRoot === "") return Object.freeze([]);
  const dir = publishedLedgerDir(replayRoot);
  if (!existsSync(dir)) return Object.freeze([]);
  const stat = lstatSync(dir);
  if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error(`published-posts ledger must be a real directory: ${dir}`);
  return Object.freeze(readdirSync(dir, { withFileTypes: true })
    .filter((entry) => entry.isFile() && entry.name.endsWith(".md"))
    .sort(bytewiseNameOrder)
    .map((entry) => {
      const path = join(dir, entry.name);
      if (lstatSync(path).isSymbolicLink()) throw new Error(`published-posts ledger entry must not be a symlink: ${entry.name}`);
      return Object.freeze({ relative: entry.name, path });
    }));
}
/**
 * Copy every ledger entry into a working corpus, overwriting whatever the
 * tracked corpus itself supplied at the same relative path. The tracked
 * corpus keeps every post at its original, never-mutated `draft: true`
 * bytes (copyCorpus copies it verbatim); the ledger is the sole durable
 * record of which of those posts have actually been routine-published and
 * carries their exact promoted (`draft: false`) projection, so it must win.
 */
function mergePublishedLedgerIntoWork({ work, replayRoot, admitted }) {
  const entries = listPublishedLedgerEntries(replayRoot);
  // The admitted post is the slug's successor: its earlier published version never overwrites it.
  for (const entry of entries) if (entry.relative !== admitted) writeFileSync(join(work, entry.relative), readFileSync(entry.path));
  return Object.freeze({ priorPublishedCount: entries.length, ...(entries.some((entry) => entry.relative === admitted) ? { updates: admitted } : {}) });
}
function createBuildPublishedLedger({ replayRoot, admitted, projectedSource }) {
  const dir = mkdtempSync(join(tmpdir(), "koios-routine-published-ledger-"));
  for (const entry of listPublishedLedgerEntries(replayRoot)) {
    if (entry.relative !== admitted) writeFileSync(join(dir, entry.relative), readFileSync(entry.path), { mode: 0o600 });
  }
  writeFileSync(join(dir, admitted), projectedSource, { mode: 0o600 });
  return dir;
}
function publishedVersionsDir(replayRoot, slug) { return join(resolve(replayRoot), "published-versions", slug); }
/**
 * Durably record one successfully formed candidate's own promoted post so
 * every future routine-publication build includes it. Best-effort: a
 * candidate that already finished and consumed its one-use authority must
 * never be turned into a thrown failure by this secondary bookkeeping step,
 * so every failure mode here is reported, not thrown.
 *
 * The ledger holds each slug's current version: a story keeps its address as
 * it develops, so a newly authorized version of a published slug supersedes
 * the one there, which is first kept under published-versions/<slug>/ by its
 * digest. Recovery records only an absent slug (`supersede: false`), since a
 * replayed older candidate must never displace a newer version.
 *
 * @param {{replayRoot: string|undefined, slug: string, projectedSource: string, supersede?: boolean}} input
 * @returns {{recorded: boolean, reason?: string, superseded?: string}}
 */
export function recordPublishedPost({ replayRoot, slug, projectedSource, supersede = true }) {
  if (typeof replayRoot !== "string" || replayRoot === "") return Object.freeze({ recorded: false, reason: "no replayRoot" });
  try {
    const dir = publishedLedgerDir(replayRoot);
    mkdirSync(dir, { recursive: true, mode: 0o700 });
    const path = join(dir, `${slug}.md`);
    if (existsSync(path)) {
      const current = readFileSync(path, "utf8");
      if (current === projectedSource || !supersede) return Object.freeze({ recorded: false, reason: "already-recorded" });
      const versions = publishedVersionsDir(replayRoot, slug);
      mkdirSync(versions, { recursive: true, mode: 0o700 });
      const superseded = sha256Hex(Buffer.from(current, "utf8"));
      writeFileSync(join(versions, `${superseded}.md`), current, { mode: 0o600 });
      fsyncDirectory(versions);
      const staging = join(dir, `.${slug}.md.${process.pid}`);
      const descriptor = openSync(staging, "w", 0o600);
      try { writeFileSync(descriptor, projectedSource, "utf8"); fsyncSync(descriptor); }
      finally { closeSync(descriptor); }
      renameSync(staging, path);
      fsyncDirectory(dir);
      return Object.freeze({ recorded: true, superseded });
    }
    let descriptor;
    try { descriptor = openSync(path, "wx", 0o600); }
    catch (error) { if (error?.code === "EEXIST") return Object.freeze({ recorded: false, reason: "already-recorded" }); throw error; }
    try { writeFileSync(descriptor, projectedSource, "utf8"); fsyncSync(descriptor); }
    finally { closeSync(descriptor); }
    fsyncDirectory(dir);
    return Object.freeze({ recorded: true });
  } catch (error) {
    return Object.freeze({ recorded: false, reason: error instanceof Error ? error.message : String(error) });
  }
}
function persistCandidateTree(path) {
  const stat = lstatSync(path);
  if (stat.isSymbolicLink()) throw new Error(`candidate persistence refuses a symlink: ${path}`);
  if (stat.isFile()) {
    const descriptor = openSync(path, "r");
    try { fsyncSync(descriptor); }
    finally { closeSync(descriptor); }
    return;
  }
  if (!stat.isDirectory()) throw new Error(`candidate persistence requires a regular file or directory: ${path}`);
  for (const entry of readdirSync(path, { withFileTypes: true }).sort(bytewiseNameOrder)) persistCandidateTree(join(path, entry.name));
  fsyncDirectory(path);
}
export function replaceDraftFlag(source, file) {
  const lines = source.replace(/\r\n?/gu, "\n").split("\n");
  const close = lines.indexOf("---", 1);
  if (lines[0] !== "---" || close < 0) throw new Error(`${file}: cannot project malformed front matter`);
  let found = false;
  for (let index = 1; index < close; index += 1) {
    if (/^draft:\s*true\s*$/u.test(lines[index])) { lines[index] = "draft: false"; found = true; }
  }
  if (!found) throw new Error(`${file}: admitted routine publication requires draft: true`);
  return lines.join("\n");
}
function corpusDigest(files) {
  const hash = createHash("sha256");
  for (const file of files) hash.update(file.relative).update("\0").update(file.sha256).update("\0");
  return `sha256:${hash.digest("hex")}`;
}
function inspectFiles(root, label) {
  const rootStat = lstatSync(root);
  if (rootStat.isSymbolicLink() || !rootStat.isDirectory()) throw new Error(`${label} root must be a real directory: ${root}`);
  const files = [];
  function visit(directory, prefix = "") {
    for (const entry of readdirSync(directory, { withFileTypes: true }).sort(bytewiseNameOrder)) {
      const relativePath = prefix === "" ? entry.name : join(prefix, entry.name);
      const path = join(directory, entry.name);
      const stat = lstatSync(path);
      if (stat.isSymbolicLink()) throw new Error(`${label} contains a symlink: ${relativePath}`);
      if (stat.isDirectory()) { visit(path, relativePath); continue; }
      if (!stat.isFile()) throw new Error(`${label} contains a non-regular file: ${relativePath}`);
      const bytes = readFileSync(path);
      files.push(Object.freeze({ relative: relativePath.split(sep).join("/"), path, sha256: sha256Digest(bytes) }));
    }
  }
  visit(root);
  return Object.freeze(files);
}
function inspectCorpus(contentDir, draftPath) {
  const root = resolve(contentDir);
  const draft = resolve(draftPath);
  const draftRelative = relative(root, draft);
  if (draftRelative === "" || draftRelative === ".." || draftRelative.startsWith(`..${sep}`)) throw new Error(`draft must be strictly inside content corpus root: ${root}`);
  if (dirname(draftRelative) !== ".") throw new Error(`draft must be a direct Markdown file in the static-delivery content root: ${draftRelative}`);
  const files = inspectFiles(root, "content corpus");
  if (!files.some((file) => file.path === draft)) throw new Error(`draft is not an ordinary corpus member: ${draft}`);
  return Object.freeze({ root, draftRelative: draftRelative.split(sep).join("/"), files, sha256: corpusDigest(files), fileCount: files.length });
}
function inspectPropertyCorpus(propertyContentDir) {
  if (typeof propertyContentDir !== "string" || !propertyContentDir) throw new Error("propertyContentDir is required");
  const root = resolve(propertyContentDir);
  const files = inspectFiles(root, "property content corpus");
  return Object.freeze({ root, files, sha256: corpusDigest(files), fileCount: files.length });
}
function copyCorpus(corpus, destination) {
  for (const file of corpus.files) {
    const target = join(destination, file.relative);
    mkdirSync(dirname(target), { recursive: true });
    const bytes = readFileSync(file.path);
    if (sha256Digest(bytes) !== file.sha256) throw new Error(`content corpus changed during candidate formation: ${file.relative}`);
    writeFileSync(target, bytes, { mode: 0o600 });
  }
}
export function validateAdmission({ draftPath, admissionPath, corpus }) {
  const absoluteDraft = resolve(draftPath);
  const absoluteAdmission = resolve(admissionPath);
  const source = readFileSync(absoluteDraft, "utf8");
  const file = basename(absoluteDraft);
  const draft = parsePost(source, file);
  if (!draft.draft) throw new Error(`${file}: routine publication accepts an editorially-admitted draft only (draft: true required)`);
  const admission = readJson(absoluteAdmission, "admission");
  if (!isRecord(admission)) throw new Error("admission must be a JSON object");
  const expected = sha256Digest(source);
  const required = [
    ["slug", draft.slug],
    ["manuscriptDigest", expected],
    ["disposition", "accept"],
    ["publishable", true],
    ["serviceAccepted", true],
    ["contract", EDITORIAL_CONTRACT],
    ["selectedTool", "submit_editorial_acceptance"],
    ["toolSelectionValidated", true],
  ];
  for (const [field, value] of required) if (admission[field] !== value) throw new Error(`admission does not prove ${field}=${JSON.stringify(value)}`);
  if (typeof admission.toolSelectionDigest !== "string" || admission.toolSelectionDigest.trim() === "") throw new Error("admission does not prove a validated tool-selection digest");
  return Object.freeze({ draft, source, sourceDigest: expected, draftPath: absoluteDraft, admission, admissionPath: absoluteAdmission, admissionDigest: sha256Digest(readFileSync(absoluteAdmission)), corpus });
}
function validateAuthority({ admission, authorityGrantPath, authorityKeysPath, assessmentReceiptPath, assessmentKeysPath, authorityNow }) {
  if (![authorityGrantPath, authorityKeysPath, authorityNow].every((value) => typeof value === "string" && value !== "")) throw new Error("authorityGrantPath, authorityKeysPath, and authorityNow are required");
  const grantSource = readFileSync(resolve(authorityGrantPath), "utf8");
  const authorityKeys = readJson(resolve(authorityKeysPath), "authority key map");
  const assessmentReceiptSource = assessmentReceiptPath === undefined ? undefined : readFileSync(resolve(assessmentReceiptPath), "utf8");
  const assessmentKeys = assessmentKeysPath === undefined ? undefined : readJson(resolve(assessmentKeysPath), "assessment key map");
  const verified = verifyPublicationAuthority({ grantSource, authorityKeys, manuscriptSource: admission.source, manuscriptSlug: admission.draft.slug, assessmentReceiptSource, assessmentKeys, now: authorityNow });
  return Object.freeze({ ...verified, grantPath: resolve(authorityGrantPath), keyMapPath: resolve(authorityKeysPath), assessmentReceiptPath: assessmentReceiptPath === undefined ? null : resolve(assessmentReceiptPath), assessmentKeyMapPath: assessmentKeysPath === undefined ? null : resolve(assessmentKeysPath), verifiedAt: authorityNow });
}
/** Read the existing authority receipt without creating or repairing custody. */
function hasConsumedPublication(replayRoot,consumptionId,receiptSha256) {
  if(typeof replayRoot!=="string"||!replayRoot)throw new TypeError("publication replay root is required");
  const root=resolve(replayRoot),consumed=join(root,"consumed");
  const path=join(consumed,`${sha256Digest(consumptionId).slice("sha256:".length)}.json`);
  if(!existsSync(path))return false;
  for(const directory of [root,consumed])if(lstatSync(directory).isSymbolicLink()||!lstatSync(directory).isDirectory())throw new Error("authority consumption custody must be a real directory");
  if(lstatSync(path).isSymbolicLink()||!lstatSync(path).isFile())throw new Error("authority consumption must be a regular file");
  const record=readJson(path,"authority consumption record");
  return isRecord(record)&&record.kind==="koios.news.routine-publication-authority-consumption/v1"&&record.consumptionId===consumptionId&&record.receiptSha256===receiptSha256;
}

export function createFileReplayStore(replayRoot) {
  if (typeof replayRoot !== "string" || replayRoot === "") throw new Error("replayRoot is required for offline candidate formation");
  const root = resolve(replayRoot);
  if (root === resolve("/") || root === resolve(process.cwd())) throw new Error(`refusing broad replay root: ${root}`);
  if (existsSync(root) && (lstatSync(root).isSymbolicLink() || !lstatSync(root).isDirectory())) throw new Error(`replay root must be a real directory: ${root}`);
  const parent = dirname(root);
  if (!existsSync(parent) || lstatSync(parent).isSymbolicLink() || !lstatSync(parent).isDirectory()) throw new Error(`replay root parent must be an existing real directory: ${parent}`);
  mkdirSync(root, { recursive: true, mode: 0o700 });
  const consumed = join(root, "consumed"); mkdirSync(consumed, { recursive: true, mode: 0o700 });
  // If either directory was just created, make its name durable before it is
  // trusted as the one-use authority ledger.
  fsyncDirectory(parent);
  fsyncDirectory(root);
  function consumptionPath(consumptionId) { return join(consumed, `${sha256Digest(consumptionId).slice("sha256:".length)}.json`); }
  return Object.freeze({ consumeIfUnused(consumptionId, receiptSha256) {
    if (typeof receiptSha256 !== "string" || !/^sha256:[a-f0-9]{64}$/u.test(receiptSha256)) throw new Error("authority consumption requires the exact staged receipt digest");
    const path = consumptionPath(consumptionId);
    let descriptor;
    try { descriptor = openSync(path, "wx", 0o600); }
    catch (error) { if (error?.code === "EEXIST") return false; throw error; }
    try { writeFileSync(descriptor, `${JSON.stringify({ kind: "koios.news.routine-publication-authority-consumption/v1", consumptionId, receiptSha256, consumedAt: new Date().toISOString() })}\n`, { encoding: "utf8" }); fsyncSync(descriptor); }
    finally { closeSync(descriptor); }
    // fsyncing the file alone does not make its newly created directory entry
    // durable.  A power loss must not turn a consumed publication authority
    // back into an apparently unused one.
    fsyncDirectory(consumed);
    return true;
  }, hasConsumed(consumptionId, receiptSha256) {
    return hasConsumedPublication(root,consumptionId,receiptSha256);
  } });
}
function consumeAuthority({ admission, authorityGrantPath, authorityKeysPath, assessmentReceiptPath, assessmentKeysPath, authorityNow, replayStore, replayRoot, receiptSha256 }) {
  const store = replayStore ?? createFileReplayStore(replayRoot);
  const receiptBoundStore = Object.freeze({ consumeIfUnused(consumptionId) { return store.consumeIfUnused(consumptionId, receiptSha256); } });
  return consumePublicationAuthority({ replayStore: receiptBoundStore, grantSource: readFileSync(resolve(authorityGrantPath), "utf8"), authorityKeys: readJson(resolve(authorityKeysPath), "authority key map"), manuscriptSource: admission.source, manuscriptSlug: admission.draft.slug, assessmentReceiptSource: assessmentReceiptPath === undefined ? undefined : readFileSync(resolve(assessmentReceiptPath), "utf8"), assessmentKeys: assessmentKeysPath === undefined ? undefined : readJson(resolve(assessmentKeysPath), "assessment key map"), now: authorityNow });
}

/** Read an already-consumed candidate's exact publication source binding.
 * The consumed receipt, not the slug's mutable current ledger entry, names
 * the version whose public receiving may be credited. This grants no new
 * authority and never recovers, rebuilds or republishes the candidate.
 */
export function consumedPublicationSource({outputDir,replayRoot,consumptionId}) {
  if(typeof outputDir!=="string"||!outputDir||typeof consumptionId!=="string"||!consumptionId)throw new TypeError("publication receiving requires the edition's candidate and consumption identity");
  const root=resolve(outputDir),path=join(root,"routine-publication-receipt.json");
  if(lstatSync(root).isSymbolicLink()||!lstatSync(root).isDirectory()||!existsSync(join(root,MARKER)))throw new Error("publication receiving candidate is not a marked directory");
  if(lstatSync(path).isSymbolicLink()||!lstatSync(path).isFile())throw new Error("publication receiving receipt is not a regular file");
  const source=readFileSync(path),receipt=JSON.parse(source),receiptSha256=sha256Digest(source);
  if(receipt?.kind!=="koios.news.routine-publication-receipt/v1"||receipt.disposition!=="offline-news-property-candidate"||receipt.authority?.consumptionId!==consumptionId||typeof receipt.slug!=="string"||!/^sha256:[a-f0-9]{64}$/u.test(receipt.provenance?.projectedSha256??""))throw new Error("publication receiving receipt does not bind this consumed edition");
  if(!hasConsumedPublication(replayRoot,consumptionId,receiptSha256))throw new Error("publication receiving lacks matching durable authority consumption");
  return Object.freeze({slug:receipt.slug,projectedSha256:receipt.provenance.projectedSha256,consumptionId,receiptSha256});
}
function runtimeReport() {
  const [major = 0, minor = 0] = process.versions.node.split(".").map(Number);
  if (major < 22 || major === 22 && minor < 18) throw new Error(`Node >=22.18 is required for routine candidate formation; found ${process.versions.node}`);
  return Object.freeze({ executionMode: "offline-news-property-candidate", nodeVersion: process.versions.node, providerInvocations: 0 });
}
function prepareOutput(outputDir, replace) {
  const target = resolve(outputDir);
  if (target === resolve("/") || target === resolve(process.cwd())) throw new Error(`refusing broad output target: ${target}`);
  const staging = `${target}.next`;
  if (existsSync(staging)) {
    if (!existsSync(join(staging, MARKER))) throw new Error(`refusing unmarked staging directory: ${staging}`);
    throw new Error(`candidate recovery staging exists; recover it before starting another publication: ${staging}`);
  }
  if (existsSync(target)) {
    if (!replace) throw new Error(`candidate output exists; use --replace only for a marked prior candidate: ${target}`);
    if (!existsSync(join(target, MARKER))) throw new Error(`refusing to replace unmarked candidate output: ${target}`);
  }
  mkdirSync(staging, { recursive: true });
  writeFileSync(join(staging, MARKER), "koios.news routine-publication-current v1\n");
  return { target, staging };
}
function safeCandidatePath(root, path) {
  const candidate = resolve(root, path);
  const rel = relative(root, candidate);
  if (rel === "" || rel === ".." || rel.startsWith(`..${sep}`)) throw new Error(`candidate path escaped output: ${path}`);
  return candidate;
}
function sealedArtifactPath(file) {
  if (typeof file !== "string" || file === "" || file.includes("\\") || file.startsWith("/") || file.split("/").some((part) => part === "" || part === "." || part === ".." || part.startsWith("."))) throw new Error(`recovery static carrier has an unsafe artifact path: ${String(file)}`);
  if (file === "manifest.json") throw new Error("recovery static carrier manifest must not list itself as an artifact");
  return file;
}
function regularSealedArtifact(root, file) {
  let cursor = root;
  for (const part of file.split("/")) {
    cursor = join(cursor, part);
    if (!existsSync(cursor) || lstatSync(cursor).isSymbolicLink()) throw new Error(`recovery static carrier artifact is missing or traverses a symlink: ${file}`);
  }
  if (!lstatSync(cursor).isFile()) throw new Error(`recovery static carrier artifact is not a regular file: ${file}`);
  return cursor;
}
function inspectSealedPublicCarrier(publicDir) {
  const manifestPath = safeCandidatePath(publicDir, "manifest.json");
  if (!existsSync(manifestPath) || lstatSync(manifestPath).isSymbolicLink() || !lstatSync(manifestPath).isFile()) throw new Error("recovery static carrier has no regular manifest.json");
  const manifestBytes = readFileSync(manifestPath);
  const manifest = readJson(manifestPath, "recovery static carrier manifest");
  if (!isRecord(manifest) || manifest.kind !== "news-property.build-manifest/v1" || !Array.isArray(manifest.artifacts)) throw new Error("recovery news-property carrier manifest has an unsupported shape");
  const declared = new Set();
  for (const artifact of manifest.artifacts) {
    if (!isRecord(artifact) || Object.keys(artifact).length !== 3 || !["file", "sha256", "bytes"].every((field) => Object.hasOwn(artifact, field))) throw new Error("recovery static carrier manifest has an invalid artifact");
    const file = sealedArtifactPath(artifact.file);
    if (declared.has(file)) throw new Error(`recovery static carrier manifest has a duplicate artifact: ${file}`);
    if (!/^[a-f0-9]{64}$/u.test(artifact.sha256) || !Number.isSafeInteger(artifact.bytes) || artifact.bytes < 0) throw new Error(`recovery static carrier manifest has invalid digest metadata: ${file}`);
    const bytes = readFileSync(regularSealedArtifact(publicDir, file));
    if (bytes.length !== artifact.bytes || sha256Digest(bytes) !== `sha256:${artifact.sha256}`) throw new Error(`recovery static carrier artifact digest mismatch: ${file}`);
    declared.add(file);
  }
  const actual = new Set();
  function visit(directory, prefix = "") {
    for (const entry of readdirSync(directory, { withFileTypes: true }).sort(bytewiseNameOrder)) {
      const file = prefix === "" ? entry.name : `${prefix}/${entry.name}`;
      const path = join(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error(`recovery static carrier contains a symlink: ${file}`);
      if (entry.isDirectory()) { visit(path, file); continue; }
      if (!entry.isFile()) throw new Error(`recovery static carrier contains an unsupported entry: ${file}`);
      if (file !== "manifest.json") actual.add(file);
    }
  }
  visit(publicDir);
  if (actual.size !== declared.size || [...actual].some((file) => !declared.has(file))) throw new Error("recovery static carrier contains an unsealed artifact");
  return Object.freeze({ manifestSha256: sha256Digest(manifestBytes), artifactCount: declared.size });
}
function readRecoveryReceipt(candidateRoot) {
  if (lstatSync(candidateRoot).isSymbolicLink() || !lstatSync(candidateRoot).isDirectory()) throw new Error(`recovery candidate must be a real directory: ${candidateRoot}`);
  if (!existsSync(join(candidateRoot, MARKER))) throw new Error(`recovery candidate is not marked: ${candidateRoot}`);
  const receipt = readJson(safeCandidatePath(candidateRoot, "routine-publication-receipt.json"), "routine publication receipt");
  if (!isRecord(receipt) || receipt.kind !== "koios.news.routine-publication-receipt/v1" || receipt.disposition !== "offline-news-property-candidate" || !isRecord(receipt.authority) || typeof receipt.authority.consumptionId !== "string" || receipt.authority.consumptionId === "") throw new Error(`recovery candidate has no valid authority consumption coordinate: ${candidateRoot}`);
  const publicDir = safeCandidatePath(candidateRoot, "public");
  if (!existsSync(publicDir) || lstatSync(publicDir).isSymbolicLink() || !lstatSync(publicDir).isDirectory()) throw new Error(`recovery candidate has no real public carrier: ${candidateRoot}`);
  if (!isRecord(receipt.newsProperty) || typeof receipt.newsProperty.manifestSha256 !== "string" || !/^sha256:[a-f0-9]{64}$/u.test(receipt.newsProperty.manifestSha256) || !Number.isSafeInteger(receipt.newsProperty.artifactCount) || receipt.newsProperty.artifactCount < 0) throw new Error(`recovery candidate has no sealed public-carrier binding: ${candidateRoot}`);
  const seal = inspectSealedPublicCarrier(publicDir);
  if (seal.manifestSha256 !== receipt.newsProperty.manifestSha256 || seal.artifactCount !== receipt.newsProperty.artifactCount) throw new Error(`recovery candidate public carrier does not match its sealed receipt: ${candidateRoot}`);
  return Object.freeze({ receipt, consumptionId: receipt.authority.consumptionId });
}
function finalizeCandidate({ target, staging, persistPublishedParent, renameCandidate = renameSync }) {
  if (existsSync(target)) {
    if (!existsSync(join(target, MARKER))) throw new Error(`refusing to replace unmarked candidate output: ${target}`);
    rmSync(target, { recursive: true });
  }
  renameCandidate(staging, target);
  persistPublishedParent(dirname(target));
}
export function recoverRoutinePublication({ outputDir, replayRoot, persistCandidate = persistCandidateTree, persistPublishedParent = fsyncDirectory, renameCandidate = renameSync }) {
  if (typeof outputDir !== "string" || outputDir === "") throw new Error("outputDir is required for candidate recovery");
  const target = resolve(outputDir);
  if (target === resolve("/") || target === resolve(process.cwd())) throw new Error(`refusing broad output target: ${target}`);
  const staging = `${target}.next`;
  const candidate = existsSync(staging) ? staging : target;
  if (!existsSync(candidate)) throw new Error(`no staged or finalized candidate is available for recovery: ${target}`);
  const recovery = readRecoveryReceipt(candidate);
  const receiptSha256 = sha256Digest(readFileSync(join(candidate, "routine-publication-receipt.json")));
  const store = createFileReplayStore(replayRoot);
  if (!store.hasConsumed(recovery.consumptionId, receiptSha256)) throw new Error("recovery candidate has no matching durable authority consumption record");
  // A retained candidate is re-persisted before it becomes visible; recovery
  // only finalizes the already-consumed coordinate and never verifies or reuses authority.
  persistCandidate(candidate);
  if (candidate === staging) finalizeCandidate({ target, staging, persistPublishedParent, renameCandidate });
  else persistPublishedParent(dirname(target));
  // Recovery finalizes an already-consumed candidate; a first attempt that
  // failed after finalizeCandidate but before recordPublishedPost would
  // otherwise permanently miss its ledger entry. Reconstruct the exact
  // projected bytes from the still-unmutated tracked corpus and the
  // receipt's own bound digests, rather than trusting anything new.
  let publishedLedger;
  try {
    const { sourcePath, sourceSha256, projectedSha256 } = recovery.receipt.provenance;
    const current = readFileSync(sourcePath, "utf8");
    if (sha256Digest(current) !== sourceSha256) throw new Error(`recovery corpus source changed since candidate formation: ${sourcePath}`);
    const reconstructed = replaceDraftFlag(current, basename(sourcePath));
    if (sha256Digest(reconstructed) !== projectedSha256) throw new Error(`recovery corpus draft promotion produced unexpected bytes: ${sourcePath}`);
    publishedLedger = recordPublishedPost({ replayRoot, slug: recovery.receipt.slug, projectedSource: reconstructed, supersede: false });
  } catch (error) {
    publishedLedger = Object.freeze({ recorded: false, reason: error instanceof Error ? error.message : String(error) });
  }
  return Object.freeze({ disposition: "recovered", outputDir: target, slug: recovery.receipt.slug, consumptionId: recovery.consumptionId, receiptSha256, publishedLedger });
}
function normalizeCandidateManifest(candidateRoot, { projectedCorpusSha256, candidateCorpusSha256, propertyRecordSha256 }) {
  // Bind the deterministic routine projection without exposing its temporary
  // filesystem coordinate in the public carrier manifest.
  const path = safeCandidatePath(candidateRoot, "manifest.json");
  const manifest = readJson(path, "news-property carrier manifest");
  if (!isRecord(manifest) || manifest.kind !== "news-property.build-manifest/v1" || !isRecord(manifest.provenance)) throw new Error("news-property produced an invalid manifest");
  manifest.provenance.projectedCorpusSha256 = projectedCorpusSha256;
  manifest.provenance.candidateCorpusSha256 = candidateCorpusSha256;
  manifest.provenance.propertyRecordSha256 = propertyRecordSha256;
  writeFileSync(path, `${JSON.stringify(manifest, null, 2)}\n`);
}
function normalizeIssueProvenance(value) {
  if (value === undefined) return undefined;
  if (!isRecord(value) || typeof value.issueDigest !== "string" || !/^sha256:[a-f0-9]{64}$/u.test(value.issueDigest) || typeof value.manuscriptEvidenceDigest !== "string" || !/^sha256:[a-f0-9]{64}$/u.test(value.manuscriptEvidenceDigest)) throw new Error("issue provenance must carry exact formation and manuscript-evidence digests");
  return Object.freeze({ issueFormationSha256: value.issueDigest, manuscriptEvidenceSha256: value.manuscriptEvidenceDigest,
    ...(value.editorialTreatment ? {editorialTreatmentDigest:value.editorialTreatment.selectionDigest,
      editorialCommissionDigest:value.editorialTreatment.authenticatedCommissionDigest,
      character:value.editorialTreatment.characterId} : {}) });
}
function prepareRoutinePublication({ property, propertyContentDir, contentDir, draftPath, admissionPath, outputDir, authorityGrantPath, authorityKeysPath, assessmentReceiptPath, assessmentKeysPath, authorityNow, issueProvenance }) {
  if (!isRecord(property) || typeof property.name !== "string" || typeof property.origin !== "string") throw new Error("property record is required");
  if (![contentDir, draftPath, admissionPath, outputDir].every((value) => typeof value === "string" && value !== "")) throw new Error("contentDir, draftPath, admissionPath, and outputDir are required");
  const corpus = inspectCorpus(contentDir, draftPath);
  const propertyCorpus = inspectPropertyCorpus(propertyContentDir);
  const admission = validateAdmission({ draftPath, admissionPath, corpus });
  // A short editorial product never bypasses the original signed exact-manuscript
  // acceptance. The trusted newsroom must supply its source-qualified treatment,
  // and that selection must be exactly present in the admitted article bytes.
  const treatment=issueProvenance?.editorialTreatment??null;
  let chosenProduct;
  if(treatment!==null){
    const subdesk=editorialCatalog.subdesks?.[treatment.subdeskId];
    if(property.name!=="Koios.News"||treatment.kind!=="editorial-treatment/v1"
      ||treatment.formatId!=="text-report"||!subdesk
      ||subdesk.parentDesk!==admission.draft.section
      ||subdesk.office!==treatment.officeId
      ||!subdesk.crew?.includes(treatment.characterId)
      ||!subdesk.allowedProducts?.includes(treatment.productId)
      ||!subdesk.registers?.includes(treatment.registerId)
      ||treatment.agencyCandidate?.state!=="candidate"
      ||treatment.agencyCandidate?.admitted!==false
      ||treatment.agencyCandidate?.executed!==false
      ||!treatment.authenticatedCommissionDigest||!treatment.selectionDigest)
      throw new Error("Publication has no source-qualified specialist office, genre, register and exact commission");
    chosenProduct=editorialProductFor(property,{section:admission.draft.section,profile:treatment.productId});
    if(JSON.stringify(chosenProduct)!==JSON.stringify(treatment.editorialProduct))
      throw new Error("Publication selected product differs from canonical evidence law");
    const match=/^---\r?\n([\s\S]*?)\r?\n---/u.exec(admission.source);
    if(!match)throw new Error("Specialist publication lacks exact signed front matter");
    const fields=match[1].split(/\r?\n/u);
    for(const [key,value] of [
      ['editorialProductProfile',treatment.productId],['koiosCharacter',treatment.characterId],
      ['koiosRegister',treatment.registerId],['koiosTreatmentDigest',treatment.selectionDigest],
      ['koiosCommissionDigest',treatment.authenticatedCommissionDigest],
      ['author',treatment.character.byline]]){
      const observed=key+': '+JSON.stringify(value);
      if(fields.filter(line=>line===observed).length!==1)
        throw new Error("Specialist publication source lacks bound "+key+" field");
    }
  }
  if(property.name==="Koios.News"){
    const shallow=articleQuality(admission.source,{property,section:admission.draft.section,editorialProduct:chosenProduct});
    if(shallow.failures.includes("insufficient-reporting-depth")||shallow.failures.includes("missing-context-sections"))throw new Error(`Publication requires complete reporting: ${shallow.words} body words, ${shallow.sections} contextual sections`);
    if(typeof issueProvenance?.manuscriptEvidencePath!=="string")throw new Error("Publication requires exact bound manuscript evidence for article-depth admission");
    const evidenceSource=readFileSync(issueProvenance.manuscriptEvidencePath,"utf8");
    if(sha256Digest(evidenceSource)!==issueProvenance.manuscriptEvidenceDigest)throw new Error("Article-depth evidence digest does not match issue provenance");
    const evidence=JSON.parse(evidenceSource);verifyManuscriptEvidence(evidence,admission.draft.body);
    const quality=articleQuality(admission.source,{candidate:evidence.candidate.content,claims:evidence.claims,property,section:admission.draft.section,editorialProduct:chosenProduct});
    if(!quality.ok)throw new Error(`Publication requires complete reporting: ${quality.failures.join(", ")}`);
  }
  const authority = validateAuthority({ admission, authorityGrantPath, authorityKeysPath, assessmentReceiptPath, assessmentKeysPath, authorityNow });
  const runtime = runtimeReport();
  const projected = replaceDraftFlag(admission.source, basename(admission.draftPath));
  parsePost(projected, basename(admission.draftPath));
  const projectedCorpusSha256 = corpusDigest(corpus.files.map((file) => file.relative === corpus.draftRelative ? Object.freeze({ ...file, sha256: sha256Digest(projected) }) : file));
  return Object.freeze({ property, propertyCorpus, propertyRecordSha256: sha256Digest(JSON.stringify(property)), admission, authority, runtime, projected, projectedCorpusSha256, issueProvenance: normalizeIssueProvenance(issueProvenance) });
}
function publicationPlan({ outputDir, prepared }) {
  const { property, propertyCorpus, propertyRecordSha256, admission, authority, runtime, projected, projectedCorpusSha256, issueProvenance } = prepared;
  return Object.freeze({
    disposition: "ready",
    executionMode: "dry-run",
    authority: "authenticated-editorial-publication-grant",
    effects: Object.freeze([]),
    candidate: Object.freeze({ outputDir: resolve(outputDir), publicDir: join(resolve(outputDir), "public"), slug: admission.draft.slug, sourceSha256: admission.sourceDigest, projectedSha256: sha256Digest(projected), admissionSha256: admission.admissionDigest, corpusSha256: admission.corpus.sha256, projectedCorpusSha256, corpusFileCount: admission.corpus.fileCount, propertyOrigin: property.origin, propertyRecordSha256, propertyCorpusSha256: propertyCorpus.sha256 }),
    provenance: Object.freeze({ contentDir: admission.corpus.root, draftPath: admission.draftPath, admissionPath: admission.admissionPath, editorialContract: EDITORIAL_CONTRACT, ...(issueProvenance === undefined ? {} : { issueFormation: issueProvenance }), authority: Object.freeze({ scope: authority.scope, grantId: authority.grantId, grantDigest: authority.grantDigest, issuedAt: authority.issuedAt, expiresAt: authority.expiresAt, manuscriptDigest: authority.manuscriptDigest, assessmentReceiptDigest: authority.assessmentReceiptDigest ?? null, verifiedAt: authority.verifiedAt }), runtime }),
    blockers: Object.freeze(["This authenticated authority permits only offline candidate formation. It creates no live publication, ScheduleDelivery receipt, ActivityPub activity, or Cloudflare deployment."]),
  });
}
export function planRoutinePublication(input) {
  return publicationPlan({ outputDir: input.outputDir, prepared: prepareRoutinePublication(input) });
}
export function writeRoutinePublication({ property, propertyContentDir, claimStoreDir, sourceFeedsPath, contentDir, draftPath, admissionPath, outputDir, authorityGrantPath, authorityKeysPath, assessmentReceiptPath, assessmentKeysPath, authorityNow, issueProvenance, replayRoot, replayStore, replace = false, persistCandidate = persistCandidateTree, persistPublishedParent = fsyncDirectory, renameCandidate = renameSync }) {
  const prepared = prepareRoutinePublication({ property, propertyContentDir, contentDir, draftPath, admissionPath, outputDir, authorityGrantPath, authorityKeysPath, assessmentReceiptPath, assessmentKeysPath, authorityNow, issueProvenance });
  const plan = publicationPlan({ outputDir, prepared });
  const { propertyCorpus, admission, projected, projectedCorpusSha256, issueProvenance: receiptIssueProvenance } = prepared;
  const { target, staging } = prepareOutput(outputDir, replace);
  const work = mkdtempSync(join(tmpdir(), "koios-routine-publication-"));
  let buildPublishedLedger;
  let authorityConsumed = false;
  try {
    const postsDirectory = property.content?.postsDirectory ?? "posts";
    const postsWork = resolve(work, postsDirectory);
    const postsRelative = relative(work, postsWork);
    if (postsRelative === ".." || postsRelative.startsWith(`..${sep}`)) throw new Error("property posts directory escapes candidate work root");
    copyCorpus(propertyCorpus, work);
    mkdirSync(postsWork, { recursive: true });
    const projectedPath = join(postsWork, admission.corpus.draftRelative);
    if (existsSync(projectedPath) && readFileSync(projectedPath, "utf8") !== admission.source) throw new Error("property corpus has a different article at the admitted slug");
    writeFileSync(projectedPath, projected);
    // Every previously routine-published post lives only in this durable
    // ledger (the tracked corpus itself is never mutated); seed it into the
    // working corpus so this candidate's own discovery surfaces regenerate
    // with every post ever published, not only this one.
    const publishedLedger = mergePublishedLedgerIntoWork({ work: postsWork, replayRoot, admitted: admission.corpus.draftRelative });
    buildPublishedLedger = createBuildPublishedLedger({ replayRoot, admitted: admission.corpus.draftRelative, projectedSource: projected });
    const candidateCorpusSha256 = corpusDigest(inspectFiles(work, "candidate content corpus"));
    const carrierOutput = join(work, "carrier");
    buildProperty({ property, contentDir: work, claimStoreDir, sourceFeedsPath, outputDir: carrierOutput, publishedPostsDir: buildPublishedLedger, asOf: new Date(authorityNow) });
    const publicOutput = join(staging, "public");
    cpSync(carrierOutput, publicOutput, { recursive: true });
    normalizeCandidateManifest(publicOutput, { projectedCorpusSha256, candidateCorpusSha256, propertyRecordSha256: prepared.propertyRecordSha256 });
    const sealedCarrier = inspectSealedPublicCarrier(publicOutput);
    const receipt = Object.freeze({ kind: "koios.news.routine-publication-receipt/v1", disposition: "offline-news-property-candidate", editorialContract: EDITORIAL_CONTRACT, slug: admission.draft.slug, authority: Object.freeze({ kind: "Ed25519", scope: prepared.authority.scope, grantId: prepared.authority.grantId, grantDigest: prepared.authority.grantDigest, issuedAt: prepared.authority.issuedAt, expiresAt: prepared.authority.expiresAt, manuscriptDigest: prepared.authority.manuscriptDigest, assessmentReceiptDigest: prepared.authority.assessmentReceiptDigest ?? null, verifiedAt: prepared.authority.verifiedAt, consumptionId: prepared.authority.consumptionId }), provenance: Object.freeze({ contentDir: admission.corpus.root, propertyOrigin: property.origin, propertyRecordSha256: prepared.propertyRecordSha256, propertyContentDir: propertyCorpus.root, propertyCorpusSha256: propertyCorpus.sha256, candidateCorpusSha256, corpusSha256: admission.corpus.sha256, projectedCorpusSha256, corpusFileCount: admission.corpus.fileCount, sourcePath: admission.draftPath, sourceSha256: admission.sourceDigest, admissionPath: admission.admissionPath, admissionSha256: admission.admissionDigest, ...(receiptIssueProvenance === undefined ? {} : { issueFormation: receiptIssueProvenance }), projectedSha256: sha256Digest(projected), transition: Object.freeze({ allowedChanges: Object.freeze(["draft"]), sourceDraft: true, candidateDraft: false, sourceMutated: false }), publishedLedger }), limitations: Object.freeze(["The authenticated editorial grant authorizes only this offline candidate; it is not a Cloudflare release grant or ScheduleDelivery acceptance.", "Candidate formation is offline only and grants no deployment or delivery authority."]), newsProperty: Object.freeze({ package: "@causeway-services/koios-news-site", output: "public/", manifestSha256: sealedCarrier.manifestSha256, artifactCount: sealedCarrier.artifactCount }) });
    const receiptText = `${JSON.stringify(receipt, null, 2)}\n`;
    const receiptSha256 = sha256Digest(receiptText);
    writeFileSync(safeCandidatePath(staging, "routine-publication-receipt.json"), receiptText);
    // Finish and persist every staged output before spending one-use editorial
    // authority.  Any persistence failure leaves that authority reusable.
    persistCandidate(staging);
    // Directories cannot be atomically replaced portably.  The complete next
    // candidate is staged first; only a marked prior target may then be removed
    // before this final rename.
    const consumption = consumeAuthority({ admission, authorityGrantPath, authorityKeysPath, assessmentReceiptPath, assessmentKeysPath, authorityNow, replayStore, replayRoot, receiptSha256 });
    authorityConsumed = true;
    // The target becomes visible through its parent directory entry.  Do not
    // report success until that entry is durable as well.
    finalizeCandidate({ target, staging, persistPublishedParent, renameCandidate });
    // The candidate is now durably visible and its authority spent; record
    // this post into the published-posts ledger so every future candidate's
    // build includes it too. A ledger-write failure here must not turn this
    // already-successful, already-consumed publication into a thrown error.
    const ledgerRecord = recordPublishedPost({ replayRoot, slug: admission.draft.slug, projectedSource: projected });
    return Object.freeze({ disposition: "written", outputDir: target, slug: admission.draft.slug, consumptionId: consumption.consumptionId, receiptSha256, plan, publishedLedger: ledgerRecord });
  } catch (error) {
    // Before consumption the staging tree is disposable. After consumption it
    // is the durable recovery artifact and must survive a publication-finalize
    // failure rather than destroying the only bytes paid for by the grant.
    if (!authorityConsumed && existsSync(staging)) rmSync(staging, { recursive: true, force: true });
    throw error;
  } finally {
    if (buildPublishedLedger && existsSync(buildPublishedLedger)) rmSync(buildPublishedLedger, { recursive: true, force: true });
    if (existsSync(work)) rmSync(work, { recursive: true, force: true });
  }
}
