/** Accepted newsroom editions and their research use the existing paid briefing. */
import { basename, join } from 'node:path';
import { readFileSync, statSync } from 'node:fs';
import { createR2RestClient, r2RestConfiguration } from "@red-cup-engineering/cloudflare-r2-services-section/r2-rest";
import { parsePost } from "@causeway-services/koios-news-site/build";
import { manuscriptEvidenceFromJournal, heldJournalCells } from "@red-cup-engineering/content-mill-newsroom-services-section/evidence";
import { claimEvidenceType, sourceEvidenceType } from "@red-cup-engineering/content-mill-newsroom-services-section/carriers";
import { createPaidBriefing, publishCurrentPaidBriefing } from "@causeway-services/koios-news-intelligence-briefing/paid-briefing";
import { readNewsroom } from './newsroom-records.mjs';
import { advanceEdition, editions } from './news-line/editions.mjs';

const boundedText = path => { const meta = statSync(path); if (!meta.isFile() || meta.size > 1048576) throw new RangeError('publication source must be a regular file <= 1 MiB'); return readFileSync(path, 'utf8'); };
/** Exact released prose, plus its already-verified public observations. */
export function researchBriefingForEdition(context, edition, assignments) {
  if (edition.state !== 'released' || !edition.releaseManifest || !edition.receiptPath) throw new TypeError('research product requires a released assessed edition');
  const assignment = assignments.find(record => record.storyId === edition.storyId && record.section === edition.section);
  if (!assignment) return null;
  const claims = heldJournalCells(context.dataRoot, 'claim', claimEvidenceType), sources = heldJournalCells(context.dataRoot, 'source-evidence', sourceEvidenceType);
  if (assignment.claimEvidenceIds.some(id => !claims.has(id)) || assignment.sourceEvidenceIds.some(id => !sources.has(id))) throw new TypeError('research source or claim is opposed or missing');
  const path = join(context.roots.publication, 'published', basename(edition.draftPath));
  const post = parsePost(boundedText(path), basename(path));
  const evidence = manuscriptEvidenceFromJournal({ dataRoot: context.dataRoot, candidateId: edition.candidateId, manuscriptBody: post.body });
  const references = {};
  for (const source of [...assignment.packet.observations.map(row => ({ url: row.source, title: row.source })),
    ...evidence.sources.map(row => ({ url: row.content.finalUrl, title: row.content.finalUrl }))]) {
    references[source.url] = { id: source.url, type: 'webpage', title: source.title, URL: source.url };
  }
  const origin = context.property.origin;
  const url = new URL('/' + edition.slug + '/', origin).href;
  const receipt = JSON.parse(boundedText(edition.receiptPath));
  return createPaidBriefing({ id: 'koios-market-research:' + assignment.packet.id + ':' + edition.candidateId,
    issuedAt: edition.releasedAt, research: assignment.packet,
    publication: { url, candidateId: edition.candidateId, releaseManifest: edition.releaseManifest,
      assessmentReceipt: receipt.assessmentId },
    issue: { title: post.title, dek: post.dek ?? '', sections: [{ heading: post.title, 'body-markdown': post.body, sources: Object.keys(references) }], references } });
}

/** Bounded retry inside the existing release stage; no extra worker or scheduler. */
export async function publishReleasedMarketResearch(context, at, { publish } = {}) {
  const rows = readNewsroom(context.dataRoot, 'market-research');
  // A row carries `told` only when it is not plainly told for.
  const opposed = new Set(rows.filter(row => row.told !== undefined).map(row => row.record?.id));
  const assignments = [...new Map(rows.filter(row => row.told === undefined && !opposed.has(row.record?.id))
    .map(row => [row.record.id, row.record])).values()];
  if (!assignments.length) return { published: 0, obstructions: [] };
  if (assignments.length > 100) throw new RangeError('retain completed research runs before adding more assignments');
  const eligible = new Set(assignments.map(row => row.storyId));
  const pending = editions(context.roots, 'released').filter(edition => eligible.has(edition.storyId) && edition.marketResearchPublication?.status !== 'published')
    .sort((a, b) => a.releasedAt.localeCompare(b.releasedAt)).slice(0, 4);
  if (!pending.length) return { published: 0, obstructions: [] };
  const obstructions = []; let published = 0;
  for (const edition of pending) {
    try {
      const briefing = researchBriefingForEdition(context, edition, assignments);
      if (!briefing) continue;
      if (publish) await publish(briefing);
      else {
        const client = createR2RestClient(r2RestConfiguration({ ...context.environment, CLOUDFLARE_R2_BUCKET: 'koios-intelligence-briefings' }));
        await publishCurrentPaidBriefing(briefing, { KOIOS_INTELLIGENCE_BRIEFINGS: { put: (key, body, metadata) => client.putCurrent(key,
          { body: Buffer.from(body), mediaType: metadata.httpMetadata.contentType }) } });
      }
      advanceEdition(context.roots, edition, 'released', at, { marketResearchPublication: { status: 'published', id: briefing.id, packetId: briefing.research.id, at } });
      published++;
    } catch (error) {
      const reason = String(error.message).slice(0, 500); obstructions.push({ slug: edition.slug, reason });
      advanceEdition(context.roots, edition, 'released', at, { marketResearchPublication: { status: 'pending', at, reason } });
    }
  }
  return { published, obstructions };
}
