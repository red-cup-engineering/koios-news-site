import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,writeFileSync,symlinkSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';
import {observeNewsroomRuntime,unitFacts,maintenanceFacts,readFeedbackSnapshot,maintenanceJournalFacts} from '../scripts/observe-newsroom-runtime.mjs';

const at='2026-10-12T19:00:00.000Z',secret='PRIVATE-ERROR-PROVIDER-DRAFT-TOKEN';
const raw={kind:'koios.news.runtime-observation/v1',observedAt:at,status:{lastRun:at,next:'intake',stages:[],blockers:[],live:{}},private:secret};
const latest={kind:'koios.news.observed-feedback/v1',observedAt:at,sensors:{cloudMaintenance:{observedAt:at,reason:secret,unit:{Environment:secret},attempt:{kind:'koios.news.maintenance-attempt-outcome/v1',startedAt:at,finishedAt:at,exitCode:42,stdout:secret}}},articles:[{draft:secret}]};
const unit='LoadState=loaded\nActiveState=activating\nResult=success\nExecMainStatus=0\nExecMainStartTimestampMonotonic=1000000\nEnvironment='+secret;

test('the fixed observation reads exactly two units and two existing snapshots without mutation',()=>{
 const calls=[];
 const result=observeNewsroomRuntime({now:()=>at,uptime:()=>180,show:name=>{calls.push(['unit',name]);return unit;},read:name=>{calls.push(['snapshot',name]);return name==='newsroom.json'?raw:latest;}});
 assert.deepEqual(calls,[['unit','koios-newsroom.service'],['unit','koios-maintenance.service'],['snapshot','newsroom.json'],['snapshot','latest.json']]);
 assert.equal(result.kind,'koios.news.read-only-runtime-observation/v1');
 assert.equal(result.units['koios-newsroom.service'].processAgeSeconds,179);
 assert.equal(result.newsroom.status,'observed');assert.equal(result.newsroom.runtime.observedAt,at);
 assert.equal(result.maintenance.attempt.exitCode,42);assert.equal(result.maintenance.attempt.status,'failed');
 assert.equal(JSON.stringify(result).includes(secret),false);
 assert.equal(latest.sensors.cloudMaintenance.attempt.stdout,secret,'the held snapshot is not mutated');
});

test('missing and malformed evidence is retained as uncertainty with sanitized failures',()=>{
 const result=observeNewsroomRuntime({now:()=>at,uptime:()=>{throw Error(secret);},show:()=>{throw Error(secret);},read:name=>{throw name==='newsroom.json'?Object.assign(Error(secret),{code:'ENOENT'}):new SyntaxError(secret);}});
 assert.deepEqual(result.newsroom,{status:'unavailable',code:'ENOENT'});
 assert.deepEqual(result.maintenance,{status:'unavailable',code:'invalid-json'});
 assert.equal(JSON.stringify(result).includes(secret),false);
 assert.deepEqual(maintenanceFacts({}),{status:'unavailable',code:'invalid-feedback'});
 assert.equal(maintenanceFacts({...latest,sensors:{cloudMaintenance:{attempt:{...latest.sensors.cloudMaintenance.attempt,startedAt:'2026-02-30T19:00:00.000Z'}}}}).attempt,null);
});

test('unit values are closed vocabulary or bounded numeric facts, never command or error text',()=>{
 const facts=unitFacts('LoadState='+secret+'\nActiveState='+secret+'\nResult='+secret+'\nExecMainStatus=999\nExecMainStartTimestampMonotonic=-42',99);
 assert.deepEqual(facts,{LoadState:null,ActiveState:null,Result:null,ExecMainStatus:null,processAgeSeconds:null});
 assert.equal(unitFacts(unit,0).processAgeSeconds,null);
 assert.equal(unitFacts(unit,NaN).processAgeSeconds,null);
 assert.equal(maintenanceFacts({...latest,sensors:{cloudMaintenance:{attempt:{...latest.sensors.cloudMaintenance.attempt,exitCode:256}}}}).attempt,null);
});

test('a fresh observer does not freshen stale newsroom or maintenance facts',()=>{
 const result=observeNewsroomRuntime({now:()=> '2026-10-12T22:00:00.000Z',uptime:()=>180,show:()=>unit,read:name=>name==='newsroom.json'?raw:latest});
 assert.equal(result.newsroom.status,'unavailable');assert.match(result.newsroom.reason,/stale/);
 assert.equal(result.newsroom.runtime.observedAt,at);assert.equal(result.maintenance.snapshotObservedAt,at);
});

const workflow=readFileSync(new URL('../.github/workflows/editorial-feedback.yml',import.meta.url),'utf8');
const observe=workflow.slice(workflow.indexOf('  observe:'),workflow.indexOf('  wake:'));
const expression=observe.match(/if: >-\n\s*\$\{\{ (.+) \}\}/)?.[1];
const admitted=new Function('github','return ('+expression+');');
const owner={repository:'causeway-services/koios.news',event_name:'issue_comment',event:{action:'created',issue:{number:57},comment:{user:{login:'emsenn',type:'User'},author_association:'MEMBER',body:'/koios observe-runtime'}}};
const wakeExpression=workflow.slice(workflow.indexOf('  wake:')).match(/if: >-\n([\s\S]*?)\n    runs-on:/)?.[1].trim().slice(3,-3);
const wake=new Function('github','contains','return ('+wakeExpression+');');
const contains=(value,part)=>String(value??'').includes(part);

test('only the authenticated owner exact repository, issue and new command can observe',()=>{
 assert.equal(admitted(owner),true);
 for(const altered of [
  {...owner,repository:'other/repo'}, {...owner,event_name:'issues'},
  {...owner,event:{...owner.event,action:'edited'}},
  {...owner,event:{...owner.event,issue:{number:58}}},
  {...owner,event:{...owner.event,issue:{number:57,pull_request:{url:'https://example.invalid'}}}},
  {...owner,event:{...owner.event,comment:{...owner.event.comment,user:{login:'other'}}}},
  {...owner,event:{...owner.event,comment:{...owner.event.comment,author_association:'NONE'}}},
  {...owner,event:{...owner.event,comment:{...owner.event.comment,body:'/koios observe-runtime extra'}}},
 ]) assert.equal(Boolean(admitted(altered)),false);
});

test('an observation command cannot enter the normal wake or recovery job',()=>{
 assert.equal(wake(owner,contains),false);
 assert.equal(wake({...owner,event:{...owner.event,comment:{...owner.event.comment,user:{login:'other',type:'User'}}}},contains),false);
 assert.equal(wake({...owner,event:{...owner.event,comment:{...owner.event.comment,body:'/koios recover-stale-newsroom'}}},contains),true);
 assert.doesNotMatch(observe,/systemctl|collect-feedback|publish-feedback|check-recovery|restart|reset-failed/);
 assert.match(observe,/persist-credentials: false/);assert.match(observe,/ref: \$\{\{ github.sha \}\}/);
 assert.match(observe,/retention-days: 7/);assert.match(observe,/github.run_id/);assert.match(observe,/github.run_attempt/);
 const ci=readFileSync(new URL('../.github/workflows/release-contract-ci.yml',import.meta.url),'utf8');
 assert.equal((ci.match(/      - test\/observe-newsroom-runtime.test.mjs/g)??[]).length,2);
 assert.match(ci,/run: node --test .*test\/observe-newsroom-runtime.test.mjs/);
});

test('the CLI rejects arbitrary selectors before reading runtime or invoking systemctl',()=>{
 const result=spawnSync(process.execPath,[new URL('../scripts/observe-newsroom-runtime.mjs',import.meta.url).pathname,'--file=/private'],{encoding:'utf8',env:{PATH:''}});
 assert.equal(result.status,2);assert.equal(result.stdout,'');assert.match(result.stderr,/accepts no arguments/);
 const source=readFileSync(new URL('../scripts/observe-newsroom-runtime.mjs',import.meta.url),'utf8');
 assert.match(source,/\['--user','show',unit/);
 // Error classifications may name a failed source-fetch; refuse actual
 // mutating invocations and systemd execution definitions instead of words
 // appearing as data in a read-only diagnostic pattern.
 assert.doesNotMatch(source,/\b(?:writeFile|rename|unlink|spawn|fetch|execSync)\s*\(/u);
 assert.doesNotMatch(source,/\b(?:EnvironmentFile|ExecStart)\s*=/u);
 assert.match(source,/execFileSync\('journalctl',\['--user','--unit=koios-maintenance.service'/);
});


test('real feedback reader refuses symlinks, FIFOs and oversize files promptly',()=>{
 const directory=mkdtempSync(join(tmpdir(),'koios-observation-read-'));
 try{
  writeFileSync(join(directory,'latest.json'),JSON.stringify(latest));
  assert.equal(readFeedbackSnapshot('latest.json',{directory}).kind,latest.kind);
  symlinkSync('latest.json',join(directory,'newsroom.json'));
  assert.throws(()=>readFeedbackSnapshot('newsroom.json',{directory}),error=>error.code==='ELOOP');
  rmSync(join(directory,'newsroom.json'));
  const fifo=spawnSync('/usr/bin/mkfifo',[join(directory,'newsroom.json')],{timeout:1000});
  assert.equal(fifo.status,0);
  const before=Date.now();
  assert.throws(()=>readFeedbackSnapshot('newsroom.json',{directory}),error=>error.code==='ENOTSUP');
  assert.ok(Date.now()-before<1000,'a nonregular carrier must not wait for a writer');
  rmSync(join(directory,'newsroom.json'));
  writeFileSync(join(directory,'newsroom.json'),Buffer.alloc(2*1024*1024+1));
  assert.throws(()=>readFeedbackSnapshot('newsroom.json',{directory}),error=>error.code==='EFBIG');
  assert.throws(()=>readFeedbackSnapshot('../private',{directory}),/two fixed feedback/);
 }finally{rmSync(directory,{recursive:true,force:true});}
});


test('only read-only observation allows time for runner action setup',()=>{
 assert.match(observe,/timeout-minutes: 10/);
 const wakeJob=workflow.slice(workflow.indexOf('  wake:'));
 assert.match(wakeJob,/timeout-minutes: 3/);
 const observer=readFileSync(new URL('../scripts/observe-newsroom-runtime.mjs',import.meta.url),'utf8');
 assert.match(observer,/timeout:10000/);
});

test('failed maintenance inspects only its own bounded journal and never emits raw provider secrets',()=>{
 const calls=[];
 const messages=[
  JSON.stringify({MESSAGE:'file:///private/root/scripts/publish-feedback.mjs:22'}),
  JSON.stringify({MESSAGE:'Error: Data observation checkout contains uncommitted changes; preserve and reconcile before publishing feedback -- '+secret}),
  JSON.stringify({MESSAGE:'Error: '+secret}),
  JSON.stringify({MESSAGE:'Secret API_KEY_GOOGLE='+secret}),
 ];
 const brokenUnit='LoadState=loaded\nActiveState=failed\nResult=exit-code\nExecMainStatus=1\nExecMainStartTimestampMonotonic=1000000';
 const result=observeNewsroomRuntime({now:()=>at,uptime:()=>180,
  show:name=>name==='koios-maintenance.service'?brokenUnit:unit,
  read:name=>name==='newsroom.json'?raw:latest,
  readJournal:()=>{calls.push('journal');return messages.join('\n');}});
 assert.deepEqual(calls,['journal']);
 assert.equal(result.maintenanceJournal.status,'observed');
 assert.ok(result.maintenanceJournal.phases.includes('feedback-publishing'));
 assert.ok(result.maintenanceJournal.errors.some(x=>x.classification==='data-checkout-dirty'));
 assert.equal(JSON.stringify(result).includes(secret),false,'raw errors must never escape');
 assert.equal(result.maintenanceJournal.errors.length,2);
 assert.equal(maintenanceJournalFacts('invalid-json').errors.length,0);
 const healthy=observeNewsroomRuntime({now:()=>at,uptime:()=>180,show:()=>unit,
  read:name=>name==='newsroom.json'?raw:latest,readJournal:()=>{throw Error('no journal allowed');}});
 assert.equal(Object.hasOwn(healthy,'maintenanceJournal'),false);
});

test('closed journal classification cannot expose encoded or arbitrary text',()=>{
 const excerpt=JSON.stringify({MESSAGE:'provider bearer account-key='+secret});
 const result=maintenanceJournalFacts(excerpt);
 assert.deepEqual(result.errors,[]);
 assert.deepEqual(result.phases,[]);
 assert.equal(JSON.stringify(result).includes(secret),false);
});
