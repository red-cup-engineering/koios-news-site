import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readdirSync,rmSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {readNewsroom,recordNewsroom} from '../src/newsroom-records.mjs';
import {semanticId} from '@red-cup-engineering/computer-content-address-engineering-services-section/semiotic-content-address';
import {admitSourceEvidence,recordSourceEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {assayReporterClaims} from '@red-cup-engineering/content-mill-newsroom-services-section/claims';
import {recordClaim} from '@red-cup-engineering/content-mill-newsroom-services-section/settlement';
import {reportArticle} from '../src/news-line/reporting.mjs';
import {lineRoots} from '../src/news-line/editions.mjs';

const at='2026-10-10T07:00:00.000Z';
const digest=semanticId;
const storyId='news-property.story:'+Buffer.from(JSON.stringify({v:{feed:'fixture-wire',title:'Offline synthetic claims'}})).toString('base64url');
const anchorQuote='Agency Delta recorded coastal findings.';
const newQuote='Agency Delta scheduled follow-up work for October 12.';
function fixture(t){
 const root=mkdtempSync(join(tmpdir(),'koios-supplied-claims-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
 const context={dataRoot:root,roots:lineRoots(root),purchaseJournalRoot:join(root,'inference-purchases'),propertyContentDir:join(root,'content'),property:{origin:'https://koios.news',content:{postsDirectory:'posts'},sections:[{slug:'world',title:'World',wires:['fixture-wire'],minimumIndependentSources:1}],inference:{customerActor:'urn:test:offline-koios-reporter'},editorialProductProfile:'standard-news/v1'}};
 mkdirSync(join(context.propertyContentDir,'posts'),{recursive:true});
 const url='https://outlet0.example/report',text=anchorQuote+'\n'+newQuote,lead={id:'fixture-held-source',url};
 const source=admitSourceEvidence(lead,{type:'PublicWebSource',requestedUrl:url,finalUrl:url,text,textDigest:digest(text),responseDigest:digest(text),rights:'public-access-observed',acquiredAt:at,networkRequests:1,responseBytes:Buffer.byteLength(text)});
 recordSourceEvidence(root,source,at);
 const anchor=admitClaimEvidence({storyId,section:'world',sourceId:lead.id,sourceUrl:url,sourceEvidenceId:source.id,host:new URL(url).hostname,subject:'Agency Delta',predicate:'recorded',object:'coastal findings',quote:anchorQuote,quoteStart:0,quoteEnd:anchorQuote.length},source);
 recordClaim(root,anchor,at);
 const valid={subject:'Agency Delta',predicate:'scheduled',object:'follow-up work for October 12',quote:newQuote};
 const effectCalls={acquire:0,purchase:0};
 const denyEffect=name=>()=>{effectCalls[name]++;throw new Error('Offline reporter fixture forbids '+name);};
 const ports={acquire:denyEffect('acquire'),purchase:denyEffect('purchase')};
 const packet=claims=>({slug:'offline-synthetic-claims',storyId,urls:[url],reporterSources:[{url,expectedTextDigest:source.content.textDigest,claims}],at});
 return {root,context,url,text,lead,source,valid,packet,ports,effectCalls};
}
function noPublication(f){
 assert.deepEqual(f.effectCalls,{acquire:0,purchase:0});
 assert.deepEqual(readdirSync(f.context.roots.editions),[]);
 assert.deepEqual(readdirSync(f.context.roots.queue),[]);
 assert.deepEqual(readdirSync(f.context.roots.grants),[]);
 assert.equal(existsSync(join(f.context.roots.publication,'published', 'offline-synthetic-claims.md')),false);
 assert.equal(existsSync(f.context.purchaseJournalRoot),false);
 // A bounded compatibility harness may supply this additional effect counter.
 if(Object.hasOwn(globalThis,'__koiosQualificationGuardCalls'))assert.deepEqual(globalThis.__koiosQualificationGuardCalls,[]);
}

test('genuine reporter assay admits an exact supplied claim without creating a priced purchase',t=>{
 const f=fixture(t),result=assayReporterClaims(f.lead,f.source,[f.valid]);
 assert.equal(result.admitted,true);assert.equal(result.origin,'reporter-submission');assert.equal(result.price,null);
 assert.deepEqual(result.assay.admittedItems,[0]);assert.equal(result.assay.receiverAcceptanceGranted,false);
 assert.equal(result.candidate.claims[0].quote,newQuote);noPublication(f);
});
test('positive NEW supplied claims join held source custody and settle through the genuine durable journal',async t=>{
 const f=fixture(t),result=await reportArticle(f.context,f.packet([f.valid]),f.ports);
 assert.equal(result.claimsAdded,1);assert.equal(result.storyId,storyId);assert.equal(result.section,'world');
 assert.equal(result.results[0].sourceEvidenceId,f.source.id);assert.equal(result.results[0].outcome,'reporter-claims-assayed');
 const claims=readNewsroom(f.root,'claim');
 assert.equal(claims.length,2);
 const added=claims.map(row=>row.record).find(cell=>cell.content.quote===newQuote);
 assert.ok(added);assert.equal(added.content.sourceEvidenceId,f.source.id);assert.equal(added.content.storyId,storyId);
 assert.equal(f.text.slice(added.content.quoteStart,added.content.quoteEnd),newQuote);
 assert.equal(readNewsroom(f.root,'reporting-source').length,1);
 assert.equal(readNewsroom(f.root,'source-obstruction').length,0);noPublication(f);
});
test('exact supplied-claims retry adds no duplicate claim and does not purchase extraction',async t=>{
 const f=fixture(t);assert.equal((await reportArticle(f.context,f.packet([f.valid]),f.ports)).claimsAdded,1);
 assert.equal((await reportArticle(f.context,f.packet([f.valid]),f.ports)).claimsAdded,0);
 assert.equal(readNewsroom(f.context.dataRoot,'claim').length,2);noPublication(f);
});
test('nonverbatim supplied quote is refused by the real work-lot assay',async t=>{
 const f=fixture(t),bad={...f.valid,quote:'Agency Delta scheduled invented work for October 13.'};
 const result=await reportArticle(f.context,f.packet([bad]),f.ports);
 assert.equal(result.claimsAdded,0);assert.equal(result.results[0].claimsRefused,1);
 assert.ok(result.results[0].groundingProblems.some(p=>p.includes('quote-does-not-match-source')));
 assert.equal(readNewsroom(f.context.dataRoot,'claim').length,1);noPublication(f);
});
test('mixed supplied claims settle only the genuinely grounded sibling',async t=>{
 const f=fixture(t),bad={...f.valid,subject:'Agency Phantom'};
 const result=await reportArticle(f.context,f.packet([f.valid,bad]),f.ports);
 assert.equal(result.claimsAdded,1);assert.equal(result.results[0].claimsRefused,1);
 assert.ok(result.results[0].groundingProblems.some(p=>p.includes('subject-or-object-not-present')));
 assert.equal(readNewsroom(f.context.dataRoot,'claim').length,2);noPublication(f);
});
test('closed schema rejects an extra supplied claim field instead of admitting it',async t=>{
 const f=fixture(t),result=await reportArticle(f.context,f.packet([{...f.valid,unreviewed:true}]),f.ports);
 assert.equal(result.claimsAdded,0);assert.equal(result.results[0].claimsRefused,1);
 assert.ok(result.results[0].groundingProblems.some(p=>p.includes('additionalProperties')));
 assert.equal(readNewsroom(f.context.dataRoot,'claim').length,1);noPublication(f);
});
