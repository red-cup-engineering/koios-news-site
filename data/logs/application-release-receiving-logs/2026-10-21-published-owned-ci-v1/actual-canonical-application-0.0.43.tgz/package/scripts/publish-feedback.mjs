import {pushData} from "./push-data.mjs";
import {execFileSync} from 'node:child_process';
import {readFileSync,mkdirSync,cpSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {diagnosticMarker,diagnosticTitle,planDiagnosticIssueActions,trustedPublisherIdentity} from '../src/feedback-diagnostics.mjs';
const source=resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT,'feedback'),snapshot=JSON.parse(readFileSync(join(source,'latest.json')));
const gh=(...args)=>execFileSync('gh',args,{encoding:'utf8'}).trim();
const api=(method,path,body)=>execFileSync('gh',['api','--method',method,path,'--input','-'],{input:JSON.stringify(body),encoding:'utf8'}).trim();
const data=resolve('data'),git=(...args)=>execFileSync('git',args,{cwd:data,encoding:'utf8'}).trim();
// The parent repository pins published content, not every new private
// feedback observation. The maintenance checkout therefore begins with an
// older data gitlink. Align the clean observation worktree to the current
// owning data branch BEFORE taking the feedback snapshot; a subsequent
// rebase of two independently modified latest.json projections conflicts.
// Never abandon local commits or uncommitted publication evidence.
if(git('status','--porcelain','--untracked-files=all'))
  throw new Error('Data observation checkout contains uncommitted changes; preserve and reconcile before publishing feedback');
git('fetch','origin','main');
if(git('rev-parse','HEAD')!==git('rev-parse','origin/main')){
  const ahead=Number(git('rev-list','--count','origin/main..HEAD'));
  if(!Number.isSafeInteger(ahead)||ahead>0)
    throw new Error('Local unpublished data commits need exact reconciliation before a feedback snapshot can advance');
  git('checkout','--detach','origin/main');
}
// Persist private publication evidence before diagnostic issue discovery or\n// update. A separate GitHub Issues outage must never strand an accepted\n// article or the host's completed feedback snapshot. Authentication remains\n// mandatory before this write.\n// Analytics snapshots are private publication evidence, not public build assets.
mkdirSync(join(data,'feedback'),{recursive:true});cpSync(join(source,'latest.json'),join(data,'feedback','latest.json'));cpSync(join(source,'standards'),join(data,'feedback','standards'),{recursive:true});
git('add','feedback');if(git('diff','--cached','--name-only')){git('-c','user.name=Koios cloud observations','-c','user.email=koios-operations@users.noreply.github.com','commit','-m','Record observed publication, audience and standards evidence');}

// Publication evidence is transferred by the fixed repository's Git transport.
// A separately credentialed issues API cannot prevent the public publication
// ledger or its failure observations from advancing to the owned data remote.
console.log(JSON.stringify(pushData(data)));

function reconcileDiagnosticIssues(){
const publisher=JSON.parse(gh('api','user'));
if(!publisher.login)throw new Error('publisher authentication required');
const trustedAuthors=trustedPublisherIdentity(publisher);
const issues=JSON.parse(gh('issue','list','--repo','causeway-services/koios.news','--state','all','--limit','1000','--json','number,title,state,body,author'));
if(!Array.isArray(issues)||issues.length>=1000)throw new Error('incomplete diagnostic issue scan');
const failures=Object.entries(snapshot.sensors).filter(([,s])=>s.status==='unavailable');
const thin=snapshot.articles.filter(x=>x.failures.some(f=>['insufficient-reporting-depth','missing-context-sections'].includes(f)));
if(thin.length)failures.push(['article-depth',{reason:`${thin.length} published articles lack the current minimum depth or contextual sections.`,articles:thin}]);
const byName=new Map(failures);
const observedNames=Object.entries(snapshot.sensors).filter(([,sensor])=>sensor.status==='observed').map(([name])=>name);
// Resolve every diagnostic identity before the first issue mutation. Duplicate
// collector issues remain an explicit diagnostic failure without losing data.
const actions=planDiagnosticIssueActions(issues,[...byName.keys()],observedNames,trustedAuthors);
for(const action of actions){
 const {name,number,state}=action;
 if(action.action==='close'){gh('issue','close',String(number),'--repo','causeway-services/koios.news','--reason','completed');continue;}
 const failure=byName.get(name),marker=diagnosticMarker(name);
 const body=`${marker}\n\nObserved ${failure.observedAt??snapshot.observedAt}.\n\n${failure.reason}\n\nEvidence: data/feedback/latest.json.\n\n${failure.articles?failure.articles.slice(0,15).map(x=>`- https://koios.news/posts/${x.slug}/ — ${x.words} body words, ${x.sections} context sections`).join('\n'):'Cloud maintenance must resolve the connection or record the exact external access needed.'}\n\nResolve by demonstrating the actual effect; do not close on configuration or a passing build alone.`;
 if(number!==null){if(state==='CLOSED')gh('issue','reopen',String(number),'--repo','causeway-services/koios.news');api('PATCH',`repos/causeway-services/koios.news/issues/${number}`,{body});}else api('POST','repos/causeway-services/koios.news/issues',{title:diagnosticTitle(name),body});
}

}

// GitHub Issues is secondary diagnostic receiving. Missing scope, partial
// listing or a transient API failure must never undo or block a successful
// content/data publication. Still report the refusal as a typed, bounded
// class so the separate credential defect can be repaired.
try{reconcileDiagnosticIssues();}
catch(error){
 const raw=String(error?.message??'');
 const reason=/incomplete diagnostic issue scan/u.test(raw)?'issue-scan-incomplete'
   :/publisher authentication required/u.test(raw)?'publisher-identity-unavailable'
   :/\b(?:gh|GraphQL|HTTP [45][0-9]{2}|API rate limit|Authentication failed)\b/iu.test(raw)?'github-issue-api-unavailable'
   :'diagnostic-issue-settlement-unavailable';
 process.stderr.write(JSON.stringify({kind:'koios.news.issue-feedback/v1',status:'unavailable',reason,
  publicationDataAlreadyAttempted:true})+'\n');
}
