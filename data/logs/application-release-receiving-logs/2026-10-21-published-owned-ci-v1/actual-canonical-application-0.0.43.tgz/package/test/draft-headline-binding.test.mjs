import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, mkdirSync, writeFileSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {readNewsroom,recordNewsroom} from '../src/newsroom-records.mjs';
import {createTypedMark} from '@red-cup-engineering/signcell/typed-mark';
import {manuscriptCandidateType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {lineRoots, openEdition, editionOf} from '../src/news-line/editions.mjs';
import {draftPost, newsLineHandlers} from '../src/news-line/stages.mjs';

const at = '2026-10-10T22:00:00.000Z';
const pole = 'Verstappen Claims First Pole Position of Season';
const duplicatePole = 'Verstappen Secures First Pole Position of the Season';
const distinct = 'India Names Test Squad for South Africa Tour';
const storyId = (title, section) => 'news-property.story:' + Buffer.from(JSON.stringify({v: {feed: `${section}-fixture`, title}})).toString('base64url');

function fixture(t) {
  const root = mkdtempSync(join(tmpdir(), 'koios-draft-headline-'));
  t.after(() => rmSync(root, {recursive: true, force: true}));
  const sections = ['sport', 'world'].map(slug => ({slug, title: slug, wires: [`${slug}-fixture`], minimumIndependentSources: 3}));
  const context = {
    dataRoot: root, roots: lineRoots(root), propertyContentDir: join(root, 'content'),
    property: {name: 'Koios.News', origin: 'https://koios.news', inference: {customerActor: 'urn:ame:koios-news'}, content: {postsDirectory: 'posts'}, sections, editorialProductProfile: 'standard-news/v1'},
    // Exercise adoption of already-held candidates without calling any writer.
    config: {batches: {maxCandidatesPerPulse: 0}}, environment: {},
  };
  mkdirSync(join(context.propertyContentDir, 'posts'), {recursive: true});
  function hold(title, section = 'sport', id = storyId(title, section)) {
    const admitted = createTypedMark(manuscriptCandidateType, {
      storyId: id, section, status: 'pending-assessment', title,
      dek: 'A synthetic draft-adoption check.',
      paragraphs: [{text: 'A synthetic draft-adoption check.', claimEvidenceIds: ['fixture-claim']}],
      manuscript: `# ${title}\n\nA synthetic draft-adoption check.\n`,
      claimEvidenceIds: ['fixture-claim'], sourceEvidenceIds: ['fixture-source'], inputClaimEvidenceIds: ['fixture-claim'],
      workLotId: `urn:inference:fixture:${title}`,
    });
    assert.equal(admitted.ok, true);
    const candidate = admitted.value;
    recordNewsroom(root, 'manuscript-candidate', candidate);
    return candidate;
  }
  function publish(candidate, slug = 'existing-story') {
    const section = candidate.content.section;
    const directory = join(context.roots.publication, 'published');
    mkdirSync(directory, {recursive: true});
    writeFileSync(join(directory, `${slug}.md`), draftPost({candidate, desk: sections.find(desk => desk.slug === section), slug, at, firstPublished: '2026-10-01'}).replace('\ndraft: true\n', '\ndraft: false\n'));
    openEdition(context.roots, {candidateId: candidate.id, storyId: candidate.content.storyId, section, slug, state: 'released', draftedAt: at, releasedAt: at});
  }
  const draft = () => newsLineHandlers(context).draft({at});
  const edition = candidate => editionOf(context.roots, candidate.id);
  return {hold, publish, draft, edition};
}

test('an unrelated NEW story reaches draft custody when its desk already has a published headline', async t => {
  const f = fixture(t); f.publish(f.hold(pole));
  const candidate = f.hold(distinct);
  const result = await f.draft();
  assert.equal(result.status, 'complete');
  assert.equal(result.editionsOpened, 1);
  assert.deepEqual(result.duplicatesRefused, []);
  assert.equal(f.edition(candidate).state, 'drafted');
  assert.equal(f.edition(candidate).firstPublished, undefined);
});

test('a same-desk near duplicate is refused before draft custody is opened', async t => {
  const f = fixture(t); f.publish(f.hold(pole));
  const candidate = f.hold(duplicatePole);
  const result = await f.draft();
  assert.equal(result.editionsOpened, 0);
  assert.equal(result.duplicatesRefused.length, 1);
  assert.equal(f.edition(candidate).state, 'refused');
  assert.equal(f.edition(candidate).reason, 'near-duplicate-headline');
  assert.equal(f.edition(candidate).duplicateOf, 'existing-story');
});

test('the same draft batch screens later candidates against earlier adopted headlines', async t => {
  const f = fixture(t);
  const candidates = [f.hold(pole), f.hold(duplicatePole)];
  const result = await f.draft();
  assert.equal(result.editionsOpened, 1);
  assert.equal(result.duplicatesRefused.length, 1);
  assert.deepEqual(candidates.map(candidate => f.edition(candidate).state).sort(), ['drafted', 'refused']);
});

test('another desk is not refused because it has the same headline', async t => {
  const f = fixture(t); f.publish(f.hold(pole, 'sport'));
  const candidate = f.hold(duplicatePole, 'world');
  const result = await f.draft();
  assert.equal(result.editionsOpened, 1);
  assert.deepEqual(result.duplicatesRefused, []);
  assert.equal(f.edition(candidate).state, 'drafted');
});

test('an anchored revision retains its address and bypasses the NEW-story duplicate screen', async t => {
  const f = fixture(t), original = f.hold(pole); f.publish(original);
  const candidate = f.hold(duplicatePole, 'sport', original.content.storyId);
  const result = await f.draft();
  assert.equal(result.editionsOpened, 1);
  assert.deepEqual(result.duplicatesRefused, []);
  assert.equal(f.edition(candidate).state, 'drafted');
  assert.equal(f.edition(candidate).slug, 'existing-story');
  assert.equal(f.edition(candidate).firstPublished, '2026-10-01');
});
