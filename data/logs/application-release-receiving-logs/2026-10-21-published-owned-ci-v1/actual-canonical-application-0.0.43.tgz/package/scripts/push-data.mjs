/** Retry every committed publication, including one committed by a previously failed cycle. */
import {execFileSync,spawnSync} from 'node:child_process';
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir}from'node:os';import{join}from'node:path';
export function pushData(cwd){
 const git=(...args)=>execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
 git('fetch','origin','main');git('rebase','origin/main');
 if(git('rev-parse','HEAD')===git('rev-parse','origin/main'))return {published:false};
 const result=spawnSync('git',['push','origin','HEAD:main'],{cwd,encoding:'utf8'});
 if(result.status===0)return {published:true,transport:'git'};
 const error=`${result.stdout}\n${result.stderr}`;
 if(!/Internal Server Error|HTTP (?:502|503|504)/i.test(error))throw new Error(error);
 // An observed Git transport outage does not remove the already-authorized exact bytes.
 const repository=git('remote','get-url','origin').replace(/^.*github\.com[:/]/,'').replace(/\.git$/,'');
 if(repository!=='causeway-services/koios-news-data')throw new Error('Publication fallback is restricted to the owned data repository');
 const temp=mkdtempSync(join(tmpdir(),'koios-git-api-'));
 const api=(path,body)=>{const args=['api',`repos/${repository}/${path}`];if(body){const file=join(temp,'request.json');writeFileSync(file,JSON.stringify(body));args.push('--method',path==='git/refs/heads/main'?'PATCH':'POST','--input',file);}return JSON.parse(execFileSync('gh',args,{cwd,encoding:'utf8'}));};
 try{
  const base=api('git/ref/heads/main').object.sha;
  if(base!==git('rev-parse','origin/main'))throw new Error('Publication input advanced during fallback; retry next cycle');
  const tree=[];
  for(const path of git('diff','--name-only',base,'HEAD').split('\n').filter(Boolean)){
   if(!path.startsWith('feedback/')&&!/^line\/publication-replay\/published\/[^/]+\.md$/.test(path)&&!/^line\/publication-evidence\/[a-z0-9]+(?:-[a-z0-9]+)*\/[a-f0-9]{64}\/(?:publication|receipt|evidence|demand|assessment-keys|review)\.json$/.test(path)&&!/^line\/publication-evidence\/[a-z0-9]+(?:-[a-z0-9]+)*\/[a-f0-9]{64}\/(?:published|manuscript)\.md$/.test(path))throw new Error(`Unexpected publication data change ${path}`);
   const entry=git('ls-tree','HEAD','--',path).split(/\s+/);
   if(!entry[0])tree.push({path,mode:'100644',type:'blob',sha:null});
   else tree.push({path,mode:entry[0],type:'blob',content:execFileSync('git',['show',`HEAD:${path}`],{cwd,encoding:'utf8',maxBuffer:4*1024*1024})});
  }
  const baseTree=api(`git/commits/${base}`).tree.sha;
  const newTree=api('git/trees',{base_tree:baseTree,tree}).sha;
  const commit=api('git/commits',{message:'Publish accepted reporting and observed newsroom evidence',tree:newTree,parents:[base]}).sha;
  api('git/refs/heads/main',{sha:commit,force:false});git('fetch','origin','main');git('reset','--soft','origin/main');
  return {published:true,transport:'github-git-api'};
 }finally{rmSync(temp,{recursive:true,force:true});}
}
