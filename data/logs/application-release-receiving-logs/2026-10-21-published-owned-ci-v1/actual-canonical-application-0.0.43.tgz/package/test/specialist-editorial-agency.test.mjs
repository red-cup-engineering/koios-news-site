import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {readAgency} from '@red-cup-engineering/organizing/agency';
import {sha256Digest} from '@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity';
import {recordNewsroom} from '../src/newsroom-records.mjs';
import {declaredEditorialTreatment,qualificationForOwnerCommission,selectEditorialAgencyTreatment,treatmentForStory,assertEditionTreatment} from '../src/news-line/editorial-agency.mjs';
import {draftPost} from '../src/news-line/stages.mjs';

const root=fileURLToPath(new URL('..',import.meta.url));
const law=JSON.parse(readFileSync(join(root,'policy/law/editorial-treatment-catalog.json'),'utf8'));
const products=JSON.parse(readFileSync(join(root,'policy/law/editorial-product-commissions.json'),'utf8'));
const agency=readAgency(root,{acts:[]});
const issue=(x)=>'Source: https://example.org/report\n<!-- koios-editorial-treatment: '+JSON.stringify(x)+' -->';
const specific=(subdesk,registerId,productId,readerQuestion,formatId='text-report')=>({subdesk,registerId,productId,formatId,readerQuestion});
const luma=specific('celebrity-and-fandom','pop-dispatch','current-news-brief/v1','What exactly did the production company publicly announce?');
const caden=specific('music-screen-criticism','culture-feature','culture-feature/v1','How did the production and reception of this work change its meaning?');
const choose=(section,declaration)=>selectEditorialAgencyTreatment({section,declaration,agency,catalog:law,profiles:products});

test('An authored Koios commission can elect an evidence-bound short brief or real cultural feature',()=>{
 const short=qualificationForOwnerCommission({section:'culture-entertainment',issueBody:issue(luma)});
 const long=qualificationForOwnerCommission({section:'culture-entertainment',issueBody:issue(caden)});
 assert.equal(short.kind,'editorial-treatment/v1');
 assert.equal(short.characterId,'luma-vale');
 assert.equal(short.character.byline,'Luma Vale');
 assert.equal(short.agencyCandidate.state,'candidate');
 assert.equal(short.agencyCandidate.admitted,false);
 assert.equal(short.agencyCandidate.executed,false);
 assert.equal(short.editorialProduct.evidenceBudget.targetWords.minimum,300);
 assert.equal(long.characterId,'caden-slate');
 assert.equal(long.character.byline,'Caden Slate');
 assert.equal(long.editorialProduct.evidenceBudget.targetWords.minimum,1100);
 assert.notEqual(short.selectionDigest,long.selectionDigest);
 assert.match(short.character.publicDisclosure,/AI editorial character/);
});
test('The actual Office -> Duty -> Work -> Skill native Organizing path is used',()=>{
 const chosen=choose('culture-entertainment',luma);
 assert.match(chosen.agencyCandidate.office.source,/lib\/agency\/offices\/koios-celebrity-and-fandom-reporter\.json$/u);
 assert.match(chosen.agencyCandidate.duty.source,/lib\/agency\/duties\/prepare-sourced-editorial-work\.json$/u);
 assert.match(chosen.agencyCandidate.skill.source,/lib\/agency\/skills\/writing\/SKILL\.md$/u);
 assert.ok(chosen.agencyCandidate.work,'the reporting duty carries a genuine work closure');
 assert.equal(chosen.agencyCandidate.work.source,chosen.agencyCandidate.duty.source,'the work is derived, not duplicated');
});
test('An agent cannot self-appoint, cross a desk, or select an uninstalled interactive',()=>{
 assert.throws(()=>choose('sport',luma),/not authorized for its accountable editorial desk/);
 assert.throws(()=>choose('culture-entertainment',{...luma,productId:'deep-report/v1'}),/not permitted/);
 assert.throws(()=>choose('culture-entertainment',{...luma,formatId:'scrollytelling'}),/separately installed and received/);
 const reduced={...agency,incumbencies:new Map([...agency.incumbencies].filter(([,seat])=>seat.holder!=='luma-vale'))};
 assert.throws(()=>selectEditorialAgencyTreatment({section:'culture-entertainment',declaration:luma,agency:reduced,catalog:law,profiles:products}),/native Organizing agency has not resolved/);
 const deficient=structuredClone(law);deficient.subdesks['celebrity-and-fandom'].office='nonexistent-office';
 assert.throws(()=>selectEditorialAgencyTreatment({section:'culture-entertainment',declaration:luma,agency,catalog:deficient,profiles:products}),/Character identity does not derive/);
});
test('Only a unique, exact, complete markup declaration is selected',()=>{
 assert.deepEqual(declaredEditorialTreatment('Ordinary signed commission with no register'),null);
 assert.deepEqual(declaredEditorialTreatment(issue(luma)),luma);
 assert.throws(()=>declaredEditorialTreatment(issue(luma)+'\n'+issue(caden)),/Exactly one/);
 assert.throws(()=>declaredEditorialTreatment(issue({...luma,actor:'self-appointed'})),/complete specific commission/);
 assert.throws(()=>declaredEditorialTreatment(issue({...luma,readerQuestion:'Short'})),/complete specific commission/);
 assert.throws(()=>choose('culture-entertainment',{...luma,registerId:'x'}),/not permitted/);
});
test('Only a held, digest-matching owner commission governs a story and its later edition',t=>{
 const dataRoot=mkdtempSync(join(tmpdir(),'koios-specialist-agency-'));
 t.after(()=>rmSync(dataRoot,{recursive:true,force:true}));
 const body=issue(luma),digest=sha256Digest(body),selected=choose('culture-entertainment',luma);
 recordNewsroom(dataRoot,'editorial-commission',{storyId:'story-1',slug:'announced-film',
  issueId:'I_abc',issueUrl:'https://github.com/causeway-services/koios.news/issues/999',
  author:'emsenn',body,bodyDigest:digest,receivedAt:'2026-10-17T00:00:00Z',
  specialistSelectionDigest:selected.selectionDigest,specialistOffice:selected.officeId,character:selected.characterId});
 const ctx={dataRoot,editorialTreatmentCatalog:law,editorialProductLaw:products,currentAgency:agency,treatmentCache:new Map()};
 const treatment=treatmentForStory(ctx,{storyId:'story-1',section:'culture-entertainment'});
 assert.equal(treatment.characterId,'luma-vale');
 const edition={storyId:'story-1',section:'culture-entertainment',treatmentDigest:treatment.selectionDigest,commissionDigest:treatment.authenticatedCommissionDigest};
 assert.equal(assertEditionTreatment(ctx,edition).selectionDigest,treatment.selectionDigest);
 assert.throws(()=>assertEditionTreatment(ctx,{...edition,commissionDigest:'sha256:wrong'}),/changed; independently reassess/);
 assert.throws(()=>assertEditionTreatment(ctx,{...edition,treatmentDigest:'sha256:wrong'}),/changed; independently reassess/);
 assert.throws(()=>assertEditionTreatment(ctx,{storyId:'story-1',section:'culture-entertainment'}),/changed; independently reassess/);
 assert.equal(treatmentForStory(ctx,{storyId:'another-event',section:'culture-entertainment'}),null);
});
test('Published byline metadata is sourced from the incumbent, not a fabricated human',()=>{
 const selected=choose('culture-entertainment',luma);
 const candidate={content:{title:'A studio confirms a new film',dek:'A release has been announced.',manuscript:'# A studio confirms a new film\n\n## Confirmed\n\nThe record names the project.'}};
 const source=draftPost({candidate,desk:{slug:'culture-entertainment',title:'Culture & Entertainment'},slug:'film-announcement',at:'2026-10-17T00:00:00Z',treatment:{...selected,authenticatedCommissionDigest:'sha256:commission-test'}});
 assert.match(source,/author: "Luma Vale"/u);
 assert.match(source,/editorialProductProfile: "current-news-brief\/v1"/u);
 assert.match(source,/koiosCharacter: "luma-vale"/u);
 assert.match(source,/koiosTreatmentDigest: "sha256:/u);
 const generic=draftPost({candidate,desk:{slug:'culture-entertainment',title:'Culture & Entertainment'},slug:'film-announcement',at:'2026-10-17T00:00:00Z'});
 assert.match(generic,/author: "Koios.News Culture & Entertainment Desk"/u);
 assert.doesNotMatch(generic,/koiosCharacter:/u);
});
