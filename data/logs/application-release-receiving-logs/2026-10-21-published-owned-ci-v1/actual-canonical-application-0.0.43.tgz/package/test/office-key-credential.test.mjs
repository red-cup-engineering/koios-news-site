import test from "node:test";
import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import { mkdtempSync, writeFileSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { officeKey } from "../src/news-line/editions.mjs";

test("officeKey signs with the issuer key from $CREDENTIALS_DIRECTORY and leaves no private copy in the state root", () => {
  const root = mkdtempSync(join(tmpdir(), "koios-key-")), credentials = mkdtempSync(join(tmpdir(), "koios-cred-"));
  const pair = generateKeyPairSync("ed25519");
  writeFileSync(join(credentials, "koios-editor-in-chief.pem"), pair.privateKey.export({ format: "pem", type: "pkcs8" }), { mode: 0o600 });
  const previous = process.env.CREDENTIALS_DIRECTORY;
  process.env.CREDENTIALS_DIRECTORY = credentials;
  try {
    const roots = { keys: join(root, "keys") };
    const first = officeKey(roots, "editor-in-chief"), second = officeKey({ keys: join(mkdtempSync(join(tmpdir(), "koios-other-")), "keys") }, "editor-in-chief");
    assert.equal(first.keyId, second.keyId, "two hosts holding the issuer key share one key id");
    assert.equal(first.privateKey.export({ format: "pem", type: "pkcs8" }), pair.privateKey.export({ format: "pem", type: "pkcs8" }));
    assert.deepEqual(Object.keys(JSON.parse(readFileSync(first.keyMapPath, "utf8"))), [first.keyId]);
    assert.throws(() => readFileSync(join(roots.keys, "editor-in-chief", "ed25519.pem")), /ENOENT/);
  } finally {
    if (previous === undefined) delete process.env.CREDENTIALS_DIRECTORY; else process.env.CREDENTIALS_DIRECTORY = previous;
  }
});
