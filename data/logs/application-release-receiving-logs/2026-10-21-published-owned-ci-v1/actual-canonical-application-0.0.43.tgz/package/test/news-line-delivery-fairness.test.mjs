import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, rmSync, writeFileSync, existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {KOIOS_NEWS_LINE, runKoiosNewsCycle, runKoiosNewsTurn, readyPublicationStage, nextKoiosNewsStage} from '../src/news-line.mjs';
import {newsLineContext} from '../src/news-line/context.mjs';
import {openEdition, editionOf, advanceEdition} from '../src/news-line/editions.mjs';
import {withEditorialLock} from '../src/news-line/execution-lock.mjs';
import {renderedEditionSetIdentity} from '../src/news-line/stages.mjs';
import {runServiceLineTurn} from '@red-cup-engineering/organizing/work/service-line';

function admittedWriterContext(dataRoot){
 const configPath=join(dataRoot,'providers.json');
 writeFileSync(configPath,JSON.stringify([{providerId:'openrouter-cohere-north',actor:'urn:ame:openrouter-inference-team',model:'nvidia/nemotron-3-super-120b-a12b:free'}]));
 return newsLineContext({environment:{KOIOS_NEWSROOM_DATA_ROOT:dataRoot,DIRECT_ENDPOINT_PROVIDER_CONFIG:configPath,API_KEY_OPENROUTER:'fixture-only-never-transmitted'}});
}

test('a completed unresolved release cannot monopolize independently repeated newsroom pulses', async () => {
  const dataRoot = mkdtempSync(join(tmpdir(), 'koios-release-fairness-'));
  const context = admittedWriterContext(dataRoot);
  const now = () => '2026-10-11T12:00:00.000Z';
  const priorSpawn = cp.spawnSync;
  let syncAttempts = 0;
  cp.spawnSync = (program, args) => {
    assert.equal(program, process.execPath);
    assert.equal(args.length, 1); assert.ok(args[0].endsWith('/scripts/sync-publication-data.mjs'));
    syncAttempts++;
    return {status: 1, stderr: 'Synthetic publication sync refusal', stdout: ''};
  };
  syncBuiltinESMExports();
  try {
    const handlers = {intake: async () => ({status: 'complete'}), analyze: async () => ({status: 'complete'}), draft: async () => ({status: 'blocked', code: 'stage-threw', reason: 'Synthetic earlier draft failure'})};
    for (let i = 0; i < 3; i++) await runServiceLineTurn(KOIOS_NEWS_LINE, {dataRoot: context.roots.root, handlers, now});
    openEdition(context.roots, {candidateId: 'fixture-rendered', storyId: 'fixture-story', slug: 'fixture-story', section: 'world', state: 'rendered', draftedAt: now(), renderedAt: now()});
    assert.equal(readyPublicationStage(context), 'release');
    const first = await runKoiosNewsCycle({context});
    const second = await runKoiosNewsCycle({context});
    console.log(JSON.stringify({first: first.turns, second: second.turns, next: second.status.next, syncAttempts}));
    assert.equal(first.turns[0].stage, 'release');
    assert.equal(second.turns[0].stage, 'draft');
    assert.equal(second.turns[0].status, 'complete');
    assert.equal(editionOf(context.roots, 'fixture-rendered').state, 'rendered');
  } finally {cp.spawnSync = priorSpawn; syncBuiltinESMExports(); rmSync(dataRoot, {recursive: true, force: true});}
});

async function deferredFixture(t, {status = 'complete', identity = true} = {}) {
  const dataRoot = mkdtempSync(join(tmpdir(), 'koios-delivery-selection-'));
  t.after(() => rmSync(dataRoot, {recursive: true, force: true}));
  const configPath=join(dataRoot,"providers.json"); writeFileSync(configPath,"[]");
  const context = newsLineContext({environment: {KOIOS_NEWSROOM_DATA_ROOT: dataRoot,DIRECT_ENDPOINT_PROVIDER_CONFIG:configPath}});
  const now = () => '2026-10-11T12:00:00.000Z';
  const handlers = {intake: async () => ({status: 'complete'}), analyze: async () => ({status: 'complete'}), draft: async () => ({status: 'blocked', code: 'stage-threw'})};
  for (let i = 0; i < 3; i++) await runServiceLineTurn(KOIOS_NEWS_LINE, {dataRoot: context.roots.root, handlers, now});
  const pending = {candidateId: 'fixture-rendered', storyId: 'fixture-story', slug: 'fixture-story', section: 'world', state: 'rendered', draftedAt: now(), renderedAt: now()};
  openEdition(context.roots, pending);
  handlers.release = async () => ({status, released: 0, ...(status === 'blocked' ? {code: 'stage-threw'} : {}), ...(identity ? {attemptedRenderedIdentity: renderedEditionSetIdentity([pending])} : {})});
  await runServiceLineTurn(KOIOS_NEWS_LINE, {dataRoot: context.roots.root, handlers, now, selectedStage: 'release'});
  return {context, now, pending};
}

test('pending exact released custody yields to the existing source cursor, not a new schedule', async t => {
  const {context} = await deferredFixture(t);
  assert.equal(readyPublicationStage(context), null);
  assert.equal(nextKoiosNewsStage(context), 'draft');
});

test('same-instant newly rendered custody restores publication priority by exact identity', async t => {
  const {context, pending} = await deferredFixture(t);
  openEdition(context.roots, {...pending, candidateId: 'fixture-new-rendered', slug: 'fixture-new-rendered'});
  assert.equal(readyPublicationStage(context), 'release');
  assert.equal(nextKoiosNewsStage(context), 'release');
});

test('pending release cannot starve already-ready render, authorization or independent assessment', async t => {
  for (const [state, stage] of [['queued', 'render'], ['accepted', 'authorize'], ['drafted', 'assess']]) {
    const {context, pending} = await deferredFixture(t);
    openEdition(context.roots, {...pending, candidateId: 'fixture-' + state, slug: 'fixture-' + state, state});
    assert.equal(readyPublicationStage(context), stage);
    assert.equal(nextKoiosNewsStage(context), stage);
  }
});

test('blocked or historical unbound release results cannot claim a completed custody attempt', async t => {
  for (const options of [{status: 'blocked'}, {identity: false}]) {
    const {context} = await deferredFixture(t, options);
    assert.equal(readyPublicationStage(context), 'release');
  }
});

test('an idle feedback cursor needs no writer admission, and feedback opens the next acquisition cycle', async t => {
  const dataRoot = mkdtempSync(join(tmpdir(), 'koios-feedback-selection-'));
  t.after(() => rmSync(dataRoot, {recursive: true, force: true}));
  const configPath=join(dataRoot,"providers.json"); writeFileSync(configPath,"[]");
  const context = newsLineContext({environment: {KOIOS_NEWSROOM_DATA_ROOT: dataRoot,DIRECT_ENDPOINT_PROVIDER_CONFIG:configPath}});
  const now = () => '2026-10-11T12:00:00.000Z';
  const handlers = Object.fromEntries(KOIOS_NEWS_LINE.stages.map(stage => [stage, async () => ({status: 'complete'})]));
  for (let i = 0; i < 7; i++) await runServiceLineTurn(KOIOS_NEWS_LINE, {dataRoot: context.roots.root, handlers, now});
  assert.equal(readyPublicationStage(context), null);
  assert.equal(nextKoiosNewsStage(context), 'feedback');
  await runServiceLineTurn(KOIOS_NEWS_LINE, {dataRoot: context.roots.root, handlers, now});
  assert.equal(nextKoiosNewsStage(context), 'intake');
});

test('rendered custody identity is deterministic, bounded and changes with a new candidate', () => {
  const rows = [{candidateId: 'one'}, {candidateId: 'two'}];
  const identity = renderedEditionSetIdentity(rows);
  assert.match(identity, /^[a-f0-9]{64}$/);
  assert.equal(renderedEditionSetIdentity([...rows].reverse()), identity);
  assert.notEqual(renderedEditionSetIdentity([...rows, {candidateId: 'three'}]), identity);
});


test('failed writer admission records the actually selected stopped stage and restores release priority', async t => {
  const {context} = await deferredFixture(t);
  assert.equal(nextKoiosNewsStage(context), 'draft');
  const stopped = await runKoiosNewsTurn({context});
  assert.equal(stopped.event.content.stage, 'draft');
  assert.equal(stopped.event.content.status, 'blocked');
  assert.equal(stopped.event.content.execute.code, 'inference-obstructed');
  assert.equal(stopped.event.content.execute.phase, 'writer-admission');
  assert.equal(readyPublicationStage(context), 'release');
  assert.equal(editionOf(context.roots, 'fixture-rendered').state, 'rendered');
});

test('unbound rendered custody remains pending without monopolizing the following pulse', async t => {
  const {context} = await deferredFixture(t, {identity: false});
  const priorSpawn = cp.spawnSync, priorFetch = globalThis.fetch;
  cp.spawnSync = (program, args) => {
    assert.equal(program, process.execPath); assert.equal(args.length, 1);
    assert.ok(args[0].endsWith('/scripts/sync-publication-data.mjs'));
    return {status: 0, stderr: '', stdout: ''};
  };
  let reads = 0;
  globalThis.fetch = async url => {
    assert.equal(url, 'https://koios.news/fingerprints/fixture-story.json'); reads++;
    return {ok: false, status: 503};
  };
  syncBuiltinESMExports();
  try {
    const first = await runKoiosNewsCycle({context});
    const second = await runKoiosNewsCycle({context});
    assert.equal(first.turns[0].stage, 'release');
    assert.equal(second.turns[0].stage, 'draft');
    assert.equal(reads, 0); // Missing consumed receipt licenses no public receiving claim.
    assert.equal(editionOf(context.roots, 'fixture-rendered').state, 'rendered');
    assert.equal(second.status.live.articlesLast24h, 0);
  } finally {cp.spawnSync = priorSpawn; globalThis.fetch = priorFetch; syncBuiltinESMExports();}
});

test('delivery selection changing while the lock is held cannot bypass writer admission', async t=>{
 const {context,pending,now}=await deferredFixture(t,{identity:false});
 assert.equal(nextKoiosNewsStage(context),'release');
 let entered,release;
 const locked=new Promise(resolve=>entered=resolve),unblock=new Promise(resolve=>release=resolve);
 const other=withEditorialLock(context,async()=>{
  entered();await unblock;
  advanceEdition(context.roots,pending,'released',now(),{releasedAt:now()});
 });
 await locked;
 const waiting=runKoiosNewsTurn({context});
 release();await other;
 const turn=await waiting;
 assert.equal(turn.event.content.stage,'draft');
 assert.equal(turn.event.content.status,'blocked');
 assert.equal(turn.event.content.execute.phase,'writer-admission');
 assert.equal(turn.event.content.execute.writerObstruction.code,'inference-obstructed');
 assert.equal(turn.event.content.execute.writingAttempts,0);
 assert.equal(turn.event.content.execute.drafted,0);
 assert.equal(turn.event.content.execute.editionsOpened,0);
 assert.equal(turn.event.content.execute.independentResult.status,'complete');
 assert.equal(turn.event.content.execute.independentResult.writingAttempts,0);
 assert.equal(existsSync(context.purchaseJournalRoot),false,'held repair must not purchase inference');
 assert.equal(turn.status.next,'draft');
});

test('each writer turn rechecks admission even when an earlier turn had a provider',async t=>{
 const {context,pending}=await deferredFixture(t);
 const admitted=admittedWriterContext(context.dataRoot);
 const first=await runKoiosNewsTurn({context:admitted});
 assert.equal(first.event.content.stage,'draft');
 assert.equal(first.event.content.status,'complete');
 assert.equal(first.event.content.execute.writerAdmission.writerFailover.admitted,1);
 // A later invocation cannot reuse the previous stage's successful admission.
 advanceEdition(context.roots,pending,'released',new Date().toISOString(),{releasedAt:new Date().toISOString()});
 writeFileSync(admitted.environment.DIRECT_ENDPOINT_PROVIDER_CONFIG,'[]');
 const handlers={analyze:async()=>({status:'blocked',code:'fixture-analyze'})};
 await runServiceLineTurn(KOIOS_NEWS_LINE,{dataRoot:context.roots.root,handlers,selectedStage:'analyze'});
 const second=await runKoiosNewsTurn({context:admitted});
 assert.equal(second.event.content.stage,'analyze');
 assert.equal(second.event.content.status,'blocked');
 assert.equal(second.event.content.execute.phase,'writer-admission');
});

test('newswire intake retains its source cursor without any admitted inference provider', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'koios-intake-without-writer-'));
  t.after(() => rmSync(dir, {recursive: true, force: true}));
  const propertyPath = join(dir, 'property.json');
  const feedsPath = join(dir, 'feeds.json');
  const providersPath = join(dir, 'providers.json');
  writeFileSync(propertyPath, JSON.stringify({
    name: 'Koios.WireCustodyTest',
    content: {root: '.', sourceFeeds: feedsPath, publishedPosts: 'line/publication-replay/published'},
    sections: [], cadence: {dailyArticleTarget: 20},
  }));
  // No external requests: an empty owned feed directory models an idle cycle.
  writeFileSync(feedsPath, '[]');
  writeFileSync(providersPath, '[]');
  const context = newsLineContext({environment: {
    KOIOS_NEWSROOM_DATA_ROOT: join(dir, 'state'),
    KOIOS_NEWS_PROPERTY: propertyPath,
    DIRECT_ENDPOINT_PROVIDER_CONFIG: providersPath,
  }});
  const intake = await runKoiosNewsTurn({context});
  assert.equal(intake.event.content.stage, 'intake');
  assert.equal(intake.event.content.status, 'complete');
  assert.equal(intake.event.content.execute.writerAdmission, undefined);
  assert.equal(intake.event.content.execute.arrivals, 0);
  assert.equal(nextKoiosNewsStage(context), 'analyze');

  // Source analysis can purchase inference; it must still fail closed if
  // no zero-cash provider has been admitted. Intake does not confer permission.
  const analysis = await runKoiosNewsTurn({context});
  assert.equal(analysis.event.content.stage, 'analyze');
  assert.equal(analysis.event.content.status, 'blocked');
  assert.equal(analysis.event.content.execute.phase, 'writer-admission');
  assert.equal(analysis.event.content.execute.code, 'inference-obstructed');
  assert.equal(analysis.event.content.execute.analysis, undefined);
});

test('writer outage retains queued source arrivals without an unadmitted claim purchase',async t=>{
 const dir=mkdtempSync(join(tmpdir(),'koios-provider-free-source-analysis-'));
 t.after(()=>rmSync(dir,{recursive:true,force:true}));
 const providers=join(dir,'providers.json');
 writeFileSync(providers,'[]');
 const context=newsLineContext({environment:{
   KOIOS_NEWSROOM_DATA_ROOT:join(dir,'newsroom'),
   DIRECT_ENDPOINT_PROVIDER_CONFIG:providers,
 }});
 const pending=join(context.roots.arrivals,'source-batch.json');
 writeFileSync(pending,'[]');
 const now=()=> '2026-10-12T12:00:00.000Z';
 await runServiceLineTurn(KOIOS_NEWS_LINE,{dataRoot:context.roots.root,
   handlers:{intake:async()=>({status:'complete'})},now,selectedStage:'intake'});
 assert.equal(nextKoiosNewsStage(context),'analyze');
 const turn=await runKoiosNewsTurn({context});
 assert.equal(turn.event.content.stage,'analyze');
 assert.equal(turn.event.content.status,'blocked');
 assert.ok(existsSync(pending),'source arrival custody must remain for a later admitted claim pass');
 const effect=turn.event.content.execute;
 assert.equal(effect.code,'inference-obstructed');
 assert.equal(effect.phase,'writer-admission');
 assert.ok(effect.writerObstruction);
 if(effect.independentResult.code!=='source-only-capability-unavailable'){
   assert.equal(effect.sourceEvidenceOnly,true);
   assert.equal(effect.phase,'writer-admission');
   assert.equal(effect.analysis?.claims?.purchaseCount,0,'no phantom provider purchase');
 }
});
