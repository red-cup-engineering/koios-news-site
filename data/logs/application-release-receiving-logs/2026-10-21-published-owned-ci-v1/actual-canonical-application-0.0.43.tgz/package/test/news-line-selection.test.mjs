import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { custodyIdentity, readSelectionHistory, currentCycleEvidence, selectKoiosWork, executeWithoutWriter } from '../src/news-line/selection.mjs';

const stages = ['intake', 'analyze', 'draft', 'assess', 'authorize', 'render', 'release', 'feedback'];
const priority = stage => ({ stage, identity: `exact-${stage}` });
const production = stage => ({ workAttempt: { kind: 'production', stage } });
const attempted = work => ({ workAttempt: { kind: 'priority', ...work } });
const writerStop = { phase: 'writer-admission', code: 'inference-obstructed' };
function record(events, stage, status = 'complete', execute = {}, cycle = 1) {
  const event = { id: `event-${events.length}`, content: { cycle, stage, status, execute,
    at: '2026-10-14T00:00:00.000Z', knowledge: { prior: events.at(-1)?.id ?? null } } };
  events.push(event); return event;
}
function snapshot(events, { priorities = [], pendingArrivals = true } = {}) {
  const cycle = Math.max(1, ...events.map(event => event.content.cycle));
  const latest = new Map(events.filter(event => event.content.cycle === cycle).map(event => [event.content.stage, event.content.status]));
  const next = stages.find(stage => latest.get(stage) !== 'complete');
  return { events, stages, priorities, pendingArrivals, status: { cycle: next ? cycle : cycle + 1, next: next ?? 'intake',
    stages: stages.map(stage => ({ stage, status: next ? latest.get(stage) ?? 'pending' : 'pending' })) } };
}
const select = (events, options, pulse) => selectKoiosWork(snapshot(events, options), pulse);

test('writer obstruction survives intervening release and assessment attempts at one instant', () => {
  const events = [], release = priority('release'), assess = priority('assess');
  record(events, 'intake');
  record(events, 'analyze', 'blocked', writerStop);
  record(events, 'release', 'complete', attempted(release));
  record(events, 'assess', 'blocked', { code: 'assessment-inference-obstructed', ...attempted(assess) });
  assert.equal(select(events, { priorities: [release, assess] }).stage, 'intake');
});

test('all-wire outage still offers held arrivals, then recovered claim work reaches drafting', () => {
  const events = [];
  record(events, 'intake', 'blocked', { code: 'every-wire-unreachable' });
  assert.equal(select(events).stage, 'analyze');
  record(events, 'analyze', 'complete', production('analyze'));
  assert.equal(select(events).stage, 'draft');
  assert.equal(select(events, {}, { attemptedStages: new Set(['intake', 'analyze']) }).stage, 'draft');
});

test('failed drafted assessment yields across independent single turns and restarts', () => {
  const events = [], assess = priority('assess'), options = { priorities: [assess] };
  record(events, 'intake');
  record(events, 'analyze', 'blocked', writerStop);
  record(events, 'draft', 'blocked', { ...writerStop, ...attempted(priority('draft')) });
  assert.equal(select(events, options).stage, 'assess');
  record(events, 'assess', 'blocked', { code: 'assessment-inference-obstructed', ...attempted(assess) });
  assert.equal(select(structuredClone(events), options).stage, 'intake');
  record(events, 'intake', 'complete', production('intake'));
  assert.equal(select(events, options).stage, 'assess');
  record(events, 'assess', 'blocked', attempted(assess));
  assert.equal(select(events, options).stage, 'analyze');
  record(events, 'analyze', 'complete', production('analyze'));
  record(events, 'assess', 'blocked', attempted(assess));
  assert.equal(select(events, options).stage, 'draft', 'renewed intake cannot preempt the recovered writer');
});

test('failed exact repair cannot unlock failed assessment without independent source opportunity', () => {
  const events = [], assess = priority('assess'), repair = priority('draft');
  record(events, 'intake');
  record(events, 'analyze', 'blocked', writerStop);
  record(events, 'assess', 'blocked', attempted(assess));
  assert.equal(select(events, { priorities: [assess, repair] }).stage, 'draft');
  record(events, 'draft', 'blocked', { code: 'reporter-submission-custody-incomplete', ...attempted(repair) });
  const selected = select(events, { priorities: [assess, repair] });
  assert.equal(selected.stage, 'intake');
  assert.equal(selected.kind, 'production');
});

test('one pulse excludes spent priorities before offering an unspent source stage', () => {
  const events = [], assess = priority('assess'), repair = priority('draft');
  record(events, 'intake');
  record(events, 'analyze', 'blocked', writerStop);
  record(events, 'assess', 'blocked', attempted(assess));
  record(events, 'draft', 'blocked', { ...writerStop, ...attempted(repair) });
  record(events, 'intake', 'complete', production('intake'));
  const pulse = { attemptedStages: new Set(['assess', 'draft', 'intake']) };
  assert.equal(select(events, { priorities: [assess, repair] }, pulse).stage, 'analyze');
  pulse.attemptedStages.add('analyze');
  assert.equal(select(events, { priorities: [assess, repair] }, pulse), null);
});

test('new exact custody reactivates priority without a clock or retry-counter change', () => {
  const events = [], assess = priority('assess');
  record(events, 'intake');
  record(events, 'assess', 'blocked', attempted(assess));
  assert.equal(select(events, { priorities: [assess] }).stage, 'analyze');
  assert.equal(select(events, { priorities: [{ ...assess, identity: 'new-judgment' }] }).stage, 'assess');
  const receipt = ['candidate', '/receipt', 'same-expiry', 'judgment-a', 'accepted-policy', 'current-policy'];
  const changed = [...receipt]; changed[3] = 'judgment-b';
  assert.notEqual(custodyIdentity('authorize', [receipt]), custodyIdentity('authorize', [changed]));
  assert.equal(custodyIdentity('assess', [['b', 'instant', 'policy'], ['a', 'instant', 'policy']]),
    custodyIdentity('assess', [['a', 'instant', 'policy'], ['b', 'instant', 'policy']]));
});

test('custody ordering is code-unit deterministic rather than locale dependent', () => {
  const tuples = [['é'], ['a'], ['Ω'], ['Z']];
  const expected = createHash('sha256').update(JSON.stringify(['assess', [['Z'], ['a'], ['é'], ['Ω']]])).digest('hex');
  assert.equal(custodyIdentity('assess', tuples), expected);
});

test('the actual snapshot-read boundary refuses provider cycles before selection or execution', () => {
  for (const failing of ['status', 'events']) {
    const cause = new Error('Cyclic service-line execution lineage');
    const reads = [], downstream = [];
    assert.throws(() => {
      readSelectionHistory(() => { reads.push('status'); if (failing === 'status') throw cause; return {}; },
        () => { reads.push('events'); throw cause; });
      downstream.push('select-or-execute');
    }, error => error.name === 'KoiosSelectionHistoryError' && error.code === 'selection-history-unverified'
      && error.executed === false && error.cause === cause);
    assert.deepEqual(reads, failing === 'status' ? ['status'] : ['status', 'events']);
    assert.deepEqual(downstream, []);
  }

});

test('empty editorial turns and historical unclassified drafts do not reset priority yields', () => {
  const events = [], release = priority('release');
  record(events, 'intake');
  record(events, 'release', 'complete', { attemptedRenderedIdentity: release.identity });
  record(events, 'draft');
  record(events, 'assess');
  record(events, 'authorize');
  assert.notEqual(select(events, { priorities: [release] }).stage, 'release');
  record(events, 'draft', 'blocked', { ...writerStop, ...production('draft') });
  assert.equal(select(events, { priorities: [release] }).stage, 'release');
});

test('causal suffix uses prior references despite input order and identical timestamps', () => {
  const events = [];
  record(events, 'intake'); record(events, 'analyze', 'blocked', writerStop);
  const input = snapshot(events);
  input.events = [...events].reverse();
  assert.equal(selectKoiosWork(input).stage, 'intake');
});

test('current-cycle cuts, forks, loops and inconsistent status fail closed', () => {
  const events = []; record(events, 'intake'); record(events, 'analyze', 'blocked', writerStop);
  const missing = snapshot(events); missing.events = events.slice(1);
  assert.equal(selectKoiosWork(missing).obstruction.code, 'selection-history-unverified');
  const forked = structuredClone(events);
  forked.push({ ...structuredClone(events[1]), id: 'fork' });
  assert.equal(select(forked).obstruction.code, 'selection-history-unverified');
  const cyclic = structuredClone(events); cyclic[0].content.knowledge.prior = cyclic[1].id;
  assert.equal(select(cyclic).obstruction.code, 'selection-history-unverified');
  const inconsistent = snapshot(events); inconsistent.status.next = 'draft';
  assert.equal(selectKoiosWork(inconsistent).obstruction.code, 'selection-history-unverified');
});

test('missing older history outside an observed cycle boundary is not needed for selection', () => {
  const events = [];
  const boundary = record(events, 'feedback', 'complete', {}, 4);
  boundary.content.knowledge.prior = 'older-than-the-read-window';
  record(events, 'intake', 'blocked', { code: 'every-wire-unreachable' }, 5);
  const input = snapshot(events);
  assert.equal(currentCycleEvidence(input.events, input.status, stages).events.length, 1);
  assert.equal(selectKoiosWork(input).stage, 'analyze');
});

test('an ordinary fully admitted cycle keeps the supplier stage order', () => {
  const events = [];
  for (const stage of stages) {
    assert.equal(select(events, { pendingArrivals: false }).stage, stage);
    record(events, stage, 'complete', production(stage));
  }
  assert.equal(select(events, { pendingArrivals: false }).stage, 'intake');
});

test('source acquisition throws preserve writer obstruction and separate typed failure', async () => {
  const result = await executeWithoutWriter('analyze', async input => {
    assert.equal(input.acquisitionOnly, true); throw Object.assign(new Error('source transport failed'), { code: 'ECONNRESET' });
  }, {}, new Error('writer allowance absent'));
  assert.equal(result.phase, 'writer-admission');
  assert.equal(result.writerObstruction.reason, 'writer allowance absent');
  assert.equal(result.independentResult.code, 'stage-threw');
  assert.equal(result.independentResult.reason, 'source transport failed');
  assert.equal(result.independentResult.cause.code, 'ECONNRESET');
});

test('source refusals and held-repair blocks remain distinct from writer admission', async () => {
  const sourceObstructions = [{ leadId: 'lead', url: 'https://example.invalid/source', reason: 'unreachable' }];
  const source = await executeWithoutWriter('analyze', async () => ({ status: 'complete', sourceObstructions }), {}, 'no writer');
  assert.equal(source.status, 'blocked');
  assert.deepEqual(source.independentResult.sourceObstructions, sourceObstructions);
  const missing = await executeWithoutWriter('analyze', async () => ({ status: 'blocked', code: 'source-only-capability-unavailable' }), {}, 'no writer');
  assert.equal(missing.code, 'inference-obstructed');
  assert.equal(missing.independentResult.code, 'source-only-capability-unavailable');
  const repair = await executeWithoutWriter('draft', async input => {
    assert.equal(input.existingOnly, true);
    return { status: 'blocked', code: 'reporter-submission-custody-incomplete' };
  }, {}, 'no writer');
  assert.equal(repair.independentResult.code, 'reporter-submission-custody-incomplete');
});
