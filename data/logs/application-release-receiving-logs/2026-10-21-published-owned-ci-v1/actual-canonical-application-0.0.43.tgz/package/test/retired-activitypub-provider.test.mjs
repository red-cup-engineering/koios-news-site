import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const RETIRED_PROVIDER_IMPORT = "../services/activitypub-retained-inbox-provider/src/server.mjs";
const OWNER_PROVIDER_EXPORT = "@causeway-services/activitypub-retained-inbox-provider/server";
const PRODUCTION_IMPORTERS = [
  "src/activitypub-bridge.mjs",
];

async function readJson(path) {
  return JSON.parse(await readFile(path, "utf8"));
}

test("Koios imports the owning ActivityPub provider, not the retired copy", async () => {
  const productionSources = await Promise.all(
    PRODUCTION_IMPORTERS.map(async (path) => [path, await readFile(path, "utf8")]),
  );

  for (const [path, source] of productionSources) {
    assert.doesNotMatch(source, new RegExp(RETIRED_PROVIDER_IMPORT.replaceAll(".", "\\.")), path);
    assert.match(source, new RegExp(OWNER_PROVIDER_EXPORT.replaceAll("/", "\\/")), path);
  }

  const koiosPackage = await readJson("package.json");
  assert.equal(
    koiosPackage.dependencies["@causeway-services/activitypub-retained-inbox-provider"],
    "0.1.1",
  );

});
