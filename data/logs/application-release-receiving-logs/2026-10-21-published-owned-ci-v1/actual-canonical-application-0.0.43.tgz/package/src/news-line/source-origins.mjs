/** Domain diversity is a screening floor, not a verdict of independent reporting.
 * A Koios article citing another Koios article cannot create a new origin.
 * Only actual HTTP(S) evidence URLs outside this publication count toward that
 * floor; editors must still detect syndication and shared underlying sources.
 */
const OWN_PUBLICATION = 'koios.news';

export function outsidePublicationHost(sourceUrl) {
  if (typeof sourceUrl !== 'string') return null;
  let url;
  try { url = new URL(sourceUrl); } catch { return null; }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return null;
  const host = url.hostname.toLowerCase().replace(/\.$/u, '').replace(/^www\./u, '');
  if (!host || host === OWN_PUBLICATION || host.endsWith('.' + OWN_PUBLICATION)) return null;
  return host;
}
