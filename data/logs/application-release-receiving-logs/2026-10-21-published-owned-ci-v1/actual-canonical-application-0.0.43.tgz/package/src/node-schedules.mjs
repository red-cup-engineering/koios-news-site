import { KOIOS_SERVICE_ENTERPRISE } from "./service-identity.mjs";

export const KOIOS_NODE_ACCOUNT = KOIOS_SERVICE_ENTERPRISE;
export const KOIOS_NEWSROOM_SCHEDULE_ID = "koios-newsroom-hourly";
export const KOIOS_PUBLICATION_SCHEDULE_ID = "koios-routine-publication-daily";

function requireInstant(value, label) {
  if (typeof value !== "string" || value.trim() === "" || !Number.isFinite(Date.parse(value))) {
    throw new TypeError(`${label} must be an explicit ISO 8601 instant`);
  }
  const canonical = new Date(value).toISOString();
  if (canonical !== value) throw new TypeError(`${label} must be a canonical UTC instant`);
  return value;
}

/**
 * The two recurring-work declarations supplied by the Koios FeltOS application.
 *
 * The host supplies both first-due instants deliberately. This module names
 * cadence and operation ownership only; the owning property supplies the cadence at deployment.
 * Existing schedule IDs are retained as durable recurrence identities, even
 * where their historical names describe an older frequency. It never guesses a deployment clock,
 * grants editorial authority, or turns candidate formation into publication.
 * The native instance loader supplies its clock account in the second argument;
 * the Koios enterprise remains the default for its dedicated instance only.
 */
export function koiosNodeScheduleDeclarations({
  newsroomFirstDueAt,
  publicationFirstDueAt,
  pulseIntervalMinutes = 15,
  newsroomJob,
  publicationJob,
  inferenceStageJobs,
} = {}, { account = KOIOS_NODE_ACCOUNT } = {}) {
  if (typeof account !== "string" || account.trim() === "") {
    throw new TypeError("Koios schedules require the installing instance's account");
  }
  if (!Number.isSafeInteger(pulseIntervalMinutes) || pulseIntervalMinutes < 1 || pulseIntervalMinutes > Math.floor(Number.MAX_SAFE_INTEGER/60)) {
    throw new TypeError("Koios newsroom cadence must be a positive representable number of whole minutes");
  }
  const newsroomAt = requireInstant(newsroomFirstDueAt, "newsroomFirstDueAt");
  const publicationAt = requireInstant(publicationFirstDueAt, "publicationFirstDueAt");
  for(const [label,job]of Object.entries({newsroomJob,publicationJob})){
   if(job!==undefined&&(job===null||typeof job!=='object'||Array.isArray(job)||Object.keys(job).length!==2
     ||![job.deployment,job.job].every(value=>typeof value==='string'&&/^[a-z0-9][a-z0-9-]*$/u.test(value))))
    throw new TypeError(`Koios ${label} requires its declared native deployment and job identities`);
  }
  if(publicationJob&&newsroomJob&&publicationJob.deployment===newsroomJob.deployment&&publicationJob.job===newsroomJob.job)
   throw new TypeError('Independent editorial delivery requires a distinct native job identity');
  const stageJobs=inferenceStageJobs??{};
  if(stageJobs===null||typeof stageJobs!=='object'||Array.isArray(stageJobs)||Object.keys(stageJobs).some(stage=>!['draft','assess'].includes(stage)))throw new TypeError('Koios inferenceStageJobs names existing draft and assess duties');
  for(const job of Object.values(stageJobs)){
   if(!job||typeof job!=='object'||Object.keys(job).length!==2||![job.deployment,job.job].every(value=>typeof value==='string'&&/^[a-z0-9][a-z0-9-]*$/u.test(value)))throw new TypeError('Koios inference stage requires its declared native job');
  }
  const jobs=[newsroomJob,publicationJob,...Object.values(stageJobs)].filter(Boolean).map(job=>job.deployment+'\u0000'+job.job);
  if(new Set(jobs).size!==jobs.length)throw new TypeError('Independent editorial duties require distinct native job identities');
  return Object.freeze([
    Object.freeze({
      id: KOIOS_NEWSROOM_SCHEDULE_ID,
      // The complete service line owns review, authority, release and feedback;
      // merely running newsroom-day would stop at drafting.
      // A host may receive the same cycle as a native job so model work
      // survives a host generation switch. The one FeltOS clock still owns
      // this recurrence, and Code's executor forbids overlapping job runs.
      verb: newsroomJob===undefined ? "koios-news-cycle" : "node-job-run",
      input: Object.freeze(newsroomJob===undefined ? {} : {...newsroomJob}),
      account,
      firstDueAt: newsroomAt,
      everySeconds: pulseIntervalMinutes * 60,
    }),
    Object.freeze({
      id: KOIOS_PUBLICATION_SCHEDULE_ID,
      // Reuse the existing recurrence for the same service line. Shared
      // stage leases exclude duplicate effects while a slow stage is in flight.
      verb: publicationJob===undefined ? "koios-news-status" : "node-job-run",
      input: Object.freeze(publicationJob===undefined ? {} : {...publicationJob}),
      account,
      firstDueAt: publicationAt,
      everySeconds: publicationJob===undefined ? 24 * 60 * 60 : pulseIntervalMinutes*60,
    }),
    ...Object.entries(stageJobs).map(([stage,job])=>Object.freeze({id:'koios-newsroom-'+stage,verb:'node-job-run',input:Object.freeze({...job}),account,firstDueAt:newsroomAt,everySeconds:pulseIntervalMinutes*60})),
  ]);
}
