import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {reportArticle} from '../src/news-line/reporting.mjs';
import {recoverableRenderRefusal} from '../src/news-line/submissions.mjs';
import {newsLineContext} from '../src/news-line/context.mjs';
import {heldJournalCells} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {claimEvidenceType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {draftEvents,newsroomDayDraft,assignedClaims,admitReporterManuscript} from '@red-cup-engineering/content-mill-newsroom-services-section/manuscript';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {recordClaim} from '@red-cup-engineering/content-mill-newsroom-services-section/settlement';
import {digest} from '@causeway-services/web-source-acquisition/acquire';
import {admitSourceEvidence,recordSourceEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {readNewsroom,recordNewsroom} from '../src/newsroom-records.mjs';
const storyId='news-property.story:'+Buffer.from(JSON.stringify({v:{feed:'welsh-wire'}})).toString('base64url');
test('Additional reporting enters the real evidence journal under the released article identity and corrected desk',async()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-reporting-'));
 const text='The Senedd makes laws for Wales in devolved policy areas.';
 const context={dataRoot:root,roots:{},property:{name:'Koios.News',sections:[{slug:'world',wires:['welsh-wire']}],inference:{customerActor:'urn:ame:koios-news'},cadence:{freeLaneOnly:true}}};
 const ports={editions:()=>[{slug:'welsh-report',storyId,section:'us-politics',releasedAt:'2026-10-02T12:00:00Z'}],
 acquire:async({urls})=>({type:'PublicWebSource',requestedUrl:urls[0],finalUrl:urls[0],text,textDigest:digest(text),responseDigest:digest(text),rights:'public-access-observed',publisher:'Welsh Parliament',published:'2025-01-01',acquiredAt:'2026-10-07T12:00:00Z',networkRequests:1,responseBytes:text.length}),
 purchase:async(item,{sourceEvidence,freeLaneOnly})=>{assert.equal(freeLaneOnly,true);return{item,admitted:true,provider:'urn:ame:fixture',sourceEvidenceId:sourceEvidence.id,sourceUrl:item.url,outcome:'fixture',candidate:{claims:[{subject:'Senedd',predicate:'makes laws for',object:'Wales in devolved policy areas',quote:text}]}};},receipt:()=>null};
 try {
 const result=await reportArticle(context,{slug:'welsh-report',urls:['https://senedd.wales/powers']},ports);
 assert.equal(result.claimsAdded,1);assert.equal(result.section,'world');
 const claim=readNewsroom(root,'claim')[0].record.content;
 assert.equal(claim.storyId,storyId);assert.equal(claim.section,'world');assert.equal(claim.quote,text);
 assert.equal(readNewsroom(root,'reporting-source').length,1);
 assert.equal(readNewsroom(root,'source-page-metadata')[0].record.declared.published,'2025-01-01');
 assert.equal(readNewsroom(root,'manuscript-candidate').length,0);
 assert.equal((await reportArticle(context,{slug:'welsh-report',urls:['https://senedd.wales/powers']},ports)).claimsAdded,0);
 const options={property:context.property,dataRoot:root,maxCandidates:1};
 assert.equal((await newsroomDayDraft(options)).refusals.length,1);
 assert.equal((await newsroomDayDraft(options)).refusals.length,1);
 assert.equal(readNewsroom(root,'manuscript-obstruction').length,1);
 context.property.sections[0].minimumIndependentSources=3;
 await newsroomDayDraft(options);
 assert.equal(readNewsroom(root,'manuscript-obstruction').length,2);
 const submitted=await reportArticle(context,{slug:'welsh-report',urls:['https://senedd.wales/powers'],reporterSources:[{url:'https://senedd.wales/powers',expectedTextDigest:digest(text),claims:[{subject:'Senedd',predicate:'makes laws for',object:'Wales in devolved policy areas',quote:text}]}]}, {...ports,purchase:()=>{throw new Error('A reporter submission must not buy another model rewrite');}});
 assert.equal(submitted.claimsAdded,1);assert.equal(submitted.results[0].outcome,'reporter-claims-assayed');
 const source=readNewsroom(root,'source-evidence')[0].record;
 const backgroundUrl='https://senedd.wales/background';
 const background=admitSourceEvidence({id:'original-feed-lead',url:backgroundUrl},{type:'PublicWebSource',...source.content,requestedUrl:backgroundUrl,finalUrl:backgroundUrl});
 recordSourceEvidence(root,background,'2026-10-07T12:00:00Z');
 const reused=await reportArticle(context,{slug:'welsh-report',urls:[backgroundUrl],reporterSources:[{url:backgroundUrl,expectedTextDigest:digest(text),claims:[{subject:'Senedd',predicate:'makes laws for',object:'Wales in devolved policy areas',quote:text}]}]},{...ports,acquire:()=>{throw new Error('The reviewed held source should be reused');}});
 assert.equal(reused.claimsAdded,1);
 const obsolete=admitClaimEvidence({...claim,section:'us-politics'},source);recordClaim(root,obsolete,'2026-10-07T12:00:00Z');
 const assigned=assignedClaims(root,()=> 'world','2026-10-07T12:01:00Z');
 assert.ok(assigned.every(entry=>entry.cell.content.section==='world'));
 const reported=assigned.find(entry=>entry.source.content.finalUrl==='https://senedd.wales/powers');assert.ok(reported);
 const proposal={title:'The Senedd and devolved laws',dek:'The Senedd makes laws in devolved areas.',paragraphs:[{text:'The Senedd makes laws for Wales in devolved policy areas.',heading:'Powers',claimEvidenceIds:[reported.cell.id]}]};
 const manuscript=admitReporterManuscript({root,storyId,section:'world',proposal,at:'2026-10-07T12:01:00Z'});
 assert.equal(manuscript.candidate.content.section,'world');
 assert.ok(manuscript.candidate.content.manuscript.includes('https://senedd.wales/powers'));
 assert.throws(()=>admitReporterManuscript({root,storyId,section:'world',proposal:{...proposal,paragraphs:[{...proposal.paragraphs[0],claimEvidenceIds:[obsolete.id]}]},at:'2026-10-07T12:01:00Z'}),/absent, opposed or differently assigned/);
 assert.equal(heldJournalCells(root,'claim',claimEvidenceType,[reported.cell.id]).size,1);
 recordNewsroom(root,'claim',reported.cell,{told:{for:true,against:true}});
 assert.equal(heldJournalCells(root,'claim',claimEvidenceType,[reported.cell.id]).size,0);
 assert.throws(()=>admitReporterManuscript({root,storyId,section:'world',proposal,at:'2026-10-07T12:03:00Z'}),/absent, opposed or differently assigned/);
 await assert.rejects(reportArticle(context,{slug:'welsh-report',urls:['https://senedd.wales/powers'],reporterSources:[{url:'https://senedd.wales/powers',expectedTextDigest:'changed',claims:[]}]},ports),/changed since review/);
 }finally{rmSync(root,{recursive:true,force:true});}
});
test('Sharing a background document does not merge unrelated published events',()=>{
 const entries=['a','b'].map(story=>({cell:{id:story,content:{section:'us-politics',storyId:story,sourceEvidenceId:'background',subject:story,predicate:'mentions',object:'devolution',quote:'quote'}},source:{id:'background',content:{finalUrl:'https://senedd.wales/powers'}}}));
 const result=draftEvents(entries,{anchorStoryIds:['a','b'],drafted:new Set(),sectionOrder:['world'],sectionForStory:()=> 'world',contextualSourceIds:new Set(['background'])});
 assert.equal(result.length,2);assert.ok(result.every(event=>event.section==='world'));
});

test('Cloud reporting has a durable purchase journal without an operator override',()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-context-'));
 try{assert.equal(newsLineContext({environment:{KOIOS_NEWSROOM_DATA_ROOT:root}}).purchaseJournalRoot,join(root,'inference-purchases'));}
 finally{rmSync(root,{recursive:true,force:true});}
});

test('Only unexpired accepted render refusals can be recovered for a fresh release attempt',()=>{
 const acceptedRefusal={state:'refused',reason:'render: output refused',receiptExpiresAt:'2026-10-10T12:00:00Z',history:[{state:'drafted'},{state:'accepted'}]};
 assert.equal(recoverableRenderRefusal(acceptedRefusal,'2026-10-09T12:00:00Z'),true);
 assert.equal(recoverableRenderRefusal({...acceptedRefusal,receiptExpiresAt:'2026-10-09T11:59:59Z'},'2026-10-09T12:00:00Z'),false);
 assert.equal(recoverableRenderRefusal({...acceptedRefusal,reason:'assessment-refused'},'2026-10-09T12:00:00Z'),false);
 assert.equal(recoverableRenderRefusal({...acceptedRefusal,history:[{state:'drafted'}]},'2026-10-09T12:00:00Z'),false);
});

test('A short obsolete draft returns before replaying a missing evidence join or retrying assessment',async()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-thin-assess-'));
 try{
  const {newsLineHandlers}=await import('../src/news-line/stages.mjs');
  const {openEdition,editionOf}=await import('../src/news-line/editions.mjs');
  const context=newsLineContext({environment:{KOIOS_NEWSROOM_DATA_ROOT:root}}),candidateId='urn:koios:obsolete-thin-draft',draftPath=join(root,'thin.md');
  writeFileSync(draftPath,'---\ntitle: Thin draft\ndate: 2026-10-02\ndraft: true\nsection: world\n---\n# Thin draft\n\nA short report lacks the contextual reporting required to publish.\n');
  openEdition(context.roots,{candidateId,storyId,section:'world',slug:'thin',draftPath,state:'drafted',draftedAt:'2026-10-07T12:00:00Z',firstPublished:'2026-10-02',attempts:0,market:null});
  const outcome=await newsLineHandlers(context).assess({at:'2026-10-07T12:01:00Z'});
  assert.equal(outcome.outcomes[0].outcome,'returned');
  const edition=editionOf(context.roots,candidateId);
  assert.equal(edition.reason,'article-depth-insufficient');assert.equal(edition.failureLayer,'writer-model');assert.equal(edition.attempts,0);
  assert.equal(edition.quality.assertions,null);
 }finally{rmSync(root,{recursive:true,force:true});}
});

test('The oldest new article keeps its reserved slot, requested published revisions precede routine copy, and new arrivals cannot starve older drafts',async()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-assessment-order-'));
 try{
  const {newsLineHandlers}=await import('../src/news-line/stages.mjs');
  const {openEdition}=await import('../src/news-line/editions.mjs');
  const base=newsLineContext({environment:{KOIOS_NEWSROOM_DATA_ROOT:root}});
  const context={...base,config:{...base.config,batches:{...base.config.batches,maxAssessmentsPerTurn:2}}};
  const draftPath=join(root,'short.md');
  writeFileSync(draftPath,'---\ntitle: A short draft\ndate: 2026-10-07\ndraft: true\nsection: world\n---\nInsufficient reporting.\n');
  for(const [slug,time,provider,firstPublished] of [['older','12:00:00','urn:ame:fixture',undefined],['newer','12:01:00','urn:ame:fixture',undefined],['requested','12:02:00','urn:ame:koios-cloud-editor','2026-10-02']]){
   openEdition(context.roots,{candidateId:'urn:koios:'+slug,storyId:storyId+slug,section:'world',slug,draftPath,state:'drafted',draftedAt:'2026-10-07T'+time+'Z',provider,firstPublished,attempts:0,market:null});
  }
  // The oldest new article owns the first slot (selectAssessmentBatch); the requested revision of
  // a released article takes the next ahead of newer routine copy.
  assert.deepEqual((await newsLineHandlers(context).assess({at:'2026-10-07T12:03:00Z'})).outcomes.map(outcome=>outcome.slug),['older','requested']);
  assert.deepEqual((await newsLineHandlers(context).assess({at:'2026-10-07T12:04:00Z'})).outcomes.map(outcome=>outcome.slug),['newer']);
 }finally{rmSync(root,{recursive:true,force:true});}
});

test('A drafted NEW reporter article is assessed before another writer preflight',async()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-new-draft-priority-'));
 try{
  const {readyPublicationStage}=await import('../src/news-line.mjs');
  const {openEdition}=await import('../src/news-line/editions.mjs');
  const context=newsLineContext({environment:{KOIOS_NEWSROOM_DATA_ROOT:root}}),draftPath=join(root,'new.md');
  writeFileSync(draftPath,'---\ntitle: Held new draft\ndate: 2026-10-11\ndraft: true\nsection: world\n---\n# Held new draft\n\nReporter-submitted copy awaiting independent assessment.\n');
  openEdition(context.roots,{candidateId:'urn:koios:new-draft',storyId:storyId+'new',section:'world',slug:'held-new-draft',draftPath,state:'drafted',draftedAt:'2026-10-11T02:00:00Z',attempts:0,market:null});
  assert.equal(readyPublicationStage(context),'assess');
 }finally{rmSync(root,{recursive:true,force:true});}
});
