import {existsSync,readFileSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {heldJournalCells} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {claimEvidenceType,sourceEvidenceType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {admitSourceEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {parsePost} from '@causeway-services/koios-news-site/build';
import {editions} from './editions.mjs';
import {storyDesk,storyAnchor} from './desk.mjs';
import {OBSERVED_PUBLICATION_PREFIX} from './existing-article.mjs';
import {nearDuplicateHeadline} from './editorial-deduplication.mjs';
import {draftEvents} from '@red-cup-engineering/content-mill-newsroom-services-section/manuscript';
import {readNewsroom} from '../newsroom-records.mjs';
import {readCurrentStories} from '@red-cup-engineering/content-mill-newsroom-services-section/intake';
import {assayReporterClaims,claimRows} from '@red-cup-engineering/content-mill-newsroom-services-section/claims';

function groundedEntries(root){
 const claims=heldJournalCells(root,'claim',claimEvidenceType);
 const sources=heldJournalCells(root,'source-evidence',sourceEvidenceType),entries=[];
 for(const cell of claims.values()){
  const source=sources.get(cell.content.sourceEvidenceId);
  if(!source)continue;
  try{
   const replayed=admitSourceEvidence({id:source.content.leadId,url:source.content.requestedUrl},{type:'PublicWebSource',...source.content});
   if(replayed.id===source.id&&admitClaimEvidence(cell.content,replayed).id===cell.id)entries.push({cell,source:replayed});
  }catch{ /* Unheld or changed source bytes cannot establish an assignment. */ }
 }
 return entries;
}

/** A NEW reporter assignment needs an existing story and exact, held newsroom evidence. */
export function newReporterAssignment(context,{slug,storyId},{reporterSources,at=new Date().toISOString()}={}){
 if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug??''))throw new Error('A valid article slug is required');
 if(typeof storyId!=='string'||storyId.startsWith(OBSERVED_PUBLICATION_PREFIX))throw new Error('A NEW reporter assignment requires an existing newsroom storyId; published stories use the slug-only revision route');
 const nowMs=Date.parse(at);
 if(!Number.isFinite(nowMs))throw new Error('A NEW reporter assignment requires a valid reporting timestamp');
 const desk=storyDesk(context.property,storyId,undefined,context.dataRoot);
 const entries=groundedEntries(context.dataRoot);
 if(entries.some(({cell})=>cell.content.storyId===storyId))return {slug,storyId,section:desk.slug};
 // A provider outage can leave an admitted wire story and its captured source
 // without any extracted claim. The reviewed-claims route may assay its first
 // claims against those existing carriers; a caller-supplied storyId alone
 // never establishes an assignment, and manuscript submission stays unchanged.
 const sectionByFeedId=new Map(context.property.sections.flatMap(section=>section.wires.map(feed=>[feed,[section.slug]])));
 const commissioned=storyAnchor(storyId,context.dataRoot);
 const story=Array.isArray(reporterSources)&&(commissioned.commission?{...commissioned,id:storyId}:readCurrentStories({
  root:context.dataRoot,sectionByFeedId,nowMs,
 }).find(row=>row.id===storyId&&row.section===desk.slug));
 const initialClaimEntries=[];
 const opposedClaims=new Set(readNewsroom(context.dataRoot,'claim').filter(({told})=>told!==undefined).map(({record})=>record?.id));
 if(story)for(const source of heldJournalCells(context.dataRoot,'source-evidence',sourceEvidenceType).values()){
  if(source.content.leadId!==story.id||source.content.requestedUrl!==story.url)continue;
  let replayed;
  try{replayed=admitSourceEvidence({id:story.id,url:story.url},{type:'PublicWebSource',...source.content});}catch{continue;}
  if(replayed.id!==source.id)continue;
  const supplied=reporterSources.find(row=>row.url===source.content.requestedUrl&&row.expectedTextDigest===source.content.textDigest);
  if(!supplied)continue;
  const assayed=assayReporterClaims({id:story.id,url:story.url},replayed,supplied.claims);
  for(const row of claimRows(assayed,{storyId,section:desk.slug},replayed)){
   const cell=admitClaimEvidence(row,replayed);
   if(!opposedClaims.has(cell.id))initialClaimEntries.push({cell,source:replayed});
  }
 }
 if(!initialClaimEntries.length)throw new Error('NEW reporter story has no held, source-bound newsroom claim or assayed source-only assignment');
 return {slug,storyId,section:desk.slug,initialClaimEntries};
}

export function assertNewReporterEvent(context,{storyId,initialClaimEntries=[]}){
 const entries=[...groundedEntries(context.dataRoot),...initialClaimEntries];
 const all=editions(context.roots);
 const anchors=all.filter(edition=>['released','drafted','accepted','queued','rendered'].includes(edition.state)).map(edition=>edition.storyId);
 const events=draftEvents(entries,{
  anchorStoryIds:anchors,drafted:new Set(all.map(edition=>`${edition.section}\u0000${edition.storyId}`)),
  sectionOrder:context.property.sections.map(section=>section.slug),
  sectionForStory:(id,section)=>storyDesk(context.property,id,section,context.dataRoot).slug,
  contextualSourceIds:new Set(readNewsroom(context.dataRoot,'reporting-source').map(({record})=>record?.sourceEvidenceId).filter(Boolean)),
 });
 const event=events.find(event=>event.storyId===storyId)??events.find(event=>event.entries.some(({cell})=>cell.content.storyId===storyId));
 if(event?.storyId!==storyId)throw new Error('Reporter story is grouped under another existing event identity');
}

/** Preserve one story/address and the ordinary draft stage's same-desk headline guard. */
export function assertNewReporterAddress(context,assignment,{title,forDraft=false}={}){
 const {slug,storyId,section}=assignment,all=editions(context.roots);
 const canonical=all.find(edition=>edition.storyId===storyId&&edition.state==='released')??all.find(edition=>edition.storyId===storyId);
 if(canonical&&canonical.slug!==slug)throw new Error('Reporter story requires its original article address');
 for(const edition of all){
  if(edition.slug===slug&&edition.storyId!==storyId)throw new Error('Reporter slug belongs to another newsroom story');
  if(edition.storyId===storyId&&edition.slug!==slug&&!['returned','refused'].includes(edition.state))throw new Error('Reporter story has a pending manuscript under another address');
  if(edition.storyId===storyId&&edition.state==='released')throw new Error('Published stories require the existing slug-only revision route');
  if(forDraft&&edition.storyId===storyId&&!['returned','refused'].includes(edition.state))throw new Error('Reporter story already has a pending manuscript; retry its exact packet');
 }
 const published=join(context.roots.publication,'published');
 const corpus=join(context.propertyContentDir,context.property.content?.postsDirectory??'posts');
 if(existsSync(join(published,slug+'.md')))throw new Error('Reporter slug already exists in publication inputs');
 const heldManuscript=join(corpus,slug+'.md');
 // The content repository is an intake for unpublished manuscripts. Its
 // presence reserves no publication authority and must not prevent the
 // reporter from submitting that manuscript to independent assessment.
 if(existsSync(heldManuscript)&&parsePost(readFileSync(heldManuscript,'utf8'),slug+'.md').draft!==true)
  throw new Error('Reporter slug belongs to a nondraft publication input');
 if(title===undefined)return;
 const standing=existsSync(published)?readdirSync(published).filter(name=>name.endsWith('.md')).map(name=>{
  const slug=name.slice(0,-3),released=all.filter(edition=>edition.slug===slug&&edition.state==='released').sort((a,b)=>a.releasedAt.localeCompare(b.releasedAt)).at(-1);
  return {path:join(published,name),slug,section:released?storyDesk(context.property,released.storyId,released.section,context.dataRoot).slug:context.property.content?.legacyPublishedSections?.[slug]};
 }):[];
 const pending=all.filter(edition=>edition.storyId!==storyId&&['drafted','accepted','queued','rendered'].includes(edition.state)&&edition.draftPath&&existsSync(edition.draftPath)).map(edition=>({path:edition.draftPath,slug:edition.slug,section:storyDesk(context.property,edition.storyId,edition.section,context.dataRoot).slug}));
 for(const entry of [...standing,...pending]){
  const post=parsePost(readFileSync(entry.path,'utf8'),entry.slug+'.md');
  if((entry.section??post.section)===section&&nearDuplicateHeadline(post.title,title))throw new Error('Reporter headline nearly duplicates another article in the same desk');
 }
}

