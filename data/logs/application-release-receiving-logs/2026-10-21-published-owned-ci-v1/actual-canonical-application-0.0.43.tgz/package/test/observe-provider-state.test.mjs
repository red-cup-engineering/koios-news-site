import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,mkdirSync,writeFileSync,rmSync,readdirSync,symlinkSync,realpathSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const script=join(root,'scripts/observe-provider-state.mjs');
const preload=join(root,'test/fixtures/provider-state-process.mjs');
const source=readFileSync(join(root,'.github/workflows/site.yml'),'utf8');
const providerJob=source.slice(source.indexOf('  observe-primary-provider:\n'));
const run=providerJob.match(/^        run: \|\n((?:          .*\n)+)/m)?.[1].replace(/^          /gm,'');
assert.ok(run);
const providerRoot=realpathSync(join(root,'node_modules'));
const deploymentId='11111111-2222-4333-8444-555555555555',versionId='66666666-7777-4888-8999-aaaaaaaaaaaa';
const createdOn='2026-10-11T13:58:22.123456Z';
const row=(overrides={})=>({id:deploymentId,created_on:createdOn,versions:[{version_id:versionId,percentage:100}],...overrides});
const good=()=>({status:0,stdout:JSON.stringify([row()]),stderr:''});
function fixture(t,result=good(),extra={}){
 const scratch=mkdtempSync(join(tmpdir(),'koios-provider-test-'));t.after(()=>rmSync(scratch,{recursive:true,force:true}));
 for(const name of ['home','config','cache','data','tmp','logs','runner'])mkdirSync(join(scratch,name));
 const fixturePath=join(scratch,'response.json'),record=join(scratch,'calls.jsonl');
 writeFileSync(fixturePath,JSON.stringify({result,...extra}));
 const env={PATH:process.env.PATH,HOME:join(scratch,'outer-home'),RUNNER_TEMP:join(scratch,'runner'),
  PROVIDER_TEST_FIXTURE:fixturePath,PROVIDER_TEST_RECORD:record,GITHUB_SHA:'bc27689932d8a253ebe7f7dc688f0d054182e053',
  GITHUB_RUN_ID:'38159999999',GITHUB_RUN_ATTEMPT:'1',CLOUDFLARE_ACCOUNT_ID:'337e54ee6dc7d488933f473204a6d89e',
  CLOUDFLARE_API_TOKEN:'PRIVATE_PROVIDER_TOKEN',GH_TOKEN:'PRIVATE_GITHUB_TOKEN',AWS_SECRET_ACCESS_KEY:'PRIVATE_AWS_TOKEN',
  NODE_PATH:'PRIVATE_NODE_PATH'};
 const calls=()=>{try{return readFileSync(record,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);}catch{return [];}};
 const execute=(override={},args=[])=>spawnSync(process.execPath,['--import',preload,'--permission',`--allow-fs-read=${root}`,`--allow-fs-read=${providerRoot}`,`--allow-fs-read=${scratch}`,`--allow-fs-write=${scratch}`,script,...args],{cwd:scratch,env:{...env,...override},encoding:'utf8',timeout:10000});
 return {scratch,env,calls,execute,record,fixturePath};
}
function assertPrivateOutput(result){assert.doesNotMatch(result.stdout+result.stderr,/PRIVATE_|author_email|annotations|stack|provider-process/);}
test('real carrier reads the fixed provider once and projects only current identity and traffic',t=>{
 const f=fixture(t),result=f.execute();assert.equal(result.status,0,result.stderr);assert.equal(result.stderr,'');assertPrivateOutput(result);
 const output=JSON.parse(result.stdout);assert.equal(output.kind,'koios.website-provider-observation/v1');assert.equal(output.mode,'read-only');
 assert.equal(output.status,'observed');assert.equal(output.sourceRevision,f.env.GITHUB_SHA);assert.equal(output.observationRunId,f.env.GITHUB_RUN_ID);
 assert.ok(Number.isFinite(Date.parse(output.observedAt)));
 assert.deepEqual(output.current,{deploymentId,createdOn,traffic:[{versionId,percentage:100}]});
 assert.deepEqual(output.target,{accountId:f.env.CLOUDFLARE_ACCOUNT_ID,workerName:'koios-news-primary',bindingSha256:'3b5605daef5613d18937b165ebdaf5632657e24560c5e296d6f3ed86df5278a2'});
 assert.equal(output.historicalComparison.status,'prior-provider-identity-unavailable');assert.equal(output.historicalComparison.publicationRunId,'38142736555');
 assert.equal(output.historicalComparison.retainedObservationProjectionSha256,'08c3d95186d444033fdc3d8394357878ecac37c5fbdb33eb81f9b939dafb7116');
 assert.deepEqual(output.successorPublication,{runId:'38145280191',effect:'unobserved'});
 assert.equal(output.historyCoverage,'recent-provider-read-not-a-complete-ledger');assert.equal(output.candidateManifestBinding,'unobserved');assert.equal(output.currentPublicAssets,'unobserved');
 const calls=f.calls();assert.equal(calls.length,1);assert.equal(calls[0].kind,'provider-process');
 const call=calls[0];assert.deepEqual(call.args.slice(1),['deployments','list','--name','koios-news-primary','--json']);
 assert.deepEqual(call.stdio,['ignore','pipe','pipe']);assert.equal(call.encoding,'utf8');
 assert.deepEqual(call.environment,{PATH:dirname(process.execPath),HOME:join(f.scratch,'home'),XDG_CONFIG_HOME:join(f.scratch,'config'),
  XDG_CACHE_HOME:join(f.scratch,'cache'),XDG_DATA_HOME:join(f.scratch,'data'),TMPDIR:join(f.scratch,'tmp'),WRANGLER_LOG_PATH:join(f.scratch,'logs/wrangler.log'),
  WRANGLER_SEND_METRICS:'false',CI:'true',CLOUDFLARE_ACCOUNT_ID:f.env.CLOUDFLARE_ACCOUNT_ID,CLOUDFLARE_API_TOKEN:f.env.CLOUDFLARE_API_TOKEN});
 assert.doesNotMatch(JSON.stringify(call.args),/PRIVATE_/);
});
test('genuine carrier chooses latest timestamp and raw provider metadata cannot leak',t=>{
 const f=fixture(t,{status:0,stdout:JSON.stringify([row({author_email:'PRIVATE_EMAIL',annotations:{message:'PRIVATE_MESSAGE'}}),row({id:'bbbbbbbb-2222-4333-8444-555555555555',created_on:'2026-09-01T00:00:00Z'})]),stderr:'PRIVATE_STDERR'});
 const result=f.execute();assert.equal(result.status,0,result.stderr);assertPrivateOutput(result);assert.equal(JSON.parse(result.stdout).current.deploymentId,deploymentId);
});
for(const [name,result,reason] of [
 ['empty list',{status:0,stdout:'[]'},'provider-read-unavailable'],
 ['split traffic',{status:0,stdout:JSON.stringify([row({versions:[{version_id:versionId,percentage:50},{version_id:deploymentId,percentage:50}]})])},'provider-read-unavailable'],
 ['failed command',{status:1,stdout:'PRIVATE_STDOUT',stderr:'PRIVATE_STDERR'},'provider-read-unavailable'],
 ['malformed JSON',{status:0,stdout:'PRIVATE_JSON'},'provider-read-unavailable'],
 ['malformed deployment ID',{status:0,stdout:JSON.stringify([row({id:'PRIVATE_ID'})])},'provider-shape'],
 ['malformed version ID',{status:0,stdout:JSON.stringify([row({versions:[{version_id:'PRIVATE_VERSION',percentage:100}]})])},'provider-shape'],
 ['malformed timestamp',{status:0,stdout:JSON.stringify([row({created_on:'PRIVATE_TIME'})])},'provider-read-unavailable'],
])test(`${name} fails closed without raw error output or a retry`,t=>{
 const f=fixture(t,result),out=f.execute();assert.equal(out.status,1);assert.equal(out.stdout,'');assertPrivateOutput(out);
 assert.deepEqual(JSON.parse(out.stderr),{kind:'koios.website-provider-observation/v1',status:'refused',reason});assert.equal(f.calls().length,1);
});
for(const [name,env,reason] of [
 ['source revision',{GITHUB_SHA:'PRIVATE_SOURCE'},'source-identity'],
 ['run identity',{GITHUB_RUN_ID:'../38142736555'},'source-identity'],
 ['run attempt',{GITHUB_RUN_ATTEMPT:'1\n'},'source-identity'],
 ['missing binding',{CLOUDFLARE_API_TOKEN:''},'credential-binding-unavailable'],
 ['wrong account',{CLOUDFLARE_ACCOUNT_ID:'PRIVATE_ACCOUNT'},'account-binding'],
])test(`invalid ${name} refuses before provider invocation`,t=>{
 const f=fixture(t),out=f.execute(env);assert.equal(out.status,1);assertPrivateOutput(out);assert.equal(JSON.parse(out.stderr).reason,reason);assert.deepEqual(f.calls(),[]);
});
test('CLI accepts no arbitrary worker, command or other arguments',t=>{
 const f=fixture(t),out=f.execute({},['--worker','another']);assert.equal(out.status,1);assert.equal(JSON.parse(out.stderr).reason,'arguments');assert.deepEqual(f.calls(),[]);
});
for(const [name,extra,reason] of [['throwing',{throwAccessor:true},'provider-read-unavailable'],['alternating',{alternatingAccessor:true},'provider-shape']])test(`${name} error accessor cannot disclose arbitrary values`,t=>{
 const f=fixture(t,good(),extra),out=f.execute();assert.equal(out.status,1);assertPrivateOutput(out);assert.equal(JSON.parse(out.stderr).reason,reason);assert.equal(f.calls().length,1);
});
test('provider workflow has fixed artifact, one credential binding and bounded isolated read',()=>{
 // The runner startup allowance is separate from the unchanged one-minute read.
 assert.deepEqual([...providerJob.matchAll(/^(\s*)timeout-minutes: (\d+)$/gm)].map(match=>[match[1].length,Number(match[2])]),[[4,30],[8,1]]);
 assert.match(providerJob,/runs-on: \[self-hosted, Linux, X64, guix, cold-red-gate, koios-news\]/);
 assert.match(providerJob,/persist-credentials: false/);assert.match(providerJob,/NODE_OPTIONS: ''\n          NODE_PATH: ''/);
 assert.equal((providerJob.match(/secrets\./g)??[]).length,1);assert.match(providerJob,/secrets.CLOUDFLARE_API_TOKEN/);
 assert.doesNotMatch(run,/source |build-public-site|release-site\.mjs|admitted-website|git |curl|fetch|\$\{\{|GH_TOKEN|GITHUB_TOKEN/);
 assert.match(run,/sha256sum --check --status/);assert.match(run,/trap 'rm -rf "\$work"' EXIT/);
 assert.match(run,/"\$artifact\/bin\/node" --no-addons --no-global-search-paths observe-provider-state\.mjs/);
});
for(const success of [true,false])test(`actual workflow run block preserves the ${success?'success':'failure'} outcome and removes scratch`,t=>{
 const f=fixture(t,success?good():{status:1,stdout:'PRIVATE_STDOUT',stderr:'PRIVATE_STDERR'});
 const artifact=join(f.scratch,'artifact');mkdirSync(join(artifact,'bin'),{recursive:true});symlinkSync(providerRoot,join(artifact,'node_modules'));
 // Only the immutable artifact path is relocated. Production carrier and verifier
 // remain genuine; the external process boundary supplies a synthetic response.
 writeFileSync(join(artifact,'bin/node'),`#!/bin/bash\nexec '${process.execPath}' --import '${preload}' --permission --allow-fs-read='${root}' --allow-fs-read='${providerRoot}' --allow-fs-read='${f.scratch}' --allow-fs-write='${f.scratch}' "$@"\n`,{mode:0o700});
 const relocated=run.replace('/gnu/store/3aiif09yrm7vhwyxq03521qpy8217s47-cold-red-gate-deployment-1',artifact);
 const out=spawnSync('/bin/bash',['-c',relocated],{cwd:root,env:{...f.env,NODE_OPTIONS:'',NODE_PATH:''},encoding:'utf8',timeout:10000});
 assert.equal(out.status,success?0:1,out.stderr);assertPrivateOutput(out);assert.equal(f.calls().length,1);assert.deepEqual(readdirSync(join(f.scratch,'runner')),[]);
 assert.equal(JSON.parse(success?out.stdout:out.stderr).status,success?'observed':'refused');
});
test('actual workflow refuses a carrier digest mismatch before any provider process',t=>{
 const f=fixture(t),artifact=join(f.scratch,'artifact');mkdirSync(artifact);symlinkSync(providerRoot,join(artifact,'node_modules'));
 const mismatched=run.replace('/gnu/store/3aiif09yrm7vhwyxq03521qpy8217s47-cold-red-gate-deployment-1',artifact)
  .replace('4f1c014aac42a5e024c3aec54ad1e8f38200db3641b233347789cab4dcfbf6ab','0'.repeat(64));
 const out=spawnSync('/bin/bash',['-c',mismatched],{cwd:root,env:f.env,encoding:'utf8',timeout:10000});
 assert.equal(out.status,1);assert.equal(out.stdout,'');assert.equal(out.stderr,'');assert.deepEqual(f.calls(),[]);assert.deepEqual(readdirSync(join(f.scratch,'runner')),[]);
});
