// Fixed provider metadata read. Never imports a public audit or publication executor.
import {dirname,join} from 'node:path';
import {observeProductionVersion,verifyBinding,TARGET} from '@causeway-services/koios-news-site/carrier';
const bindingSha256='3b5605daef5613d18937b165ebdaf5632657e24560c5e296d6f3ed86df5278a2';
const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iu;
const matches=(value,pattern)=>typeof value==='string'&&!/\s/u.test(value)&&pattern.test(value);
const refuse=reason=>{throw Object.assign(new Error('Provider observation refused'),{reason});};
const permittedReasons=new Set(['arguments','source-identity','credential-binding-unavailable','account-binding','carrier-binding','provider-shape']);

export function observeProviderState({environment=process.env,scratch=process.cwd(),now=()=>new Date()}={}){
 if(!matches(environment.GITHUB_SHA,/^[a-f0-9]{40}$/u)||!matches(environment.GITHUB_RUN_ID,/^[1-9][0-9]{0,19}$/u)
  ||!matches(environment.GITHUB_RUN_ATTEMPT,/^[1-9][0-9]{0,7}$/u))refuse('source-identity');
 if(typeof environment.CLOUDFLARE_API_TOKEN!=='string'||environment.CLOUDFLARE_API_TOKEN.length===0)refuse('credential-binding-unavailable');
 if(environment.CLOUDFLARE_ACCOUNT_ID!=='337e54ee6dc7d488933f473204a6d89e')refuse('account-binding');
 const bindingPath=new URL(import.meta.resolve('@causeway-services/koios-news-site/release-binding')).pathname;
 if(TARGET.accountId!==environment.CLOUDFLARE_ACCOUNT_ID||TARGET.workerName!=='koios-news-primary'
  ||TARGET.hostname!=='koios.news'||TARGET.routePattern!=='koios.news/*'||verifyBinding(bindingPath).digest!==bindingSha256)refuse('carrier-binding');
 // No token appears in argv. Only this exact environment reaches pinned Wrangler.
 const readEnvironment={
  PATH:dirname(process.execPath),HOME:join(scratch,'home'),XDG_CONFIG_HOME:join(scratch,'config'),
  XDG_CACHE_HOME:join(scratch,'cache'),XDG_DATA_HOME:join(scratch,'data'),TMPDIR:join(scratch,'tmp'),
  WRANGLER_LOG_PATH:join(scratch,'logs','wrangler.log'),WRANGLER_SEND_METRICS:'false',CI:'true',
  CLOUDFLARE_ACCOUNT_ID:TARGET.accountId,CLOUDFLARE_API_TOKEN:environment.CLOUDFLARE_API_TOKEN,
 };
 // This genuine admitted carrier verifies pinned Wrangler and rejects empty/split
 // traffic. There is one read invocation, no injected executor and no retry.
 const current=observeProductionVersion({environment:readEnvironment});
 if(!matches(current?.deploymentId,UUID)||!matches(current?.versionId,UUID)
  ||!matches(current?.createdOn,/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/u)
  ||!Number.isFinite(Date.parse(current.createdOn)))refuse('provider-shape');
 const observedAt=now().toISOString();
 return {kind:'koios.website-provider-observation/v1',status:'observed',mode:'read-only',observedAt,
  sourceRevision:environment.GITHUB_SHA,observationRunId:environment.GITHUB_RUN_ID,observationRunAttempt:environment.GITHUB_RUN_ATTEMPT,
  target:{accountId:TARGET.accountId,workerName:TARGET.workerName,bindingSha256},
  current:{deploymentId:current.deploymentId,createdOn:current.createdOn,traffic:[{versionId:current.versionId,percentage:100}]},
  historicalComparison:{status:'prior-provider-identity-unavailable',publicationRunId:'38142736555',
   retainedObservationRunId:'38149634125',retainedObservationProjectionSha256:'08c3d95186d444033fdc3d8394357878ecac37c5fbdb33eb81f9b939dafb7116'},
  successorPublication:{runId:'38145280191',effect:'unobserved'},
  historyCoverage:'recent-provider-read-not-a-complete-ledger',candidateManifestBinding:'unobserved',currentPublicAssets:'unobserved'};
}

if(import.meta.main){
 try{if(process.argv.length!==2)refuse('arguments');console.log(JSON.stringify(observeProviderState()));}
 catch(error){
  let reason='provider-read-unavailable';
  // Even a hostile exception accessor cannot leak a value or replace this outcome.
  try{const value=error?.reason;if(permittedReasons.has(value))reason=value;}catch{}
  console.error(JSON.stringify({kind:'koios.website-provider-observation/v1',status:'refused',reason}));process.exitCode=1;
 }
}
