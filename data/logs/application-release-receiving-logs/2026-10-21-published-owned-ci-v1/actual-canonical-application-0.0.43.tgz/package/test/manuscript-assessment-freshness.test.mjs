import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {draftHasExpired} from "../src/news-line/throughput-feedback.mjs";

const observedAt="2026-10-13T19:00:00.000Z";
const seconds=48*60*60;
const edition=(draftedAt,extra={})=>({
  state:"drafted",storyId:"news-event:one",candidateId:"ni:///sha-256;candidate",
  draftedAt,...extra,
});

test("a new independently submitted manuscript is not aged from an earlier draft of the same unpublished story",()=>{
  const historical=edition("2026-10-10T08:00:00.000Z",{candidateId:"old"});
  const renewed=edition("2026-10-13T18:00:00.000Z",{candidateId:"fresh",revises:"old"});
  assert.equal(historical.storyId,renewed.storyId);
  assert.equal(draftHasExpired(historical,observedAt,seconds),true);
  assert.equal(draftHasExpired(renewed,observedAt,seconds),false);
  // Historical custody does not alter the new candidate's own date.
  const withHistorical=[historical,renewed];
  assert.deepEqual(withHistorical.filter(e=>!draftHasExpired(e,observedAt,seconds))
    .map(e=>e.candidateId),["fresh"]);
});

test("unpublished new editions and revisions of published pages share the same per-manuscript deadline",()=>{
  const newArticle=edition("2026-10-13T18:00:00.000Z");
  const revision=edition("2026-10-13T18:00:00.000Z",{firstPublished:"2026-09-30"});
  for(const item of [newArticle,revision])
    assert.equal(draftHasExpired(item,observedAt,seconds),false);
  assert.equal(draftHasExpired(edition("2026-10-11T19:00:00.000Z"),observedAt,seconds),true,
    "the expiry boundary itself refuses an original manuscript");
  assert.equal(draftHasExpired(edition("2026-10-11T19:00:00.001Z"),observedAt,seconds),false);
});

test("updating or retrying an expired exact manuscript cannot reset its age",()=>{
  const old=edition("2026-10-10T08:00:00.000Z",
    {updatedAt:"2026-10-13T18:59:00.000Z",attempts:8,firstPublished:"2026-10-09"});
  assert.equal(draftHasExpired(old,observedAt,seconds),true);
});

test("uncertain clocks and unbounded freshness grants cannot quietly admit publication",()=>{
  for(const value of [undefined,null,"", "malformed", "2026-10-14T12:00:00.000Z"])
    assert.throws(()=>draftHasExpired(edition(value),observedAt,seconds),/timestamps/);
  for(const value of [NaN,0,-1,Infinity,1.2,null])
    assert.throws(()=>draftHasExpired(edition("2026-10-13T18:00:00.000Z"),observedAt,value),/positive whole seconds/);
  assert.throws(()=>draftHasExpired(edition("2026-10-13T18:00:00.000Z"),"bad-time",seconds),/timestamps/);
});

test("the actual assessment handler uses manuscript identity, not the oldest story ID",()=>{
  const source=readFileSync(new URL("../src/news-line/stages.mjs",import.meta.url),"utf8");
  assert.match(source,/draftHasExpired\(edition, at, config\.freshness\.storySeconds\)/u);
  assert.doesNotMatch(source,/storyAt\s*=\s*new Map/u);
  assert.match(source,/advanceEdition\(roots, edition, "refused", at, \{ reason: "story-went-stale" \}\)/u);
  assert.match(source,/const demand = assessmentDemand\(context, edition, manuscriptSource\)/u);
  assert.match(source,/invoke = invokeEditorialAssessment/u);
});
