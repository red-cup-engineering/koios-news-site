/** Authenticated, encrypted recovery of the durable newsroom on a separate cloud carrier. */
import {createCipheriv,createDecipheriv,createHash,randomBytes} from 'node:crypto';
import {createReadStream,createWriteStream,readFileSync,writeFileSync,appendFileSync,statSync,statfsSync,mkdirSync,mkdtempSync,rmSync,readdirSync,existsSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {spawn,execFileSync} from 'node:child_process';
import {pipeline} from 'node:stream/promises';

const MAGIC=Buffer.from('KOIOSBK1');
const REPOSITORY='causeway-services/koios-news-data';
const sha=value=>createHash('sha256').update(value).digest('hex');
const json=path=>JSON.parse(readFileSync(path,'utf8'));
export function readRecoveryKey(path){
  const value=readFileSync(path,'utf8').trim();
  if(!/^[a-f0-9]{64}$/.test(value))throw new Error('Recovery key must contain exactly 32 bytes encoded as hex');
  if((statSync(path).mode&0o077)!==0)throw new Error('Recovery key must be private to its cloud owner');
  return Buffer.from(value,'hex');
}
function filesIn(root,relative=''){
  return readdirSync(join(root,relative),{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name)).flatMap(entry=>{
    const path=join(relative,entry.name);
    if(entry.name==='.coordination.lease'||['feedback','website-releases','recovery-upload','recovery-manifest.json','line/editorial-execution.lock'].includes(path))return [];
    if(entry.isDirectory())return filesIn(root,path);
    if(!entry.isFile())throw new Error(`Recovery refuses a non-regular state entry: ${path}`);
    return [path];
  });
}
async function encryptedHash(path){const h=createHash('sha256');for await(const bytes of createReadStream(path))h.update(bytes);return h.digest('hex');}
export async function createRecoverySnapshot({dataRoot,keyPath,destination,at=new Date().toISOString()}){
  const key=readRecoveryKey(keyPath);
  if(statfsSync(dataRoot).bavail*statfsSync(dataRoot).bsize<1024*1024*1024)throw new Error('Recovery needs at least 1 GiB available before snapshotting; recover cloud capacity');
  mkdirSync(destination,{recursive:true,mode:0o700});
  const nonce=randomBytes(12),name=`koios-newsroom-${at.replace(/[-:.]/g,'')}.enc`,path=join(destination,name),temporary=path+'.pending';
  const manifest={kind:'koios.news.recovery-manifest/v1',at,files:[]};
  for(const relative of filesIn(dataRoot))manifest.files.push({path:relative,bytes:statSync(join(dataRoot,relative)).size,sha256:await encryptedHash(join(dataRoot,relative))});
  const workspace=mkdtempSync(join(destination,'.recovery-'));
  try{
    writeFileSync(join(workspace,'recovery-manifest.json'),JSON.stringify(manifest)+'\n',{mode:0o600});
    writeFileSync(temporary,Buffer.concat([MAGIC,nonce]),{mode:0o600});
    const archive=spawn('tar',['--create','--gzip','--file=-','--directory',dataRoot,'--exclude=.coordination.lease','--exclude=./feedback','--exclude=./website-releases','--exclude=./recovery-upload','--exclude=./recovery-manifest.json','--exclude=./line/editorial-execution.lock','.','--directory',workspace,'recovery-manifest.json'],{stdio:['ignore','pipe','pipe']});
    let error='';archive.stderr.on('data',bytes=>{error=(error+bytes.toString()).slice(-2000);});
    const completed=new Promise((yes,no)=>{archive.once('error',no);archive.once('close',code=>code===0?yes():no(new Error(`Cloud snapshot failed: ${error}`)));});
    const cipher=createCipheriv('aes-256-gcm',key,nonce);cipher.setAAD(MAGIC);
    try{await Promise.all([pipeline(archive.stdout,cipher,createWriteStream(temporary,{flags:'a',mode:0o600})),completed]);}catch(e){archive.kill();throw e;}
    appendFileSync(temporary,cipher.getAuthTag());
    const {renameSync}=await import('node:fs');renameSync(temporary,path);
    const receipt={kind:'koios.news.encrypted-recovery/v1',at,archive:name,bytes:statSync(path).size,sha256:await encryptedHash(path),keyFingerprint:sha(key),files:manifest.files.length,format:'KOIOSBK1 + 12-byte nonce + AES-256-GCM(tar.gz) + 16-byte authentication tag'};
    writeFileSync(path+'.json',JSON.stringify(receipt,null,2)+'\n',{mode:0o600});
    return {path,receiptPath:path+'.json',receipt};
  }finally{rmSync(workspace,{recursive:true,force:true});rmSync(temporary,{force:true});}
}

export async function verifyRecoverySnapshot({archivePath,receiptPath=archivePath+'.json',keyPath,destination}){
  const receipt=json(receiptPath),key=readRecoveryKey(keyPath),size=statSync(archivePath).size;
  if(size!==receipt.bytes||await encryptedHash(archivePath)!==receipt.sha256||sha(key)!==receipt.keyFingerprint)throw new Error('Recovery archive or key differs from its recorded digest');
  if(existsSync(destination)&&readdirSync(destination).length)throw new Error('Recovery verification requires an empty isolated destination');
  mkdirSync(destination,{recursive:true,mode:0o700});
  const workspace=mkdtempSync(join(tmpdir(),'koios-recovery-'));
  try{
    const {openSync,readSync,closeSync}=await import('node:fs');const fd=openSync(archivePath,'r');const header=Buffer.alloc(20),tag=Buffer.alloc(16);
    try{readSync(fd,header,0,20,0);readSync(fd,tag,0,16,size-16);}finally{closeSync(fd);}
    if(size<36||!header.subarray(0,8).equals(MAGIC))throw new Error('Unknown recovery archive');
    const decipher=createDecipheriv('aes-256-gcm',key,header.subarray(8));decipher.setAAD(MAGIC);decipher.setAuthTag(tag);
    const plain=join(workspace,'snapshot.tar.gz');
    // Authenticate the whole archive before any extraction can mutate the destination.
    await pipeline(createReadStream(archivePath,{start:20,end:size-17}),decipher,createWriteStream(plain,{mode:0o600}));
    const listing=execFileSync('tar',['--list','--gzip','--file',plain],{encoding:'utf8',maxBuffer:16*1024*1024});
    if(listing.split('\n').filter(Boolean).some(path=>path.startsWith('/')||path.split('/').includes('..')))throw new Error('Recovery contains an unsafe path');
    execFileSync('tar',['--extract','--gzip','--file',plain,'--directory',destination,'--no-same-owner','--no-same-permissions']);
    const manifest=json(join(destination,'recovery-manifest.json'));
    if(manifest.kind!=='koios.news.recovery-manifest/v1'||manifest.files.length!==receipt.files)throw new Error('Recovery manifest differs from the receipt');
    if(JSON.stringify(filesIn(destination).sort())!==JSON.stringify(manifest.files.map(file=>file.path).sort()))throw new Error('Recovered state contains missing or unrecorded files');
    for(const file of manifest.files){const restoredPath=join(destination,file.path);if(statSync(restoredPath).size!==file.bytes||await encryptedHash(restoredPath)!==file.sha256)throw new Error(`Recovered state differs: ${file.path}`);}
    return {verified:true,files:manifest.files.length,at:manifest.at};
  }finally{rmSync(workspace,{recursive:true,force:true});}
}

export async function publishRecoverySnapshot(options){
  const gh=(...args)=>execFileSync('gh',args,{encoding:'utf8',timeout:120000,maxBuffer:1024*1024}).trim();
  const snapshot=await createRecoverySnapshot(options);
  await options.onCaptured?.();
  const proof=join(options.destination,'restore-proof');
  try{
    const restored=await verifyRecoverySnapshot({...options,archivePath:snapshot.path,receiptPath:snapshot.receiptPath,destination:proof});
    const tag=`koios-recovery-${snapshot.receipt.at.replace(/[-:.]/g,'')}`;
    gh('release','create',tag,snapshot.path,snapshot.receiptPath,'--repo',REPOSITORY,'--target','main','--title','Encrypted cloud newsroom recovery','--notes',`Authenticated recovery snapshot; all ${restored.files} state files restored and digest-verified in isolation before upload. Recovery key is held in the cloud private configuration and KOIOS_BACKUP_KEY repository secret. Feedback and disposable website builds are excluded.`);
    const release=JSON.parse(gh('api',`repos/${REPOSITORY}/releases/tags/${tag}`));
    const observed=release.assets.find(asset=>asset.name===snapshot.receipt.archive);
    if(!observed||observed.size!==snapshot.receipt.bytes||observed.digest!==`sha256:${snapshot.receipt.sha256}`)throw new Error('GitHub recovery asset does not match the verified archive');
    const result={...snapshot.receipt,tag,repository:REPOSITORY,releaseUrl:release.html_url,restoreVerifiedAt:new Date().toISOString()};
    mkdirSync(join(options.dataRoot,'feedback'),{recursive:true});writeFileSync(join(options.dataRoot,'feedback','recovery.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});
    return result;
  }finally{rmSync(proof,{recursive:true,force:true});rmSync(snapshot.path,{force:true});rmSync(snapshot.receiptPath,{force:true});}
}

if(import.meta.main){
  const dataRoot=resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT??''),keyPath=process.env.KOIOS_BACKUP_KEY_PATH;
  const command=process.argv[2]??'publish';
  if(!keyPath||(!process.env.KOIOS_NEWSROOM_DATA_ROOT&&command!=='verify'))throw new Error('Explicit cloud state root and private recovery key are required');
  if(command==='verify')console.log(JSON.stringify(await verifyRecoverySnapshot({archivePath:resolve(process.argv[3]),keyPath,destination:resolve(process.argv[4])})));
  else if(command==='check'){readRecoveryKey(keyPath);if(!existsSync(join(dataRoot,'line','publication-replay','published')))throw new Error('The durable publication ledger is missing');console.log(JSON.stringify({mode:'read-only',ready:true}));}
  else if(command==='publish'){
    const prior=join(dataRoot,'feedback','recovery.json');
    if(!process.argv.includes('--force')&&existsSync(prior)&&Date.now()-Date.parse(json(prior).at)<20*60*60*1000){console.log(JSON.stringify({status:'already-captured',at:json(prior).at}));process.exit(0);}
    const lease=spawn('flock',['--exclusive',join(dataRoot,'line','editorial-execution.lock'),'bash','-c','printf "locked\\n"; cat >/dev/null'],{stdio:['pipe','pipe','pipe']});
    const leaseExit=new Promise((yes,no)=>{lease.once('error',no);lease.once('close',code=>code===0?yes():no(new Error('Recovery could not acquire the newsroom stage lock')));});
    try{
      await new Promise((yes,no)=>{lease.stdout.once('data',yes);lease.once('error',no);lease.once('close',()=>no(new Error('Recovery lock acquisition failed')));});
      console.log(JSON.stringify(await publishRecoverySnapshot({dataRoot,keyPath,destination:join(dataRoot,'recovery-upload'),onCaptured:async()=>{lease.stdin.end();await leaseExit;}})));
    }finally{lease.stdin.end();await leaseExit;}
  }else throw new Error('Use publish, check, or verify');
}
