import assert from "node:assert/strict";
import { createHash, generateKeyPairSync, sign } from "node:crypto";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import { listPublishedLedgerEntries, planRoutinePublication, recordPublishedPost, recoverRoutinePublication, writeRoutinePublication } from "../src/offline-publication.mjs";
import { canonicalJson } from "@red-cup-engineering/json-services-section/canonical";

const PROPERTY = { name: "Cedar Ledger", origin: "https://cedar.example", tagline: "A sample news property", language: "en", locale: "en_US", sections: [{ slug: "news", title: "News" }], masthead: { publisher: "Cedar", editorialMethod: "Source-grounded reporting", bylineDescriptions: {} }, content: {} };
const digest = (value) => `sha256:${createHash("sha256").update(value).digest("hex")}`;
function draft() {
  return "---\ntitle: Exact accepted item\ndate: 2026-08-29\ndraft: true\nslug: exact-accepted-item\nsection: news\n---\nA bounded, editorially admitted item.\n";
}
function acceptance(bytes, additions = {}) {
  return { slug: "exact-accepted-item", manuscriptDigest: digest(bytes), disposition: "accept", publishable: true, serviceAccepted: true, contract: "ni:///sha-256;GTSsfC0lmcjPLQvtlGmYwLJLCa9pirz1d8oUqRweioo", selectedTool: "submit_editorial_acceptance", toolSelectionValidated: true, toolSelectionDigest: "ni:///sha-256;example", ...additions };
}
function setup() {
  const temp = mkdtempSync(join(tmpdir(), "koios-routine-publication-"));
  const contentDir = join(temp, "posts");
  const propertyContentDir = join(temp, "property");
  mkdirSync(contentDir);
  mkdirSync(join(propertyContentDir, "posts"), { recursive: true });
  const draftPath = join(contentDir, "exact-accepted-item.md");
  const admissionPath = join(temp, "admission.json");
  const authorityGrantPath = join(temp, "authority-grant.json");
  const authorityKeysPath = join(temp, "authority-keys.json");
  const authorityNow = "2026-08-29T12:00:00.000Z";
  const bytes = draft();
  writeFileSync(draftPath, bytes);
  const existingPost = "---\ntitle: Existing public item\ndate: 2026-08-28\ndraft: false\nslug: existing-post\nsection: news\n---\nA previously published corpus item.\n";
  writeFileSync(join(contentDir, "existing-post.md"), existingPost);
  writeFileSync(join(propertyContentDir, "posts", "existing-post.md"), existingPost);
  writeFileSync(admissionPath, `${JSON.stringify(acceptance(bytes))}\n`);
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const issuerKeyId = "routine-authority-key-0001";
  const unsignedGrant = { expiresAt: "2026-08-30T00:00:00.000Z", grantId: "routine-grant-id-0001", issuedAt: "2026-08-29T00:00:00.000Z", issuerKeyId, kind: "koios.news.editorial-publication-grant/v1", scope: { manuscript: { digest: digest(bytes), slug: "exact-accepted-item" }, type: "exact-manuscript" } };
  const signature = sign(null, Buffer.from(canonicalJson(unsignedGrant), "utf8"), privateKey).toString("base64url");
  writeFileSync(authorityGrantPath, `${canonicalJson({ ...unsignedGrant, signature })}\n`);
  writeFileSync(authorityKeysPath, `${JSON.stringify({ [issuerKeyId]: publicKey.export({ format: "jwk" }).x })}\n`);
  return { property: PROPERTY, propertyContentDir, temp, contentDir, draftPath, admissionPath, authorityGrantPath, authorityKeysPath, authorityNow, outputDir: join(temp, "candidate"), replayRoot: join(temp, "replay"), bytes };
}

test("defaults to a no-write exact-admission plan", () => {
  const fixture = setup();
  try {
    const result = planRoutinePublication(fixture);
    assert.equal(result.disposition, "ready");
    assert.equal(result.executionMode, "dry-run");
    assert.equal(result.authority, "authenticated-editorial-publication-grant");
    assert.deepEqual(result.effects, []);
    assert.equal(existsSync(fixture.outputDir), false);
    assert.match(result.candidate.sourceSha256, /^sha256:[a-f0-9]{64}$/);
    assert.equal(result.candidate.corpusFileCount, 2);
    assert.match(result.candidate.corpusSha256, /^sha256:[a-f0-9]{64}$/);
    assert.equal(result.provenance.runtime.executionMode, "offline-news-property-candidate");
    assert.equal(result.provenance.runtime.providerInvocations, 0);
    assert.equal(result.provenance.authority.scope, "exact-manuscript");
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("refuses a record not bound to the exact draft or an unvalidated selection", () => {
  const fixture = setup();
  try {
    writeFileSync(fixture.admissionPath, JSON.stringify(acceptance(fixture.bytes, { manuscriptDigest: "sha256:wrong" })));
    assert.throws(() => planRoutinePublication(fixture), /manuscriptDigest/);
    writeFileSync(fixture.admissionPath, JSON.stringify(acceptance(fixture.bytes, { toolSelectionValidated: false })));
    assert.throws(() => planRoutinePublication(fixture), /toolSelectionValidated/);
    assert.equal(existsSync(fixture.outputDir), false);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("refuses absent, expired, or byte-inexact publication authority before candidate writes", () => {
  const fixture = setup();
  try {
    assert.throws(() => planRoutinePublication({ ...fixture, authorityGrantPath: undefined }), /authorityGrantPath/u);
    assert.throws(() => planRoutinePublication({ ...fixture, authorityNow: "2026-08-30T00:00:00.000Z" }), /expired/u);
    const changed = `${fixture.bytes}changed`;
    writeFileSync(fixture.draftPath, changed);
    writeFileSync(fixture.admissionPath, `${JSON.stringify(acceptance(changed))}\n`);
    assert.throws(() => planRoutinePublication(fixture), /does not bind/u);
    assert.equal(existsSync(fixture.outputDir), false);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("refuses corpus symlinks before any candidate write", () => {
  const fixture = setup();
  try {
    symlinkSync(fixture.draftPath, join(fixture.contentDir, "linked-draft.md"));
    assert.throws(() => planRoutinePublication(fixture), /content corpus contains a symlink/);
    assert.equal(existsSync(fixture.outputDir), false);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("writes a marked two-phase offline candidate without changing source bytes or losing public corpus posts", () => {
  const fixture = setup();
  try {
    const result = writeRoutinePublication(fixture);
    assert.equal(result.disposition, "written");
    assert.equal(readFileSync(fixture.draftPath, "utf8"), fixture.bytes);
    assert.equal(existsSync(join(fixture.outputDir, ".koios-routine-publication-current")), true);
    assert.equal(existsSync(join(fixture.outputDir, "public", "retained.txt")), false);
    assert.equal(readFileSync(join(fixture.outputDir, "public", "manifest.json"), "utf8").includes(fixture.temp), false);
    assert.match(readFileSync(join(fixture.outputDir, "public", "index.html"), "utf8"), /Exact accepted item/);
    assert.match(readFileSync(join(fixture.outputDir, "public", "index.html"), "utf8"), /Existing public item/);
    assert.match(readFileSync(join(fixture.outputDir, "public", "posts", "existing-post", "index.html"), "utf8"), /Existing public item/);
    assert.deepEqual(JSON.parse(readFileSync(join(fixture.outputDir, "public", "desks.json"), "utf8")).kind, "news-property.public-desks/v1");
    assert.match(readFileSync(join(fixture.outputDir, "public", "feed.xml"), "utf8"), /cedar\.example/u);
    const receipt = JSON.parse(readFileSync(join(fixture.outputDir, "routine-publication-receipt.json"), "utf8"));
    const manifest = JSON.parse(readFileSync(join(fixture.outputDir, "public", "manifest.json"), "utf8"));
    assert.equal(manifest.provenance.candidateCorpusSha256, receipt.provenance.candidateCorpusSha256);
    assert.equal(manifest.provenance.propertyRecordSha256, receipt.provenance.propertyRecordSha256);
    assert.notEqual(receipt.provenance.candidateCorpusSha256, receipt.provenance.projectedCorpusSha256);
    assert.equal(receipt.provenance.sourceSha256, digest(fixture.bytes));
    assert.equal(receipt.provenance.corpusFileCount, 2);
    assert.match(receipt.provenance.corpusSha256, /^sha256:[a-f0-9]{64}$/);
    assert.equal(receipt.provenance.transition.sourceMutated, false);
    assert.equal(receipt.authority.kind, "Ed25519");
    assert.equal(receipt.authority.scope, "exact-manuscript");
    assert.equal(receipt.authority.issuedAt, "2026-08-29T00:00:00.000Z");
    assert.equal(receipt.authority.expiresAt, "2026-08-30T00:00:00.000Z");
    assert.equal(receipt.disposition, "offline-news-property-candidate");
    assert.match(receipt.newsProperty.manifestSha256, /^sha256:[a-f0-9]{64}$/u);
    assert.ok(receipt.newsProperty.artifactCount > 0);
    assert.match(result.consumptionId, /^grant:/u);
    assert.throws(() => writeRoutinePublication(fixture), /candidate output exists/u);
    assert.throws(() => writeRoutinePublication({ ...fixture, replace: true }), /already been consumed/u);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("persists the complete staged candidate before consuming publication authority", () => {
  const fixture = setup();
  try {
    let staged = false, consumed = false, published = false;
    const result = writeRoutinePublication({
      ...fixture,
      persistCandidate: (path) => {
        assert.equal(path, `${fixture.outputDir}.next`);
        assert.equal(existsSync(join(path, "routine-publication-receipt.json")), true);
        assert.equal(existsSync(join(path, "public", "manifest.json")), true);
        staged = true;
      },
      replayStore: { consumeIfUnused() { assert.equal(staged, true); consumed = true; return true; } },
      persistPublishedParent: (path) => { assert.equal(path, fixture.temp); published = true; },
    });
    assert.equal(result.disposition, "written");
    assert.equal(consumed, true);
    assert.equal(published, true);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("does not consume publication authority when staged-candidate persistence fails", () => {
  const fixture = setup();
  try {
    let consumed = false;
    assert.throws(() => writeRoutinePublication({
      ...fixture,
      persistCandidate: () => { throw new Error("candidate fsync failed"); },
      replayStore: { consumeIfUnused() { consumed = true; return true; } },
    }), /candidate fsync failed/u);
    assert.equal(consumed, false);
    assert.equal(existsSync(fixture.outputDir), false);
    assert.equal(existsSync(`${fixture.outputDir}.next`), false);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("recovers a persisted candidate after authority consumption without reusing authority", () => {
  const fixture = setup();
  try {
    assert.throws(() => writeRoutinePublication({
      ...fixture,
      renameCandidate: () => { throw new Error("final candidate rename failed"); },
    }), /final candidate rename failed/u);
    assert.equal(existsSync(fixture.outputDir), false);
    assert.equal(existsSync(`${fixture.outputDir}.next`), true);
    assert.throws(() => writeRoutinePublication(fixture), /recovery staging exists/u);
    const recovered = recoverRoutinePublication(fixture);
    assert.equal(recovered.disposition, "recovered");
    assert.equal(recovered.consumptionId, "grant:routine-grant-id-0001");
    assert.equal(existsSync(fixture.outputDir), true);
    assert.equal(existsSync(`${fixture.outputDir}.next`), false);
    assert.match(readFileSync(join(fixture.outputDir, "public", "index.html"), "utf8"), /Exact accepted item/);
    assert.throws(() => writeRoutinePublication({ ...fixture, replace: true }), /already been consumed/u);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

function stageConsumedCandidate(fixture) {
  assert.throws(() => writeRoutinePublication({
    ...fixture,
    renameCandidate: () => { throw new Error("final candidate rename failed"); },
  }), /final candidate rename failed/u);
  return `${fixture.outputDir}.next`;
}

test("recovery rejects a receipt modified after its authority consumption", () => {
  const fixture = setup();
  try {
    const staging = stageConsumedCandidate(fixture);
    const receiptPath = join(staging, "routine-publication-receipt.json");
    const receipt = JSON.parse(readFileSync(receiptPath, "utf8"));
    receipt.slug = "tampered-item";
    writeFileSync(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`);
    assert.throws(() => recoverRoutinePublication(fixture), /matching durable authority consumption record/u);
    assert.equal(existsSync(staging), true);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("recovery rejects a public manifest modified after authority consumption", () => {
  const fixture = setup();
  try {
    const staging = stageConsumedCandidate(fixture);
    const manifestPath = join(staging, "public", "manifest.json");
    writeFileSync(manifestPath, `${readFileSync(manifestPath, "utf8")} `);
    assert.throws(() => recoverRoutinePublication(fixture), /does not match its sealed receipt/u);
    assert.equal(existsSync(staging), true);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("recovery rejects changed or unsealed public artifacts after authority consumption", () => {
  for (const mutate of [
    (staging) => writeFileSync(join(staging, "public", "index.html"), "tampered\n"),
    (staging) => writeFileSync(join(staging, "public", "unsealed.txt"), "extra\n"),
  ]) {
    const fixture = setup();
    try {
      const staging = stageConsumedCandidate(fixture);
      mutate(staging);
      assert.throws(() => recoverRoutinePublication(fixture), /artifact digest mismatch|unsealed artifact/u);
      assert.equal(existsSync(staging), true);
    } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
  }
});

test("forms a candidate independently of obsolete static production carry-forward", () => {
  const fixture = setup();
  try {
    assert.doesNotThrow(() => planRoutinePublication(fixture));
    assert.equal(writeRoutinePublication(fixture).disposition, "written");
    assert.equal(existsSync(join(fixture.outputDir, "public", "retained.txt")), false);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

/**
 * Admit a second, independent post into the same fixture corpus, signed by
 * its own key but recorded in the fixture's shared authority key map, so a
 * second writeRoutinePublication call can target it without disturbing the
 * first job's own draft/admission/grant.
 */
function admitSecondJob(fixture, { slug, title }) {
  const bytes = `---\ntitle: ${title}\ndate: 2026-08-30\ndraft: true\nslug: ${slug}\nsection: news\n---\nA second, independently admitted item.\n`;
  const draftPath = join(fixture.contentDir, `${slug}.md`);
  writeFileSync(draftPath, bytes);
  const admissionPath = join(fixture.temp, `${slug}-admission.json`);
  writeFileSync(admissionPath, `${JSON.stringify(acceptance(bytes, { slug, manuscriptDigest: digest(bytes) }))}\n`);
  const { privateKey, publicKey } = generateKeyPairSync("ed25519");
  const issuerKeyId = `routine-authority-key-${slug}`;
  const unsignedGrant = { expiresAt: "2026-08-31T00:00:00.000Z", grantId: `routine-grant-id-${slug}`, issuedAt: "2026-08-30T00:00:00.000Z", issuerKeyId, kind: "koios.news.editorial-publication-grant/v1", scope: { manuscript: { digest: digest(bytes), slug }, type: "exact-manuscript" } };
  const signature = sign(null, Buffer.from(canonicalJson(unsignedGrant), "utf8"), privateKey).toString("base64url");
  const authorityGrantPath = join(fixture.temp, `${slug}-authority-grant.json`);
  writeFileSync(authorityGrantPath, `${canonicalJson({ ...unsignedGrant, signature })}\n`);
  const keys = JSON.parse(readFileSync(fixture.authorityKeysPath, "utf8"));
  keys[issuerKeyId] = publicKey.export({ format: "jwk" }).x;
  writeFileSync(fixture.authorityKeysPath, `${JSON.stringify(keys)}\n`);
  return { ...fixture, draftPath, admissionPath, authorityGrantPath, authorityNow: "2026-08-30T12:00:00.000Z", outputDir: join(fixture.temp, `candidate-${slug}`), bytes };
}

test("regeneration invariant: a later candidate's discovery surfaces include every earlier routine-published post", () => {
  const fixture = setup();
  try {
    const first = writeRoutinePublication(fixture);
    assert.equal(first.disposition, "written");
    assert.equal(first.publishedLedger.recorded, true);
    // The tracked corpus post is still untouched draft: true — publication
    // state lives only in the durable ledger, never by mutating this file.
    assert.equal(readFileSync(fixture.draftPath, "utf8"), fixture.bytes);
    assert.match(readFileSync(fixture.draftPath, "utf8"), /draft: true/);

    const second = admitSecondJob(fixture, { slug: "second-published-item", title: "Second published item" });
    const result = writeRoutinePublication(second);
    assert.equal(result.disposition, "written");
    assert.equal(result.publishedLedger.recorded, true);

    // The second candidate's own build must include BOTH posts in every
    // discovery surface, atomically with its own release, even though the
    // first post's corpus source file was never touched.
    const secondPublic = join(second.outputDir, "public");
    for (const [file, pattern] of [["index.html", /Exact accepted item/], ["feed.xml", /Exact accepted item/], ["feed.atom", /Exact accepted item/], ["sitemap.xml", /exact-accepted-item/]]) {
      assert.match(readFileSync(join(secondPublic, file), "utf8"), pattern, `${file} must include the earlier routine-published post`);
    }
    assert.equal(existsSync(join(secondPublic, "posts", "exact-accepted-item", "index.html")), true);
    assert.match(readFileSync(join(secondPublic, "index.html"), "utf8"), /Second published item/);

    // The first candidate's own build (formed before the second post ever
    // existed) is untouched by the second candidate's ledger write.
    assert.doesNotMatch(readFileSync(join(fixture.outputDir, "public", "index.html"), "utf8"), /Second published item/);

    const ledgerEntries = listPublishedLedgerEntries(fixture.replayRoot);
    assert.deepEqual(ledgerEntries.map((entry) => entry.relative), ["exact-accepted-item.md", "second-published-item.md"]);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("custody-enforced routine builds bind prior and admitted posts to a published ledger", () => {
  const fixture = setup();
  try {
    const existing = readFileSync(join(fixture.propertyContentDir, "posts", "existing-post.md"), "utf8");
    assert.equal(recordPublishedPost({ replayRoot: fixture.replayRoot, slug: "existing-post", projectedSource: existing }).recorded, true);
    const result = writeRoutinePublication({ ...fixture, property: { ...PROPERTY, content: { requirePublishedLedger: true } } });
    assert.equal(result.disposition, "written");
    assert.match(readFileSync(join(fixture.outputDir, "public", "index.html"), "utf8"), /Exact accepted item/);
    assert.match(readFileSync(join(fixture.outputDir, "public", "index.html"), "utf8"), /Existing public item/);
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});

test("recordPublishedPost keeps each slug's current version and never throws on a failed durable write", () => {
  const fixture = setup();
  try {
    assert.deepEqual(recordPublishedPost({ replayRoot: undefined, slug: "x", projectedSource: "y" }), { recorded: false, reason: "no replayRoot" });
    const first = recordPublishedPost({ replayRoot: fixture.replayRoot, slug: "exact-accepted-item", projectedSource: "one\n" });
    assert.equal(first.recorded, true);
    assert.equal(recordPublishedPost({ replayRoot: fixture.replayRoot, slug: "exact-accepted-item", projectedSource: "one\n" }).reason, "already-recorded");
    const replayed = recordPublishedPost({ replayRoot: fixture.replayRoot, slug: "exact-accepted-item", projectedSource: "two\n", supersede: false });
    assert.equal(replayed.reason, "already-recorded");
    const second = recordPublishedPost({ replayRoot: fixture.replayRoot, slug: "exact-accepted-item", projectedSource: "two\n" });
    assert.equal(second.recorded, true);
    assert.equal(readFileSync(join(fixture.replayRoot, "published", "exact-accepted-item.md"), "utf8"), "two\n");
    assert.equal(readFileSync(join(fixture.replayRoot, "published-versions", "exact-accepted-item", `${second.superseded}.md`), "utf8"), "one\n");
  } finally { rmSync(fixture.temp, { recursive: true, force: true }); }
});
