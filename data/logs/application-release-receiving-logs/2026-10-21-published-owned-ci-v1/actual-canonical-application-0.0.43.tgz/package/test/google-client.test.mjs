import {test} from 'node:test';
import assert from 'node:assert/strict';
import {googleRequest} from '../scripts/google-client.mjs';
test('Google observation recovers transport and temporary service failures',async()=>{
 let attempts=0;
 const result=await googleRequest('https://google.test/read',{}, {wait:async()=>{},fetchImpl:async()=>{attempts++;if(attempts===1)throw new TypeError('fetch failed');return new Response('{}',{status:attempts===2?503:200});}});
 assert.equal(result.status,200);assert.equal(attempts,3);
});
test('Missing Google access is not retried or made successful',async()=>{
 let attempts=0;
 const result=await googleRequest('https://google.test/read',{}, {wait:async()=>{},fetchImpl:async()=>{attempts++;return new Response('{}',{status:403});}});
 assert.equal(result.status,403);assert.equal(attempts,1);
});
