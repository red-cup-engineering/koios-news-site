import test from 'node:test';
import assert from 'node:assert/strict';
import { releasedClaimsAsMarketObservation } from '../src/market-claim-observation.mjs';
import { withCorrection } from '../src/news/topology/claim.mjs';
import { marketGame } from '@red-cup-engineering/mandate-portfolio-allocation-service/market-game';

const issuerUrl = 'https://www.ondas.com/post/ondas-announces-regna-ai-powered-by-palantir-to-advance-sovereign-ai';
const event = {
  subject: 'urn:public-event:regna-ai',
  claims: [{
    id: 'ondas.1', proposition: { predicate: 'forms', object: 'Regna AI' },
    scope: { entity: 'ONDS' },
    time: { asserted: '2026-10-12T15:30:00Z', valid: '2026-10-12' },
    force: 'announces', provenance: { witness: 'Ondas', citation: issuerUrl },
    status: 'supported',
  }],
};
const edition = { state: 'released', candidateId: 'candidate-regna',
  releaseManifest: 'release:synthetic', releasedAt: '2026-10-12T16:00:00Z' };
const project = (overrides = {}) => releasedClaimsAsMarketObservation({
  bundle: event, edition, publicationUrl: 'https://koios.news/regna-research/',
  sourceEvidenceIds: ['urn:source:issuer-release'], observedAt: '2026-10-12T16:05:00Z',
  ...overrides,
});

test('a released dated source becomes a shared market-game observation, not a trading signal', () => {
  const move = project();
  assert.equal(move.kind, 'observe');
  assert.equal(move.observation.availableAt, edition.releasedAt);
  assert.equal(move.observation.source, 'https://koios.news/regna-research/');
  assert.equal(move.observation.value.probabilityEstablished, false);
  assert.equal(move.observation.value.financiallyActionable, false);
  assert.equal(move.tradeEligible, false);
  assert.equal(move.orderEffect, false);
  const state = marketGame.extend(marketGame.initialPosition(), move).state;
  assert.ok(state.observations[move.observation.id]);
  assert.equal(state.forecast, null, 'a publisher claim is not a forecast');
  assert.deepEqual(state.decisions, {}, 'no order was produced');
});

test('corrected and opposed claims retain history, not a flattened sentiment label', () => {
  const correction = { id: 'ondas.2', corrects: 'ondas.1',
    proposition: { predicate: 'clarifies', object: 'first customer is Ondas' },
    time: { asserted: '2026-10-12T15:40:00Z' }, force: 'corrects',
    provenance: { witness: 'Ondas', citation: issuerUrl }, status: 'supported' };
  const bundle = withCorrection(event, correction);
  const { observation } = project({ bundle });
  assert.equal(observation.value.claims.length, 2);
  assert.deepEqual(observation.value.effectiveClaimIds, ['ondas.2']);
  assert.equal(observation.value.claims[0].status, 'corrected');
  assert.equal(observation.value.claims[0].supersededBy, 'ondas.2');
});

test('drafts, postdated claims, unobserved sources and untrusted URLs fail closed', () => {
  assert.throws(() => project({ edition: { ...edition, state: 'draft' } }), /released-sourced/);
  assert.throws(() => project({ observedAt: '2026-10-12T15:00:00Z' }), /released-sourced/);
  assert.throws(() => project({ sourceEvidenceIds: [] }), /released-sourced/);
  assert.throws(() => project({ publicationUrl: 'http://koios.news/research' }), /public-newsroom-url/);
  assert.throws(() => project({ bundle: { ...event, claims: [
    { ...event.claims[0], time: { asserted: '2026-10-12T17:00:00Z' } },
  ] } }), /publication-cannot-precede/);
});
