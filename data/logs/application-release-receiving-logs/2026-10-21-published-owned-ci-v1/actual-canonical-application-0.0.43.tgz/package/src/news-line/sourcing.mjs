/**
 * Source shortage as demand, not refusal. A story group holding fewer distinct source hosts than
 * its desk requires is a demand for the missing hosts: which story, which claims it already holds,
 * how many more hosts. The turn acts on a demand by searching the claims the wires have already
 * yielded for another host reporting the same event, and adopts them into the story, before the
 * story is drafted (and refused for want of hosts). Both functions below are pure; the bounded
 * action is `meetSourcingDemands` in stages.mjs.
 */
import { createHash } from "node:crypto";
import { outsidePublicationHost } from './source-origins.mjs';

export const SOURCING_DEMAND_KIND = "koios.news.sourcing-demand/v1";
const MAX_CLAIMS = 8;
const MAX_TERMS = 24;
const STOP = new Set(["that", "this", "with", "from", "have", "been", "were", "will", "would", "about", "after", "their", "there", "which", "into", "over", "than", "said", "says"]);

const termsOf = (text) => String(text ?? "").toLowerCase().match(/[\p{L}\p{N}]{4,}/gu)?.filter((term) => !STOP.has(term)) ?? [];
export const hostOfUrl = (url) => outsidePublicationHost(url) ?? "";

/**
 * The demand one story group makes, or null when it holds enough distinct hosts. `claims` are the
 * group's admitted claim contents (`{host?, sourceUrl, subject, predicate, object}`).
 * @param {{storyId: string, section: string, claims: object[], minimumSources: number}} group
 */
export function sourcingDemandOf({ storyId, section, claims, minimumSources }) {
  const hosts = [...new Set(claims.map((claim) => hostOfUrl(claim.sourceUrl)).filter(Boolean))].sort();
  const needed = minimumSources - hosts.length;
  if (needed <= 0) return null;
  const held = [];
  for (const { subject, predicate, object } of claims) {
    if (held.length < MAX_CLAIMS && !held.some((claim) => claim.subject === subject && claim.predicate === predicate && claim.object === object)) held.push({ subject, predicate, object });
  }
  const terms = [...new Set(held.flatMap(({ subject, object }) => [...termsOf(subject), ...termsOf(object)]))].sort().slice(0, MAX_TERMS);
  const body = { kind: SOURCING_DEMAND_KIND, storyId, section, hosts, needed, claims: held, terms };
  return Object.freeze({ id: `sha256:${createHash("sha256").update(JSON.stringify(body)).digest("hex")}`, ...body });
}

/**
 * The sources that could answer a demand, from the claims the wires have yielded: each from a host
 * the group does not hold, its claims naming at least `minimumOverlap` of the demand's terms, one
 * source per host, best overlap first, at most `needed` + 1 (a spare for a source that adds nothing).
 * `pool` is the admitted claim contents of other stories (`{sourceEvidenceId, sourceUrl, subject, object, quote}`).
 * @returns {Array<{sourceEvidenceId: string, host: string, overlap: number}>}
 */
export function sourcingLeadsFor(demand, pool, { minimumOverlap = 2 } = {}) {
  const wanted = new Set(demand.terms), held = new Set(demand.hosts);
  const bySource = new Map();
  for (const claim of pool) {
    const host = hostOfUrl(claim.sourceUrl);
    if (host === "" || held.has(host)) continue;
    const entry = bySource.get(claim.sourceEvidenceId) ?? { sourceEvidenceId: claim.sourceEvidenceId, host, terms: new Set() };
    for (const term of [...termsOf(claim.subject), ...termsOf(claim.object), ...termsOf(claim.quote)]) if (wanted.has(term)) entry.terms.add(term);
    bySource.set(claim.sourceEvidenceId, entry);
  }
  const ranked = [...bySource.values()].map(({ terms, ...rest }) => ({ ...rest, overlap: terms.size })).filter(({ overlap }) => overlap >= minimumOverlap)
    .sort((a, b) => b.overlap - a.overlap || a.sourceEvidenceId.localeCompare(b.sourceEvidenceId));
  const hosts = new Set(), leads = [];
  for (const lead of ranked) {
    if (hosts.has(lead.host)) continue;
    hosts.add(lead.host); leads.push(lead);
    if (leads.length >= demand.needed + 1) break;
  }
  return Object.freeze(leads);
}
