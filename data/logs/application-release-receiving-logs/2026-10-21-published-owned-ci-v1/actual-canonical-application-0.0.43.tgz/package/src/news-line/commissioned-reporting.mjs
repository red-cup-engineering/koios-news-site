/** Owner-submitted articles enter the same newsroom as wire reporting.
 * A commission supplies an assignment, never claims or publication authority.
 */
import {execFileSync} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {sha256Digest} from '@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity';
import {heldJournalCells} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {sourceEvidenceType,claimEvidenceType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {purchaseClaimExtraction,claimRows,recordPurchaseReceipt} from '@red-cup-engineering/content-mill-newsroom-services-section/claims';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {recordClaim} from '@red-cup-engineering/content-mill-newsroom-services-section/settlement';
import {dispatchInferenceAsConfiguredCustomer} from '@red-cup-engineering/computer-inference-engine/dispatch/inference-dispatch';
import {readNewsroom,recordNewsroom} from '../newsroom-records.mjs';
import {commissionArticle,currentSourcePolicyCaptures,captureNeedsRefresh,deniedCommissionSources} from './commissions.mjs';
import {storyAnchor} from './desk.mjs';
import {publicationHold} from './publication-holds.mjs';
import {slugFor,editions} from './editions.mjs';

export function verifiedEditorialCommissions(context){
 const latest=new Map();
 for(const {record}of readNewsroom(context.dataRoot,'editorial-commission')){
  if(record.author!=='emsenn'||typeof record.body!=='string'||sha256Digest(record.body)!==record.bodyDigest)continue;
  const prior=latest.get(record.storyId);
  if(!prior||record.receivedAt>prior.receivedAt)latest.set(record.storyId,{...record,section:record.section??storyAnchor(record.storyId,context.dataRoot).commission?.section});
 }
 return latest;
}

/** Only an actual article submission is considered; unrelated issues are not commissions. */
export function preparedArticleIssue(issue,property){
 if(issue?.user?.login!=='emsenn'||issue.state!=='open'||issue.pull_request||typeof issue.body!=='string')return null;
 const marked=/^## Review draft received[^\n]*\n/mu.exec(issue.body);
 const labeled=(issue.labels??[]).some(label=>['article-submission','koios-article'].includes(label.name));
 if(!marked&&!labeled)return null;
 const body=marked?issue.body.slice(marked.index+marked[0].length).split(/^## Prior decision history/mu)[0].trim():issue.body;
 const lines=body.split(/\n/u).map(line=>line.trim()).filter(Boolean);
 const opinion=lines.findIndex(line=>/^Opinion(?: and advocacy)?$/iu.test(line));
 const declared=/^Section:\s*([a-z0-9-]+)\s*$/mu.exec(body)?.[1];
 const section=opinion>=0?'opinion-analysis':declared??property.sections.find(desk=>(issue.labels??[]).some(label=>[desk.slug,'desk:'+desk.slug].includes(label.name)))?.slug;
 if(!property.sections.some(desk=>desk.slug===section))return {obstruction:'Article submission needs an explicit existing desk',issue:issue.number};
 const title=opinion>0?lines[opinion-1].replace(/^#+\s*/u,''):issue.title;
 const urls=[...new Set([...body.matchAll(/https?:\/\/[^\s<>()]+/gu)].map(match=>match[0]))];
 if(!urls.length)return {obstruction:'Article submission has no public source URLs',issue:issue.number};
 return {issueNumber:issue.number,slug:slugFor(title,new Set(),issue.node_id),section,preparedTitle:title,sourceUrl:urls[0],sourceUrls:urls.slice(1)};
}

export async function receivePreparedArticleIssues(context,{at=new Date().toISOString(),readIssues=()=>execFileSync('gh',['api','--paginate','--jq','.[] | @json','repos/causeway-services/koios.news/issues?state=open&per_page=100'],{encoding:'utf8',timeout:30000,maxBuffer:16*1024*1024}).split('\n').filter(Boolean).map(line=>JSON.parse(line))}={}){
 const received=[],obstructions=[];
 let issues;
 try{issues=await readIssues();}catch(error){return {received,obstructions:[{code:'article-issue-intake-unavailable',reason:String(error.message).slice(0,500)}]};}
 const known=[...verifiedEditorialCommissions(context).values()];
 const sources=[...heldJournalCells(context.dataRoot,'source-evidence',sourceEvidenceType).values()];
 const current=currentSourcePolicyCaptures(context),denied=deniedCommissionSources(context);
 for(const issue of issues){
  const proposal=preparedArticleIssue(issue,context.property);
  if(!proposal)continue;
  if(proposal.obstruction){obstructions.push(proposal);continue;}
  const prior=known.find(record=>record.issueId===issue.node_id);
  if(prior)proposal.slug=prior.slug;
  if(prior?.bodyDigest===sha256Digest(issue.body)&&[proposal.sourceUrl,...proposal.sourceUrls].every(url=>denied.has(url)||sources.some(source=>source.content.leadId===prior.storyId&&source.content.requestedUrl===url&&!captureNeedsRefresh(source,current)&&Date.parse(at)-Date.parse(source.content.acquiredAt)<(context.config.freshness?.storySeconds??172800)*1000)))continue;
  try{
   const result=await commissionArticle(context,proposal,{at,readIssue:()=>issue});
   if(result.assignmentReceived||result.sourcesAcquired>0)received.push({issue:issue.number,storyId:result.storyId,slug:result.slug,sources:result.sources.length,sourcesAcquired:result.sourcesAcquired});
   obstructions.push(...result.sourceObstructions.map(row=>({issue:issue.number,...row})));
  }catch(error){obstructions.push({issue:issue.number,reason:String(error.message).slice(0,500)});}
 }
 return {received,obstructions};
}

/** Use the shared source-bound extractor for commissioned documents too.
 * Completed source work is retained by exact commission and source identity.
 */
export async function analyzeEditorialCommissions(context,{at=new Date().toISOString(),acquisitionOnly=false}={}){
 const assignments=verifiedEditorialCommissions(context),held=heldJournalCells(context.dataRoot,'source-evidence',sourceEvidenceType);
 const done=new Set(readNewsroom(context.dataRoot,'commission-source-analysis').map(({record})=>record).filter(record=>record.complete===true).map(record=>record.bodyDigest+'\0'+record.sourceEvidenceId));
 const all=editions(context.roots),jobs=[],outcomes=[],requiresSourceRefresh=[];
 const current=currentSourcePolicyCaptures(context),denied=deniedCommissionSources(context),latest=new Map();
 for(const source of held.values()){const key=JSON.stringify([source.content.leadId,source.content.requestedUrl]);const prior=latest.get(key);if(!prior||Date.parse(source.content.acquiredAt)>Date.parse(prior.content.acquiredAt))latest.set(key,source);}
 for(const assignment of assignments.values()){
  if(publicationHold(context,assignment.slug,at,assignment.storyId)||all.some(row=>row.storyId===assignment.storyId&&['drafted','accepted','queued','rendered','released'].includes(row.state)))continue;
  const story=storyAnchor(assignment.storyId,context.dataRoot);
  if(!story.commission||story.commission.section!==assignment.section)throw Error('Commission desk differs from its immutable story');
  for(const source of latest.values()){
   if(source.content.leadId!==assignment.storyId)continue;
   if(captureNeedsRefresh(source,current)){if(!denied.has(source.content.requestedUrl))requiresSourceRefresh.push({storyId:assignment.storyId,sourceEvidenceId:source.id,url:source.content.requestedUrl});continue;}
   if(done.has(assignment.bodyDigest+'\0'+source.id))continue;
   jobs.push({assignment,story,source});
  }
 }
 const heldClaims=()=>[...heldJournalCells(context.dataRoot,'claim',claimEvidenceType).values()].filter(cell=>assignments.has(cell.content.storyId)).length;
 if(requiresSourceRefresh.length)return {requiresSourceRefresh,purchases:0,claimsAdded:0,heldClaims:heldClaims()};
 if(acquisitionOnly)return {pendingSources:jobs.length,purchases:0,claimsAdded:0,heldClaims:heldClaims(),sourceEvidenceOnly:true};
 const concurrency=context.property.cadence?.purchaseConcurrency??6;
 if(!Number.isSafeInteger(concurrency)||concurrency<1)throw new TypeError('Commission extraction concurrency must be a positive integer');
 const turnId=randomUUID();
 for(let offset=0;offset<jobs.length;offset+=concurrency)await Promise.all(jobs.slice(offset,offset+concurrency).map(async({assignment,story,source})=>{
  try{
   const purchase=await purchaseClaimExtraction({id:assignment.storyId,url:source.content.requestedUrl,title:story.title},{maximumClaims:24,freeLaneOnly:context.property.cadence?.freeLaneOnly===true,customerActor:context.property.inference.customerActor,sourceEvidence:source,reportingFocus:assignment.preparedTitle??story.title,
    dispatch:(request,settings)=>dispatchInferenceAsConfiguredCustomer({...request,objective:request.objective+'\n\n'+context.editorialMethods.researching},{...settings,environment:context.environment})});
   recordPurchaseReceipt(purchase,{root:context.purchaseJournalRoot,turnId,actor:context.property.inference.customerActor,recordedAt:at});
   const claims=claimRows(purchase,{storyId:assignment.storyId,section:assignment.section},source).map(row=>admitClaimEvidence(row,source));
   for(const claim of claims)recordClaim(context.dataRoot,claim,at);
   if(source.content.requestedUrl!==story.url&&claims.length)recordNewsroom(context.dataRoot,'reporting-source',{type:'KoiosArticleReportingSource',storyId:assignment.storyId,slug:assignment.slug,sourceEvidenceId:source.id,researchedAt:at,method:'commissioned-source-bound-extraction'});
   const outcome={storyId:assignment.storyId,bodyDigest:assignment.bodyDigest,sourceEvidenceId:source.id,complete:purchase.admitted===true&&claims.length>0,claims:claims.length,outcome:purchase.outcome,workLotId:purchase.workLotId};
   recordNewsroom(context.dataRoot,'commission-source-analysis',{...outcome,analyzedAt:at});outcomes.push(outcome);
  }catch(error){outcomes.push({storyId:assignment.storyId,sourceEvidenceId:source.id,complete:false,claims:0,reason:String(error.message).slice(0,500)});}
 }));
 return {sourceAttempts:jobs.length,purchases:outcomes.filter(row=>typeof row.workLotId==='string').length,claimsAdded:outcomes.reduce((n,row)=>n+row.claims,0),heldClaims:heldClaims(),outcomes};
}
