import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {lineRoots,openEdition,editions,writeJsonAtomic} from '../src/news-line/editions.mjs';
import {receivePublicEditions,renderedEditionSetIdentity} from '../src/news-line/stages.mjs';
import {KOIOS_NEWS_LINE,readyPublicationStage} from '../src/news-line.mjs';
import {runServiceLineTurn} from '@red-cup-engineering/organizing/work/service-line';

function fixture(t){
 const dataRoot=mkdtempSync(join(tmpdir(),'koios-public-custody-'));t.after(()=>rmSync(dataRoot,{recursive:true,force:true}));
 const roots=lineRoots(dataRoot),context={roots,policyDigest:'fixture-policy'};
 openEdition(roots,{candidateId:'urn:candidate:public',storyId:'urn:story:public',slug:'public-story',state:'rendered',draftedAt:'2026-10-18T00:00:00Z',consumptionId:'fixture-consumption',candidateDir:join(dataRoot,'candidate')});
 const obstruction=join(roots.releases,'obstruction.json');writeJsonAtomic(obstruction,{code:'prior-publication-failed'});
 const readBinding=()=>({slug:'public-story',projectedSha256:'a'.repeat(64),receiptSha256:'b'.repeat(64)});
 return {context,roots,obstruction,readBinding};
}

test('a public receipt advances custody after the same release attempt has already yielded',async t=>{
 const {context,roots,obstruction,readBinding}=fixture(t);
 const identity=renderedEditionSetIdentity(editions(roots,'rendered'));
 await runServiceLineTurn(KOIOS_NEWS_LINE,{dataRoot:roots.root,selectedStage:'release',handlers:{release:async()=>({status:'blocked',code:'preview-unavailable',workAttempt:{kind:'priority',stage:'release',identity}})}});
 assert.equal(readyPublicationStage(context),null,'the unchanged attempted release is not selected again');
 const missing=await receivePublicEditions(context,{readBinding,observe:async()=>null});
 assert.equal(missing.released,0);assert.equal(editions(roots)[0].state,'rendered');assert.equal(existsSync(obstruction),true);
 let requests=0;
 const received=await receivePublicEditions(context,{at:'2026-10-18T12:00:00Z',readBinding,observe:async({projectedSha256})=>{
  requests++;assert.equal(projectedSha256,'a'.repeat(64));return {fingerprint:{sha256:'c'.repeat(64)},manifestBytes:Buffer.from('{"public":true}'),article:{url:'https://koios.news/posts/public-story/',sha256:'d'.repeat(64),bytes:42}};
 }});
 assert.equal(requests,1);assert.equal(received.released,1);
 const edition=editions(roots)[0];assert.equal(edition.state,'released');assert.equal(edition.releasedSourceSha256,'a'.repeat(64));assert.equal(edition.publicationReceiptSha256,'b'.repeat(64));assert.equal(edition.publicArticleUrl,'https://koios.news/posts/public-story/');
 assert.equal(existsSync(obstruction),false);
 assert.equal((await receivePublicEditions(context,{readBinding,observe:async()=>{throw Error('released custody must not be observed twice');}})).released,0);
});

test('wrong publication identity and unavailable public evidence preserve rendered custody',async t=>{
 const {context,roots,obstruction}=fixture(t);let requests=0;
 const result=await receivePublicEditions(context,{readBinding:()=>({slug:'another-story'}),observe:async()=>{requests++;}});
 assert.equal(result.released,0);assert.equal(requests,0);assert.equal(editions(roots)[0].state,'rendered');assert.equal(existsSync(obstruction),true);
});
