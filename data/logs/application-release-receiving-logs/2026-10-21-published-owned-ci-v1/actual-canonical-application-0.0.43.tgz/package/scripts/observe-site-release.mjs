// Read-only projection of one already-existing website run. Never imports the
// deployment carrier, reads credentials, invokes a process, or contacts a provider.
import {constants,openSync,closeSync,fstatSync,lstatSync,realpathSync,readFileSync,opendirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {homedir} from 'node:os';
import {join,resolve,isAbsolute} from 'node:path';
const MAX_BYTES=2*1024*1024,MAX_AUTHORITY_FILES=32;
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const matches=(value,pattern)=>typeof value==='string'&&!/\s/u.test(value)&&pattern.test(value);
const SHA=/^[a-f0-9]{64}$/u,REVISION=/^[a-f0-9]{40}$/u,NUMBER=/^[1-9][0-9]{0,19}$/u;
const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iu;
const refuse=reason=>{throw Object.assign(new Error('Release receipt observation refused'),{code:'RECEIPT_OBSERVATION_REFUSED',reason});};
const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const same=(a,b)=>a.dev===b.dev&&a.ino===b.ino&&a.size===b.size&&a.mtimeMs===b.mtimeMs;
function stat(path){try{return lstatSync(path);}catch(error){if(error.code==='ENOENT')return null;refuse('unreadable');}}
function directory(path){const found=stat(path);if(!found)return null;
 if(!found.isDirectory()||found.isSymbolicLink()||realpathSync(path)!==path)refuse('unsafe-directory');return found;}
function reading(path){
 const before=stat(path);if(!before)return null;
 if(!before.isFile()||before.isSymbolicLink())refuse('unsafe-file');
 if(before.size>MAX_BYTES)refuse('file-too-large');
 let fd,bytes;
 try{fd=openSync(path,constants.O_RDONLY|constants.O_NOFOLLOW);if(!same(before,fstatSync(fd)))refuse('changed-file');
  bytes=readFileSync(fd);if(bytes.length>MAX_BYTES)refuse('file-too-large');
  if(!same(before,fstatSync(fd))||!same(before,lstatSync(path)))refuse('changed-file');
 }finally{if(fd!==undefined)closeSync(fd);}
 let value;try{value=JSON.parse(bytes);}catch{refuse('invalid-json');}
 if(!object(value))refuse('invalid-json');return {value,sha256:digest(bytes),bytes:bytes.length};
}
function provider(value){
 if(!object(value)||!matches(value.deploymentId,UUID)||!matches(value.versionId,UUID)
  ||!matches(value.createdOn,/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/u)
  ||!Number.isFinite(Date.parse(value.createdOn)))refuse('provider-shape');
 return {deploymentId:value.deploymentId,versionId:value.versionId,createdOn:value.createdOn};
}

export function observeSiteRelease({releasesRoot,runId,runAttempt,revision,candidateManifestSha256,bindingSha256}){
 if(!matches(runId,NUMBER)||!matches(runAttempt,/^[1-9][0-9]{0,7}$/u)||!matches(revision,REVISION)
  ||!matches(candidateManifestSha256,SHA)||!matches(bindingSha256,SHA))refuse('identity');
 if(typeof releasesRoot!=='string'||!isAbsolute(releasesRoot)||resolve(releasesRoot)!==releasesRoot)refuse('root');
 const identity={runId,runAttempt,revision,candidateManifestSha256,bindingSha256};
 const result={kind:'koios.website-release-receipt-observation/v1',...identity,
  mode:'read-only',runBinding:'exact-directory-identity',currentProvider:'unobserved',currentPublicAssets:'unobserved',
  effects:{preview:'unobserved',production:'unobserved'},receipts:[],authorityUses:[]};
 const rootStat=directory(releasesRoot);
 if(!rootStat)return {...result,status:'releases-root-absent'};
 const run=join(releasesRoot,`${runId}-${runAttempt}-${revision}`),runStat=directory(run);
 if(!runStat)return {...result,status:'run-absent'};
 const receipts=join(run,'.release'),receiptStat=directory(receipts);
 if(!receiptStat)return {...result,status:'receipts-absent'};
 const snapshots=[[releasesRoot,rootStat],[run,runStat],[receipts,receiptStat]];
 const inputs=new Map(),read=name=>{const found=reading(join(receipts,name));if(found)inputs.set(name,found);return found;};
 for(const name of ['baseline.json','already-live-audit.json','preview.json.deployment.json','preview.json',
  'probe.json','rollback.json','release.json.deployment.json','release.json'])read(name);
 const baseline=inputs.get('baseline.json');
 if(baseline&&!['news-property.build-manifest/v1','koios.news.static-publication-manifest/v1'].includes(baseline.value.kind))refuse('baseline-kind');
 const authority=join(receipts,'authority'),authorityStat=directory(authority),uses={preview:[],release:[]};
 if(authorityStat){
  snapshots.push([authority,authorityStat]);const dir=opendirSync(authority);let count=0;
  try{for(let entry;(entry=dir.readSync())!==null;){
   if(++count>MAX_AUTHORITY_FILES)refuse('authority-limit');
   if(!/^(?:self-[a-f0-9]{64}|grant-[A-Za-z0-9_-]{1,128})\.json$/u.test(entry.name))refuse('authority-name');
   const found=reading(join(authority,entry.name));if(!found)refuse('changed-file');const value=found.value;
   if(value.kind!=='koios.news.cloudflare-release-authority-use/v1'||!['preview','release'].includes(value.phase)
    ||value.consumptionId!==entry.name.slice(0,-5)||!matches(value.grantDigest,SHA)
    ||value.candidateManifestSha256!==candidateManifestSha256||value.bindingSha256!==bindingSha256)refuse('authority-binding');
   if(value.phase==='release'&&(!baseline||value.productionBaselineManifestSha256!==baseline.sha256))refuse('baseline-binding');
   uses[value.phase].push(found);result.authorityUses.push({phase:value.phase,sha256:found.sha256,bytes:found.bytes});
  }}finally{dir.closeSync();}
  if(uses.preview.length>1||uses.release.length>1)refuse('ambiguous-authority');
 }
 const kinds={
  'already-live-audit.json':'koios.news.cloudflare-production-observation-receipt/v1',
  'preview.json':'koios.news.cloudflare-preview-deployment-receipt/v1',
  'probe.json':'koios.news.cloudflare-preview-receipt/v1',
  'release.json':'koios.news.cloudflare-release-receipt/v1',
 };
 for(const [name,found]of inputs){
  const value=found.value,row={file:name,sha256:found.sha256,bytes:found.bytes};
  if(name==='baseline.json')row.matchesCandidate=found.sha256===candidateManifestSha256;
  else if(name==='rollback.json'){
   if(value.kind!=='koios.news.cloudflare-rollback-binding/v1'||value.bindingSha256!==bindingSha256
    ||!matches(value.priorVersionId,UUID))refuse('rollback-binding');
   row.priorVersionId=value.priorVersionId;row.candidateBinding='not-carried';
  }else if(name.endsWith('.deployment.json')){
   const phase=name.startsWith('preview.')?'preview':'release';
   if(value.phase!==phase||value.candidateManifestSha256!==candidateManifestSha256)refuse('deployment-binding');
   // This carrier record has no binding digest of its own. Require its matching
   // one-use record, but never output the authority identity or captured stdout.
   if(uses[phase].length!==1)refuse('deployment-authority-unavailable');
   row.reportedProvider=provider(value.provider);row.bindingEvidence='matching-authority-use';
  }else{
   if(value.kind!==kinds[name]||value.candidateManifestSha256!==candidateManifestSha256||value.bindingSha256!==bindingSha256
    ||value.probe?.accepted!==true||value.probe?.candidateManifestSha256!==candidateManifestSha256
    ||value.probe?.bindingSha256!==bindingSha256||value.probe?.manifestSha256!==candidateManifestSha256)refuse('receipt-binding');
   row.reportedPublicVerification=true;
   if(name==='preview.json'||name==='release.json'){
    const phase=name==='preview.json'?'preview':'release',use=uses[phase][0]?.value;
    const grantId=use?.consumptionId.startsWith('grant-')?use.consumptionId.slice(6):use?.consumptionId;
    if(!use||value.grantId!==grantId||value.grantDigest!==use.grantDigest
     ||value.authorityUsePath!==join(authority,`${use.consumptionId}.json`))refuse('receipt-authority-binding');
    if(phase==='release'){
     if(!baseline||value.productionBaselineManifestSha256!==baseline.sha256)refuse('baseline-binding');
     const probe=inputs.get('probe.json'),rollback=inputs.get('rollback.json');
     if(!probe||value.previewReceiptSha256!==probe.sha256)refuse('preview-binding');
     if(!rollback||value.rollback?.priorVersionId!==rollback.value.priorVersionId)refuse('rollback-binding');
    }
    row.reportedProvider=provider(value.deployment?.readback);
   }
  }
  result.receipts.push(row);
 }
 for(const phase of ['preview','release']){
  const effect=phase==='preview'?'preview':'production';
  const deployment=inputs.get(`${phase}.json.deployment.json`),verified=inputs.get(`${phase}.json`);
  if(deployment&&verified&&JSON.stringify(provider(deployment.value.provider))!==JSON.stringify(provider(verified.value.deployment?.readback)))refuse('provider-conflict');
  if(uses[phase].length)result.effects[effect]='attempted-unreconciled';
  if(inputs.has(`${phase}.json.deployment.json`))result.effects[effect]='provider-report-retained';
  if(inputs.has(`${phase}.json`))result.effects[effect]='public-verification-report-retained';
 }
 // A terminal run's immutable receipt directory should not change during observation.
 for(const[path,before]of snapshots){const after=directory(path);if(!after||!same(before,after))refuse('changed-directory');}
 return {...result,status:'observed'};
}

if(import.meta.main){
 try{
  const args=process.argv.slice(2);if(args.length!==5)refuse('arguments');
  const [runId,runAttempt,revision,candidateManifestSha256,bindingSha256]=args;
  console.log(JSON.stringify(observeSiteRelease({releasesRoot:join(homedir(),'.local/state/561-group/news-property/Koios.News/website-releases'),
   runId,runAttempt,revision,candidateManifestSha256,bindingSha256})));
 }catch(error){console.error(JSON.stringify({kind:'koios.website-release-receipt-observation/v1',status:'refused',
  reason:error?.code==='RECEIPT_OBSERVATION_REFUSED'?error.reason:'unavailable'}));process.exitCode=1;}
}
