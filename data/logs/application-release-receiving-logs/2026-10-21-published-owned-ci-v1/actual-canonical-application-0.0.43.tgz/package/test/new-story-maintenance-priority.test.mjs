import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import test from "node:test";
import {preferUnpublishedWriterOrders} from "../src/news-line/throughput-feedback.mjs";

const duty=readFileSync(new URL("../deploy/maintenance-duty.txt",import.meta.url),"utf8");
const evidenceFloorProhibition=/do not wait on the failed provider, weaken evidence floors, or treat a draft as publication\./u;

function assertNewReporterContract(text){
  assert.match(text,/claims accepts \{slug, storyId, sources: \[\{url, expectedTextDigest, claims: \[\{subject, predicate, object, quote\}\]\}\]\}/u);
  assert.match(text,/draft accepts \{slug, storyId, title, dek, paragraphs: \[\{text, heading, claimEvidenceIds\}\]\}/u);
  assert.match(text,/same existing held newsroom storyId to both reporter packets/u);
  assert.match(text,/do not invent an assignment or encode a guessed storyId/u);
  assert.match(text,/sourceEvidenceId and its held full source text/u);
  assert.match(text,/exact textDigest as expectedTextDigest/u);
  assert.match(text,/actual admitted claim IDs for that story/u);
  assert.match(text,/Omitting storyId keeps the existing published-slug revision route/u);
  assert.match(text,/NEW draft submission opens drafted custody only, without inventing firstPublished, editorial acceptance or publication authority/u);
  assert.match(text,/Resume an existing draft using its exact original packet and bound story and slug/u);
  assert.match(text,/a manuscript candidate has journal custody without an edition, reconcile the interrupted submission/u);
  for(const mode of ["claims","draft"]){
    assert.ok(text.includes('node "$KOIOS_NEWS_RUNTIME_PACKAGE/bin/koios-reporter-submit.mjs" '+mode));
  }
  assert.match(text,/A fetched source checkout does not change that admitted application/u);
  assert.match(text,/do not substitute checkout code, mutate the installed runtime, or start a parallel article task/u);
  assert.match(text,/verified public URL with its exact release receipt/u);
}

test("maintenance prioritizes new-story throughput when writer capacity is the binding failure",()=>{
  assert.match(duty,/below the daily NEW-article target/u);
  assert.match(duty,/dominant return layer is `writer-model`/u);
  assert.match(duty,/restoring new-story throughput outranks another historical depth repair/u);
  assert.match(duty,/evidence-bound cloud reporter claims\/draft route/u);
  assert.match(duty,/new accepted slug entering the published ledger and then the public receiver/u);
  assert.match(duty,evidenceFloorProhibition);
});

test("evidence-floor guard rejects reversed or missing prohibitions",()=>{
  for(const unsafeDuty of [
    duty.replace("do not wait on the failed provider, ",""),
    duty.replace(", weaken evidence floors","")
  ]){
    assert.notEqual(unsafeDuty,duty);
    assert.throws(()=>assert.match(unsafeDuty,evidenceFloorProhibition),{code:"ERR_ASSERTION"});
  }
});

test("maintenance teaches the admitted NEW reporter packet and receiving contract",()=>{
  assertNewReporterContract(duty);
});

test("NEW reporter contract rejects missing packet bindings and unsafe source selection",()=>{
  for(const [from,to] of [
    ["claims accepts {slug, storyId, sources:","claims accepts {slug, sources:"],
    ["draft accepts {slug, storyId, title,","draft accepts {slug, title,"],
    ["do not invent an assignment or encode a guessed storyId","invent an assignment or encode a guessed storyId"],
    ["exact textDigest as expectedTextDigest","a guessed digest as expectedTextDigest"],
    ["actual admitted claim IDs for that story","claim IDs from any story"],
    ["do not substitute checkout code, mutate the installed runtime, or start a parallel article task","substitute checkout code, mutate the installed runtime, or start a parallel article task"]
  ]){
    const unsafeDuty=duty.replace(from,to);
    assert.notEqual(unsafeDuty,duty);
    assert.throws(()=>assertNewReporterContract(unsafeDuty),{code:"ERR_ASSERTION"});
  }
});

test("native writer orders prioritize genuinely observed new-publication deficit, not unknown metrics",()=>{
  assert.equal(preferUnpublishedWriterOrders({articlesLast24h:0,dailyArticleTarget:20}),true);
  assert.equal(preferUnpublishedWriterOrders({articlesLast24h:19,dailyArticleTarget:20}),true);
  assert.equal(preferUnpublishedWriterOrders({articlesLast24h:20,dailyArticleTarget:20}),false);
  assert.equal(preferUnpublishedWriterOrders({articlesLast24h:21,dailyArticleTarget:20}),false);
  for(const observation of [{},null,{articlesLast24h:null,dailyArticleTarget:20},
    {articlesLast24h:-1,dailyArticleTarget:20},{articlesLast24h:0,dailyArticleTarget:0},
    {articlesLast24h:0,dailyArticleTarget:Infinity},
    {articlesLast24h:"0",dailyArticleTarget:20}])
    assert.equal(preferUnpublishedWriterOrders(observation),false);
  const source=readFileSync(new URL("../src/news-line/stages.mjs",import.meta.url),"utf8");
  assert.match(source,/preferUnpublishedStories = preferUnpublishedWriterOrders\(newsLineMetrics\(context, at\)\)/u);
  assert.match(source,/preferUnpublishedStories,/u);
});
