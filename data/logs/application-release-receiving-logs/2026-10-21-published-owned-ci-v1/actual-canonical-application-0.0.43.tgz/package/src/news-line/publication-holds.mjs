import {readNewsroom} from '../newsroom-records.mjs';

/** Human response windows constrain publication, never grant acceptance.
 * Later requests may lengthen a window; an early response cannot shorten it.
 * Records remain in custody after expiry for the reporting history. */
export function publicationHold(context,slug,at=new Date().toISOString(),storyId){
 const now=Date.parse(at);
 if(!Number.isFinite(now))throw new TypeError('Publication requires a valid clock');
 const rows=readNewsroom(context.dataRoot,'publication-hold').map(x=>x.record)
  .filter(x=>x.slug===slug||(typeof storyId==='string'&&x.storyId===storyId));
 for(const row of rows)if(row.type!=='KoiosArticlePublicationHold'||row.version!==1||!Number.isFinite(Date.parse(row.notBefore)))
  throw new Error('Invalid publication hold for '+slug);
 return rows.filter(row=>Date.parse(row.notBefore)>now).sort((a,b)=>Date.parse(b.notBefore)-Date.parse(a.notBefore))[0]??null;
}
