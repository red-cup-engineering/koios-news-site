import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, mkdtempSync, writeFileSync, rmSync, existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {newsroomFeedback, newsroomRuntimeFacts} from '../scripts/newsroom-feedback.mjs';
import {newArticleThroughputFeedback} from '../src/news-line/throughput-feedback.mjs';

const observedAt = '2026-10-11T15:23:23.224Z';
const executedAt = '2026-10-11T15:15:00.000Z';
const failedAt = '2026-10-11T07:00:00.000Z';
const stages = ['intake', 'analyze', 'draft', 'assess', 'authorize', 'render', 'release', 'feedback'];
function snapshot() {
  return {kind: 'koios.news.runtime-observation/v1', observedAt: executedAt,
    turns: [{stage: 'release', status: 'complete', cycle: 209}],
    status: {cycle: 209, lastRun: executedAt, next: 'draft',
      stages: stages.map(stage => ({stage, status: stage === 'draft' ? 'blocked' : 'complete', lastRun: stage === 'draft' ? failedAt : executedAt})),
      blockers: [{stage: 'draft', status: 'blocked', code: 'stage-threw', failureClass: 'CONTROL_PLANE_DEFECT'}],
      live: {at: executedAt, articlesLast24h: 1, revisionsLast24h: 4, dailyArticleTarget: 20, publishedLedger: 76,
        editions: {drafted: 0, accepted: 0, returned: 81, queued: 0, rendered: 1, released: 76, refused: 3},
        returnedByFailureLayer: {'writer-model': 84, sources: 46}, releaseObstruction: null}}};
}

test('blocked feedback preserves separate collection, execution and failing-stage clocks plus queue facts', () => {
  const runtime = snapshot(), before = structuredClone(runtime), result = newsroomFeedback(runtime, observedAt);
  assert.equal(result.status, 'unavailable');
  assert.match(result.reason, /draft: stage-threw/);
  assert.equal(result.runtime.observedAt, executedAt);
  assert.equal(result.runtime.status.lastRun, executedAt);
  assert.equal(result.runtime.status.blockers[0].lastRun, failedAt);
  assert.deepEqual(result.runtime.turns, runtime.turns);
  assert.equal(result.runtime.status.next, 'draft');
  assert.equal(result.runtime.status.live.editions.rendered, 1);
  assert.equal(result.runtime.status.live.articlesLast24h, 1);
  assert.equal(result.runtime.status.live.revisionsLast24h, 4);
  assert.deepEqual(runtime, before);
});

test('a recent assessment can clear its blocker without falsely clearing an older draft blocker', () => {
  const runtime = snapshot(); runtime.turns = [{stage: 'assess', status: 'complete', cycle: 209}];
  const result = newsroomFeedback(runtime, observedAt);
  assert.equal(result.status, 'unavailable');
  assert.equal(result.runtime.turns[0].stage, 'assess');
  assert.equal(result.runtime.status.blockers[0].lastRun, failedAt);
});

test('healthy execution remains observed with bounded operating facts', () => {
  const runtime = snapshot(); runtime.status.blockers = []; runtime.status.next = 'intake';
  const result = newsroomFeedback(runtime, observedAt);
  assert.equal(result.status, 'observed'); assert.equal(result.reason, undefined);
  assert.equal(result.runtime.status.live.publishedLedger, 76);
});

test('stale execution remains unavailable while retaining the last known queue and clocks', () => {
  const runtime = snapshot(); runtime.observedAt = '2026-10-11T12:00:00.000Z'; runtime.status.lastRun = runtime.observedAt;
  for (const stage of runtime.status.stages) if (stage.stage !== 'draft') stage.lastRun = runtime.observedAt;
  const result = newsroomFeedback(runtime, observedAt);
  assert.equal(result.status, 'unavailable'); assert.match(result.reason, /stale/);
  assert.equal(result.runtime.observedAt, runtime.observedAt); assert.equal(result.runtime.status.live.editions.returned, 81);
});

test('future, malformed and absent execution timestamps cannot become observed health', () => {
  for (const value of ['2026-10-11T16:00:00.000Z', 'not-a-time', null, undefined]) {
    const runtime = snapshot(); runtime.observedAt = value;
    assert.equal(newsroomFeedback(runtime, observedAt).status, 'unavailable');
  }
  const runtime = snapshot(); runtime.status.lastRun = '2026-10-11T16:00:00.000Z';
  assert.equal(newsroomFeedback(runtime, observedAt).status, 'unavailable');
  for (const value of [null, {}, {kind: 'different'}, {kind: snapshot().kind, observedAt: executedAt, status: {}}]) {
    assert.equal(newsroomFeedback(value, observedAt).status, 'unavailable');
  }
  assert.throws(() => newsroomFeedback(snapshot(), 'not-a-time'), /UTC/);
});

test('future or invalid retained stage clocks fail unavailable without erasing other stage facts', () => {
  for (const value of ['2026-10-11T16:00:00.000Z', '2026-02-30T15:00:00.000Z', 'not-a-time']) {
    const runtime = snapshot(); runtime.status.blockers = [];
    runtime.status.stages.find(row => row.stage === 'assess').lastRun = value;
    const result = newsroomFeedback(runtime, observedAt);
    assert.equal(result.status, 'unavailable'); assert.match(result.reason, /stage timestamp/);
    assert.equal(result.runtime.status.stages.find(row => row.stage === 'draft').lastRun, failedAt);
  }
});

test('calendar-normalized dates are invalid while exact UTC seconds and milliseconds remain supported', () => {
  for (const value of ['2026-02-30T15:00:00.000Z', '2026-10-11T24:00:00.000Z']) {
    const runtime = snapshot(); runtime.observedAt = value;
    assert.equal(newsroomFeedback(runtime, observedAt).status, 'unavailable');
    assert.equal(newsroomRuntimeFacts(runtime).observedAt, null);
  }
  const runtime = snapshot(); runtime.observedAt = '2026-10-11T15:15:00Z';
  assert.equal(newsroomRuntimeFacts(runtime).observedAt, '2026-10-11T15:15:00Z');
});

test('publication obstruction is visible without copying provider output or filesystem paths', () => {
  const runtime = snapshot(); runtime.status.blockers = [];
  runtime.status.live.releaseObstruction = {reason: 'private provider text', path: '/private/operator/path', stderr: 'private stderr'};
  const result = newsroomFeedback(runtime, observedAt);
  assert.equal(result.status, 'unavailable'); assert.match(result.reason, /publication-data sync/);
  assert.deepEqual(result.runtime.status.live.releaseObstruction, {present: true});
  assert.equal(JSON.stringify(result).includes('private'), false);
});

test('only fixed diagnostic enums and numeric counts cross the private feedback boundary', () => {
  const runtime = snapshot();
  runtime.credentials = 'secret'; runtime.status.path = '/secret'; runtime.status.run = 'secret';
  runtime.turns.push({stage: 'secret', status: 'secret', cycle: 'secret'});
  Object.assign(runtime.status.blockers[0], {code: 'secret', failureClass: 'secret', repairRequest: 'secret', reason: 'secret', stack: 'secret'});
  Object.assign(runtime.status.live, {stdout: 'secret', articlesLast24h: 'secret', revisionsLast24h: -1, dailyArticleTarget: Infinity});
  runtime.status.live.editions.rendered = NaN;
  const result = newsroomFeedback(runtime, observedAt);
  assert.equal(result.runtime.status.blockers[0].code, 'unclassified-blocker');
  assert.equal(result.runtime.status.blockers[0].failureClass, null);
  assert.equal(result.runtime.status.live.articlesLast24h, null);
  assert.equal(result.runtime.status.live.revisionsLast24h, null);
  assert.equal(result.runtime.status.live.dailyArticleTarget, null);
  assert.equal(result.runtime.status.live.editions.rendered, null);
  assert.equal(JSON.stringify(result).includes('secret'), false);
});

test('blocker and turn projections are bounded; malformed rows do not add arbitrary fields', () => {
  const runtime = snapshot(); runtime.turns = Array.from({length: 100}, () => ({stage: 'draft', status: 'pending', cycle: 210}));
  runtime.status.blockers = Array.from({length: 100}, () => null);
  const facts = newsroomRuntimeFacts(runtime);
  assert.equal(facts.turns.length, 8); assert.equal(facts.status.blockers.length, 8);
  assert.equal(facts.status.blockers[0].code, 'unclassified-blocker');
});

test('the actual collector newsroom callback retains failure facts with a real local snapshot read', async () => {
  const source = readFileSync(new URL('../scripts/collect-feedback.mjs', import.meta.url), 'utf8');
  // Run the exact bounded callback rather than executing unrelated external sensors.
  const start = source.indexOf("await sensor('newsroom',async()=>{");
  const end = source.indexOf("\nawait sensor('newArticleThroughput'", start);
  assert.ok(start >= 0 && end > start);
  const callback = source.slice(start, end);
  const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
  const run = new AsyncFunction('sensor', 'join', 'out', 'existsSync', 'readFileSync', 'newsroomFeedback', 'at', 'Date', callback);
  const out = mkdtempSync(join(tmpdir(), 'koios-newsroom-feedback-'));
  try {
    writeFileSync(join(out, 'newsroom.json'), JSON.stringify(snapshot()));
    let result;
    const sensor = async (name, fn) => {assert.equal(name, 'newsroom'); try {result = {status: 'observed', observedAt, ...await fn()};} catch (error) {result = {status: 'unavailable', observedAt, reason: error.message};}};
    const FixedDate = class extends Date {constructor(...args) {super(...(args.length ? args : [observedAt]));}};
    await run(sensor, join, out, existsSync, readFileSync, newsroomFeedback, '2026-10-11T15:00:00.000Z', FixedDate);
    assert.equal(result.status, 'unavailable');
    assert.equal(result.observedAt, observedAt);
    assert.equal(result.runtime.observedAt, executedAt);
    assert.doesNotMatch(result.reason, /future timestamp/);
    assert.equal(result.runtime.status.blockers[0].lastRun, failedAt);
    assert.equal(result.runtime.status.live.editions.rendered, 1);
  } finally {rmSync(out, {recursive: true, force: true});}
});

test('failure-layer feedback preserves only known numeric cumulative counts', () => {
  const runtime = snapshot();
  runtime.status.live.returnedByFailureLayer = {
    sources: 46, 'writer-model': 84, assignment: -1,
    providerAccountToken: 'secret', 'draft-repair': Infinity, none: 0,
  };
  const facts = newsroomRuntimeFacts(runtime);
  assert.deepEqual(facts.status.live.returnedByFailureLayer, {
    'writer-model': 84, sources: 46, none: 0,
  });
  assert.equal(JSON.stringify(facts).includes('secret'), false);
  assert.equal(Object.keys(facts.status.live.returnedByFailureLayer).length, 3);
});

test('the actual collector connects healthy runtime to a failing new-article throughput sensor', async () => {
  const source = readFileSync(new URL('../scripts/collect-feedback.mjs', import.meta.url), 'utf8');
  const start = source.indexOf("await sensor('newsroom',async()=>{");
  const end = source.indexOf("\nawait sensor('searchConsole'", start);
  assert.ok(start >= 0 && end > start, 'both collector callbacks must be present');
  const callback = source.slice(start, end);
  const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
  const run = new AsyncFunction(
    'sensor', 'join', 'out', 'existsSync', 'readFileSync',
    'newsroomFeedback', 'newArticleThroughputFeedback', 'sensors', 'Date',
    callback,
  );
  const out = mkdtempSync(join(tmpdir(), 'koios-throughput-callback-'));
  try {
    const runtime = snapshot();
    runtime.status.blockers = [];
    runtime.status.next = 'intake';
    writeFileSync(join(out, 'newsroom.json'), JSON.stringify(runtime));
    const sensors = {};
    const sensor = async (name, fn) => {
      assert.ok(['newsroom', 'newArticleThroughput'].includes(name));
      sensors[name] = {status: 'observed', ...await fn()};
    };
    const FixedDate = class extends Date {
      constructor(...args) {super(...(args.length ? args : [observedAt]));}
    };
    await run(sensor, join, out, existsSync, readFileSync,
      newsroomFeedback, newArticleThroughputFeedback, sensors, FixedDate);
    assert.equal(sensors.newsroom.status, 'observed');
    assert.equal(sensors.newArticleThroughput.status, 'unavailable');
    assert.equal(sensors.newArticleThroughput.articlesLast24h, 1);
    assert.equal(sensors.newArticleThroughput.deficit, 19);
    assert.deepEqual(sensors.newArticleThroughput.leadingReturnLayer,
      {layer: 'writer-model', count: 84});
    assert.equal(sensors.newArticleThroughput.revisionsLast24h, 4);
  } finally {
    rmSync(out, {recursive: true, force: true});
  }
});
