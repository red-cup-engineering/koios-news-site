import {OBSERVED_PUBLICATION_PREFIX} from './existing-article.mjs';
import {readStory} from '@red-cup-engineering/content-mill-newsroom-services-section/intake';

/** Read the source-owned story; only historical constituted IDs contain their anchor. */
export function storyAnchor(storyId,dataRoot){
 const prefix='news-property.story:';
 if(storyId?.startsWith(prefix))return JSON.parse(Buffer.from(storyId.slice(prefix.length),'base64url').toString('utf8')).v;
 if(typeof dataRoot==='string'&&dataRoot&&typeof storyId==='string'){
  let record;
  try{record=readStory(dataRoot,storyId);}catch(error){throw new Error('Story requires an existing newsroom anchor identity',{cause:error});}
  if(record&&(typeof record.feed==='string'||['causeway-services/koios-news','causeway-services/koios.news'].includes(record.commission?.repository))&&typeof record.url==='string'&&typeof record.title==='string')return record;
 }
 throw new Error('Story requires an existing newsroom anchor identity');
}

/** The anchor feed's declared desk governs assignment; a model cannot rebind it. */
export function storyDesk(property, storyId, proposedSection, dataRoot) {
  if(storyId?.startsWith(OBSERVED_PUBLICATION_PREFIX)){
    const record=JSON.parse(Buffer.from(storyId.slice(OBSERVED_PUBLICATION_PREFIX.length),"base64url").toString("utf8"));
    if(record.origin!==property.origin||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(record.slug??''))throw new Error("Invalid observed publication identity");
    const assigned=property.content?.legacyPublishedSections?.[record.slug]??proposedSection;
    const desk=property.sections.find(desk=>desk.slug===assigned);
    if(!desk)throw new Error("Observed publication lacks an assigned editorial desk");
    return desk;
  }
  const anchor=storyAnchor(storyId,dataRoot);
  if(anchor.commission){
    const desk=property.sections.find(row=>row.slug===anchor.commission.section);
    if(!desk)throw new Error('Commission lacks an assigned editorial desk');
    return desk;
  }
  const feed = anchor?.feed;
  const desks = property.sections.filter((section) => section.wires?.includes(feed));
  if (desks.length !== 1) throw new Error(`anchor feed ${feed} must have exactly one editorial desk`);
  return desks[0];
}

