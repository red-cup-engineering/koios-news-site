import { closeSync, existsSync, fsyncSync, lstatSync, mkdirSync, openSync, readFileSync, writeFileSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";

import { verifyAssessmentReceipt, verifyPublicationAuthority } from "@causeway-services/editorial-publication-authority";
import { manuscriptEvidenceFromJournal, verifyManuscriptEvidence } from "@red-cup-engineering/content-mill-newsroom-services-section/evidence";
import { parsePost } from "@causeway-services/koios-news-site/build";
import { canonicalJson } from "@red-cup-engineering/json-services-section/canonical";
import { sha256Digest, sha256Hex } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity";

const ISSUE_KIND = "koios.news.routine-issue/v2";
const JOB_KIND = "koios.news.routine-issue-job/v3";
const isRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const isSlug = (value) => /^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(value ?? "");
const isId = (value) => /^[A-Za-z0-9_-]{16,128}$/u.test(value ?? "");
const isDigest = (value) => /^sha256:[a-f0-9]{64}$/u.test(value ?? "");

function fail(message) { throw new TypeError(`routine issue formation: ${message}`); }
function realDirectory(path, label) {
  const absolute = resolve(path ?? "");
  try { const stat = lstatSync(absolute); if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error(); }
  catch { fail(`${label} must be an existing real directory`); }
  return absolute;
}
function realFile(path, label) {
  const absolute = resolve(path ?? "");
  try { const stat = lstatSync(absolute); if (stat.isSymbolicLink() || !stat.isFile()) throw new Error(); }
  catch { fail(`${label} must be an existing real file`); }
  return absolute;
}
function jsonFile(path, label) {
  const source = readFileSync(realFile(path, label), "utf8");
  try { return Object.freeze({ source, value: JSON.parse(source), path: resolve(path) }); }
  catch (error) { fail(`${label} is not JSON: ${error.message}`); }
}
function fsyncDirectory(path) { const descriptor = openSync(path, "r"); try { fsyncSync(descriptor); } finally { closeSync(descriptor); } }
function createOnly(path, source) {
  let descriptor;
  try { descriptor = openSync(path, "wx", 0o600); }
  catch (error) { if (error?.code === "EEXIST") return false; throw error; }
  try { writeFileSync(descriptor, source, "utf8"); fsyncSync(descriptor); } finally { closeSync(descriptor); }
  return true;
}
function exactKeys(value, keys, label) { if (!isRecord(value) || Object.keys(value).length !== keys.length || keys.some((key) => !(key in value))) fail(`${label} has an invalid shape`); }
function manuscriptEvidenceRecord(source, manuscriptBody) {
  let value;
  try { value = JSON.parse(source); } catch (error) { fail(`manuscript evidence is not JSON: ${error.message}`); }
  const verified = verifyManuscriptEvidence(value, manuscriptBody);
  return Object.freeze({ digest: sha256Digest(source), ...verified });
}
function admission(source, manuscriptDigest, manuscriptSlug) {
  let value;
  try { value = JSON.parse(source); } catch (error) { fail(`admission projection is not JSON: ${error.message}`); }
  if (!isRecord(value) || value.slug !== manuscriptSlug || value.manuscriptDigest !== manuscriptDigest) fail("admission projection is not bound to this exact manuscript");
  // This projection is deliberately not evidence of editorial acceptance. The
  // signed assessment receipt below is the only acceptance authority here.
  return sha256Digest(source);
}
function unconsumed(authorityReplayRoot, consumptionId) {
  const consumed = join(realDirectory(authorityReplayRoot, "authority replay root"), "consumed", `${sha256Hex(consumptionId)}.json`);
  if (existsSync(consumed)) fail("publication authority use has already been consumed");
}
function issueName(jobId) { return `${jobId}.json`; }
function digestFile(path, label) { return sha256Digest(readFileSync(realFile(path, label))); }

/**
 * Verify the immutable issue and manuscript-evidence bytes bound into one v2 queue
 * job.  Candidate formation calls this before it reads any mutable manuscript
 * coordinate, so a queue file cannot smuggle a hand-written admission through
 * the scheduler.
 */
export function verifyRoutineIssue(job) {
  const required = ["admissionPath", "assessmentReceiptPath", "authorityGrantPath", "candidateName", "contentDir", "draftPath", "issueFormation", "jobId", "kind", "operation", "manuscriptEvidence"];
  exactKeys(job, required, "routine issue job");
  if (job.kind !== JOB_KIND || job.operation !== "form-offline-candidate" || !isId(job.jobId) || typeof job.candidateName !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u.test(job.candidateName) || basename(job.candidateName) !== job.candidateName) fail("routine issue job has invalid identity");
  for (const field of ["admissionPath", "assessmentReceiptPath", "authorityGrantPath", "draftPath"]) realFile(job[field], `routine issue job ${field}`);
  realDirectory(job.contentDir, "routine issue job contentDir");
  exactKeys(job.issueFormation, ["path", "sha256"], "routine issue formation reference");
  exactKeys(job.manuscriptEvidence, ["path", "sha256"], "routine issue manuscript evidence reference");
  if (!isDigest(job.issueFormation.sha256) || !isDigest(job.manuscriptEvidence.sha256)) fail("routine issue provenance digest is invalid");
  const issuePath = realFile(job.issueFormation.path, "routine issue formation record");
  const evidencePath = realFile(job.manuscriptEvidence.path, "routine issue manuscript evidence");
  const issueSource = readFileSync(issuePath, "utf8");
  if (sha256Digest(issueSource) !== job.issueFormation.sha256) fail("routine issue formation record digest does not match queue job");
  const evidenceSource = readFileSync(evidencePath, "utf8");
  if (sha256Digest(evidenceSource) !== job.manuscriptEvidence.sha256) fail("routine issue manuscript evidence digest does not match queue job");
  const manuscriptSource = readFileSync(realFile(job.draftPath, "routine issue draft"), "utf8");
  const manuscriptDigest = sha256Digest(manuscriptSource);
  let issue;
  try { issue = JSON.parse(issueSource); } catch (error) { fail(`routine issue formation record is not JSON: ${error.message}`); }
  exactKeys(issue, ["authority", "editorialAssessment", "job", "kind", "manuscript", "provenance"], "routine issue formation record");
  if (issue.kind !== ISSUE_KIND || JSON.stringify(issue.job) !== JSON.stringify(Object.fromEntries(["admissionPath", "assessmentReceiptPath", "authorityGrantPath", "candidateName", "contentDir", "draftPath", "jobId", "operation"].map((key) => [key, job[key]])))) fail("routine issue formation record is not bound to this exact queue job");
  if (!isRecord(issue.manuscript) || issue.manuscript.digest !== manuscriptDigest || !isSlug(issue.manuscript.slug)) fail("routine issue formation record is not bound to its exact manuscript");
  const evidenceRecord = manuscriptEvidenceRecord(evidenceSource, parsePost(manuscriptSource, basename(job.draftPath)).body);
  if (!isRecord(issue.provenance) || issue.provenance.evidenceDigest !== evidenceRecord.digest || issue.provenance.claimCount !== evidenceRecord.claimCount || issue.provenance.candidateId !== evidenceRecord.candidateId || issue.provenance.evidenceDigest !== job.manuscriptEvidence.sha256) fail("routine issue formation record is not bound to its manuscript evidence");
  if (!isRecord(issue.editorialAssessment) || issue.editorialAssessment.receiptDigest !== digestFile(job.assessmentReceiptPath, "routine issue assessment receipt") || !isRecord(issue.authority) || issue.authority.grantDigest !== digestFile(job.authorityGrantPath, "routine issue authority grant")) fail("routine issue formation record does not match its editorial evidence");
  return Object.freeze({ issueDigest: job.issueFormation.sha256, issuePath, manuscriptEvidenceDigest: evidenceRecord.digest, manuscriptEvidencePath: evidencePath, manuscriptDigest, manuscriptSlug: issue.manuscript.slug });
}

/**
 * Form one immutable queue job from already-settled reporting and independently
 * authenticated editorial evidence. This is a queue effect only: it neither
 * spends publication authority nor forms, releases, or publishes a candidate.
 */
export function formRoutineIssue(input) {
  const manuscriptPath = realFile(input.draftPath, "draft");
  const manuscriptSource = readFileSync(manuscriptPath, "utf8");
  const manuscriptDigest = sha256Digest(manuscriptSource);
  if (!isSlug(input.manuscriptSlug)) fail("manuscriptSlug is invalid");
  if (!isId(input.jobId)) fail("jobId is invalid");
  if (typeof input.candidateName !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u.test(input.candidateName) || basename(input.candidateName) !== input.candidateName) fail("candidateName is invalid");
  const contentDir = realDirectory(input.contentDir, "content directory");
  const manuscriptBody = parsePost(manuscriptSource, basename(manuscriptPath)).body;
  const evidence = manuscriptEvidenceFromJournal({ dataRoot: input.dataRoot, candidateId: input.candidateId, manuscriptBody });
  const evidenceSource = `${canonicalJson(evidence)}\n`;
  const evidenceRecord = manuscriptEvidenceRecord(evidenceSource, manuscriptBody);
  const admissionPath = realFile(input.admissionPath, "admission projection");
  const admissionDigest = admission(readFileSync(admissionPath, "utf8"), manuscriptDigest, input.manuscriptSlug);
  const assessment = verifyAssessmentReceipt({ receiptSource: readFileSync(realFile(input.assessmentReceiptPath, "assessment receipt"), "utf8"), assessmentKeys: jsonFile(input.assessmentKeysPath, "assessment key map").value, manuscriptSource, manuscriptSlug: input.manuscriptSlug, now: input.now });
  const grantPath = realFile(input.authorityGrantPath, "publication grant");
  const authority = verifyPublicationAuthority({ grantSource: readFileSync(grantPath, "utf8"), authorityKeys: jsonFile(input.authorityKeysPath, "authority key map").value, assessmentReceiptSource: readFileSync(realFile(input.assessmentReceiptPath, "assessment receipt"), "utf8"), assessmentKeys: jsonFile(input.assessmentKeysPath, "assessment key map").value, manuscriptSource, manuscriptSlug: input.manuscriptSlug, now: input.now });
  unconsumed(input.authorityReplayRoot, authority.consumptionId);
  const queueRoot = realDirectory(input.queueRoot, "routine issue queue root");
  const formationRoot = realDirectory(input.formationReplayRoot, "routine issue formation replay root");
  const evidenceRoot = join(formationRoot, "manuscript-evidence"), issuesRoot = join(formationRoot, "issues"); mkdirSync(evidenceRoot, { recursive: true, mode: 0o700 }); mkdirSync(issuesRoot, { recursive: true, mode: 0o700 }); fsyncDirectory(formationRoot); fsyncDirectory(evidenceRoot); fsyncDirectory(issuesRoot);
  const coreJob = Object.freeze({ admissionPath, assessmentReceiptPath: realFile(input.assessmentReceiptPath, "assessment receipt"), authorityGrantPath: grantPath, candidateName: input.candidateName, contentDir, draftPath: manuscriptPath, jobId: input.jobId, operation: "form-offline-candidate" });
  const issue = Object.freeze({ kind: ISSUE_KIND, authority: Object.freeze({ consumptionId: authority.consumptionId, grantDigest: authority.grantDigest, scope: authority.scope }), editorialAssessment: Object.freeze({ assessmentId: assessment.receipt.assessmentId, receiptDigest: assessment.digest }), job: coreJob, manuscript: Object.freeze({ digest: manuscriptDigest, slug: input.manuscriptSlug }), provenance: Object.freeze({ admissionDigest, evidenceDigest: evidenceRecord.digest, claimCount: evidenceRecord.claimCount, candidateId: evidenceRecord.candidateId }) });
  const source = `${JSON.stringify(issue)}\n`;
  const evidencePath = join(evidenceRoot, `${evidenceRecord.digest.slice("sha256:".length)}.json`);
  if (!createOnly(evidencePath, evidenceSource) && readFileSync(evidencePath, "utf8") !== evidenceSource) fail("manuscript evidence digest is already bound to different bytes");
  else fsyncDirectory(evidenceRoot);
  const issuePath = join(issuesRoot, `${sha256Hex(authority.consumptionId)}.json`);
  if (!createOnly(issuePath, source)) {
    const prior = readFileSync(issuePath, "utf8");
    if (prior !== source) fail("publication authority is already reserved by a different routine issue");
  } else fsyncDirectory(issuesRoot);
  const job = Object.freeze({ ...coreJob, kind: JOB_KIND, issueFormation: Object.freeze({ path: issuePath, sha256: sha256Digest(source) }), manuscriptEvidence: Object.freeze({ path: evidencePath, sha256: evidenceRecord.digest }) });
  const queuePath = join(queueRoot, issueName(input.jobId));
  const createdQueueJob = createOnly(queuePath, `${JSON.stringify(job)}\n`);
  if (!createdQueueJob) {
    if (readFileSync(queuePath, "utf8") !== `${JSON.stringify(job)}\n`) fail("routine issue jobId is already bound to different queue bytes");
  } else fsyncDirectory(queueRoot);
  return Object.freeze({ disposition: "queued", idempotent: !createdQueueJob, issueDigest: sha256Digest(source), issuePath, manuscriptEvidenceDigest: evidenceRecord.digest, manuscriptEvidencePath: evidencePath, jobPath: queuePath, jobSha256: sha256Digest(`${JSON.stringify(job)}\n`), authority: Object.freeze({ consumptionId: authority.consumptionId, consumed: false }) });
}
