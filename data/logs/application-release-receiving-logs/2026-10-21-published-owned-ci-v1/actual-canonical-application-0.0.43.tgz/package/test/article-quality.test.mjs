import{test}from'node:test';import assert from'node:assert/strict';import{readFileSync}from'node:fs';import{articleQuality}from'../src/article-quality.mjs';
const property=JSON.parse(readFileSync('config/koios-news-property.json'));
test('The original short Welsh summary cannot receive a new depth admission',()=>{const source=readFileSync('test/fixtures/welsh-short-original.md','utf8');assert.equal(articleQuality(source,{property}).ok,false);assert.ok(articleQuality(source,{property}).failures.includes('insufficient-reporting-depth'));});
test('Length and repeated claims cannot substitute for reporting',()=>{const claim={subject:'x',predicate:'said',object:'y',sourceUrl:'https://example.org/report'};const source='## Context\n'+Array(900).fill('filler').join(' ');const result=articleQuality(source,{claims:Array(30).fill(claim),property});assert.equal(result.assertions,1);assert.equal(result.ok,false);assert.ok(result.failures.includes('too-much-prose-for-evidence'));});
test('A public-surface feedback audit does not invent zero claim evidence',()=>{const source='---\ntitle: Test\n---\n## What happened\n'+Array(320).fill('reported').join(' ');const result=articleQuality(source,{property,claims:null,evidenceRequired:false});assert.equal(result.evidenceAvailable,false);assert.equal(result.assertions,null);assert.equal(result.sourceHosts,null);assert.equal(result.failures.includes('insufficient-distinct-supported-assertions'),false);assert.equal(result.failures.includes('insufficient-source-origins'),false);});
import {mkdtempSync,mkdirSync,writeFileSync,rmSync} from 'node:fs';import {tmpdir}from'node:os';import{join}from'node:path';import{createHash}from'node:crypto';import{planRoutinePublication}from'../src/offline-publication.mjs';
test('The final publication writer refuses the actual short Welsh manuscript through alternate entry points',()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-depth-')),corpus=join(root,'drafts'),propertyContent=join(root,'content');mkdirSync(corpus);mkdirSync(propertyContent);
 const slug='welsh-first-minister-pushes-for-more-devolution-powers';const source=readFileSync('test/fixtures/welsh-short-original.md','utf8').replace('draft: false','draft: true');const draftPath=join(corpus,slug+'.md'),admissionPath=join(root,'admission.json');writeFileSync(draftPath,source);
 writeFileSync(admissionPath,JSON.stringify({slug,manuscriptDigest:'sha256:'+createHash('sha256').update(source).digest('hex'),disposition:'accept',publishable:true,serviceAccepted:true,contract:'ni:///sha-256;GTSsfC0lmcjPLQvtlGmYwLJLCa9pirz1d8oUqRweioo',selectedTool:'submit_editorial_acceptance',toolSelectionValidated:true,toolSelectionDigest:'fixture'}));
 try{assert.throws(()=>planRoutinePublication({property,propertyContentDir:propertyContent,contentDir:corpus,draftPath,admissionPath,outputDir:join(root,'candidate')}),/Publication requires complete reporting/);}finally{rmSync(root,{recursive:true,force:true});}
});

test('Short and long reporting are genuinely different editorial products, not the same global word floor',()=>{
 const base=property;
 const withSportsBrief={...base,sections:base.sections.map(desk=>desk.slug==='sport'?{...desk,editorialProductProfile:'current-news-brief/v1'}:desk)};
 const brief='## Confirmed update\n'+Array(375).fill('reported').join(' ');
 const sports=articleQuality(brief,{property:withSportsBrief,candidate:{section:'sport'},claims:[],evidenceRequired:false});
 const standard=articleQuality(brief,{property:withSportsBrief,candidate:{section:'world'},claims:[],evidenceRequired:false});
 assert.equal(sports.failures.includes('insufficient-reporting-depth'),false);
 assert.equal(standard.failures.includes('insufficient-reporting-depth'),true);
 const feature=articleQuality(brief,{property:withSportsBrief,section:'sport',productProfile:'culture-feature/v1',claims:[],evidenceRequired:false});
 assert.equal(feature.failures.includes('insufficient-reporting-depth'),true);
});
test('A specific cultural or scientific commission can opt into an evidence-law profile',()=>{
 const text='## Reporting\n'+Array(900).fill('documented').join(' ');
 const cultural=articleQuality(text,{property,section:'culture-entertainment',productProfile:'culture-feature/v1',evidenceRequired:false,claims:[]});
 const science=articleQuality(text,{property,section:'science-climate',productProfile:'science-explainer/v1',evidenceRequired:false,claims:[]});
 assert.ok(cultural.failures.includes('insufficient-reporting-depth'));
 assert.equal(science.failures.includes('insufficient-reporting-depth'),false);
 assert.throws(()=>articleQuality(text,{property,section:'missing',claims:[]}),/Unknown editorial desk/);
 assert.throws(()=>articleQuality(text,{property,section:'science-climate',productProfile:'phantom/v1',claims:[]}),/Unknown commissioned editorial product/);
});
