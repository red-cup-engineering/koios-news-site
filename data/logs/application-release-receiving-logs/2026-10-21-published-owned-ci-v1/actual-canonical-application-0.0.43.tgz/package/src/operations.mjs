/**
 * Koios News's newsroom operations at its own service boundary: forming an
 * admissible research packet and a licensed editorial state from a
 * demand, forming and verifying a routine issue from Content Mill evidence,
 * taking the next routine job, auditing production, and settling a message at the service
 * section's ActivityStreams boundary.
 */
import { operation } from "@red-cup-engineering/computer-system-engine/rpc/operation";
import { formAdmissibleResearchPacket } from "./contract-admissible-research-packet.mjs";
import { formLicensedEditorialState } from "./contract-licensed-editorial-state.mjs";
import { formRoutineIssue, verifyRoutineIssue } from "./routine-issue-formation.mjs";
import { selectRoutineQueueJob } from "./routine-job-queue.mjs";
import { formRoutinePublication, previewRoutinePublication } from "./routine-publication.mjs";
import { newsroomDay } from "./newsroom-day.mjs";
import { koiosNewsStatus, runKoiosNewsCycle } from "./news-line.mjs";
import { koiosClaimCells } from "./claim-cells.mjs";
import { newsLineContext } from "./news-line/stages.mjs";
import { auditProduction } from "./production-audit.mjs";
import {publisherReadinessOperations} from '@causeway-services/koios-publisher-readiness-service/operations';
import { describeServiceSection, settleMessage } from "./service-section.mjs";

const instantOf = (input) => input?.instant ?? new Date().toISOString();

export function koiosNewsOperations(_binding, { environment = process.env, configuration = {} } = {}) {
  if (configuration === null || typeof configuration !== "object" || Array.isArray(configuration)
    || Object.keys(configuration).some(key => key !== "environmentBindings")) {
    throw new TypeError("Koios operation configuration declares only environmentBindings");
  }
  // Installed operation factories receive their host-selected configuration.
  // Bind names, never secret values, in the instance declaration. Keep this
  // application scoped; changing process.env would change every other tenant.
  const bindings = configuration.environmentBindings ?? {};
  if (bindings === null || typeof bindings !== "object" || Array.isArray(bindings)) {
    throw new TypeError("Koios environmentBindings must map environment variable names");
  }
  const selectedEnvironment = { ...environment };
  for (const [target, source] of Object.entries(bindings)) {
    if (!/^[A-Z][A-Z0-9_]*$/u.test(target) || typeof source !== "string"
      || !/^[A-Z][A-Z0-9_]*$/u.test(source)) {
      throw new TypeError("Koios environment bindings require variable names");
    }
    if (typeof environment[source] !== "string" || environment[source].trim() === "") {
      throw new TypeError(`Koios required host binding is absent: ${source}`);
    }
    selectedEnvironment[target] = environment[source];
  }
  Object.freeze(selectedEnvironment);
  // Read newsroom custody when an operation executes, not while the host
  // installs its catalog. Merely loading the app must not open its journals.
  const lineContext = () => newsLineContext({ environment: selectedEnvironment });
  return Object.freeze([
    operation({
      verb: "koios-service-section",
      summary: "Describe the Koios News service section: its offered services, boundary and inbox.",
      description: "Domain: {}. Codomain: the ActivityStreams Service describing the section.",
      run: () => describeServiceSection(),
    }),
    operation({
      verb: "koios-research-packet",
      summary: "Form an admissible research packet from a research demand.",
      description: "Domain: { demand, instant? }: an AdmissibleResearchPacketDemand (assignment, primary source URLs, delivered public web texts, prior research). Codomain: the packet with its selected sources, or a typed refusal naming the layer to repair.",
      run: (input) => formAdmissibleResearchPacket(input?.demand, instantOf(input)),
    }),
    operation({
      verb: "koios-editorial-state",
      summary: "Form the licensed editorial state a writer works under from an editorial demand.",
      description: "Domain: { demand, instant? }: a LicensedEditorialStateDemand (assignment, research packet, genre requirements, section purposes, writer prompt laws). Codomain: the licensed editorial state, or a typed refusal.",
      run: (input) => formLicensedEditorialState(input?.demand, instantOf(input)),
    }),
    operation({
      verb: "koios-routine-issue",
      summary: "Form a routine issue job from an admitted draft and its receipts.",
      description: "Domain: { draftPath, manuscriptSlug, jobId, candidateName, ... } naming the draft, admission, assessment receipt, authority grant and content directory. Codomain: the routine issue job.",
      reads: ["koios-news/drafts"],
      run: (input) => formRoutineIssue(input ?? {}),
    }),
    operation({
      verb: "koios-routine-issue-verify",
      summary: "Verify a routine issue job against its files and Content Mill manuscript evidence.",
      description: "Domain: a routine issue job. Codomain: the verified job; a mismatch is refused.",
      reads: ["koios-news/drafts"],
      run: (input) => verifyRoutineIssue(input),
    }),
    operation({
      verb: "koios-routine-queue-job",
      summary: "Take the next routine issue job from the queue, binding it to one pulse.",
      description: "Domain: { queueRoot, replayRoot, pulseId, reserve? }. Codomain: the selected job; the replay root keeps the occurrence-to-job binding so a retry never advances the queue or rebinds a manuscript.",
      writes: ["koios-news/replay"],
      run: (input) => selectRoutineQueueJob(input ?? {}),
    }),
    operation({
      verb: "koios-newsroom-day",
      summary: "Run one newsroom pulse: take the wires' fresh arrivals from the source broker, select the day's stories, buy their claim extraction, and settle the pulse.",
      description: "Domain: { maxStories?, maxSourcesPerStory? }. The property record is the host's (KOIOS_NEWS_PROPERTY names its file); its data root is KOIOS_NEWSROOM_DATA_ROOT, by default the property's own under ~/.local/state. The broker's cursor there skips arrivals already taken. Codomain: the pulse's intake, selection, claim and settlement counts and its budget readout.",
      reads: ["news/wires"],
      writes: ["koios-news/stories", "koios-news/claims", "inference/purchases"],
      effects: { class: "external", replay: "coordinated", coordination: "coordination-required", deterministic: "unmeasured", totality: "unmeasured" },
      run: (input) => newsroomDay({ ...input, environment: selectedEnvironment }),
    }),
    operation({
      verb: "koios-news-cycle",
      summary: "Run one cycle of the Koios news line: intake, analyze, draft, assess, authorize, render, release, feedback.",
      description: "Domain: { maxTurns? }. Each locked turn selects ready editorial work or an independent source opportunity. Unchanged attempted editorial custody yields; each stage runs at most once within maxTurns. The cycle stops at feedback, its ready-release boundary, exhausted eligible work or the turn budget. Stage failures retain their incident and repair request. Unreadable selection history rejects the cycle before that turn executes, without appending an event through the unreadable carrier. Editions carry each manuscript from Content Mill draft through independent assessment and the editor-in-chief's standing policy to a Cloudflare release of koios.news. Codomain: the turns run and the line's status.",
      reads: ["news/wires", "koios-news/editions"],
      writes: ["koios-news/stories", "koios-news/claims", "koios-news/editions", "koios-news/candidates", "koios-news/releases", "inference/purchases"],
      effects: { class: "external", replay: "coordinated", coordination: "coordination-required", deterministic: "unmeasured", totality: "unmeasured" },
      run: (input) => runKoiosNewsCycle({ context: lineContext(), ...(input?.maxTurns === undefined ? {} : { maxTurns: input.maxTurns }) }),
    }),
    operation({
      verb: "koios-news-status",
      summary: "Read the Koios news line: its stages, blockers, editions by state, and the newsroom's competitive measures.",
      description: "Domain: {}. Codomain: the line's status with articles in the last day against the daily target, draft-to-release latency, desk coverage, editorial acceptance rate and returned failure layers.",
      reads: ["koios-news/editions"],
      run: () => koiosNewsStatus({ context: lineContext() }),
    }),
    operation({
      verb: "koios-claim-cells",
      summary: "Read the claims the Koios newsroom tracks, each as a FOUR cell with its sources on each side.",
      description: "Domain: { story?, reading?, limit?, cursor? }. story filters to claims a story cites; reading to one knowledge reading (absurd, potential, active or stable: told nothing, for, against, both); limit is 1 to 200, default 50; cursor is the previous page's nextCursor. Codomain: { cells, matching, skipped, nextCursor } where each cell is { id (the claim's content address), statement, reading, sources: { for, against } (each a source content address, host and URL), storyIds, editionIds }. Evidence for one claim folds by the knowledge join, so a reading never depends on arrival order. Read-only: nothing is written, published or offered.",
      reads: ["koios-news/claims", "koios-news/editions"],
      effects: { class: "host-read", replay: "safe", coordination: "coordination-free", deterministic: "unmeasured", totality: "partial" },
      run: (input) => koiosClaimCells(lineContext().dataRoot, input ?? {}),
    }),
    operation({
      verb: "koios-routine-publication",
      summary: "Form this pulse's routine publication: write the selected issue job as an offline reader-facing candidate.",
      description: "Domain: { pulseId?, preview? }. The pulse defaults to the clock occurrence that runs it, so a retried occurrence never takes a second job from the queue; preview plans with no effect. The job, keys and candidate roots are the host's (config/routine-operation.json names them). This forms a candidate; it does not deploy or release it.",
      reads: ["koios-news/drafts"],
      writes: ["koios-news/candidates", "koios-news/replay"],
      effects: { class: "external", replay: "idempotency-key", coordination: "coordination-required", deterministic: "unmeasured", totality: "unmeasured" },
      run: (input, _args, context) => {
        const caller = context?.invocation?.caller, now = context?.startedAt ?? new Date().toISOString();
        if (input?.preview === true) return previewRoutinePublication({ now, environment: selectedEnvironment });
        const pulseId = input?.pulseId ?? (caller?.schedule === undefined ? undefined : `${caller.schedule}#${caller.occurrence}`);
        return formRoutinePublication({ pulseId, now, environment: selectedEnvironment });
      },
    }),
    operation({
      verb: "koios-production-audit",
      summary: "Audit the live production against its release, schedule, scheduler, backup and restore receipts.",
      description: "Domain: { releaseReceiptPath, scheduleTransitionReceiptPath, schedulerTickPath, backupReceiptPath, restoreReceiptPath }. Codomain: accepted and failed checks with problems and warnings.",
      reads: ["koios-news/receipts"],
      run: (input) => auditProduction(input ?? {}),
    }),
    ...publisherReadinessOperations(),
    operation({
      verb: "koios-settle-message",
      summary: "Settle one ActivityStreams message at the Koios service section's boundary.",
      description: "Domain: { activity, instant? }. Codomain: the offer, contract delivery or typed Reject; replaying the exact message returns the first durable response.",
      writes: ["koios-news/inbox-settlements"],
      run: (input) => settleMessage(input?.activity, instantOf(input)),
    }),
  ]);
}
