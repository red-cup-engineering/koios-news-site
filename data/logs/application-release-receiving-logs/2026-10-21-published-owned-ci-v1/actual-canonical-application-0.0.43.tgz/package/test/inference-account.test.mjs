import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {loadDirectEndpointProviderDescriptors,directEndpointAdmissionReasons} from '@red-cup-engineering/computer-inference-engine/dispatch/direct-endpoint-provider';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {assessZeroCashWriterFailover,observeInferenceAccount,refreshInferenceAccounts,requiresPrivateAccountObservation,requireZeroCashWriterFailover,requireNewsroomWriterAdmission} from '../src/inference-account.mjs';

const descriptor={provider:'urn:ame:gemini-inference-team',model:'gemini-3.8-flash',endpoint:'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',apiKey:'fixture-secret'};
const freeDescriptor={provider:'urn:ame:openrouter-inference-team',model:'nvidia/nemotron-3-super-120b-a12b:free',endpoint:'https://openrouter.ai/api/v1/chat/completions',apiKey:'fixture-openrouter'};

test('Account observation follows the live key parent and keeps credentials out of returned evidence',async()=>{
 const urls=[];
 const result=await observeInferenceAccount(descriptor,{now:()=>0,request:async url=>{urls.push(url);return url.includes('lookupKey')?{parent:'projects/123/locations/global',name:'private-resource'}:{billingEnabled:false,billingAccountName:''};}});
 assert.equal(urls[1],'https://cloudbilling.googleapis.com/v1/projects/123/billingInfo');
 assert.equal(result.billingEnabled,false);assert.equal(result.billingAccountBound,false);
 assert.equal(JSON.stringify(result).includes('fixture-secret'),false);assert.equal(JSON.stringify(result).includes('private-resource'),false);
});
test('Attached billing remains paid evidence and unknown billing is refused',async()=>{
 const request=async url=>url.includes('lookupKey')?{parent:'projects/123/locations/global',name:'key'}:{billingEnabled:true,billingAccountName:'billingAccounts/123'};
 const result=await observeInferenceAccount(descriptor,{request});assert.equal(result.billingEnabled,true);assert.equal(result.billingAccountBound,true);
 await assert.rejects(observeInferenceAccount(descriptor,{request:async url=>url.includes('lookupKey')?{parent:'projects/123/locations/global',name:'key'}:{}}),/no billing state/);
});
test('Provider observation failure does not disclose its credential',async()=>{
 await assert.rejects(observeInferenceAccount(descriptor,{request:async()=>{throw new Error('denied keyString=fixture-secret');}}),error=>error.message.includes('<redacted>')&&!error.message.includes('fixture-secret'));
});

test('Private account refresh observes Google but does not misroute contract-free providers through the Google billing observer',async(t)=>{
 assert.equal(requiresPrivateAccountObservation(descriptor),true);
 assert.equal(requiresPrivateAccountObservation(freeDescriptor),false);
 const dir=mkdtempSync(join(tmpdir(),'koios-inference-account-'));
 t.after(()=>rmSync(dir,{recursive:true,force:true}));
 const destination=join(dir,'entitlements.json');
 const calls=[];
 const rows=await refreshInferenceAccounts([descriptor,freeDescriptor],destination,{observe:async d=>{
  calls.push(d.provider);
  return {
   type:'GoogleApiKeyAccountObservation',
   accountIdentity:'projects/123',
   observedAt:'2026-10-10T06:00:00.000Z',
   billingEnabled:false,
   billingAccountBound:false,
   evidenceIdentity:'ni:///sha-256;fixture',
   credentialSha256:'fixture-hash',
  };
 }});
 assert.deepEqual(calls,[descriptor.provider]);
 assert.equal(rows.length,1);
 assert.equal(rows[0].providerIdentity,descriptor.provider);
 assert.equal(rows[0].cashCost,'zero');
 assert.equal(rows[0].paidOverage,'forbidden');
 assert.deepEqual(JSON.parse(readFileSync(destination,'utf8')),rows);
});


test('Writer startup reports degraded failover but still requires a zero-cash provider',()=>{
 const admitted={provider:'one',model:'free-one',reasons:[]};
 const second={provider:'two',model:'free-two',reasons:[]};
 const refused={provider:'two',model:'free-two',reasons:['zero-cash-entitlement-not-admitted']};
 assert.deepEqual(requireZeroCashWriterFailover([admitted,second]).admitted.map(row=>row.provider),['one','two']);
 assert.deepEqual(assessZeroCashWriterFailover([admitted,refused]),{admitted:[admitted],providerCount:1,minimum:2,ok:false,degraded:true,unavailable:false});
 assert.deepEqual(requireZeroCashWriterFailover([admitted,refused],{allowDegraded:true}).admitted,[admitted]);
 assert.throws(()=>requireZeroCashWriterFailover([admitted,refused]),/requires at least 2 admitted zero-cash providers; found 1/u);
 assert.throws(()=>requireZeroCashWriterFailover([],{allowDegraded:true}),/requires at least 1 admitted zero-cash provider; found 0/u);
});

function admissionFixture(t){
 const dir=mkdtempSync(join(tmpdir(),'koios-stage-admission-'));
 t.after(()=>rmSync(dir,{recursive:true,force:true}));
 const config=join(dir,'providers.json'),destination=join(dir,'entitlements.json');
 writeFileSync(config,JSON.stringify([{provider:descriptor.provider,endpoint:descriptor.endpoint,model:descriptor.model,apiKeyEnv:'FIXTURE_KEY'}]));
 const environment={DIRECT_ENDPOINT_PROVIDER_CONFIG:config,DIRECT_ENDPOINT_ACCOUNT_ENTITLEMENTS:destination,FIXTURE_KEY:'fixture-secret'};
 const calls=[];
 const observe=async d=>{
  calls.push(d.provider);
  return {type:'GoogleApiKeyAccountObservation',accountIdentity:'projects/123',observedAt:new Date().toISOString(),billingEnabled:false,billingAccountBound:false,evidenceIdentity:'ni:///sha-256;fixture-observation',credentialSha256:createHash('sha256').update(d.apiKey).digest('hex')};
 };
 return {environment,calls,observe,destination,config};
}

test('writer admission renews missing evidence once and reuses the still-current credential-bound lease',async t=>{
 const {environment,calls,observe}=admissionFixture(t);
 const first=await requireNewsroomWriterAdmission(environment,{observe});
 const second=await requireNewsroomWriterAdmission(environment,{observe});
 assert.equal(calls.length,1);
 assert.deepEqual(first.writerFailover,{minimum:2,admitted:1,admittedModels:1,degraded:true});
 assert.deepEqual(second,first);
 assert.equal(JSON.stringify(first).includes('fixture-secret'),false);
});

test('expired or changed-credential evidence must be renewed before a later writer effect',async t=>{
 const {environment,calls,observe,destination}=admissionFixture(t);
 await requireNewsroomWriterAdmission(environment,{observe});
 const expired=JSON.parse(readFileSync(destination,'utf8'));
 expired[0].observedAt='2020-01-01T00:00:00.000Z';expired[0].validUntil='2020-01-01T01:00:00.000Z';
 writeFileSync(destination,JSON.stringify(expired));
 await requireNewsroomWriterAdmission(environment,{observe});
 assert.equal(calls.length,2);
 environment.FIXTURE_KEY='fixture-replacement-never-transmitted';
 await requireNewsroomWriterAdmission(environment,{observe});
 assert.equal(calls.length,3);
});

test('writer admission refuses attached billing and malformed retained evidence',async t=>{
 const {environment,observe,destination}=admissionFixture(t);
 await assert.rejects(requireNewsroomWriterAdmission(environment,{observe:async d=>({...await observe(d),billingEnabled:true})}),/billing is attached/);
 writeFileSync(destination,'not JSON');
 await assert.rejects(requireNewsroomWriterAdmission(environment,{observe}));
});

test('contract-free writer admission prepares the configured evidence path without private account observation',async t=>{
 const {environment,config,calls,observe,destination}=admissionFixture(t);
 writeFileSync(config,JSON.stringify([{providerId:'openrouter-cohere-north',actor:'urn:ame:openrouter-inference-team',model:'nvidia/nemotron-3-super-120b-a12b:free'}]));
 environment.API_KEY_OPENROUTER='fixture-only-never-transmitted';
 const admitted=await requireNewsroomWriterAdmission(environment,{observe});
 assert.equal(admitted.writerFailover.admitted,1);
 assert.deepEqual(calls,[]);
 const actualDispatchDescriptors=loadDirectEndpointProviderDescriptors(environment,{configPath:environment.DIRECT_ENDPOINT_PROVIDER_CONFIG});
 assert.equal(actualDispatchDescriptors.length,1);
 assert.deepEqual(directEndpointAdmissionReasons(actualDispatchDescriptors[0],{zeroCashOnly:true}),[]);
 assert.deepEqual(JSON.parse(readFileSync(destination,'utf8')),[]);
});

test('Google private observation failure cannot starve separately admitted free writers',async t=>{
 const {environment,config,destination,calls}=admissionFixture(t);
 writeFileSync(config,JSON.stringify([
  {provider:descriptor.provider,endpoint:descriptor.endpoint,model:descriptor.model,apiKeyEnv:'FIXTURE_KEY'},
  {providerId:'openrouter-cohere-north',actor:'urn:ame:openrouter-inference-team',
   model:'nvidia/nemotron-3-super-120b-a12b:free'},
 ]));
 environment.API_KEY_OPENROUTER='fixture-only-key';
 const accepted=await requireNewsroomWriterAdmission(environment,{observe:async d=>{
  calls.push(d.provider);
  throw new Error('Google project billing observer has no IAM permission');
 }});
 assert.equal(calls.length,1);
 assert.deepEqual(JSON.parse(readFileSync(destination,'utf8')),[]);
 assert.equal(accepted.writerFailover.admitted,1);
 assert.equal(accepted.writerFailover.degraded,true);
 assert.deepEqual(accepted.privateAccountRefusals,[{
  provider:descriptor.provider,model:descriptor.model,reason:'private-account-observation-unavailable'
 }]);
 assert.equal(JSON.stringify(accepted).includes('fixture-only-key'),false);
 assert.equal(JSON.stringify(accepted).includes('IAM permission'),false);
 const admitted=loadDirectEndpointProviderDescriptors(environment,{configPath:environment.DIRECT_ENDPOINT_PROVIDER_CONFIG});
 assert.equal(admitted.some(d=>d.provider==='urn:ame:openrouter-inference-team'
  && directEndpointAdmissionReasons(d,{zeroCashOnly:true}).length===0),true);
});

test('Google paid or malformed evidence remains unadmitted during independent free fallback',async t=>{
 const {environment,config,destination,observe}=admissionFixture(t);
 writeFileSync(config,JSON.stringify([
  {provider:descriptor.provider,endpoint:descriptor.endpoint,model:descriptor.model,apiKeyEnv:'FIXTURE_KEY'},
  {providerId:'openrouter-cohere-north',actor:'urn:ame:openrouter-inference-team',
   model:'nvidia/nemotron-3-super-120b-a12b:free'}
 ]));
 environment.API_KEY_OPENROUTER='fixture-only-key';
 for(const [observation,reason] of [
  [async d=>({...await observe(d),billingEnabled:true,billingAccountBound:true}),'private-account-zero-cash-unverified'],
  [async d=>({...await observe(d),observedAt:'malformed'}),'private-account-observation-invalid'],
 ]) {
  // Even an older qualified Google lease is revoked on a new bad observation.
  writeFileSync(destination,JSON.stringify([{
   providerIdentity:descriptor.provider,endpoint:descriptor.endpoint,model:descriptor.model,
   credentialSha256:createHash('sha256').update(environment.FIXTURE_KEY).digest('hex'),
   observedAt:'2020-01-01T00:00:00.000Z',validUntil:'2020-01-01T01:00:00.000Z',
   cashCost:'zero',paidOverage:'forbidden'
  }]));
  const accepted=await requireNewsroomWriterAdmission(environment,{observe:observation});
  assert.equal(accepted.writerFailover.admitted,1);
  assert.equal(accepted.privateAccountRefusals[0].reason,reason);
  assert.deepEqual(JSON.parse(readFileSync(destination,'utf8')),[]);
 }
});

test('Private observation exceptions must remain fatal when there is no admitted independent route',async t=>{
 const {environment}=admissionFixture(t);
 await assert.rejects(requireNewsroomWriterAdmission(environment,{observe:async()=>{
  throw new Error('Google observer denied');
 }}),/Google observer denied/);
});
