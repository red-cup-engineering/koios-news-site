import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {createRecoverySnapshot,verifyRecoverySnapshot} from '../scripts/backup-newsroom.mjs';

test('Durable reporting and private keys recover exactly; disposable output is excluded',async()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-recovery-test-'));try{
  const dataRoot=join(root,'state'),keyPath=join(root,'backup.key'),destination=join(dataRoot,'recovery-upload');
  mkdirSync(join(dataRoot,'line','keys'),{recursive:true});mkdirSync(join(dataRoot,'feedback'));mkdirSync(join(dataRoot,'website-releases'));
  writeFileSync(keyPath,'a'.repeat(64),{mode:0o600});writeFileSync(join(dataRoot,'line','keys','office.key'),'private test signing key',{mode:0o600});writeFileSync(join(dataRoot,'journal.jsonl'),'preserved source evidence\n');writeFileSync(join(dataRoot,'feedback','events.jsonl'),'disposable');
  const snapshot=await createRecoverySnapshot({dataRoot,keyPath,destination});
  const restored=join(root,'restored');const proof=await verifyRecoverySnapshot({...snapshot,archivePath:snapshot.path,keyPath,destination:restored});
  assert.equal(proof.files,2);assert.equal(readFileSync(join(restored,'line','keys','office.key'),'utf8'),'private test signing key');assert.equal(readFileSync(join(restored,'journal.jsonl'),'utf8'),'preserved source evidence\n');
  assert.ok(!readdirSync(restored).includes('feedback'));assert.ok(!readFileSync(snapshot.path).includes(Buffer.from('private test signing key')));
  const bytes=readFileSync(snapshot.path);bytes[24]^=1;writeFileSync(snapshot.path,bytes);
  const receipt=JSON.parse(readFileSync(snapshot.receiptPath));receipt.sha256=createHash('sha256').update(bytes).digest('hex');writeFileSync(snapshot.receiptPath,JSON.stringify(receipt));
  const rejected=join(root,'rejected');await assert.rejects(verifyRecoverySnapshot({archivePath:snapshot.path,keyPath,destination:rejected}),/authenticate|Unsupported state/i);assert.deepEqual(readdirSync(rejected),[]);
 }finally{rmSync(root,{recursive:true,force:true});}
});
