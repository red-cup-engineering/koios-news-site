import assert from "node:assert/strict";
import test from "node:test";
import { boundedDraftDispatch, configuredDraftWriterTimeoutMs } from "../src/news-line/draft-dispatch.mjs";

test("draft dispatch timeout returns a typed writer obstruction and aborts the provider call", async () => {
  let sawSignal;
  const result = await boundedDraftDispatch(
    async (_request, { signal }) => {
      sawSignal = signal;
      return new Promise(() => {});
    },
    { objective: "fixture" },
    { customerActor: "urn:actor:fixture", timeoutMs: 5 },
  );

  assert.equal(sawSignal.aborted, true);
  assert.equal(result.outcome, "inference-obstructed");
  assert.deepEqual(result.directLaneRefusals, [{
    provider: "urn:ame:koios-news",
    reason: "writer-dispatch-timeout",
    cause: { kind: "cancelled", reason: "timeout" },
  }]);
});

test("draft dispatch returns prompt provider results before the timeout", async () => {
  const result = await boundedDraftDispatch(
    async (_request, { customerActor, signal }) => ({ outcome: "candidate-pending-koios-news-acceptance", customerActor, aborted: signal.aborted }),
    { objective: "fixture" },
    { customerActor: "urn:actor:fixture", timeoutMs: 1_000 },
  );

  assert.equal(result.customerActor, "urn:actor:fixture");
  assert.equal(result.aborted, false);
});

test("draft writer timeout defaults to a finite newsroom bound and can be disabled explicitly", () => {
  assert.equal(configuredDraftWriterTimeoutMs({ environment: {}, config: {} }), 180_000);
  assert.equal(configuredDraftWriterTimeoutMs({ environment: { KOIOS_NEWS_DRAFT_WRITER_TIMEOUT_MS: "0" }, config: {} }), null);
  assert.equal(configuredDraftWriterTimeoutMs({ environment: {}, config: { timeouts: { draftWriterMs: 250 } } }), 250);
  assert.throws(
    () => configuredDraftWriterTimeoutMs({ environment: { KOIOS_NEWS_DRAFT_WRITER_TIMEOUT_MS: "soon" }, config: {} }),
    /positive integer/,
  );
});
