import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { parseJavaScript } from "@red-cup-engineering/javascript-node-services-section/javascript-parser";

// Parse the publisher as source: importing it would execute publication.
const publisher = await readFile(new URL("../bin/koios-publish-source-observations.mjs", import.meta.url), "utf8");
const manifest = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
const imports = parseJavaScript(publisher).body.filter((node) => node.type === "ImportDeclaration");
const broker = "@causeway-services/newscable-source-broker";
const bindingsFrom = (source) => imports.filter((node) => node.source.value === source)
  .flatMap((node) => node.specifiers.map((specifier) => ({
    imported: specifier.imported?.name,
    local: specifier.local.name,
  })));

test("source-observation publisher declares its separately owned broker dependency", () => {
  assert.equal(manifest.dependencies[broker], "workspace:*");
  assert.ok(imports.every((node) => !node.source.value.startsWith("../services/newscable-source-broker/")));
});

test("source-observation publisher imports the broker's public index export", () => {
  assert.deepEqual(bindingsFrom(`${broker}/source-observation-index`),
    [{ imported: "sourceObservationIndex", local: "sourceObservationIndex" }]);
});

test("source-observation publisher imports the broker's public observation export", () => {
  assert.deepEqual(bindingsFrom(`${broker}/source-observation`),
    [{ imported: "SOURCE_OBSERVATION_INDEX_KEY", local: "SOURCE_OBSERVATION_INDEX_KEY" }]);
});
