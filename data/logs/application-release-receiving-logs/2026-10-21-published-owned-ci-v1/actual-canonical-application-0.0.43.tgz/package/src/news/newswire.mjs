/**
 * organizing-a-newswire - the single-wire facet.
 *
 * A newswire is one provenanced claim stream with its own store, masthead,
 * item projection, production writes, and web-free surfaces. Newscables bundle
 * these wires; they do not own the wire state.
 */
export {
  addDays,
  assertedNow,
  auditOf,
  claimLine,
  computesClaim,
  createNewswire,
  freshnessOf,
  htmlPage,
  itemSummary,
  itemTitle,
  loadWireBundles,
  projectItem,
  propositionText,
  publishedOf,
  readBundleFile,
  reportWrite,
  resolveDate,
  sortReverseChronological,
  updatedOf,
  wireSurfaceUrls,
  writeBundleIfAbsent,

} from "./cable/index.mjs";
