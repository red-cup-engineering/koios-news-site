import {execFileSync} from 'node:child_process';
import {put} from '@red-cup-engineering/semiotic-eavt-services-section/store';
import {STORY_TYPE,readStory} from '@red-cup-engineering/content-mill-newsroom-services-section/intake';
import {admitSourceEvidence,recordSourceEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {sha256Digest} from '@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity';
import {acquirePublicWebSources,normalizePublicUrl,PUBLIC_SOURCE_TEXT_POLICY_ID} from '@causeway-services/web-source-acquisition/acquire';
import {readNewsroom,recordNewsroom} from '../newsroom-records.mjs';
import {qualificationForOwnerCommission} from './editorial-agency.mjs';
import {heldJournalCells} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {sourceEvidenceType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';

export const currentSourcePolicyCaptures=context=>new Set(readNewsroom(context.dataRoot,'source-acquisition-policy').filter(row=>row.told===undefined&&row.record.policy===PUBLIC_SOURCE_TEXT_POLICY_ID).map(({record})=>record.sourceEvidenceId));
/** Refresh the known old prefix boundaries, preserving the original evidence. */
export const captureNeedsRefresh=(source,current)=>[49999,50000,99999,100000].includes(source.content.text.length)&&!current.has(source.id);
export const deniedCommissionSources=context=>new Map(readNewsroom(context.dataRoot,'source-access-obstruction').filter(row=>row.told===undefined&&row.record.cause?.kind==='http'&&[401,403].includes(row.record.cause.status)).map(({record})=>[record.requestedUrl,record]));

/** Receive an owner's actual editorial commission, never an invented wire story.
 * This supplies assignment and source custody only. Claims, manuscript,
 * independent assessment and publication authority remain separate acts.
 */
export async function commissionArticle(context,{issueNumber,slug,section,sourceUrl,sourceUrls=[],preparedTitle},{at=new Date().toISOString(),readIssue=number=>JSON.parse(execFileSync('gh',['api',`repos/causeway-services/koios.news/issues/${number}`],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024})),acquire=acquirePublicWebSources}={}){
 if(!Number.isSafeInteger(issueNumber)||issueNumber<1||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug??''))throw new Error('Exact issue number and article slug required');
 if(!context.property.sections.some(desk=>desk.slug===section))throw new Error('Commission requires an existing desk');
 if(!Array.isArray(sourceUrls))throw new Error('Commission source URLs must be an array');
 const issue=await readIssue(issueNumber),url=normalizePublicUrl(sourceUrl),urls=[...new Set([url,...sourceUrls.map(normalizePublicUrl)])];
 if(issue.number!==issueNumber||issue.pull_request||issue.user?.login!=='emsenn'||issue.state!=='open'||issue.html_url!==`https://github.com/causeway-services/koios.news/issues/${issueNumber}`||urls.some(source=>!issue.body?.includes(source)))
  throw new Error('An open owner-authored Koios commission naming this source is required');
 if(preparedTitle!==undefined&&(typeof preparedTitle!=='string'||!preparedTitle.trim()||!issue.body.includes(preparedTitle)))throw Error('Prepared headline must occur in the authenticated owner submission');
 // Only a real owner-authored issue may specify a specialist assignment. Resolve
 // it against native agency incumbency and the existing newsroom law BEFORE
 // creating a story, touching source evidence, or sending inference.
 const specialist=qualificationForOwnerCommission({section,issueBody:issue.body});
 const prior=readNewsroom(context.dataRoot,'editorial-commission').map(row=>row.record).find(row=>row.issueId===issue.node_id&&row.slug===slug);
 let storyId;
 if(prior){
  const story=readStory(context.dataRoot,prior.storyId);
  if(story?.url!==url||story.commission?.section!==section)throw new Error('Commission already has a different source or desk');
  storyId=prior.storyId;
 }else{
  storyId=put(context.dataRoot,STORY_TYPE,{url,title:preparedTitle??issue.title,time:at,commission:{repository:'causeway-services/koios.news',issue:issueNumber,issueId:issue.node_id,author:issue.user.login,bodyDigest:sha256Digest(issue.body),section,slug}});
  recordNewsroom(context.dataRoot,'editorial-commission',{issueId:issue.node_id,issueUrl:issue.html_url,slug,storyId,receivedAt:at});
 }
 // Preserve the real assignment for the independent editor, rather than
 // silently substituting a generic investigation for the commissioned report.
 const assignment={issueId:issue.node_id,issueUrl:issue.html_url,author:issue.user.login,
  slug,storyId,section,sourceUrls:urls,...(preparedTitle?{preparedTitle}:{}),body:issue.body,bodyDigest:sha256Digest(issue.body),
  ...(specialist?{specialistSelectionDigest:specialist.selectionDigest,specialistOffice:specialist.officeId,character:specialist.characterId}:{} )};
 const assignmentReceived=!readNewsroom(context.dataRoot,'editorial-commission').some(({record})=>record.storyId===storyId&&record.bodyDigest===assignment.bodyDigest);
 if(assignmentReceived)
  recordNewsroom(context.dataRoot,'editorial-commission',{...assignment,receivedAt:at});
 const sources=[],sourceObstructions=[],freshness=(context.config.freshness?.storySeconds??172800)*1000,current=currentSourcePolicyCaptures(context),denied=deniedCommissionSources(context);
 const cached=new Map([...heldJournalCells(context.dataRoot,'source-evidence',sourceEvidenceType).values()]
  .filter(cell=>cell.content.leadId===storyId&&Date.parse(at)-Date.parse(cell.content.acquiredAt)<freshness&&!captureNeedsRefresh(cell,current))
  .sort((a,b)=>a.content.acquiredAt.localeCompare(b.content.acquiredAt)).map(cell=>[cell.content.requestedUrl,cell]));
 for(const requested of urls)if(cached.has(requested))sources.push(cached.get(requested));
 for(const requested of urls)if(!cached.has(requested)&&denied.has(requested))sourceObstructions.push(denied.get(requested));
 const pending=urls.filter(requested=>!cached.has(requested)&&!denied.has(requested));
 let sourcesAcquired=0;
 // Batch networking without discarding the rest of a submitted bibliography.
 for(let offset=0;offset<pending.length;offset+=6){
  const batch=pending.slice(offset,offset+6),delivery=await acquire({purpose:'journalistic-source-research',urls:batch},at);
  sourceObstructions.push(...(delivery.obstructions??[]));
  for(const obstruction of delivery.obstructions??[])if(obstruction.cause?.kind==='http'&&[401,403].includes(obstruction.cause.status))recordNewsroom(context.dataRoot,'source-access-obstruction',{...obstruction,issueId:issue.node_id,bodyDigest:assignment.bodyDigest});
  for(const requested of batch){
   try{const held=admitSourceEvidence({id:storyId,url:requested,title:issue.title},delivery);recordSourceEvidence(context.dataRoot,held,at,delivery);recordNewsroom(context.dataRoot,'source-acquisition-policy',{sourceEvidenceId:held.id,policy:PUBLIC_SOURCE_TEXT_POLICY_ID,acquiredAt:at});sources.push(held);sourcesAcquired++;}
   catch(error){sourceObstructions.push({requestedUrl:requested,reason:String(error.message).slice(0,500)});}
  }
 }
 return {slug,storyId,section,issueUrl:issue.html_url,assignmentReceived,sourcesAcquired,source:sources.find(held=>held.content.requestedUrl===url)??null,sources,sourceObstructions,publication:'Assignment and source custody only; submit assayed claims and manuscript for independent editorial assessment.'};
}
