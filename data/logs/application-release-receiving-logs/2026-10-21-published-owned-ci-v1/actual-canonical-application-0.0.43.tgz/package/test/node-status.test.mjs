import assert from "node:assert/strict";
import { mkdtempSync, rmSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";

import {defaultFilesystemBinding} from '@red-cup-engineering/computer-system-engine/rpc/binding';
import {reconcileDeclaredSchedules} from '@red-cup-engineering/feltos/recurring-work';
import {KOIOS_NODE_ACCOUNT,koiosNodeScheduleDeclarations} from '../src/node-schedules.mjs';
import { readKoiosNodeStatus } from "../src/node-status.mjs";

const NOW = "2026-10-02T15:00:00.000Z";

test("Koios node status reads admitted schedules without starting the process", () => {
  const dataRoot = mkdtempSync(path.join(tmpdir(), "koios-node-status-"));
  const clockStateRoot = path.join(dataRoot, "clock");
  try {
    reconcileDeclaredSchedules(defaultFilesystemBinding(dataRoot,{clockStateRoot,now:()=>NOW}),KOIOS_NODE_ACCOUNT,koiosNodeScheduleDeclarations({
      newsroomFirstDueAt: "2026-10-02T16:00:00.000Z",
      publicationFirstDueAt: "2026-10-03T12:00:00.000Z",
    }),()=>NOW);

    const status = readKoiosNodeStatus({
      dataRoot,
      clockStateRoot,
      now: () => NOW,
    });

    assert.equal(status.kind, "koios.node.status");
    assert.equal(status.packageVersion, JSON.parse(readFileSync(new URL("../package.json",import.meta.url))).version);
    assert.equal(status.ready, true);
    assert.equal(status.schedules[0].verb,"koios-news-cycle");
    assert.equal(status.schedules[0].everySeconds,15*60);
    assert.equal(status.schedules[1].everySeconds,24*60*60);
    assert.equal(status.schedules[1].verb,"koios-news-status");
    assert.deepEqual(
      status.schedules.map(({ id, state }) => ({ id, state })),
      [
        { id: "koios-newsroom-hourly", state: "not-due" },
        { id: "koios-routine-publication-daily", state: "not-due" },
      ],
    );
    assert.deepEqual(status.obstructions, []);
  } finally {
    rmSync(dataRoot, { recursive: true, force: true });
  }
});

test("Koios node status makes a due occurrence with no durable outcome explicit", () => {
  const dataRoot = mkdtempSync(path.join(tmpdir(), "koios-node-status-"));
  const clockStateRoot = path.join(dataRoot, "clock");
  try {
    reconcileDeclaredSchedules(defaultFilesystemBinding(dataRoot,{clockStateRoot,now:()=>NOW}),KOIOS_NODE_ACCOUNT,koiosNodeScheduleDeclarations({
      newsroomFirstDueAt: NOW,
      publicationFirstDueAt: "2026-10-03T12:00:00.000Z",
    }),()=>NOW);

    const status = readKoiosNodeStatus({
      dataRoot,
      clockStateRoot,
      now: () => NOW,
    });

    assert.equal(status.ready, false);
    assert.equal(status.schedules[0].state, "due-without-recorded-outcome");
    assert.equal(status.schedules[0].currentOccurrence, 0);
    assert.deepEqual(status.obstructions, [{
      schedule: "koios-newsroom-hourly",
      state: "due-without-recorded-outcome",
      obstruction: "current occurrence has no recorded outcome",
    }]);
  } finally {
    rmSync(dataRoot, { recursive: true, force: true });
  }
});
