/**
 * Koios claim cells: each claim the newsroom tracks, read as one FOUR cell.
 *
 * A claim is a proposition (subject, predicate, object) at its content address. Every
 * claim-evidence row the newsroom journal holds for it is told for or against; a row's own
 * point is FOUR's (told for, told against), and the claim's reading is the knowledge join of
 * its rows' points, so the cell does not depend on the order evidence arrived in. A claim with
 * no admitted evidence reads absurd (told nothing). Sources sit on the side they were told.
 * Pure: the journal, candidate and edition reads belong to the caller.
 */
import { isReading, readingFamilies } from "@red-cup-engineering/computer-data-engineering-services-section/four";
import { claimEvidenceType } from "@red-cup-engineering/content-mill-newsroom-services-section/carriers";
import { cell as signCell, address, knowledgeReading, merge } from "@red-cup-engineering/signcell/cell";
import { admitTypedMark } from "@red-cup-engineering/signcell/typed-mark";
import { readNewsroom } from "./newsroom-records.mjs";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const FAMILY = "knowledge";
const byText = (left, right) => (left < right ? -1 : left > right ? 1 : 0);

/** Use the same ni:/canonical-CBOR triple identity as SignCell itself.
 * The publisher must not invent a second JSON/SHA claim-naming algorithm:
 * revisions to evidence are new tellings about this exact triple, not a
 * different claim; unrelated positional roles never identify each other. */
export const claimIdOf = ({ subject, predicate, object }) =>
  address(signCell(subject, predicate, object));

const uniqueBy = (items, key) => [...new Map(items.map((item) => [key(item), item])).values()].sort((a, b) => byText(key(a), key(b)));

/**
 * @param {{claimRows: {record: object, told?: {for: boolean, against: boolean}}[],
 *   candidateRows?: {record: object}[], editions?: {candidateId: string}[]}} input
 *   claimRows are the journal's `claim` rows; candidateRows its `manuscript-candidate` rows;
 *   editions the line's edition records (an edition's id is its candidate id).
 * @returns {{cells: object[], skipped: number}} cells sorted by id; skipped counts rows that
 *   are not admitted source-grounded claim evidence (historical rows stay readable elsewhere).
 */
export function claimCellsOf({ claimRows = [], candidateRows = [], editions = [] } = {}) {
  const claims = new Map();
  const evidenceClaim = new Map();
  let skipped = 0;
  // A row carries `told` only when it is not plainly told for.
  for (const { record, told = { for: true, against: false } } of claimRows) {
    const admitted = admitTypedMark(claimEvidenceType, record);
    if (!admitted.ok) { skipped += 1; continue; }
    const { id, content } = admitted.value;
    const claimId = claimIdOf(content);
    evidenceClaim.set(id, claimId);
    if (!claims.has(claimId)) {
      claims.set(claimId, { id: claimId, statement: [content.subject, content.predicate, content.object].join(" "),
        sign: signCell(content.subject, content.predicate, content.object),
        forSources: [], againstSources: [], storyIds: new Set(), candidateIds: new Set() });
    }
    const cell = claims.get(claimId);
    const forTold = told.for === true, againstTold = told.against === true;
    // SignCell owns both identity and its knowledge join: no publisher-local
    // FOUR fold that can diverge from the original evidence substrate.
    cell.sign = merge(cell.sign, signCell(content.subject, content.predicate, content.object, {
      for: forTold ? [id] : [], against: againstTold ? [id] : [],
    }));
    const source = { id: content.sourceEvidenceId, host: content.host, url: content.sourceUrl };
    if (forTold) cell.forSources.push(source);
    if (againstTold) cell.againstSources.push(source);
    cell.storyIds.add(content.storyId);
  }
  for (const { record } of candidateRows) {
    const content = record?.content ?? {};
    for (const evidenceId of content.claimEvidenceIds ?? []) {
      const cell = claims.get(evidenceClaim.get(evidenceId));
      if (cell === undefined) continue;
      cell.candidateIds.add(record.id);
      if (typeof content.storyId === "string") cell.storyIds.add(content.storyId);
    }
  }
  const editionIds = new Set(editions.map(({ candidateId }) => candidateId));
  const cells = [...claims.values()].map((cell) => Object.freeze({
    id: cell.id, statement: cell.statement, reading: knowledgeReading(cell.sign),
    sources: Object.freeze({ for: uniqueBy(cell.forSources, ({ id }) => id), against: uniqueBy(cell.againstSources, ({ id }) => id) }),
    storyIds: [...cell.storyIds].sort(byText),
    editionIds: [...cell.candidateIds].filter((id) => editionIds.has(id)).sort(byText),
  })).sort((a, b) => byText(a.id, b.id));
  return Object.freeze({ cells: Object.freeze(cells), skipped });
}

/** Page the same addressed claim population. A cursor must name an actual
 * member of the chosen story/reading projection, not any arbitrary text that
 * could skip rows or a stale legacy SHA digest from another identity scheme. */
export function pageClaimCells({ cells, skipped = 0 }, { story, reading, limit = 50, cursor } = {}) {
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 200) throw new TypeError("koios-claim-cells: limit must be an integer from 1 to 200");
  if (reading !== undefined && !isReading(reading, FAMILY)) throw new TypeError(`koios-claim-cells: reading must be one of ${readingFamilies[FAMILY].join(", ")}`);
  const matching = cells.filter((cell) => (story === undefined || cell.storyIds.includes(story)) && (reading === undefined || cell.reading === reading));
  if (cursor !== undefined && (typeof cursor !== "string" || !matching.some((cell) => cell.id === cursor)))
    throw new TypeError("koios-claim-cells: cursor is absent from this addressed claim projection");
  const rest = cursor === undefined ? matching : matching.filter((cell) => cell.id > cursor);
  const page = rest.slice(0, limit);
  return Object.freeze({ cells: page, matching: matching.length, skipped, nextCursor: rest.length > limit ? page.at(-1).id : null });
}

/** Edition records are the line's working set; reading them must not create the line's roots. */
function readEditions(dataRoot) {
  const directory = join(dataRoot, "line", "editions");
  if (!existsSync(directory)) return [];
  return readdirSync(directory).filter((name) => name.endsWith(".json"))
    .map((name) => JSON.parse(readFileSync(join(directory, name), "utf8")));
}

/** Read the newsroom journal under `dataRoot` (never written) and page its claim cells. */
export function koiosClaimCells(dataRoot, input = {}) {
  const cells = claimCellsOf({
    claimRows: readNewsroom(dataRoot, "claim"), candidateRows: readNewsroom(dataRoot, "manuscript-candidate"),
    editions: readEditions(dataRoot),
  });
  return pageClaimCells(cells, input);
}
