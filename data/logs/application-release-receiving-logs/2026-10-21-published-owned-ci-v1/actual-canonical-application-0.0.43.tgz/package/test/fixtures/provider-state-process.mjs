// Test-only provider process boundary. The real wrapper/carrier/verifiers run.
import childProcess from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {appendFileSync,readFileSync} from 'node:fs';
const fixture=JSON.parse(readFileSync(process.env.PROVIDER_TEST_FIXTURE,'utf8'));
const record=entry=>appendFileSync(process.env.PROVIDER_TEST_RECORD,JSON.stringify(entry)+'\n');
globalThis.fetch=()=>{record({kind:'forbidden-fetch'});throw new Error('forbidden fetch');};
childProcess.spawnSync=(program,args,options)=>{
 record({kind:'provider-process',program,args,environment:options.env,encoding:options.encoding,stdio:options.stdio});
 if(program!==process.execPath||!args[0].endsWith('/koios-news-site/node_modules/wrangler/bin/wrangler.js')
  ||JSON.stringify(args.slice(1))!==JSON.stringify(['deployments','list','--name','koios-news-primary','--json']))
  throw new Error('unapproved process');
 if(fixture.throwAccessor)throw Object.defineProperty({},'reason',{get(){throw new Error('PRIVATE_ACCESSOR');}});
 if(fixture.alternatingAccessor){let reads=0;throw Object.defineProperty({},'reason',{get(){return ++reads===1?'provider-shape':'PRIVATE_ALTERNATING';}});}
 return fixture.result;
};
syncBuiltinESMExports();
