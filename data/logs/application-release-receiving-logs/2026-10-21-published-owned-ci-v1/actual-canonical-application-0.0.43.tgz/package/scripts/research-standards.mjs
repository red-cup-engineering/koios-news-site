import {createHash} from 'node:crypto';
import {mkdirSync,readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,join} from 'node:path';
const sources=[
'https://ai.google.dev/gemini-api/docs/structured-output',
'https://ai.google.dev/gemini-api/docs/pricing',
'https://developers.openai.com/codex/cli/reference/',
'https://developers.google.com/search/docs/fundamentals/creating-helpful-content',
'https://developers.google.com/search/docs/fundamentals/ai-optimization-guide',
'https://developers.google.com/search/docs/appearance/structured-data/article',
'https://developers.google.com/search/docs/appearance/google-discover',
'https://developers.google.com/search/blog',
'https://www.bing.com/webmasters/help/webmaster-guidelines-30fba23a',
'https://developers.cloudflare.com/workers/static-assets/routing/static-site-generation/',
'https://www.w3.org/TR/WCAG22/',
'https://www.w3.org/TR/activitypub/',
'https://www.iptc.org/std/ninjs/',
'https://www.rfc-editor.org/rfc/rfc9309.txt',
'https://www.sitemaps.org/protocol.html'];
const root=resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT??'data','feedback','standards');mkdirSync(root,{recursive:true});const observations=[];
for(const url of sources){const id=createHash('sha256').update(url).digest('hex').slice(0,16),path=join(root,id+'.txt');try{
 const r=await fetch(url,{headers:{'user-agent':'Koios.News standards research (+https://koios.news/about/)'},signal:AbortSignal.timeout(30000)});if(!r.ok)throw new Error(`HTTP ${r.status}`);
 const raw=await r.text();const main=/<main\b[^>]*>([\s\S]*?)<\/main>/i.exec(raw)?.[1]??raw;
 const text=main.replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi,'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
 const prior=existsSync(path)?readFileSync(path,'utf8'):null,digest=createHash('sha256').update(text).digest('hex');writeFileSync(path,text);
 observations.push({url,observedAt:new Date().toISOString(),status:'observed',digest,changed:prior!==text,previousDigest:prior===null?null:createHash('sha256').update(prior).digest('hex'),evidence:path});
}catch(e){observations.push({url,observedAt:new Date().toISOString(),status:'unavailable',reason:e.message});}}
writeFileSync(join(root,'latest.json'),JSON.stringify({observations},null,2)+'\n');console.log(JSON.stringify({sources:observations.length,changed:observations.filter(x=>x.changed).length,unavailable:observations.filter(x=>x.status==='unavailable').map(x=>x.url)}));
