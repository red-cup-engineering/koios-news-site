import assert from 'node:assert/strict';
import {test} from 'node:test';
import {
  NEWSROOM_STARTUP_MINIMUM_BYTES,
  RECOVERY_SNAPSHOT_MINIMUM_BYTES,
  cloudCapacityObservation,
} from '../src/cloud-capacity.mjs';

test('cloud capacity blocks only below the newsroom startup floor', () => {
  const assessment = cloudCapacityObservation({
    availableBytes: NEWSROOM_STARTUP_MINIMUM_BYTES - 1,
    totalBytes: 64 * 1024 * 1024 * 1024,
  });
  assert.equal(assessment.status, 'startup-blocked');
  assert.equal(assessment.observation.minimumWorkingBytes, NEWSROOM_STARTUP_MINIMUM_BYTES);
});

test('cloud capacity records low recovery headroom without blocking startup', () => {
  const assessment = cloudCapacityObservation({
    availableBytes: NEWSROOM_STARTUP_MINIMUM_BYTES + 128 * 1024 * 1024,
    totalBytes: 64 * 1024 * 1024 * 1024,
  });
  assert.equal(assessment.status, 'observed');
  assert.equal(assessment.observation.recoveryMinimumBytes, RECOVERY_SNAPSHOT_MINIMUM_BYTES);
  assert.equal(assessment.observation.recoveryHeadroom, 'low');
});

test('cloud capacity is observed when recovery headroom is available', () => {
  const assessment = cloudCapacityObservation({
    availableBytes: RECOVERY_SNAPSHOT_MINIMUM_BYTES + 1,
    totalBytes: 64 * 1024 * 1024 * 1024,
  });
  assert.equal(assessment.status, 'observed');
  assert.equal(assessment.observation.recoveryHeadroom, undefined);
});
