import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readdirSync,readFileSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {readNewsroom,recordNewsroom} from '../src/newsroom-records.mjs';
import {createTypedMark} from '@red-cup-engineering/signcell/typed-mark';
import {manuscriptCandidateType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {lineRoots,openEdition} from '../src/news-line/editions.mjs';
import * as stages from '../src/news-line/stages.mjs';

const at='2026-10-10T07:00:00.000Z';
const storyId='news-property.story:'+Buffer.from(JSON.stringify({v:{feed:'fixture-wire',title:'Fixture development'}})).toString('base64url');
function fixture(t){
 const root=mkdtempSync(join(tmpdir(),'koios-reporter-custody-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
 const context={dataRoot:root,roots:lineRoots(root),propertyContentDir:join(root,'content'),property:{name:'Koios.News',origin:'https://koios.news',content:{postsDirectory:'posts'},sections:[{slug:'world',title:'World',wires:['fixture-wire'],minimumIndependentSources:3}],editorialProductProfile:'standard-news/v1'},config:{batches:{maxCandidatesPerPulse:0}},environment:{}};
 mkdirSync(join(context.propertyContentDir,'posts'),{recursive:true});
 const hold=({lot='urn:koios:reporter-submission:fixture',id=storyId,told={for:true,against:false}}={})=>{
  const admitted=createTypedMark(manuscriptCandidateType,{storyId:id,section:'world',status:'pending-assessment',title:'Fixture development',dek:'A synthetic custody check.',paragraphs:[{text:'A synthetic custody check.',claimEvidenceIds:['fixture-claim']}],manuscript:'# Fixture development\n\nA synthetic custody check.\n',claimEvidenceIds:['fixture-claim'],sourceEvidenceIds:['fixture-source'],inputClaimEvidenceIds:['fixture-claim'],workLotId:lot});
  assert.equal(admitted.ok,true);const candidate=admitted.value;recordNewsroom(root,'manuscript-candidate',candidate,{told});return candidate;
 };
 return {context,root,hold};
}
function edition(context,candidate,extra={}){openEdition(context.roots,{candidateId:candidate.id,storyId:candidate.content.storyId,section:'world',slug:'requested-address',state:'drafted',draftedAt:at,...extra});}
function snapshot(root){const out={};for(const entry of readdirSync(root,{withFileTypes:true})){const path=join(root,entry.name);if(entry.isDirectory()){for(const [name,value] of Object.entries(snapshot(path)))out[entry.name+'/'+name]=value;}else out[entry.name]=readFileSync(path).toString('base64');}return out;}

test('draft blocks before any repair or writer can adopt an orphaned NEW reporter candidate',async t=>{
 const f=fixture(t),candidate=f.hold();
 // A real pre-existing repair would fail on this absent delivery if the guard ran late.
 openEdition(f.context.roots,{candidateId:'fixture-returned',storyId,section:'world',slug:'returned-address',state:'returned',draftedAt:at,reason:'submit_revision_request',deliveryPath:join(f.context.dataRoot,'must-not-read.json')});
 const heldBefore=readNewsroom(f.context.dataRoot,'manuscript-candidate'),before=snapshot(f.context.roots.root),result=await stages.newsLineHandlers(f.context).draft({at});
 assert.equal(result.status,'blocked');assert.equal(result.code,'reporter-submission-custody-incomplete');
 assert.deepEqual(result.candidates,[{candidateId:candidate.id,storyId}]);assert.match(result.reason,/exact submitted address/);
 // Journal reads may refresh their derived verification index, not newsroom work.
 assert.deepEqual(snapshot(f.context.roots.root),before);
 assert.deepEqual(readNewsroom(f.context.dataRoot,'manuscript-candidate'),heldBefore);
});
test('all orphan reporter IDs are returned in stable order',t=>{
 const f=fixture(t),a=f.hold(),b=f.hold({lot:'urn:koios:reporter-submission:second'}),result=stages.reporterSubmissionCustodyBlock(f.context);
 assert.deepEqual(result.candidates.map(row=>row.candidateId),[a.id,b.id].sort((a,b)=>a.localeCompare(b)));
});
test('no orphan leaves the draft stage eligible to proceed',t=>{
 const f=fixture(t);assert.equal(stages.reporterSubmissionCustodyBlock(f.context),null);
});
test('an exact edition reconciles custody without changing the reporter candidate',t=>{
 const f=fixture(t),candidate=f.hold();assert.equal(stages.reporterSubmissionCustodyBlock(f.context).status,'blocked');
 edition(f.context,candidate);assert.equal(stages.reporterSubmissionCustodyBlock(f.context),null);
});
test('ordinary model candidates are not mistaken for reporter interruptions',t=>{
 const f=fixture(t);f.hold({lot:'urn:inference:writer-work'});assert.equal(stages.reporterSubmissionCustodyBlock(f.context),null);
});
test('opposed reporter cells do not block the held-candidate path',t=>{
 const f=fixture(t),candidate=f.hold();recordNewsroom(f.root,'manuscript-candidate',candidate,{told:{for:true,against:true}});
 assert.equal(stages.reporterSubmissionCustodyBlock(f.context),null);
});
test('a published revision keeps its standing address route',t=>{
 const f=fixture(t),candidate=f.hold(),old=f.hold({lot:'urn:inference:published-work'});
 edition(f.context,old,{state:'released',releasedAt:at});mkdirSync(join(f.context.roots.publication,'published'),{recursive:true});
 writeFileSync(join(f.context.roots.publication,'published','requested-address.md'),'---\ntitle: Fixture development\ndate: 2026-10-01\nsection: world\ndraft: false\n---\n# Fixture development\n\nPublished fixture.\n');
 assert.notEqual(candidate.id,old.id);assert.equal(stages.reporterSubmissionCustodyBlock(f.context),null);
});
test('a released-state claim without an actual ledger article is not a standing publication',t=>{
 const f=fixture(t),candidate=f.hold(),old=f.hold({lot:'urn:inference:published-work'});edition(f.context,old,{state:'released',releasedAt:at});
 assert.deepEqual(stages.reporterSubmissionCustodyBlock(f.context).candidates,[{candidateId:candidate.id,storyId}]);
});
