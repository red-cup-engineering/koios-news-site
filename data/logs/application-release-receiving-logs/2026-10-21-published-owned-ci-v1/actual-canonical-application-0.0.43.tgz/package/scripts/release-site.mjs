import {releaseWebsite} from '@causeway-services/koios-news-site/release';
console.log(JSON.stringify(await releaseWebsite({candidateDir:'.public',receipts:'.release'})));
