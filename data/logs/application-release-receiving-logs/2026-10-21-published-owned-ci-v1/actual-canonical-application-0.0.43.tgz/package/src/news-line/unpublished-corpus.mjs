/**
 * Count the editorial inventory in the existing Koios content and source
 * archives. This does not decide editorial acceptance or publication.
 * A file containing claims is a research lead, not an accepted article.
 * This sensor reads names of archived claims rather than loading all texts
 * into a memory-constrained production machine.
 */
import {lstatSync,readFileSync,readdirSync} from "node:fs";
import {join} from "node:path";
import {outsidePublicationHost} from './source-origins.mjs';

const MAX_POSTS=2000,MAX_CLAIMS=100000,MAX_POST_BYTES=1024*1024;
function markdown(dir,{optional=false,includeSource=true}={}){
 let entries;
 try{entries=readdirSync(dir,{withFileTypes:true});}
 catch(error){if(optional&&error.code==="ENOENT")return{present:false,files:[]};throw error;}
 const selected=entries.filter(e=>e.name.endsWith(".md"));
 if(selected.length>MAX_POSTS)throw Error("Manuscript inventory exceeds bound");
 const files=[];
 for(const e of selected){
  if(!e.isFile()||e.isSymbolicLink())throw Error("Nonregular manuscript in editorial inventory");
  const file=join(dir,e.name);
  if(includeSource&&lstatSync(file).size>MAX_POST_BYTES)throw Error("Oversized manuscript in editorial inventory");
  files.push({slug:e.name.slice(0,-3),...(includeSource?{source:readFileSync(file,"utf8")}:{})});
 }
 return{present:true,files};
}
function claimFileCount(root){
 let n=0;
 for(const category of readdirSync(root,{withFileTypes:true})){
  if(!category.isDirectory()||category.isSymbolicLink())throw Error("Nonregular claim directory");
  for(const entry of readdirSync(join(root,category.name),{withFileTypes:true})){
   if(!entry.isFile()||entry.isSymbolicLink()||!entry.name.endsWith(".json"))throw Error("Nonregular claim record filename");
   if(++n>MAX_CLAIMS)throw Error("Claim inventory exceeds bound");
  }
 }
 return n;
}
/** Surface screening alone cannot show independent source acceptance. */
export function inspectHeldManuscript(source,at){
 const match=/^---\r?\n([\s\S]*?)\r?\n---\r?\n/u.exec(source);
 if(!match)return{metadata:"missing",draft:"unknown",gate:"unknown",words:0,sections:0,declaredReferenceHosts:0,datedWithinWindow:false};
 const front=match[1],body=source.slice(match[0].length);
 const draft=/^draft:\s*(true|false)\s*$/imu.exec(front)?.[1]??"unknown";
 const gate=/(?:^|\n)\s{2}gates_clear:\s*(true|false)\s*(?:\n|$)/iu.exec(front)?.[1]??"unknown";
 const date=/^date:\s*["']?(\d{4}-\d{2}-\d{2})(?:["'])?\s*$/imu.exec(front)?.[1];
 const ms=date?Date.parse(date+"T00:00:00Z"):NaN;
 const hosts=new Set();
 for(const link of front.matchAll(/^\s*(?:-\s*)?(?:URL|url):\s*["']?(https?:\/\/[^\s"']+)/gimu)){
  const host=outsidePublicationHost(link[1]);
  if(host)hosts.add(host);
 }
 return{metadata:"parsed",draft,gate,words:body.trim().split(/\s+/u).filter(Boolean).length,
  sections:(body.match(/^#{2,3}\s+/gmu)??[]).length,declaredReferenceHosts:hosts.size,
  datedWithinWindow:Number.isFinite(ms)&&ms<=at.getTime()&&at.getTime()-ms<=7*86400000};
}
/** Return only non-sensitive counts for the existing observed-feedback sensor.
 * Roots or metadata that cannot be read fail unknown through the caller's
 * sensor boundary. No new ledger, index, or parallel editorial state is made.
 */
export function observeUnpublishedCorpus({postsDir,reporterDir,claimsDir,publishedDir,observedAt=new Date()}={}){
 if(!(observedAt instanceof Date)||!Number.isFinite(observedAt.getTime()))throw TypeError("Invalid observation instant");
 if([postsDir,claimsDir,publishedDir].some(p=>typeof p!=="string"||!p))throw TypeError("Explicit source roots required");
 const posts=markdown(postsDir),reporters=reporterDir?markdown(reporterDir,{optional:true}):{present:false,files:[]};
 const published=new Set(markdown(publishedDir,{includeSource:false}).files.map(x=>x.slug));
 const gates={false:0,true:0,unknown:0},wordBuckets={"under-700":0,"700-999":0,"1000-plus":0};
 const hostBuckets={"0":0,"1":0,"2":0,"3-plus":0};
 let drafts=0,other=0,newSlugs=0,revisionSlugs=0,sevenDays=0,surfaceScreen=0,missingFrontmatter=0;
 for(const {slug,source} of posts.files){
  const row=inspectHeldManuscript(source,observedAt);
  if(published.has(slug))revisionSlugs++;else newSlugs++;
  if(row.draft==="true")drafts++;else other++;
  gates[row.gate]++;
  if(row.words<700)wordBuckets["under-700"]++;
  else if(row.words<1000)wordBuckets["700-999"]++;
  else wordBuckets["1000-plus"]++;
  hostBuckets[row.declaredReferenceHosts>=3?"3-plus":String(row.declaredReferenceHosts)]++;
  if(row.datedWithinWindow)sevenDays++;
  if(row.words>=700&&row.sections>=3&&row.declaredReferenceHosts>=3)surfaceScreen++;
  if(row.metadata==="missing")missingFrontmatter++;
 }
 return Object.freeze({kind:"koios.news.unpublished-corpus-census/v1",observedAt:observedAt.toISOString(),
  manuscriptFiles:posts.files.length,explicitlyMarkedDraft:drafts,draftFlagMissingOrFalse:other,
  unpublishedNewSlugFiles:newSlugs,draftFilesRevisingPublicSlug:revisionSlugs,
  separateReporterManuscripts:reporters.present?reporters.files.length:null,
  sourceClaimArchiveFiles:claimFileCount(claimsDir),publishedLedgerFiles:published.size,
  declaredGates:gates,bodyWordBuckets:wordBuckets,citedHostCountBuckets:hostBuckets,
  manuscriptDatesWithinSevenDays:sevenDays,structurallyCompleteBySurfaceHeuristic:surfaceScreen,
  frontmatterUnparsed:missingFrontmatter,editorialAcceptance:"unverified",
  releaseAuthorization:"not-implied",sourceIndependence:"unverified",
  classificationNote:"Claim archive files, cited hosts, dates and manuscript word counts never establish grounded claims, independently originating sources, editorial acceptance or publication rights. Do not flip draft flags to release."});
}
