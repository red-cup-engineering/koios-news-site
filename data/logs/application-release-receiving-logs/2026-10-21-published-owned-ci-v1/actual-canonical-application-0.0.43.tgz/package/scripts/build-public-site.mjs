#!/usr/bin/env node
import { buildConfiguredProperty } from "@causeway-services/koios-news-site/build-property";
const at = process.argv.indexOf("--out");
if (at < 0 || !process.argv[at + 1]) throw new Error("Usage: build-public-site --out <public-directory>");
console.log(JSON.stringify(buildConfiguredProperty(process.env.KOIOS_NEWS_PROPERTY ?? new URL("../config/koios-news-property.json", import.meta.url).pathname, process.argv[at + 1])));
