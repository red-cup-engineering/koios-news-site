import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash,generateKeyPairSync,sign} from 'node:crypto';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,rmSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {canonicalJson} from '@red-cup-engineering/json-services-section/canonical-json';
import {writeRoutinePublication} from '../src/offline-publication.mjs';
import {newsLineHandlers} from '../src/news-line/stages.mjs';
import {newsLineContext} from '../src/news-line/context.mjs';
import {openEdition,editionOf} from '../src/news-line/editions.mjs';

const digest=value=>'sha256:'+createHash('sha256').update(value).digest('hex');
const property={name:'Cedar Ledger',origin:'https://koios.news',tagline:'A sample news property',language:'en',locale:'en_US',sections:[{slug:'news',title:'News'}],masthead:{publisher:'Cedar',editorialMethod:'Source-grounded reporting',bylineDescriptions:{}},content:{}};
const at='2026-10-11T12:00:00.000Z',slug='exact-accepted-item';
function candidate(context,id,body){
 const root=join(context.dataRoot,id),contentDir=join(root,'posts'),propertyContentDir=join(root,'property');
 mkdirSync(contentDir,{recursive:true});mkdirSync(join(propertyContentDir,'posts'),{recursive:true});
 const source=`---\ntitle: Exact accepted item\ndate: 2026-10-11\ndraft: true\nslug: ${slug}\nsection: news\n---\n${body}\n`;
 const draftPath=join(contentDir,slug+'.md'),admissionPath=join(root,'admission.json'),authorityGrantPath=join(root,'grant.json'),authorityKeysPath=join(root,'keys.json');
 writeFileSync(draftPath,source);
 writeFileSync(admissionPath,JSON.stringify({slug,manuscriptDigest:digest(source),disposition:'accept',publishable:true,serviceAccepted:true,contract:'ni:///sha-256;GTSsfC0lmcjPLQvtlGmYwLJLCa9pirz1d8oUqRweioo',selectedTool:'submit_editorial_acceptance',toolSelectionValidated:true,toolSelectionDigest:'ni:///sha-256;fixture'}));
 const {privateKey,publicKey}=generateKeyPairSync('ed25519'),issuerKeyId='receiving-fixture-key';
 const grant={expiresAt:'2026-10-12T00:00:00.000Z',grantId:'receiving-fixture-'+id,issuedAt:'2026-10-11T00:00:00.000Z',issuerKeyId,kind:'koios.news.editorial-publication-grant/v1',scope:{manuscript:{digest:digest(source),slug},type:'exact-manuscript'}};
 writeFileSync(authorityGrantPath,canonicalJson({...grant,signature:sign(null,Buffer.from(canonicalJson(grant)),privateKey).toString('base64url')})+'\n');
 writeFileSync(authorityKeysPath,JSON.stringify({[issuerKeyId]:publicKey.export({format:'jwk'}).x}));
 const written=writeRoutinePublication({property,propertyContentDir,contentDir,draftPath,admissionPath,authorityGrantPath,authorityKeysPath,authorityNow:at,outputDir:join(context.roots.candidates,id),replayRoot:context.roots.publication});
 const edition={candidateId:'fixture-'+id,storyId:'one-story',slug,section:'news',state:'rendered',draftedAt:at,renderedAt:at,firstPublished:'2026-10-11',draftPath,candidateDir:written.outputDir,consumptionId:written.consumptionId};
 openEdition(context.roots,edition);
 return {edition,written,receipt:JSON.parse(readFileSync(join(written.outputDir,'routine-publication-receipt.json'),'utf8'))};
}

function fixture(t){
 const dataRoot=mkdtempSync(join(tmpdir(),'koios-edition-receiving-'));
 t.after(()=>rmSync(dataRoot,{recursive:true,force:true}));
 return newsLineContext({environment:{KOIOS_NEWSROOM_DATA_ROOT:dataRoot}});
}
async function observe(context,published,{manifestOk=true,fingerprintOk=true,articleOk=true,articleBody}={}){
 const fingerprintBytes=readFileSync(join(published.written.outputDir,'public','fingerprints',slug+'.json'));
 const fingerprint=JSON.parse(fingerprintBytes);
 const manifest=readFileSync(join(published.written.outputDir,'public','manifest.json'));
 const article=articleBody??readFileSync(join(published.written.outputDir,'public','posts',slug,'index.html'));
 assert.equal('sha256:'+fingerprint.facts.sourceSha256,published.receipt.provenance.projectedSha256);
 const spawn=cp.spawnSync,fetch=globalThis.fetch;
 cp.spawnSync=(program,args)=>{assert.equal(program,process.execPath);assert.equal(args.length,1);assert.ok(args[0].endsWith('/scripts/sync-publication-data.mjs'));return {status:0,stdout:'',stderr:''};};
 globalThis.fetch=async url=>{
  if(url===`https://koios.news/fingerprints/${slug}.json`)return new Response(fingerprintBytes,{status:fingerprintOk?200:503});
  if(url===`https://koios.news/posts/${slug}/`)return new Response(article,{status:articleOk?200:404});
  assert.equal(url,'https://koios.news/manifest.json');return new Response(manifest,{status:manifestOk?200:503});
 };
 syncBuiltinESMExports();
 try{return await newsLineHandlers(context).release({at});}
 finally{cp.spawnSync=spawn;globalThis.fetch=fetch;syncBuiltinESMExports();}
}

test('public receiving credits only the exact consumed edition, not every pending version of its slug',async t=>{
 const context=fixture(t);
 const old=candidate(context,'older','The first independently admitted fixture version.');
 const latest=candidate(context,'newer','The later independently admitted fixture version.');
 assert.notEqual(old.receipt.provenance.projectedSha256,latest.receipt.provenance.projectedSha256);
 const result=await observe(context,latest);
 console.log(JSON.stringify({released:result.released,old:editionOf(context.roots,old.edition.candidateId).state,latest:editionOf(context.roots,latest.edition.candidateId).state}));
 assert.equal(result.released,1);
 assert.equal(editionOf(context.roots,old.edition.candidateId).state,'rendered');
 const received=editionOf(context.roots,latest.edition.candidateId);
 assert.equal(received.state,'released');
 assert.equal(received.releasedSourceSha256,latest.receipt.provenance.projectedSha256);
 assert.equal(received.publicationReceiptSha256,latest.written.receiptSha256);
 assert.equal(received.publicArticleUrl,`https://koios.news/posts/${slug}/`);
 const actual=readFileSync(join(latest.written.outputDir,'public','posts',slug,'index.html'));
 assert.equal(received.publicArticleSha256,digest(actual).slice(7));
 assert.equal(received.publicArticleBytes,actual.length);
});

test('an observed older version can be credited even after the ledger advanced to a newer version',async t=>{
 const context=fixture(t);
 const old=candidate(context,'older','The first independently admitted fixture version.');
 const latest=candidate(context,'newer','The later independently admitted fixture version.');
 const result=await observe(context,old);
 assert.equal(result.released,1);
 assert.equal(editionOf(context.roots,old.edition.candidateId).state,'released');
 assert.equal(editionOf(context.roots,latest.edition.candidateId).state,'rendered');
});

for(const defect of ['absent receipt','changed receipt','wrong consumption','absent consumption','wrong slug','historical unbound edition']){
 test(`unbound public receiving remains pending: ${defect}`,async t=>{
  const context=fixture(t),held=candidate(context,'candidate','An independently admitted fixture version.');
  const receiptPath=join(held.written.outputDir,'routine-publication-receipt.json');
  // Corrupt persisted custody explicitly; opening an existing edition is idempotent.
  const corruptCustody=row=>{const files=readdirSync(context.roots.editions).filter(name=>name.endsWith('.json'));assert.equal(files.length,1);writeFileSync(join(context.roots.editions,files[0]),JSON.stringify(row));};
  if(defect==='absent receipt')rmSync(receiptPath);
  if(defect==='changed receipt')writeFileSync(receiptPath,JSON.stringify({...held.receipt,provenance:{...held.receipt.provenance,projectedSha256:'sha256:'+'0'.repeat(64)}}));
  if(defect==='wrong consumption')corruptCustody({...held.edition,consumptionId:'grant:another-edition'});
  if(defect==='absent consumption')rmSync(join(context.roots.publication,'consumed',digest(held.edition.consumptionId).slice(7)+'.json'));
  if(defect==='wrong slug')corruptCustody({...held.edition,slug:'another-slug'});
  if(defect==='historical unbound edition'){const {candidateDir,consumptionId,...legacy}=held.edition;corruptCustody(legacy);}
  const result=await observe(context,held);
  assert.equal(result.released,0);
  assert.equal(editionOf(context.roots,held.edition.candidateId).state,'rendered');
 });
}

test('a failed public manifest observation cannot complete exact-edition receiving',async t=>{
 const context=fixture(t),held=candidate(context,'candidate','An independently admitted fixture version.');
 const result=await observe(context,held,{manifestOk:false});
 assert.equal(result.released,0);
 assert.equal(editionOf(context.roots,held.edition.candidateId).state,'rendered');
});

test('an unavailable public fingerprint leaves the genuine consumed edition pending',async t=>{
 const context=fixture(t),held=candidate(context,'candidate','An independently admitted fixture version.');
 const result=await observe(context,held,{fingerprintOk:false});
 assert.equal(result.released,0);
 assert.equal(editionOf(context.roots,held.edition.candidateId).state,'rendered');
});

for(const defect of ['missing article','changed article']){
 test(`matching fingerprint and manifest cannot credit a ${defect}`,async t=>{
  const context=fixture(t),held=candidate(context,'candidate','An independently admitted fixture version.');
  const result=await observe(context,held,defect==='missing article'?{articleOk:false}:{articleBody:'unrelated page'});
  assert.equal(result.released,0);
  const pending=editionOf(context.roots,held.edition.candidateId);
  assert.equal(pending.state,'rendered');
  assert.equal(pending.publicArticleSha256,undefined);
 });
}

