import test from "node:test";
import assert from "node:assert/strict";
import { newArticleThroughputFeedback } from "../src/news-line/throughput-feedback.mjs";

const sample = (overrides = {}) => ({
  articlesLast24h: 0,
  revisionsLast24h: 8,
  dailyArticleTarget: 20,
  returnedByFailureLayer: { "writer-model": 84, sources: 46 },
  at: "2026-10-12T04:25:15.270Z",
  ...overrides,
});

test("a running newsroom with zero new articles misses the target even after revisions", () => {
  const result = newArticleThroughputFeedback(sample());
  assert.equal(result.status, "unavailable");
  assert.equal(result.articlesLast24h, 0);
  assert.equal(result.revisionsLast24h, 8);
  assert.equal(result.deficit, 20);
  assert.deepEqual(result.leadingReturnLayer, { layer: "writer-model", count: 84 });
  assert.match(result.reason, /NEW article/);
  assert.match(result.reason, /revisions do not count/);
});

test("partial new-story output still reports the observed deficit", () => {
  const result = newArticleThroughputFeedback(sample({ articlesLast24h: 5 }));
  assert.equal(result.status, "unavailable");
  assert.equal(result.deficit, 15);
});

test("meeting the target closes the deficit without mistaking revisions for output", () => {
  for (const count of [20, 21]) {
    const result = newArticleThroughputFeedback(sample({ articlesLast24h: count }));
    assert.equal(result.status, "observed");
    assert.equal(result.deficit, 0);
    assert.equal(result.reason, undefined);
  }
});

test("missing or malformed metrics remain unknown, never success or zero", () => {
  for (const metrics of [undefined, null, [], {}, sample({ dailyArticleTarget: 0 }), sample({ articlesLast24h: -1 }), sample({ articlesLast24h: null })]) {
    const result = newArticleThroughputFeedback(metrics);
    assert.equal(result.status, "unknown");
    assert.match(result.reason, /reading|invalid/);
  }
});

test("return-layer counts are diagnostic lifetime totals, not a daily causal proof", () => {
  const result = newArticleThroughputFeedback(sample({
    returnedByFailureLayer: { sources: 9, "writer-model": 9, unrelated: "not a count" },
  }));
  assert.deepEqual(result.leadingReturnLayer, { layer: "sources", count: 9 });
  assert.deepEqual(result.returnLayerCountsLifetime, { sources: 9, "writer-model": 9 });
  assert.equal(result.metricAt, "2026-10-12T04:25:15.270Z");
});
