/**
 * Koios.News as one micro-enterprise service line: wire arrivals to released editions in
 * bounded MAPE-K turns. Each turn runs one stage (./news-line/stages.mjs); a cycle is one
 * pass from intake to feedback. The node's clock repeats cycles; nothing here schedules.
 */
import { defineServiceLine, runServiceLineTurn, serviceLineStatus, serviceLineEvents, readServiceLineSnapshot, withServiceLineExecution } from "@red-cup-engineering/organizing/work/service-line";
import { readJson,editions } from "./news-line/editions.mjs";
import { STAGES, newsLineContext, newsLineHandlers, newsLineMetrics, renderedEditionSetIdentity, receivePublicEditions, receiveDraftedManuscripts } from "./news-line/stages.mjs";
import { isPendingExactEditorialRepair } from "./news-line/throughput-feedback.mjs";
import {groundedClaims} from "@red-cup-engineering/content-mill-newsroom-services-section/manuscript";
import {requireNewsroomWriterAdmission} from './inference-account.mjs';
import { existsSync, readdirSync } from "node:fs";
import { custodyIdentity, readSelectionHistory, currentCycleEvidence, unattemptedPriority, selectKoiosWork, executeWithoutWriter } from "./news-line/selection.mjs";
import { join } from "node:path";
import {publicationHold} from './news-line/publication-holds.mjs';

export const KOIOS_NEWS_LINE = defineServiceLine({
  service: "koios-news",
  stages: STAGES,
  subjectField: "edition",
  eventTypeName: "KoiosNewsLineEvent",
  defaultRun: "autonomous-koios-news-line",
  statusExtras: (lineRoot) => {
    const path = join(lineRoot, "metrics.json");
    return existsSync(path) ? { metrics: readJson(path) } : {};
  },
});

/** Offered business custody, not diagnostic timestamps or retry counters. */
function publicationWork(context, held) {
  const priorities = [], { policyDigest } = context;
  const offer = (stage, rows, tuple) => {
    if (rows.length) priorities.push({ stage, identity: custodyIdentity(stage, rows.map(tuple)) });
  };
  const rendered = held.filter(row => row.state === 'rendered');
  if (rendered.length) priorities.push({ stage: 'release', identity: renderedEditionSetIdentity(rendered) });
  offer('render', held.filter(row => row.state === 'queued'&&!publicationHold(context,row.slug,undefined,row.storyId)),
    row => [row.candidateId, row.jobPath, row.grantId, row.grantExpiresAt, policyDigest]);
  offer('authorize', held.filter(row => row.state === 'accepted'&&!publicationHold(context,row.slug,undefined,row.storyId)),
    row => [row.candidateId, row.receiptPath, row.receiptExpiresAt, row.toolSelectionDigest, row.policyDigest, policyDigest]);
  offer('assess', held.filter(row => row.state === 'drafted'), row => [row.candidateId, row.draftedAt, policyDigest]);
  offer('draft', held.filter(isPendingExactEditorialRepair), row => {
    let judgment = null;
    try {
      const digest = readJson(row.deliveryPath).object?.toolSelectionDigest;
      judgment = typeof digest === 'string' && digest.trim() !== '' ? digest : null;
    }
    catch { /* Unavailable judgment stays visible; the owning stage refuses its execution. */ }
    return [row.candidateId, row.deliveryPath, judgment];
  });
  if(context.dataRoot&&context.config?.freshness?.storySeconds){
  const heldStories=new Set(held.map(row=>row.storyId));
  const now=Date.now(),freshness=context.config.freshness.storySeconds*1000;
  const readyClaims=groundedClaims(context.dataRoot).filter(({cell,source})=>
    !heldStories.has(cell.content.storyId)&&now-Date.parse(source.content.acquiredAt)<=freshness
    &&!publicationHold(context,null,undefined,cell.content.storyId));
  offer('draft',readyClaims,({cell})=>[cell.content.storyId,cell.id,policyDigest]);
  }
  return priorities;
}

/** One selection snapshot under the existing lock, discarded after this turn.
 * Organizing still performs its own history/status reads when recording the turn.
 */
function selectionSnapshot(context) {
  let snapshot;
  const { status, events } = readSelectionHistory(
    () => (snapshot=readServiceLineSnapshot(KOIOS_NEWS_LINE,context.roots.root)).status,
    () => snapshot.events);
  const held = editions(context.roots);
  return { status, events, stages: STAGES, priorities: publicationWork(context, held),
    pendingArrivals: readdirSync(context.roots.arrivals).some(name => name.endsWith('.json')) };
}

async function runSelectedTurn({ context, now, attemptedStages }) {
  await withServiceLineExecution(KOIOS_NEWS_LINE,{dataRoot:context.roots.root,stage:'receiving',skipBusy:true,legacyExclusiveLock:join(context.roots.root,'editorial-execution.lock')},async()=>{
    await receivePublicEditions(context);receiveDraftedManuscripts(context);
  });
  const excluded=new Set(attemptedStages);
  while(excluded.size<STAGES.length){
    const selected = selectKoiosWork(selectionSnapshot(context), { attemptedStages:excluded });
    if (!selected) return null;
    const handlers = { ...newsLineHandlers(context) };
    // The shared service line reserves only this stage. Admission is checked
    // at its effect boundary; no earlier turn authorizes a later purchase.
    for (const stage of ['analyze', 'draft']) {
      const execute = handlers[stage];
      handlers[stage] = async input => {
        let admission;
        try { admission = await requireNewsroomWriterAdmission(context.environment); }
        catch (error) { return executeWithoutWriter(stage, execute, input, error); }
        return { ...await execute(input), writerAdmission: admission };
      };
    }
    const execute = handlers[selected.stage];
    handlers[selected.stage] = async input => {
      if (selected.obstruction) return { status: 'blocked', ...selected.obstruction };
      let result;
      try { result = await execute(input); }
      catch (error) { result = { status: 'blocked', code: 'stage-threw', reason: String(error?.message ?? error) }; }
      // The existing event carrier accepts this outcome field. Preserve it on
      // throws as well, so ordinary outages yield across standalone turns.
      return { ...result, workAttempt: { kind: selected.kind, stage: selected.stage,
        ...(selected.identity ? { identity: selected.identity } : {}) } };
    };
    const turn = await runServiceLineTurn(KOIOS_NEWS_LINE, { dataRoot: context.roots.root, handlers,
      selectedStage: selected.stage, skipBusy:true, legacyExclusiveLock:join(context.roots.root,"editorial-execution.lock"), ...(now ? { now } : {}) });
    if(!turn){excluded.add(selected.stage);continue;}
    return { turn, selected };
  }
  return null;
}

/** One bounded turn, including operation callers outside the scheduled cycle. */
export async function runKoiosNewsTurn({ context = newsLineContext(), now } = {}) {
  return (await runSelectedTurn({ context, now }))?.turn??null;
}

/** Advisory reads only. Execution always reselects after acquiring the lock. */
export function readyPublicationStage(context) {
  const snapshot = selectionSnapshot(context);
  const evidence = currentCycleEvidence(snapshot.events, snapshot.status, STAGES);
  if (evidence.obstruction) return null;
  return unattemptedPriority(snapshot.priorities, evidence.events)?.stage ?? null;
}

export function nextKoiosNewsStage(context) {
  return selectKoiosWork(selectionSnapshot(context)).stage;
}

/** A bounded pulse offers each stage at most once. Failed editorial work can
 * yield to independent source production; the existing clock owns repetition.
 */
export async function runKoiosNewsCycle({ context = newsLineContext(), maxTurns = STAGES.length, allowedStages=STAGES } = {}) {
  if(!Array.isArray(allowedStages)||!allowedStages.length||allowedStages.some(stage=>!STAGES.includes(stage)))throw new TypeError('A Koios job must name existing service-line stages');
  const turns = [], attemptedStages = new Set(STAGES.filter(stage=>!allowedStages.includes(stage)));
  for (let index = 0; index < maxTurns; index += 1) {
    const result = await runSelectedTurn({ context, attemptedStages });
    if (!result) break;
    const { turn, selected } = result, { stage, status, cycle } = turn.event.content;
    turns.push({ stage, status, cycle });
    attemptedStages.add(stage);
    // Accepted work blocked at publication needs its receiving operation
    // repaired before another potentially long research batch takes the lock.
    // Provider waits in assessment still yield to independent source work.
    if (status === 'blocked' && ['authorize', 'render', 'release'].includes(stage)) break;
    if (selected.obstruction || stage === STAGES.at(-1) || (selected.kind === 'priority' && stage === 'release')) break;
  }
  return Object.freeze({ turns, status: koiosNewsStatus({ context }) });
}

export function koiosNewsStatus({ context = newsLineContext() } = {}) {
  return Object.freeze({ ...serviceLineStatus(KOIOS_NEWS_LINE, context.roots.root), live: newsLineMetrics(context) });
}
