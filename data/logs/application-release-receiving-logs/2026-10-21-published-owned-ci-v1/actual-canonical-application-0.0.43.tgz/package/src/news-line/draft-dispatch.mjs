const DEFAULT_DRAFT_WRITER_TIMEOUT_MS = null;

export function configuredDraftWriterTimeoutMs(context) {
  const raw = context.environment.KOIOS_NEWS_DRAFT_WRITER_TIMEOUT_MS
    ?? context.config.timeouts?.draftWriterMs
    ?? DEFAULT_DRAFT_WRITER_TIMEOUT_MS;
  if (raw === null || raw === false || raw === "0" || raw === 0) return null;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < 1) throw new TypeError("draft writer timeout must be a positive integer number of milliseconds");
  return value;
}

export async function boundedDraftDispatch(dispatch, request, { customerActor, timeoutMs } = {}) {
  if (timeoutMs === null || timeoutMs === undefined) return dispatch(request, { customerActor });
  const controller = new AbortController();
  let timeout;
  const refusal = new Promise((resolve) => {
    timeout = setTimeout(() => {
      controller.abort();
      resolve({
        outcome: "inference-obstructed",
        directLaneRefusals: [{
          provider: "urn:ame:koios-news",
          reason: "writer-dispatch-timeout",
          cause: { kind: "cancelled", reason: "timeout" },
        }],
        integrationAccepted: false,
        receiverAcceptanceRequired: true,
        obstruction: `draft writer timed out after ${timeoutMs}ms`,
      });
    }, timeoutMs);
  });
  const delivery = Promise.resolve().then(() => dispatch(request, { customerActor, signal: controller.signal }));
  delivery.catch(() => {});
  try {
    return await Promise.race([delivery, refusal]);
  } finally {
    clearTimeout(timeout);
  }
}
