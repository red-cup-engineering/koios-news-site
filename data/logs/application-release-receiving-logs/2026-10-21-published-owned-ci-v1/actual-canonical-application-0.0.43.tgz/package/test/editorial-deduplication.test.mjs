import assert from "node:assert/strict";
import test from "node:test";

import { nearDuplicateHeadline } from "../src/news-line/editorial-deduplication.mjs";

test("catches the duplicate Verstappen first-pole headlines observed on the public site", () => {
  assert.equal(
    nearDuplicateHeadline(
      "Verstappen Claims First Pole Position of Season",
      "Verstappen Secures First Pole Position of the Season",
    ),
    true,
  );
});

test("does not collapse distinct stories that merely share a desk or entity", () => {
  assert.equal(
    nearDuplicateHeadline(
      "Apple Tightens macOS Privacy Settings Amid AI Agent Risks",
      "Apple Reports Quarterly Revenue Growth as Services Expand",
    ),
    false,
  );
  assert.equal(
    nearDuplicateHeadline(
      "India Wins Asian Games Cricket Gold",
      "India Names Test Squad for South Africa Tour",
    ),
    false,
  );
});

test("requires enough shared evidence-bearing terms to act", () => {
  assert.equal(nearDuplicateHeadline("Fed Cuts Rates", "Fed Cuts Rates Again"), false);
});
