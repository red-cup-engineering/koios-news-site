/** Recover an observed public identity, never a claimed past editorial acceptance. */
import{existsSync,readdirSync,readFileSync}from'node:fs';
import{join}from'node:path';
import{createHash}from'node:crypto';
import{parsePost}from'@causeway-services/koios-news-site/build';
import{editions}from'./editions.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export const OBSERVED_PUBLICATION_PREFIX='news-property.published:';
export function observedArticleAssignments(context){
 const root=join(context.roots.publication,'prior-publication-observations');
 if(!existsSync(root))return [];
 const result=[];
 for(const directory of readdirSync(root)){
  const folder=join(root,directory),recordPath=join(folder,'recovery.json');if(!existsSync(recordPath))continue;
  const record=JSON.parse(readFileSync(recordPath)),auditBytes=readFileSync(join(folder,'newswire-audit.json')),audit=JSON.parse(auditBytes),manifest=JSON.parse(readFileSync(join(folder,'manifest.json')));
  if(record.kind!=='koios.news.observed-prior-publication/v1'||record.editorialAcceptanceCertified!==false||sha(auditBytes)!==record.auditSha256||manifest.artifacts.find(row=>row.file==='newswire-audit.json')?.sha256!==record.auditSha256)throw new Error('Prior publication observation differs from its captured manifest');
  for(const row of record.recovered){
   if(!/^[a-z0-9]+(?:-[a-z0-9]+)*\.md$/.test(row.filename)||row.filename!==row.slug+'.md'||!audit.posts.some(p=>p.slug===row.slug&&p.sourceSha256===row.sourceSha256&&p.url===row.url))throw new Error('Prior publication is outside its observed source identity');
   const bytes=readFileSync(join(context.roots.publication,'published',row.filename));
   // A later accepted version has its own released edition, not this historical observation.
   if(sha(bytes)!==row.sourceSha256)continue;
   const post=parsePost(bytes.toString('utf8'),row.filename),section=context.property.content?.legacyPublishedSections?.[row.slug]??post.section;
   if(!context.property.sections.some(desk=>desk.slug===section)||new URL(row.url).origin!==context.property.origin)throw new Error('Observed article lacks its actual publication desk');
   const identity={origin:context.property.origin,slug:row.slug};
   result.push({slug:row.slug,section,title:post.title,firstPublished:post.date,observedPriorPublication:true,storyId:OBSERVED_PUBLICATION_PREFIX+Buffer.from(JSON.stringify(identity)).toString('base64url')});
  }
 }
 return result;
}
export function existingArticleAssignment(context,slug,{releasedEditions=editions(context.roots,'released')}={}){
 const released=releasedEditions.filter(row=>row.slug===slug).sort((a,b)=>a.releasedAt.localeCompare(b.releasedAt)).at(-1);
 if(released)return released;
 const observed=observedArticleAssignments(context).find(row=>row.slug===slug);
 if(!observed)throw new Error(`No released or verified prior-publication custody for ${slug}; recover the actual publication first`);
 return observed;
}
