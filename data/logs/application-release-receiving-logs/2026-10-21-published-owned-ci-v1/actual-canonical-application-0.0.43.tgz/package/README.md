# Koios.News

`@causeway-services/koios-news` is a FeltOS application. It composes AOE
Newswire, shared Content Mill, independent editorial assessment, publication
authority and the separately owned public website. Its operation and schedule
factories install into MetroPlat; FeltOS owns the host and recurring work.

The living source owners are:

- `src/news-line`: the Koios editorial service line and property policy.
- `sites/koios.news`: `@causeway-services/koios-news-site`, the renderer and
  Cloudflare release carrier.
- `content` and `data`: independently versioned manuscript intake, source
  evidence, accepted publication ledger and portable editorial evidence.
- `services/newscable-source-broker`: source acquisition and wire custody.
- `services/editorial-publication-authority`, `independent-editorial-assessment`,
  `editorial-admission-receipt`, `web-source-acquisition`,
  `koios-intelligence-briefing` and `activitypub-retained-inbox-provider`:
  independent provider repositories and exact package dependencies.
- `history` and `research/source-receiving`: retained original work and theory.
  Historical implementations are not the selected production runtime.

## Running the application

`config/feltos-instance.json` declares the application operations, host environment
bindings, requested capabilities and recurring work. The native clock runs
`koios-news-cycle` every 15 minutes. This carries intake through analysis,
drafting, independent assessment, authority, rendering, release and feedback.
The retained daily publication schedule reads `koios-news-status`; it does not
start a competing publisher.

Cold Red Gate owns the frozen application composition and Guix deployment in
`deployment/applications/koios` of `561-group/cold-red-gate-services-section`.
Code fabricates its exact registry closure; LAGOON receives it through the native
Guix profile and service manager. Source changes require a new immutable release.
Do not install the source workspace or revive a private Koios server or timer.
The host may compose additional declared native jobs with separate credentials,
including encrypted recovery; their declarations belong to Operations.

Newsroom inference uses the credential-bound zero-cash provider configuration
and current account evidence. Research, writing and independent assessment must
retain that admission. Codex, Claude and Gemini subscriptions or API credentials
are not a newsroom fallback. A provider refusal is an obstruction, never an
editorial verdict. Slow inference has no default three-minute writer deadline.

## Publishing reporting

A manuscript remains unpublished until its exact bytes carry independent
editorial acceptance and publication authority. Content Mill joins the held
claims to their original source documents. Similar words or a shared document
do not establish that two stories are the same event. Source shortages reopen
reporting; they cannot be filled by padding or unrelated claim copies.

Use the installed application's reporter tools with its configured cloud
environment. `bin/koios-reporter-submit.mjs claims PACKET.json` admits reviewed
quotes against captured source text. Its `draft PACKET.json` operation submits
a supported manuscript for independent assessment. A new story names its existing
newsroom `storyId`; a revision uses the existing slug and preserves the original
publication date. These tools hold the same editorial lock as the service line.
They grant no publication authority. Authenticated issue commissions retain their
specific product, character and register selection throughout editorial custody.

The accepted ledger lives at `line/publication-replay/published` in newsroom
state. The release stage pushes its exact source and editorial evidence to
`koios-news-data`, then advances the parent repository's data input through an
ancestry-preserving Git handoff. The existing website workflow builds the site,
protects existing routes and releases the Cloudflare candidate. A release is
received only when the public article matches the consumed publication source.
A draft, rendered candidate, successful clock run or healthy host is insufficient.

`koios-news-status` reports actual new articles in the last day against the
20-article target, revisions separately, desk coverage and editorial blockers.
Publication holds bind the story and address. Responses received early cannot
shorten an agreed response window.

Metadata corrections use `scripts/correct-article.mjs` and retain a dated source
binding. Body changes require fresh independent acceptance. The historical
public corpus retains its recovered provenance; no past acceptance is invented.
Portable accepted evidence is retained under
`data/line/publication-evidence/SLUG/SOURCE_SHA256`.

## Recovery

`scripts/backup-newsroom.mjs` captures the durable newsroom under the editorial
lock, encrypts it with AES-256-GCM, restores it in isolation and uploads the
verified encrypted archive to the private data repository's releases. Private
office keys are included; process leases and disposable outputs are excluded.
The recovery key and upload credentials belong to the recovery job, separately
from writer credentials. The job's native receipt and actual uploaded archive,
not its schedule declaration, establish that recovery ran.

Read the dated research against current observations before changing policy.
Preserve unsupported work as reporting demand, and carry useful work to its
reader before claiming recovered throughput.

## Lenticule Science research-watch policy

The approved [publication-watch installation record](LENTICULE-RESEARCH-WATCH.md) describes how publicly received Lenticule papers become source-bound Koios newsroom leads under the appropriate existing desk. The first edition remains a candidate; the watch is not activated until a verified public release feed and the matching Content Mill supplier version exist. Do not add wire IDs to the live property without the source broker declaring those feeds too.
