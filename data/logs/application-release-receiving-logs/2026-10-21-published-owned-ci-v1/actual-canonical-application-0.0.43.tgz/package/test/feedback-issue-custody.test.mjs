import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,chmodSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

// Exercise the unchanged publisher and pushData helper through synthetic CLI
// boundaries. No inherited HOME, credentials, Git executable, or network client.
const script=fileURLToPath(new URL('../scripts/publish-feedback.mjs',import.meta.url));
const cli=`#!${process.execPath}
const fs=require('node:fs'),path=require('node:path');
const a=process.argv.slice(2),tool=path.basename(process.argv[1]);
const is=expected=>JSON.stringify(a)===JSON.stringify(expected);
const log=value=>fs.appendFileSync(process.env.CALLS,JSON.stringify(value)+'\\n');
log([tool,a]);
if(tool==='gh'){
 if(is(['api','user']))console.log(JSON.stringify({login:process.env.PUBLISHER}));
 else if(is(['issue','list','--repo','causeway-services/koios.news','--state','all','--limit','1000','--json','number,title,state,body,author'])){if(process.env.FAIL_ISSUE_SCAN)throw Error('Synthetic issue scan outage');process.stdout.write(fs.readFileSync(process.env.ISSUES));}
 else if(is(['issue','reopen','42','--repo','causeway-services/koios.news'])||is(['issue','close','42','--repo','causeway-services/koios.news','--reason','completed'])){}
 else if(is(['api','--method','PATCH','repos/causeway-services/koios.news/issues/42','--input','-'])||is(['api','--method','POST','repos/causeway-services/koios.news/issues','--input','-'])){log(['body',JSON.parse(fs.readFileSync(0,'utf8'))]);console.log('{}');}
 else throw Error('unexpected gh command');
}else if(tool==='git'){
 if(a[0]==='rev-parse')console.log('same-synthetic-commit');
 else if([['add','feedback'],['diff','--cached','--name-only'],['fetch','origin','main'],['rebase','origin/main'],['status','--porcelain','--untracked-files=all'],['checkout','--detach','origin/main']].some(x=>JSON.stringify(x)===JSON.stringify(a))){}
 else throw Error('unexpected git command');
}else throw Error('unexpected tool');
`;
function run(issues,{status='unavailable',publisher='publisher',failure=false,failIssueScan=false}={}){
 const root=mkdtempSync(join(tmpdir(),'koios-feedback-custody-'));
 try{
  for(const p of ['bin','home','data','incoming/feedback/standards'])mkdirSync(join(root,p),{recursive:true});
  writeFileSync(join(root,'incoming/feedback/latest.json'),JSON.stringify({observedAt:'2026-10-11T00:00:00Z',sensors:{execution:{status,reason:'Synthetic receiving probe'}},articles:[]}));
  writeFileSync(join(root,'issues.json'),JSON.stringify(issues));writeFileSync(join(root,'calls'),'');
  for(const name of ['gh','git']){const p=join(root,'bin',name);writeFileSync(p,cli);chmodSync(p,0o700);}
  const result=spawnSync(process.execPath,[script],{cwd:root,encoding:'utf8',timeout:15000,env:{PATH:join(root,'bin'),HOME:join(root,'home'),KOIOS_NEWSROOM_DATA_ROOT:join(root,'incoming'),ISSUES:join(root,'issues.json'),CALLS:join(root,'calls'),PUBLISHER:publisher,...(failIssueScan?{FAIL_ISSUE_SCAN:'1'}:{})}});
  assert.equal(result.error,undefined);const calls=readFileSync(join(root,'calls'),'utf8').split('\n').filter(Boolean).map(JSON.parse);
  const mutations=calls.filter(([tool,args])=>tool==='gh'&&((args[0]==='issue'&&['close','reopen'].includes(args[1]))||(args[0]==='api'&&args[1]==='--method')));
  // The fixed owned data repository is committed before consulting the
  // unrelated Issues API; only an authenticated publisher may mutate issues.
  const auth=calls.findIndex(([tool,args])=>tool==='gh'&&args[0]==='api'&&args[1]==='user');
  const dataCommit=calls.findIndex(([tool,args])=>tool==='git'&&args[0]==='add'&&args[1]==='feedback');
  const dataRead=calls.findIndex(([tool,args])=>tool==='git'&&args[0]==='fetch'&&args[1]==='origin'&&args[2]==='main');
  const issueScan=calls.findIndex(([tool,args])=>tool==='gh'&&args[0]==='issue'&&args[1]==='list');
  assert.ok(dataRead>=0&&dataCommit>dataRead&&auth>dataCommit,
    'original publication data must advance before optional issue identity');
  if(publisher)assert.ok(issueScan>auth,'issue list must follow authenticated publisher identity');
  else assert.equal(issueScan,-1,'missing publisher cannot query/mutate existing issues');
  assert.equal(result.status,0,result.stderr);
  if(failure||failIssueScan||!publisher){
    assert.deepEqual(mutations,[],'failed issue discovery cannot mutate unrelated issues');
    const reason=failIssueScan?'github-issue-api-unavailable':!publisher?'publisher-identity-unavailable':'issue-scan-incomplete';
    assert.match(result.stderr,new RegExp('"reason":"'+reason+'"'));
    assert.match(result.stderr,/"publicationDataAlreadyAttempted":true/);
  }
  for(const [,body]of calls.filter(([tool])=>tool==='body'))assert.match(body.body,/^<!-- koios-feedback:execution -->\n\nObserved /);
  return mutations;
 }finally{rmSync(root,{recursive:true,force:true});}
}
const owned={number:42,title:'Repair observed Koios.News execution deficiency',state:'OPEN',body:'<!-- koios-feedback:execution -->\nSynthetic evidence',author:{login:'publisher'}};
for(const [name,change] of Object.entries({
 'wrong author':{author:{login:'customer'}},'missing author':{author:null},
 'wrong title':{title:'Customer question'},'embedded marker':{body:'Customer text\n<!-- koios-feedback:execution -->'},
 'wrong marker':{body:'<!-- koios-feedback:other -->'},'zero number':{number:0},
 'string number':{number:'42'},'unknown state':{state:'unknown'}
}))for(const status of ['unavailable','observed'])test(`${name} is never selected for mutation (${status})`,()=>{
 const invalidIdentity=['zero number','string number','unknown state'].includes(name);
 const calls=run([{...owned,...change}],{status});assert.equal(calls.length,status==='unavailable'&&!invalidIdentity?1:0);
 if(calls.length)assert.deepEqual(calls[0][1],['api','--method','POST','repos/causeway-services/koios.news/issues','--input','-']);
});
test('owned open diagnostic is updated',()=>{const c=run([owned]);assert.equal(c.length,1);assert.deepEqual(c[0][1],['api','--method','PATCH','repos/causeway-services/koios.news/issues/42','--input','-']);});
test('owned closed diagnostic is reopened then updated',()=>{const c=run([{...owned,state:'CLOSED'}]);assert.deepEqual(c.map(x=>x[1]),[['issue','reopen','42','--repo','causeway-services/koios.news'],['api','--method','PATCH','repos/causeway-services/koios.news/issues/42','--input','-']]);});
test('owned diagnostic closes only for an observed sensor',()=>{const c=run([owned],{status:'observed'});assert.equal(c.length,1);assert.deepEqual(c[0][1],['issue','close','42','--repo','causeway-services/koios.news','--reason','completed']);});
for(const status of ['unknown','unavailable-pending','stale'])test(`retain diagnostic when status is ${status}`,()=>assert.deepEqual(run([owned],{status}),[]));
for(const count of [1000,1001])test(`scan of ${count} issues fails before mutations`,()=>run(Array.from({length:count},()=>owned),{failure:true}));
test('missing publisher fails before mutations',()=>run([],{publisher:'',failure:true}));
test('non-array scan fails before mutations',()=>run({},{failure:true}));
test('a GitHub issue outage follows durable feedback, never blocks its data receiving',()=>{
  assert.deepEqual(run([],{failIssueScan:true}),[]);
});
test('publisher identity denial is a diagnostic refusal, never permission to rewrite someone else\'s issues',()=>{
  assert.deepEqual(run([owned],{publisher:'',failure:true}),[]);
});
