/**
 * Publication throughput is a receiving obligation, not an inference from
 * a successful service turn. The newsroom already separates newly released
 * articles from updates to existing URLs. Preserve that distinction here.
 *
 * An absent or malformed reading is unknown, never success or zero output.
 * A deficit is an observed failure of the publication target, even when
 * every process exited successfully. This observer grants no editorial
 * acceptance or publication authority.
 */
export function newArticleThroughputFeedback(metrics) {
  if (!metrics || typeof metrics !== "object" || Array.isArray(metrics)) {
    return { status: "unknown", reason: "No valid newsroom publication-throughput reading is available." };
  }
  const { articlesLast24h, revisionsLast24h, dailyArticleTarget, returnedByFailureLayer, at } = metrics;
  if (!Number.isSafeInteger(articlesLast24h) || articlesLast24h < 0 ||
      !Number.isSafeInteger(dailyArticleTarget) || dailyArticleTarget < 1) {
    return { status: "unknown", reason: "New-article count or positive daily publication target is absent or invalid." };
  }
  const layers = returnedByFailureLayer && typeof returnedByFailureLayer === "object" && !Array.isArray(returnedByFailureLayer)
    ? Object.entries(returnedByFailureLayer).filter(([, count]) => Number.isSafeInteger(count) && count >= 0)
    : [];
  layers.sort(([a, countA], [b, countB]) => countB - countA || a.localeCompare(b));
  const leadingReturnLayer = layers.length ? { layer: layers[0][0], count: layers[0][1] } : null;
  const observation = {
    articlesLast24h,
    dailyArticleTarget,
    deficit: Math.max(0, dailyArticleTarget - articlesLast24h),
    revisionsLast24h: Number.isSafeInteger(revisionsLast24h) && revisionsLast24h >= 0 ? revisionsLast24h : null,
    metricAt: typeof at === "string" ? at : null,
    leadingReturnLayer,
    // Lifetime counts are diagnostic, not a last-24-hour provider failure rate.
    returnLayerCountsLifetime: Object.fromEntries(layers),
  };
  if (observation.deficit > 0) {
    return {
      status: "unavailable",
      reason: `Only ${articlesLast24h} NEW article(s) reached released custody in the last 24 hours against a target of ${dailyArticleTarget}; ${observation.deficit} short. Existing-article revisions do not count. Investigate the acquisition, writing, evidence and editorial gates before treating the newsroom as healthy.`,
      ...observation,
    };
  }
  return { status: "observed", ...observation };
}

/** A daily NEW-article deficit chooses fresh source-backed writing over archival revisions.
 * This only ranks candidate model orders. It never decides claim admission,
 * independent assessment, editorial signature or publication authority.
 * An unknown throughput observation is not assumed to be a zero count.
 */
export function preferUnpublishedWriterOrders(metrics = {}) {
  const {articlesLast24h,dailyArticleTarget} = metrics ?? {};
  return Number.isSafeInteger(articlesLast24h) && articlesLast24h >= 0 &&
    Number.isSafeInteger(dailyArticleTarget) && dailyArticleTarget > 0 &&
    articlesLast24h < dailyArticleTarget;
}

/**
 * Return true only for an independently assessed returned manuscript whose
 * exact repair tools may still be executed without paying a writer model.
 * Neither rejected sources nor an unsponsored assignment is a writable
 * manuscript. A retry uses the existing edition revision lineage.
 */

export function isPendingExactEditorialRepair(edition) {
  return edition?.state === "returned" && edition.reason === "submit_revision_request"
    && !edition.revisedAs && !edition.revisionRefused
    && Number.isSafeInteger(edition.revision ?? 0)
    && (edition.revision ?? 0) >= 0;
}
/**
 * One exact manuscript must reach independent assessment within its own
 * finite editorial window. An earlier refused, expired or revised candidate
 * is historical custody, NOT the clock for new independently sourced work
 * under the same story ID. Publication event/source currentness is separately
 * judged by the independent editor against the complete originating records.
 *
 * `updatedAt`, repeated attempts and firstPublished may never renew the
 * submitted manuscript's original `draftedAt` deadline.
 * Missing, future or malformed custody clocks are refused for investigation
 * instead of silently considered fresh.
 */
export function draftHasExpired(edition, assessedAt, storySeconds) {
  if (!Number.isSafeInteger(storySeconds) || storySeconds < 1)
    throw new TypeError("assessor manuscript lifetime must be positive whole seconds");
  const issued = typeof edition?.draftedAt === "string" ? Date.parse(edition.draftedAt) : NaN;
  const now = typeof assessedAt === "string" ? Date.parse(assessedAt) : NaN;
  if (!Number.isFinite(issued) || !Number.isFinite(now) || issued > now)
    throw new TypeError("assessor manuscript custody timestamps missing, malformed or future-dated");
  return now - issued >= storySeconds * 1000;
}

