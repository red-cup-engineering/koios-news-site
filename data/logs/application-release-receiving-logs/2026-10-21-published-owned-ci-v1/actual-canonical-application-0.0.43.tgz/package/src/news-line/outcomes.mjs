/**
 * The editor's verdict as a producer on the one outcome path (561 Group note of 2026-10-03, "One
 * outcome path"). When the independent editorial assessment accepts a draft or returns it, the line
 * tells that judgment at the source as the one outcome record: the story's work lot, the draft
 * (candidate) delivered, the carrier that wrote it (the model), and the market coordinate of the
 * inference delivery that produced the draft, so the inference market's routing learns which models
 * write acceptable copy. There is no Koios ledger: the record goes to the node's outcome journal,
 * and routing, staffing and the readout are folds of it.
 */
import { outcomeJournal, outcomeOf } from "@red-cup-engineering/organizing/enterprise";
import { marketCoordinateOfDelivery, pricingRootOf } from "@red-cup-engineering/computer-inference-engine/dispatch/expected-resolution-pricing-client";
import { ACTOR as EDITOR } from "@causeway-services/independent-editorial-assessment/contract";

/** The section the line delivers from, and the editor that judges its editions. */
export const KOIOS_SECTION = "section:lib/emsenn/services/561-group/services/public-services-section/services/public-media-services-section/services/public-news-media-services-section/services/koios-news-services-section";
export const KOIOS_EDITOR = EDITOR;
export const EDITION_TASK_CLASS = "koios/news-edition";

const VERDICTS = Object.freeze({ accepted: "accepted", returned: "rejected" });
const text = (value) => typeof value === "string" && value.trim() !== "";

/** Where the node keeps its outcome journal, and the inference book the market's coordinates live in. */
export const outcomeRootOf = (environment) => (text(environment.METROPLAT_DATA_ROOT) ? environment.METROPLAT_DATA_ROOT : undefined);
export const pricingRootFor = (environment) => pricingRootOf(environment);

/** The market coordinate of the delivery that wrote a candidate: its work lot and receipt, found in the pricing root. */
export const draftMarketOf = (environment, candidateContent) => (text(candidateContent?.workLotId) && text(candidateContent?.exchangeId)
  ? marketCoordinateOfDelivery(pricingRootFor(environment), { workLot: candidateContent.workLotId, receipt: candidateContent.exchangeId })
  : undefined);

/**
 * The outcome record of one editor verdict on an edition: `state` is the edition state the verdict
 * moved it to (`accepted` or `returned`), `at` when it was judged. Undefined for any other state.
 */
export function editorOutcomeOf(edition, state, at, { reason, failureLayer } = {}) {
  const verdict = VERDICTS[state];
  if (verdict === undefined) return undefined;
  return outcomeOf({
    source: "editor", lot: edition.storyId ?? edition.candidateId, delivery: edition.candidateId,
    provider: KOIOS_SECTION, judge: KOIOS_EDITOR, verdict, at,
    evidence: [`koios-edition:${edition.candidateId}`, `koios-edition-${state}:${at}`, ...(verdict === "accepted" && text(edition.receiptPath) ? [`koios-receipt:${edition.receiptPath.split("/").at(-1)}`] : [])],
    ...(text(edition.model) ? { carrier: edition.model } : {}), taskClass: EDITION_TASK_CLASS,
    ...(edition.market === undefined || edition.market === null ? {} : { market: edition.market }),
    ...(verdict === "rejected" ? { reason: [reason, failureLayer].filter(text).join(": ") || state } : {}),
  });
}

/**
 * Tell one editor verdict into the node's outcome journal. Returns `{told, reason?}`: a line whose
 * environment names no outcome root tells nothing and says so, never silently.
 */
export function tellEditorOutcome(environment, edition, state, at, details) {
  const outcome = editorOutcomeOf(edition, state, at, details);
  if (outcome === undefined) return { told: 0, reason: "not-a-verdict" };
  const root = outcomeRootOf(environment);
  if (root === undefined) return { told: 0, reason: "no-outcome-root" };
  return { told: outcomeJournal(root).record(outcome), outcome: outcome.id };
}
