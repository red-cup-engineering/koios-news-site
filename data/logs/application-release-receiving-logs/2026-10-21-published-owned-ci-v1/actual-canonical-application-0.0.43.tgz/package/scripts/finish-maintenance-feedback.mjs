import {readFileSync,writeFileSync,renameSync,rmSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';

const instant=value=>typeof value==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(value)&&Number.isFinite(Date.parse(value));
const unitFields=['LoadState','ActiveState','Result','ExecMainStatus','ExecMainExitTimestamp'];
export function maintenanceFailureCode(error){
 if(['ENOENT','EACCES','EPERM','ENOSPC','EISDIR','ENOTDIR','EROFS','ETIMEDOUT'].includes(error?.code))return error.code;
 if(['SyntaxError','TypeError','RangeError'].includes(error?.name))return error.name;
 return 'record-or-publication-failed';
}

/** A running unit observation is not a completed maintenance attempt. */
export function maintenanceUnitObservation(unit){
 if(unit.LoadState!=='loaded'||unit.ActiveState==='failed'||unit.Result!=='success')throw Object.assign(new Error(`Cloud maintenance is ${unit.ActiveState}, result ${unit.Result}, exit ${unit.ExecMainStatus}, last exit ${unit.ExecMainExitTimestamp||'unknown'}. Inspect koios-maintenance.service and preserve interrupted reporting before resuming. A healthy publication does not establish an operating maintenance agent.`),{observation:{unit}});
 return {status:unit.ActiveState==='activating'?'running':'observed',unit};
}

/** Only bounded process facts are added; prior unit state keeps its observation time. */
export function completedMaintenanceFeedback(snapshot,{exitCode,startedAt,finishedAt,processId}){
 if(!snapshot||snapshot.kind!=='koios.news.observed-feedback/v1'||!snapshot.sensors||typeof snapshot.sensors!=='object'||Array.isArray(snapshot.sensors))throw new TypeError('A held Koios feedback snapshot is required');
 if(!Number.isInteger(exitCode)||exitCode<0||exitCode>255)throw new TypeError('Maintenance exit code must be an integer from 0 to 255');
 if(!instant(startedAt)||!instant(finishedAt)||Date.parse(finishedAt)<Date.parse(startedAt))throw new TypeError('Ordered explicit UTC maintenance instants are required');
 if(!Number.isSafeInteger(processId)||processId<1)throw new TypeError('The maintenance process identity is required');
 const prior=snapshot.sensors.cloudMaintenance??{},unit=prior.unit;
 const attempt={kind:'koios.news.maintenance-attempt-outcome/v1',id:'koios-maintenance:'+createHash('sha256').update(JSON.stringify({startedAt,processId})).digest('hex').slice(0,32),startedAt,finishedAt,exitCode,status:exitCode===0?'succeeded':'failed'};
 const cloudMaintenance={status:exitCode===0?'observed':'unavailable',observedAt:finishedAt,attempt,
  ...(unit&&typeof unit==='object'?{unit:Object.fromEntries(unitFields.filter(key=>typeof unit[key]==='string').map(key=>[key,unit[key].slice(0,200)])),unitObservedAt:prior.unitObservedAt??prior.observedAt}:{}),
  ...(exitCode===0?{}:{reason:`Cloud maintenance attempt exited ${exitCode} at ${finishedAt}. Preserve interrupted reporting and inspect koios-maintenance.service. This completed-attempt result does not assert the current unit state.`})};
 return {...snapshot,sensors:{...snapshot.sensors,cloudMaintenance}};
}

export async function finishMaintenanceFeedback({feedbackRoot,exitCode,startedAt,processId,now=()=>new Date().toISOString(),publish}){
 const path=join(feedbackRoot,'latest.json'),snapshot=JSON.parse(readFileSync(path,'utf8'));
 const completed=completedMaintenanceFeedback(snapshot,{exitCode,startedAt,processId,finishedAt:now()});
 const temporary=path+'.maintenance-'+process.pid+'.tmp';
 try{writeFileSync(temporary,JSON.stringify(completed,null,2)+'\n',{mode:0o600});renameSync(temporary,path);}
 finally{rmSync(temporary,{force:true});}
 await publish();
 return completed.sensors.cloudMaintenance;
}

/** Supervise only this Linux/POSIX publisher group, including its gh/git children. */
export function publishMaintenanceFeedback({publisherPath=fileURLToPath(new URL('./publish-feedback.mjs',import.meta.url)),timeoutMs=180000}={}){
 if(process.platform==='win32')throw new Error('Maintenance publication requires POSIX process groups');
 if(!Number.isSafeInteger(timeoutMs)||timeoutMs<1)throw new TypeError('A positive bounded publication timeout is required');
 return new Promise((resolveDone,reject)=>{
  let child,timer,settled=false,obstruction;
  const stopGroup=()=>{if(child?.pid)try{process.kill(-child.pid,'SIGKILL');}catch(error){if(error.code!=='ESRCH')obstruction='publication-group-cleanup-failed';}};
  const interrupt=signal=>{obstruction??='publication-interrupted-'+signal;stopGroup();};
  const listeners=new Map(['SIGHUP','SIGINT','SIGTERM'].map(signal=>[signal,()=>interrupt(signal)]));
  const finish=(status,signal)=>{if(settled)return;settled=true;clearTimeout(timer);for(const [name,handler]of listeners)process.removeListener(name,handler);
   // A publisher that dies before its synchronous child must not release the
   // maintenance lock while that child can still mutate the feedback carrier.
   stopGroup();
   if(obstruction||status!==0)reject(new Error(obstruction??'publication-failed-'+(status??signal??'unknown')));else resolveDone();
  };
  for(const [name,handler]of listeners)process.on(name,handler);
  try{
   // No remote response, arbitrary tool output or session data reaches our logs.
   child=spawn(process.execPath,[publisherPath],{stdio:'ignore',detached:true});
   child.once('error',()=>{obstruction='publication-start-failed';finish(null,null);});
   child.once('close',finish);
   timer=setTimeout(()=>{obstruction='publication-timeout';stopGroup();},timeoutMs);
  }catch{obstruction='publication-start-failed';finish(null,null);}
 });
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 try{
  if(!process.env.KOIOS_NEWSROOM_DATA_ROOT)throw new Error('KOIOS_NEWSROOM_DATA_ROOT is required');
  if(![5,6].includes(process.argv.length))throw new Error('Expected maintenance exit code, start instant, process identity and optional publication mode');
  const mode=process.argv[5]??'publish';
  if(!['publish','record-only'].includes(mode))throw new Error('Unknown maintenance publication mode');
  // Startup may precede the publisher's cwd/data prerequisites or stop on an
  // uncertain initial publication. Retain only the held snapshot in that case.
  await finishMaintenanceFeedback({feedbackRoot:join(resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT),'feedback'),exitCode:Number(process.argv[2]),startedAt:process.argv[3],processId:Number(process.argv[4]),publish:mode==='publish'?publishMaintenanceFeedback:async()=>{}});
 }catch(error){console.error('Final maintenance feedback failed: '+maintenanceFailureCode(error));process.exitCode=1;}
}

