/** Koios's owned newsroom composition: an authenticated editorial commission is
 * interpreted through the EXISTING Organizing agency, then the Content Mill's
 * registered treatment selector. No persona record, issue comment or prompt
 * by itself makes an actor an officer or grants an editorial publication right.
 */
import {readAgency,resolve} from '@red-cup-engineering/organizing/agency';
import {selectOfficeDutyOperation} from '@red-cup-engineering/organizing/work/request-intake';
import {resolveEditorialTreatment} from '@red-cup-engineering/content-mill-newsroom-services-section/editorial-treatment';
import {readFileSync} from 'node:fs';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha256Digest} from '@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity';
import {canonicalJson} from '@red-cup-engineering/json-services-section/canonical';
import {readNewsroom} from '../newsroom-records.mjs';

const ROOT=fileURLToPath(new URL('../..',import.meta.url));
const OWNER='causeway-services/koios.news';
const MARKER=/^<!-- koios-editorial-treatment: (\{[^\r\n]+\}) -->\s*$/gmu;
const fields=['subdesk','registerId','productId','formatId','readerQuestion'];
const readJson=path=>JSON.parse(readFileSync(join(ROOT,path),'utf8'));
const legalId=value=>typeof value==='string'&&/^[a-z0-9]+(?:-[a-z0-9]+)*(?:\/[a-z0-9]+(?:-[a-z0-9]+)*)?$/u.test(value);

/** A declaration is only usable after commissionArticle verified the owner-authored issue.
 * Unmarked ordinary commissions remain on the original generic news path.
 * Do NOT call this parser on arbitrary reader comments as an authority grant.
 */
export function declaredEditorialTreatment(issueBody){
 if(typeof issueBody!=='string')throw new TypeError('Owner-authored issue body required');
 const found=[...issueBody.matchAll(MARKER)];
 if(found.length===0)return null;
 if(found.length!==1)throw new TypeError('Exactly one editorial treatment declaration permitted');
 let record;
 try{record=JSON.parse(found[0][1]);}catch{throw new TypeError('Invalid editorial treatment JSON in authenticated commission');}
 if(!record||typeof record!=='object'||Array.isArray(record)
   ||Object.keys(record).sort().join('|')!==[...fields].sort().join('|')
   ||!fields.slice(0,4).every(key=>legalId(record[key]))
   ||typeof record.readerQuestion!=='string'||record.readerQuestion.trim().length<10||record.readerQuestion.length>500) {
  throw new TypeError('Editorial treatment requires a complete specific commission, not an inferred voice');
 }
 return Object.freeze({...record,readerQuestion:record.readerQuestion.trim()});
}

/** This is a candidate writer order/loadout, NOT an authorization to publish.
 * It is derived from a source-current agency reading and authored source values.
 */
export function selectEditorialAgencyTreatment({section,declaration,agency,catalog,profiles}={}){
 if(!declaration)return null;
 if(!agency||agency.kind!=='organizing.agency')throw new TypeError('A current native Organizing agency reading is required');
 if(!catalog||catalog.kind!=='koios.news.editorial-treatment-catalog/v1'||!profiles?.profiles)throw new TypeError('Source-owned Koios product and genre catalog required');
 const desk=catalog.subdesks?.[declaration.subdesk];
 if(!desk||!(desk.parentDesk===section||(desk.parentDesk==='crossdesk'&&desk.crossDeskCommissionRequired===true)))
  throw new TypeError('Commission subdesk is not authorized for its accountable editorial desk');
 if(!desk.crew?.length||desk.crew.length!==1||!desk.office||!desk.requiredDuty)
  throw new TypeError('Specialist desk lacks an unambiguous office and actual incumbent');
 if(!desk.registers?.includes(declaration.registerId)||!desk.allowedProducts?.includes(declaration.productId))
  throw new TypeError('Genre/register is not permitted by the owning specialist desk');
 // A new graphic may not travel through the ordinary manuscript renderer as if it were an article.
 if(declaration.formatId!=='text-report')
  throw new TypeError('Interactive format requires a separately installed and received visual publication lane');
 const writer=desk.crew[0];
 const character=resolve(agency,'characters',writer);
 const office=resolve(agency,'offices',desk.office);
 if(!character||!office||character.authored?.['is-AI-character']!==true
   ||character.authored?.['holds-office']!==desk.office
   ||character.authored?.['reports-to']!==office.reportsTo
   ||character.authored?.['editor-in-chief']!=='nik-koios')
  throw new TypeError('Character identity does not derive from the office it claims to hold');
 const operation=selectOfficeDutyOperation(agency,{actor:writer,office:office.key,duty:desk.requiredDuty,skill:'writing'});
 if(operation.state!=='candidate'||operation.admitted!==false||operation.executed!==false)
  throw new TypeError('The native Organizing agency has not resolved an eligible specialist duty and skill');
 const reg=Object.fromEntries(desk.registers.map(key=>{
  const original=catalog.registers[key];
  if(!original)throw new TypeError('Declared newsroom register is unresolved');
  return [key,{writerRules:original.writerRules??[original.style],
    feelingRules:original.affectiveGuard??{expected:[],permitted:[],refused:[]},
    ...(original.fleschKincaidGrade?{readabilityAdvisory:{fleschKincaidGrade:original.fleschKincaidGrade}}:{})}];
 }));
 const characterRecord={
  kind:'ai-editorial-character',
  byline:character.name,
  publicDisclosure:character.name+' is an AI editorial character. Koios.News retains independent assessment, corrections, and publication accountability.',
  allowedRegisters:[...desk.registers],
  desks:[section],
  identityLimits:character.authored['identity-limits'],
  disposition:character.authored.disposition,
  officeId:office.id
 };
 const normalized={
  products:Object.fromEntries(desk.allowedProducts.map(key=>{
   const profile=profiles.profiles[key];
   if(!profile)throw new TypeError('The chosen product has no admitted evidence law');
   return [key,profile];
  })),
  registers:reg,
  characters:{[writer]:characterRecord},
  formats:{'text-report':{allowedProducts:[...desk.allowedProducts]}}
 };
 const selection=resolveEditorialTreatment({
  section,
  desk:{slug:section,
   defaults:{product:desk.defaultProduct,register:desk.defaultRegister,character:writer,format:'text-report'},
   allowed:{products:desk.allowedProducts,registers:desk.registers,characters:desk.crew,formats:['text-report']}},
  catalog:normalized,
  commission:{productId:declaration.productId,registerId:declaration.registerId,
    characterId:writer,formatId:declaration.formatId,readerQuestion:declaration.readerQuestion}
 });
 return Object.freeze({...selection,subdeskId:declaration.subdesk,officeId:office.id,
  agencyCandidate:operation,
  selectionDigest:sha256Digest(canonicalJson({
    section,subdesk:declaration.subdesk,writer,product:declaration.productId,
    register:declaration.registerId,format:declaration.formatId,
    question:declaration.readerQuestion,office:operation.office,duty:operation.duty,skill:operation.skill,
    law:desk,registerLaw:catalog.registers[declaration.registerId],productLaw:selection.editorialProduct
  }))});
}

/** Preflight only after the current GitHub issue's owner, URL and state are checked.
 * This does not itself receive the source nor create a newsroom work order.
 */
export function qualificationForOwnerCommission({section,issueBody}={}){
 const declaration=declaredEditorialTreatment(issueBody);
 if(declaration===null)return null;
 return selectEditorialAgencyTreatment({section,declaration,
  agency:readAgency(ROOT,{acts:[]}),
  catalog:readJson('policy/law/editorial-treatment-catalog.json'),
  profiles:readJson('policy/law/editorial-product-commissions.json')});
}

/** Read only the exact source-custodied assignment formed from an authenticated issue.
 * An unrelated social post, a model's suggestion, or an author profile selects nothing.
 */
export function treatmentForStory(context,{storyId,section}={}){
 if(!storyId||!section)return null;
 const cacheKey=section+'\u0000'+storyId;
 if(context.treatmentCache?.has(cacheKey))return context.treatmentCache.get(cacheKey);
 const originals=readNewsroom(context.dataRoot,'editorial-commission')
  .filter(({record,told})=>told===undefined&&record?.storyId===storyId&&
    record?.author==='emsenn'&&record?.issueUrl?.startsWith('https://github.com/'+OWNER+'/issues/')&&
    typeof record.body==='string'&&sha256Digest(record.body)===record.bodyDigest)
  .map(({record})=>record)
  .sort((a,b)=>(b.receivedAt??'').localeCompare(a.receivedAt??''));
 const current=originals[0];
 if(!current){context.treatmentCache?.set(cacheKey,null);return null;}
 const declaration=declaredEditorialTreatment(current.body);
 if(!declaration){context.treatmentCache?.set(cacheKey,null);return null;}
 const catalog=context.editorialTreatmentCatalog??readJson('policy/law/editorial-treatment-catalog.json');
 const profiles=context.editorialProductLaw??readJson('policy/law/editorial-product-commissions.json');
 const agency=context.currentAgency??context.agencyCache?.current??readAgency(ROOT,{acts:[]});
 if(context.agencyCache&&!context.agencyCache.current)context.agencyCache.current=agency;
 const selected=selectEditorialAgencyTreatment({section,declaration,catalog,profiles,agency});
 if(current.specialistSelectionDigest!==selected.selectionDigest||current.character!==selected.characterId||current.specialistOffice!==selected.officeId)
  throw new TypeError('Specialist assignment no longer matches its authenticated original commission');
 const result=Object.freeze({...selected,authenticatedCommissionDigest:current.bodyDigest,issueUrl:current.issueUrl});
 context.treatmentCache?.set(cacheKey,result);
 return result;
}

/** Refuse a changed commission or normative agency selection for an already held edition. */
export function assertEditionTreatment(context,edition){
 const selected=treatmentForStory(context,{storyId:edition.storyId,section:edition.section});
 if(edition.treatmentDigest===undefined && selected===null)return null;
 if(!selected||edition.treatmentDigest!==selected.selectionDigest
   ||edition.commissionDigest!==selected.authenticatedCommissionDigest)
  throw new TypeError('Editorial assignment, agency incumbency or commissioned treatment changed; independently reassess before continuation');
 return selected;
}
