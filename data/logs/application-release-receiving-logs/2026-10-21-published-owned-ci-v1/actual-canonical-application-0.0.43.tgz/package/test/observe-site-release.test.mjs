import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,readdirSync,rmSync,symlinkSync,lstatSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {observeSiteRelease} from '../scripts/observe-site-release.mjs';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const tuple={runId:'38142736555',runAttempt:'1',revision:'11a0a26233449354caf1aad9dc3eabb916cf0206',
 candidateManifestSha256:'3a5981ab67324bc91ce1d0737fa5cbd93c74b6662c9bef0dbe97620eda774970',bindingSha256:'3b5605daef5613d18937b165ebdaf5632657e24560c5e296d6f3ed86df5278a2'};
const provider={deploymentId:'11111111-1111-1111-1111-111111111111',versionId:'22222222-2222-2222-2222-222222222222',createdOn:'2026-10-11T14:00:00.123456Z'};
const inventory=root=>{
 const rows=[];const walk=path=>{for(const entry of readdirSync(path,{withFileTypes:true})){
  const file=join(path,entry.name),stat=lstatSync(file);assert.equal(stat.isSymbolicLink(),false);
  if(entry.isDirectory())walk(file);else rows.push([file,stat.mode,sha(readFileSync(file))]);
 }};walk(root);return rows.sort();
};
function fixture(t){
 const home=mkdtempSync(join(tmpdir(),'koios-receipt-observer-'));t.after(()=>rmSync(home,{recursive:true,force:true}));
 const releasesRoot=join(home,'.local/state/561-group/news-property/Koios.News/website-releases');
 const run=join(releasesRoot,`${tuple.runId}-${tuple.runAttempt}-${tuple.revision}`),receipts=join(run,'.release'),authority=join(receipts,'authority');
 mkdirSync(authority,{recursive:true});
 const write=(name,value)=>{const bytes=JSON.stringify(value)+'\n';writeFileSync(join(receipts,name),bytes);return sha(bytes);};
 const baseline=write('baseline.json',{kind:'news-property.build-manifest/v1',artifacts:[],private:'never disclose baseline bodies'});
 const use=phase=>{
  const consumptionId=`self-${(phase==='preview'?'a':'b').repeat(64)}`,value={kind:'koios.news.cloudflare-release-authority-use/v1',phase,
   consumptionId,grantDigest:'d'.repeat(64),candidateManifestSha256:tuple.candidateManifestSha256,bindingSha256:tuple.bindingSha256,
   ...(phase==='release'?{productionBaselineManifestSha256:baseline}:{})};
  write(`authority/${consumptionId}.json`,value);return value;
 };
 const deployment=phase=>write(`${phase}.json.deployment.json`,{phase,provider,candidateManifestSha256:tuple.candidateManifestSha256,
  uploadedArtifacts:77,stdout:'SECRET_RAW_PROVIDER_STDOUT',environment:{token:'SECRET_ENVIRONMENT'}});
 const receipt=phase=>{
  const auth=use(phase);deployment(phase);
  const probe={accepted:true,candidateManifestSha256:tuple.candidateManifestSha256,bindingSha256:tuple.bindingSha256,manifestSha256:tuple.candidateManifestSha256};
  let previewReceiptSha256;
  if(phase==='release'){
   previewReceiptSha256=write('probe.json',{kind:'koios.news.cloudflare-preview-receipt/v1',candidateManifestSha256:tuple.candidateManifestSha256,bindingSha256:tuple.bindingSha256,probe});
   write('rollback.json',{kind:'koios.news.cloudflare-rollback-binding/v1',bindingSha256:tuple.bindingSha256,priorVersionId:provider.versionId});
  }
  write(`${phase}.json`,{kind:phase==='preview'?'koios.news.cloudflare-preview-deployment-receipt/v1':'koios.news.cloudflare-release-receipt/v1',
   candidateManifestSha256:tuple.candidateManifestSha256,bindingSha256:tuple.bindingSha256,
   grantId:auth.consumptionId,grantDigest:auth.grantDigest,authorityUsePath:join(authority,`${auth.consumptionId}.json`),
   ...(phase==='release'?{productionBaselineManifestSha256:baseline,previewReceiptSha256,rollback:{priorVersionId:provider.versionId}}:{}),deployment:{readback:provider},
   probe:{accepted:true,candidateManifestSha256:tuple.candidateManifestSha256,bindingSha256:tuple.bindingSha256,manifestSha256:tuple.candidateManifestSha256,
    privateContent:'SECRET_ARTICLE_BODY'}});
 };
 return {home,releasesRoot,run,receipts,authority,write,use,deployment,receipt,read:()=>observeSiteRelease({releasesRoot,...tuple})};
}

test('authority-use alone remains attempted/unreconciled with byte-for-byte one-use custody unchanged',t=>{
 const f=fixture(t);f.use('release');const before=inventory(f.home),result=f.read();
 assert.equal(result.effects.production,'attempted-unreconciled');assert.equal(result.effects.preview,'unobserved');
 assert.equal(result.currentProvider,'unobserved');assert.equal(result.currentPublicAssets,'unobserved');
 assert.deepEqual(inventory(f.home),before);assert.equal(JSON.stringify(result).includes('grantDigest'),false);
});

test('provider report and public verification remain distinct stored witnesses with structural redaction',t=>{
 const f=fixture(t);f.use('preview');f.deployment('preview');f.receipt('release');
 f.write('ignored-output.json',{secret:'DO_NOT_READ_OR_PRINT'});
 const before=inventory(f.home),result=f.read();
 assert.equal(result.effects.preview,'provider-report-retained');assert.equal(result.effects.production,'public-verification-report-retained');
 assert.equal(result.receipts.find(row=>row.file==='release.json').reportedPublicVerification,true);
 assert.deepEqual(result.receipts.find(row=>row.file==='release.json.deployment.json').reportedProvider,provider);
 const text=JSON.stringify(result);for(const secret of ['SECRET_','privateContent','stdout','environment','grantDigest','authorityUsePath','DO_NOT_READ'])assert.equal(text.includes(secret),false,secret);
 assert.deepEqual(inventory(f.home),before);assert.equal(result.runBinding,'exact-directory-identity');
});

test('missing receipts are unknown, never evidence that no deployment happened',t=>{
 const f=fixture(t),result=f.read();assert.deepEqual(result.effects,{preview:'unobserved',production:'unobserved'});
 assert.equal(result.status,'observed');assert.equal(result.receipts.length,1);
});

for(const key of ['runId','runAttempt','revision','candidateManifestSha256','bindingSha256'])test(`rejects traversal, whitespace and malformed ${key}`,t=>{
 const f=fixture(t);for(const value of ['../elsewhere',tuple[key]+'\n','invalid'])assert.throws(()=>observeSiteRelease({releasesRoot:f.releasesRoot,...tuple,[key]:value}),error=>error.reason==='identity');
});

for(const target of ['run','receipts','authority','file'])test(`refuses symlink ${target} before receipt disclosure`,t=>{
 const f=fixture(t);let path;
 if(target==='run')path=f.run;else if(target==='receipts')path=f.receipts;else if(target==='authority')path=f.authority;else path=join(f.receipts,'baseline.json');
 const other=join(f.home,'outside');if(target==='file')writeFileSync(other,'{}');else mkdirSync(other);
 rmSync(path,{recursive:true,force:true});symlinkSync(other,path);
 assert.throws(f.read,error=>['unsafe-directory','unsafe-file'].includes(error.reason));
});

test('a symlink in the trusted root ancestry is refused',t=>{
 const f=fixture(t),alias=join(f.home,'alias');symlinkSync(dirname(f.releasesRoot),alias);
 assert.throws(()=>observeSiteRelease({...tuple,releasesRoot:join(alias,'website-releases')}),error=>error.reason==='unsafe-directory');
});

for(const field of ['candidateManifestSha256','bindingSha256'])test(`foreign authority ${field} is refused`,t=>{
 const f=fixture(t),value=f.use('preview');value[field]='e'.repeat(64);f.write(`authority/${value.consumptionId}.json`,value);
 assert.throws(f.read,error=>error.reason==='authority-binding');
});

test('deployment without its matching authority binding does not fabricate provider success',t=>{
 const f=fixture(t);f.deployment('release');assert.throws(f.read,error=>error.reason==='deployment-authority-unavailable');
});

test('foreign receipt, baseline and provider identities are refused',t=>{
 const f=fixture(t);f.receipt('release');
 const path=join(f.receipts,'release.json'),value=JSON.parse(readFileSync(path));
 for(const [field,reason]of [['candidateManifestSha256','receipt-binding'],['bindingSha256','receipt-binding'],['productionBaselineManifestSha256','baseline-binding']]){
  f.write('release.json',{...value,[field]:'e'.repeat(64)});assert.throws(f.read,error=>error.reason===reason);
 }
 f.write('release.json',value);f.write('release.json.deployment.json',{phase:'release',candidateManifestSha256:tuple.candidateManifestSha256,provider:{...provider,versionId:'SECRET_VALUE'}});
 assert.throws(f.read,error=>error.reason==='provider-shape');
});

test('oversized and malformed files are refused without printing their contents',t=>{
 const f=fixture(t);writeFileSync(join(f.receipts,'baseline.json'),Buffer.alloc(2*1024*1024+1,65));
 assert.throws(f.read,error=>error.reason==='file-too-large');
 writeFileSync(join(f.receipts,'baseline.json'),'SECRET_BROKEN_JSON');assert.throws(f.read,error=>error.reason==='invalid-json');
});

test('CLI works with read-only filesystem permission and no child-process grant',t=>{
 const f=fixture(t);f.use('preview');const before=inventory(f.home);
 const script=resolve(dirname(fileURLToPath(import.meta.url)),'../scripts/observe-site-release.mjs');
 const result=spawnSync(process.execPath,['--permission',`--allow-fs-read=${f.home}`,`--allow-fs-read=${script}`,script,
  tuple.runId,tuple.runAttempt,tuple.revision,tuple.candidateManifestSha256,tuple.bindingSha256],
 {env:{HOME:f.home,PATH:dirname(process.execPath)},encoding:'utf8',timeout:10000});
 assert.equal(result.status,0,result.stderr);assert.equal(result.stderr,'');
 assert.equal(JSON.parse(result.stdout).effects.preview,'attempted-unreconciled');assert.deepEqual(inventory(f.home),before);
});

test('production receipt must retain its exact preview, rollback and provider witnesses',t=>{
 const f=fixture(t);f.receipt('release');const value=JSON.parse(readFileSync(join(f.receipts,'release.json')));
 f.write('release.json',{...value,previewReceiptSha256:'e'.repeat(64)});assert.throws(f.read,error=>error.reason==='preview-binding');
 f.write('release.json',{...value,rollback:{priorVersionId:'33333333-3333-3333-3333-333333333333'}});assert.throws(f.read,error=>error.reason==='rollback-binding');
 f.write('release.json',value);
 f.write('release.json.deployment.json',{phase:'release',candidateManifestSha256:tuple.candidateManifestSha256,provider:{...provider,versionId:'33333333-3333-3333-3333-333333333333'}});
 assert.throws(f.read,error=>error.reason==='provider-conflict');
});


for(const phase of ['preview','release'])test(`signed-grant ${phase} receipt uses the genuine prefixed consumption identity`,t=>{
 const f=fixture(t);f.receipt(phase);
 const receipt=JSON.parse(readFileSync(join(f.receipts,`${phase}.json`)));
 const oldPath=receipt.authorityUsePath,use=JSON.parse(readFileSync(oldPath));
 const grantId='genuine-grant-id-1234',consumptionId=`grant-${grantId}`;
 rmSync(oldPath);use.consumptionId=consumptionId;f.write(`authority/${consumptionId}.json`,use);
 receipt.grantId=grantId;receipt.authorityUsePath=join(f.authority,`${consumptionId}.json`);
 f.write(`${phase}.json`,receipt);const before=inventory(f.home),result=f.read();
 assert.equal(result.effects[phase==='preview'?'preview':'production'],'public-verification-report-retained');
 assert.deepEqual(inventory(f.home),before);assert.equal(JSON.stringify(result).includes(grantId),false);
 f.write(`${phase}.json`,{...receipt,grantId:consumptionId});
 assert.throws(f.read,error=>error.reason==='receipt-authority-binding');
});
