import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { isPendingExactEditorialRepair } from "../src/news-line/throughput-feedback.mjs";

const eligible = (changes = {}) => ({
  state: "returned", reason: "submit_revision_request", revision: 0,
  revisedAs: null, revisionRefused: null, ...changes
});

test("independently returned exact repairs remain executable without writer capacity", () => {
  assert.equal(isPendingExactEditorialRepair(eligible()), true);
  assert.equal(isPendingExactEditorialRepair(eligible({ revision: 1 })), true);
  for(const revision of [2,3,100]) assert.equal(isPendingExactEditorialRepair(eligible({revision})), true);
});

test("source failure, acceptance, invalid lineage and used repairs are not revival authority", () => {
  for (const row of [
    null, {}, eligible({state:"refused"}), eligible({state:"released"}),
    eligible({reason:"no-sources"}), eligible({reason:"submit_editorial_refusal"}),
    eligible({revisedAs:"ni:///sha-256;already-held"}),
    eligible({revisionRefused:"unsupported-repair"}),
    eligible({revision:-1}), eligible({revision:Infinity}),
  ]) assert.equal(isPendingExactEditorialRepair(row), false, JSON.stringify(row));
});

test("writer admission refusal executes existing-only stage and never calls unadmitted inference", () => {
  const runner = readFileSync(new URL("../src/news-line.mjs", import.meta.url), "utf8");
  const stage = readFileSync(new URL("../src/news-line/stages.mjs", import.meta.url), "utf8");
  const selection = readFileSync(new URL("../src/news-line/selection.mjs", import.meta.url), "utf8");
  assert.match(runner, /for \(const stage of \['analyze', 'draft'\]\)/u);
  assert.match(runner, /executeWithoutWriter\(stage, execute, input, error\)/u);
  assert.match(selection, /stage === 'analyze' \? \{ acquisitionOnly: true \} : \{ existingOnly: true \}/u);
  assert.match(runner, /offer\('draft', held\.filter\(isPendingExactEditorialRepair\)/u);
  assert.match(stage, /const drafted = existingOnly\s*\? \{ writingAttempts: 0, candidates: \[\], refusals: \[\] \}\s*: await newsroomDayDraft/u);
  assert.match(stage, /executeReturnedRevisions\(context, at\)/u);
  assert.match(stage, /openEdition\(roots, \{ candidateId: candidate\.id/u);
});

test("a blank inference market cannot be treated as a fully completed fresh-news cycle", () => {
  const runner = readFileSync(new URL("../src/news-line.mjs", import.meta.url), "utf8");
  const selection = readFileSync(new URL("../src/news-line/selection.mjs", import.meta.url), "utf8");
  assert.match(selection, /status: 'blocked', code: 'inference-obstructed', phase: 'writer-admission'/u);
  assert.match(runner, /selectKoiosWork\(selectionSnapshot\(context\)/u);
  const stage = readFileSync(new URL("../src/news-line/stages.mjs", import.meta.url), "utf8");
  assert.match(stage, /return editions\(roots, "returned"\)\.filter\(isPendingExactEditorialRepair\)/u);
});
