import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {defineServiceLine,runServiceLineTurn,serviceLineEvents,serviceLineStatus} from '@red-cup-engineering/organizing/work/service-line';
test('Recorded newsroom outcomes retain lineage, retry blocked stages and advance only after completion',async()=>{
 const dataRoot=mkdtempSync(join(tmpdir(),'koios-turns-'));
 const line=defineServiceLine({service:'koios-transition-assay',stages:['report','assess'],subjectField:'edition'});
 let refused=true;
 const now=()=> '2026-10-07T12:00:00.000Z';
 const handlers={report:async()=>({status:'complete'}),assess:async()=>refused?{status:'blocked',code:'evidence-missing'}:{status:'complete'}};
 try{
  const report=await runServiceLineTurn(line,{dataRoot,handlers,now});
  const blocked=await runServiceLineTurn(line,{dataRoot,handlers,now});
  assert.equal(serviceLineStatus(line,dataRoot).next,'assess');
  assert.equal(blocked.event.content.knowledge.prior,report.event.id);
  assert.equal(blocked.event.content.execute.repairRequest.status,'open');
  refused=false;
  const accepted=await runServiceLineTurn(line,{dataRoot,handlers,now});
  assert.equal(accepted.event.content.knowledge.prior,blocked.event.id);
  assert.equal(accepted.status.cycle,2);assert.equal(accepted.status.next,'report');assert.deepEqual(accepted.status.blockers,[]);
  assert.deepEqual(serviceLineEvents(line,dataRoot).map(x=>x.content.status),['complete','blocked','complete']);
 }finally{rmSync(dataRoot,{recursive:true,force:true});}
});

test('Ready publication can execute while reporting is blocked without erasing its unresolved work',async()=>{
 const dataRoot=mkdtempSync(join(tmpdir(),'koios-publication-priority-'));
 const line=defineServiceLine({service:'koios-ready-publication-assay',stages:['report','release'],subjectField:'edition'});
 const now=()=> '2026-10-07T12:00:00.000Z';
 const calls=[],handlers={report:async()=>{calls.push('report');return {status:'blocked',code:'sources-waiting'};},release:async()=>{calls.push('release');return {status:'complete',released:1};}};
 try{
  const blocked=await runServiceLineTurn(line,{dataRoot,handlers,now});
  const released=await runServiceLineTurn(line,{dataRoot,handlers,now,selectedStage:'release'});
  assert.deepEqual(calls,['report','release']);assert.equal(released.event.content.execute.released,1);
  assert.equal(released.event.content.knowledge.prior,blocked.event.id);
  assert.equal(released.status.next,'report');assert.equal(released.status.blockers[0].stage,'report');
  await assert.rejects(runServiceLineTurn(line,{dataRoot,handlers,now,selectedStage:'invented'}),/admitted service-line stage/);
 }finally{rmSync(dataRoot,{recursive:true,force:true});}
});
