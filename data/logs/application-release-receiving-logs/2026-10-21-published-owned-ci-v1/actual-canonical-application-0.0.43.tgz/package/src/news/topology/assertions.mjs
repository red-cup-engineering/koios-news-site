/**
 * assertions — the claim carrier's relationship to told evidence
 * — the round-trip between editorial WRITE requests, a flat ASSERTION
 * TRACE of told cells, and the per-subject CLAIM SETS folded back out of it.
 *
 * This is content-domain, not agency: it is the news carrier's own
 * (de)serialization over SignCell evidence and the content domain's
 * OWN JsonValue — it borrows nothing from the agent fleet. (It was harvested
 * out of services/newsroom, which had only agent's JsonLike to hand; here it
 * sits where it belongs, below both the newsroom fiber and the wire surfaces.)
 *
 * A WRITE is `{ subject, claims, citation }`. An ASSERTION is the told cell
 * `{ e (entity/subject), a (attribute = predicate+object), v (evidence),
 * t (transaction) }`; a gate object of "fail" is asserted as a DENIAL, every
 * other claim as a witnessed potential. Folding a trace groups assertions by
 * subject and partitions the cells by the reading of their evidence into a
 * NewsClaimSet's potential/active/stable.
 */

import { evidence, knowledgeReading } from "@red-cup-engineering/signcell/cell";
import { canonical } from "@red-cup-engineering/json-services-section";

import { GATE_FAIL } from "./index.mjs";

/** A claim cell: entity, attribute (predicate + object), its told evidence (its
 * witnesses), and the transaction it was asserted in. */

/** The input to a single claim assertion. */

/** Options for folding writes into a trace: the transaction stamped on every
 * assertion (the caller owns the clock). */

const affirmed = (witness) => evidence({ for: [witness] });
const denied = (witness) => evidence({ against: [witness] });

/** Coerce a value to the content domain's JsonValue, rejecting non-JSON
 * shapes; `undefined` object fields are dropped. */
export function toJsonValue(value, path = "value") {
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new TypeError(`${path} must be a finite number`);
    return value;
  }
  if (Array.isArray(value)) return Object.freeze(value.map((item, index) => toJsonValue(item, `${path}[${index}]`)));
  if (typeof value === "object") {
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) throw new TypeError(`${path} must be JSON-like`);
    const out = {};
    for (const [key, item] of Object.entries(value)) {
      if (item === undefined) continue;
      out[key] = toJsonValue(item, `${path}.${key}`);
    }
    return Object.freeze(out);
  }
  throw new TypeError(`${path} must be JSON-like`);
}

/** A write request against a subject's claims. */
export function write(subject, claims, citation) {
  return Object.freeze({ subject, claims: Object.freeze({ ...claims }), citation });
}

/** A gate-clearing write: the gate predicate carries pass/fail under the
 * subject, cited to the desk that ruled it. */
export function clearGate(subject, gate, pass = true, citation = `news:${gate}`) {
  return write(subject, { [gate]: pass ? "pass" : GATE_FAIL }, citation);
}

/** A stable, order-independent key for a JSON value (object keys sorted). */
export function stableJsonKey(value) {
  return canonical(value);
}

/** The deterministic id of an assertion: a stable key over its entity,
 * attribute, transaction, and the reading of its evidence. */
export function traceEntryId(entry) {
  return `assertion:${stableJsonKey({ e: entry.e, a: entry.a, t: (entry.t ?? null)             , v: knowledgeReading(entry.v) })}`;
}

/** One claim asserted: a witnessed potential, or a denial when the object is a
 * gate fail. */
export function assertionFromClaim(claim) {
  const object = toJsonValue(claim.object, `${claim.subject}.${claim.predicate}`);
  return Object.freeze({
    e: toJsonValue(claim.subject, "subject"),
    a: Object.freeze({ predicate: toJsonValue(claim.predicate, "predicate"), object }),
    v: object === GATE_FAIL ? denied(claim.citation) : affirmed(claim.citation),
    t: claim.transaction,
  });
}

/** Fold a list of writes into an assertion trace, one assertion per defined
 * claim, each stamped with the transaction. */
export function assertionsFromWrites(writes, options) {
  const transaction = toJsonValue(options.transaction, "transaction");
  const assertions = [];
  for (const request of writes) {
    for (const [predicate, object] of Object.entries(request.claims)) {
      if (object === undefined) continue;
      assertions.push(assertionFromClaim({ subject: request.subject, predicate, object, citation: request.citation, transaction }));
    }
  }
  return Object.freeze(assertions);
}

function newsSubject(value) {
  return typeof value === "string" ? value : stableJsonKey(value);
}

function newsPredicate(value) {
  if (typeof value === "string") return value;
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const record = value;
    if (typeof record.mark === "string" && record.mark.trim()) return record.mark;
    if (typeof record.predicate === "string" && record.predicate.trim()) return record.predicate;
  }
  return null;
}

function newsObject(attribute, fallback) {
  if (attribute && typeof attribute === "object" && !Array.isArray(attribute)) {
    const record = attribute;
    if (record.object !== undefined) return record.object;
  }
  return fallback;
}

function newsClaimFromTraceEntry(entry) {
  const predicate = newsPredicate(entry.a);
  if (predicate === null) return null;
  return {
    subject: newsSubject(entry.e),
    claim: Object.freeze({
      predicate,
      object: newsObject(entry.a, entry.t),
      citation: traceEntryId(entry),
      claimedBy: Object.freeze(entry.v.evidence[0].map(String)),
      contraryClaimedBy: Object.freeze(entry.v.evidence[1].map(String)),
    }),
  };
}

/** Fold an assertion trace back into per-subject claim sets: assertions group
 * by subject and partition by the reading of their evidence into potential/active/
 * stable cells. */
export function claimSetsFromTrace(trace) {
  const grouped = new Map ();
  for (const entry of trace) {
    const mapped = newsClaimFromTraceEntry(entry);
    if (!mapped) continue;
    const bucket = grouped.get(mapped.subject) ?? { potential: [], active: [], stable: [] };
    if (entry.t !== undefined) bucket.t = entry.t;
    const reading = knowledgeReading(entry.v);
    if (reading === "stable") bucket.stable.push(mapped.claim);
    else if (reading === "potential") bucket.potential.push(mapped.claim);
    else if (reading === "active") bucket.active.push(mapped.claim);
    grouped.set(mapped.subject, bucket);
  }
  return Object.freeze([...grouped.entries()].map(([subject, bucket]) => Object.freeze({
    subject,
    potential: Object.freeze(bucket.potential),
    active: Object.freeze(bucket.active),
    stable: Object.freeze(bucket.stable),
    ...(bucket.t === undefined ? {} : { t: bucket.t }),
  })));
}
