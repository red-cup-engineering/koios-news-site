import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {lineRoots,openEdition,editions} from '../src/news-line/editions.mjs';
import {receivePublicEditions} from '../src/news-line/stages.mjs';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import {readPublicEditionEvidence} from '../src/news-line/public-receiving.mjs';

const projectedSha256 = 'sha256:' + 'a'.repeat(64);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const articleUrl = 'https://koios.news/posts/fixture-story/';
const fingerprint = {kind: 'producing-content.article-fingerprint', sha256: 'b'.repeat(64),
  facts: {kind: 'producing-content.article-fingerprint.facts', slug: 'fixture-story',
    url: articleUrl.slice(0, -1), sourceSha256: 'a'.repeat(64)}};
const fingerprintBytes = Buffer.from(JSON.stringify(fingerprint) + '\n');
const articleBytes = Buffer.from('<!doctype html><html><body>Exact article.</body></html>\n');
const artifact = (file, bytes) => ({file, sha256: digest(bytes), bytes: bytes.length});
const manifest = {kind: 'news-property.build-manifest/v1', provenance: {origin: 'https://koios.news'},
  routes: [{url: articleUrl, hash: digest(articleBytes)}],
  artifacts: [artifact('fingerprints/fixture-story.json', fingerprintBytes), artifact('posts/fixture-story/index.html', articleBytes)]};
const manifestBytes = Buffer.from(JSON.stringify(manifest) + '\n');
const input = signal => ({slug: 'fixture-story', projectedSha256, signal});
function mockedFetch(t, implementation) {
  const original = globalThis.fetch;
  globalThis.fetch = implementation;
  t.after(() => {globalThis.fetch = original;});
}

test('exact source receiving joins fingerprint, manifest and article with one deadline signal', async t => {
  const controller = new AbortController(), requests = [];
  mockedFetch(t, async (url, options) => {
    requests.push(url); assert.equal(options.signal, controller.signal);
    assert.equal(options.headers['cache-control'], 'no-cache');
    assert.equal(options.redirect, 'error');
    return new Response([fingerprintBytes, manifestBytes, articleBytes][requests.length - 1]);
  });
  const result = await readPublicEditionEvidence(input(controller.signal));
  assert.deepEqual(result.fingerprint, fingerprint);
  assert.deepEqual(result.manifestBytes, manifestBytes);
  assert.deepEqual(result.article, {...manifest.artifacts[1], url: articleUrl});
  assert.deepEqual(requests, ['https://koios.news/fingerprints/fixture-story.json', 'https://koios.news/manifest.json', articleUrl]);
});

test('mismatched source and failed fingerprint never request a manifest', async t => {
  let reads = 0;
  mockedFetch(t, async () => {reads++; return new Response(JSON.stringify({...fingerprint, facts: {...fingerprint.facts, sourceSha256: 'b'.repeat(64)}}));});
  assert.equal(await readPublicEditionEvidence(input(new AbortController().signal)), null);
  assert.equal(reads, 1);
  globalThis.fetch = async () => new Response('unavailable', {status: 503});
  assert.equal(await readPublicEditionEvidence(input(new AbortController().signal)), null);
});

for (const [name, change] of [
  ['wrong manifest kind', value => {value.kind = 'other';}],
  ['wrong origin', value => {value.provenance.origin = 'https://another.example';}],
  ['absent fingerprint', value => {value.artifacts.shift();}],
  ['duplicate fingerprint', value => {value.artifacts.push({...value.artifacts[0]});}],
  ['unbound fingerprint bytes', value => {value.artifacts[0].sha256 = 'c'.repeat(64);}],
  ['wrong fingerprint byte count', value => {value.artifacts[0].bytes++;}],
  ['absent article', value => {value.artifacts.pop();}],
  ['duplicate article', value => {value.artifacts.push({...value.artifacts[1]});}],
  ['article path alias', value => {value.artifacts[1].file = 'posts/../fixture-story/index.html';}],
  ['malformed article digest', value => {value.artifacts[1].sha256 = 'not-a-digest';}],
  ['invalid article byte count', value => {value.artifacts[1].bytes = 1.5;}],
  ['oversized article declaration', value => {value.artifacts[1].bytes = 8 * 1024 * 1024 + 1;}],
  ['absent canonical route', value => {value.routes = [];}],
  ['duplicate canonical route', value => {value.routes.push({...value.routes[0]});}],
  ['foreign canonical route', value => {value.routes[0].url = 'https://another.example/posts/fixture-story/';}],
  ['wrong route hash', value => {value.routes[0].hash = 'c'.repeat(64);}],
]) {
  test(`receiving refuses ${name} before reading article bytes`, async t => {
    const value = structuredClone(manifest); change(value);
    let reads = 0;
    mockedFetch(t, async () => {
      reads++;
      assert.ok(reads <= 2, 'invalid bindings cannot license another read');
      return new Response(reads === 1 ? fingerprintBytes : JSON.stringify(value));
    });
    assert.equal(await readPublicEditionEvidence(input(new AbortController().signal)), null);
    assert.equal(reads, 2);
  });
}

for (const field of ['kind', 'sha256', 'slug', 'url']) {
  test(`fingerprint ${field} must identify this renderer and edition`, async t => {
    const value = structuredClone(fingerprint);
    if (field === 'kind' || field === 'sha256') value[field] = 'other';
    else value.facts[field] = 'other';
    let reads = 0;
    mockedFetch(t, async () => {reads++; return new Response(JSON.stringify(value));});
    assert.equal(await readPublicEditionEvidence(input(new AbortController().signal)), null);
    assert.equal(reads, 1);
  });
}

for (const slug of ['../fixture-story', 'fixture-story?outside=yes', 'fixture/story']) {
  test(`unsafe edition coordinate refuses without network: ${slug}`, async t => {
    mockedFetch(t, async () => assert.fail('no network for invalid edition coordinate'));
    await assert.rejects(readPublicEditionEvidence({...input(new AbortController().signal), slug}), /exact edition slug/);
  });
}

for (const defect of ['missing', 'partial', 'short', 'same-length-wrong-hash']) {
  test(`valid source bindings do not receive ${defect} article bytes`, async t => {
    let reads = 0;
    mockedFetch(t, async () => {
      reads++;
      if (reads === 1) return new Response(fingerprintBytes);
      if (reads === 2) return new Response(manifestBytes);
      return new Response(defect === 'short' ? 'short' : defect === 'same-length-wrong-hash'
        ? Buffer.alloc(articleBytes.length, 120) : articleBytes,
      {status: defect === 'missing' ? 404 : defect === 'partial' ? 206 : 200});
    });
    assert.equal(await readPublicEditionEvidence(input(new AbortController().signal)), null);
    assert.equal(reads, 3);
  });
}

for (const stalledAt of ['headers', 'fingerprint body', 'manifest body', 'article headers', 'article body']) {
  test(`terminal deadline and cancellation survive a client ignoring the signal at ${stalledAt}`, async t => {
    const controller = new AbortController(), reason = new Error('fixture deadline');
    let reads = 0, cancelled = 0, entered;
    const started = new Promise(resolve => {entered = resolve;});
    mockedFetch(t, async () => {
      reads++;
      if (stalledAt === 'headers') {entered(); return new Promise(() => {});}
      if ((stalledAt === 'manifest body' || stalledAt.startsWith('article ')) && reads === 1) return new Response(fingerprintBytes);
      if (stalledAt.startsWith('article ') && reads === 2) return new Response(manifestBytes);
      if (stalledAt === 'article headers') {entered(); return new Promise(() => {});}
      return new Response(new ReadableStream({start() {entered();}, cancel() {cancelled++;}}));
    });
    const pending = readPublicEditionEvidence(input(controller.signal));
    await started; controller.abort(reason);
    await assert.rejects(pending, error => error === reason);
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(reads, stalledAt.startsWith('article ') ? 3 : stalledAt === 'manifest body' ? 2 : 1);
    if (!stalledAt.endsWith('headers')) assert.equal(cancelled, 1);
  });
}

for (const lateResponse of [1, 3]) {
test(`late successful response ${lateResponse} after cancellation cannot continue receiving`, async t => {
  const controller = new AbortController(), reason = new Error('fixture deadline');
  let resolveFetch, reads = 0, entered;
  const started = new Promise(resolve => {entered = resolve;});
  mockedFetch(t, () => {
    reads++;
    if (reads < lateResponse) return Promise.resolve(new Response([fingerprintBytes, manifestBytes][reads - 1]));
    entered(); return new Promise(resolve => {resolveFetch = resolve;});
  });
  const pending = readPublicEditionEvidence(input(controller.signal));
  await started;
  controller.abort(reason);
  await assert.rejects(pending, error => error === reason);
  resolveFetch(new Response(lateResponse === 1 ? fingerprintBytes : articleBytes));
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(reads, lateResponse);
});
}

for (const changedResponse of [1, 2, 3]) {
  test(`changed response URL ${changedResponse} cannot supply this edition's evidence`, async t => {
    let reads = 0;
    mockedFetch(t, async () => {
      const response = new Response([fingerprintBytes, manifestBytes, articleBytes][reads++]);
      if (reads === changedResponse) Object.defineProperty(response, 'url', {value: 'https://another.example/'});
      return response;
    });
    assert.equal(await readPublicEditionEvidence(input(new AbortController().signal)), null);
    assert.equal(reads, changedResponse);
  });
}

for (const body of ['fingerprint', 'manifest', 'article']) {
  for (const declared of [false, true]) {
    test(`oversized ${body} is rejected with ${declared ? 'declared' : 'streamed'} length`, async t => {
      let requests = 0, cancelled = 0;
      const maximum = body === 'fingerprint' ? 64 * 1024 : body === 'manifest' ? 8 * 1024 * 1024 : articleBytes.length;
      mockedFetch(t, async () => {
        requests++;
        if (body !== 'fingerprint' && requests === 1) return new Response(fingerprintBytes);
        if (body === 'article' && requests === 2) return new Response(manifestBytes);
        return new Response(new ReadableStream({start(controller) {if (!declared) controller.enqueue(new Uint8Array(maximum + 1));}, cancel() {cancelled++;}}), {headers: declared ? {'content-length': String(maximum + 1)} : {}});
      });
      await assert.rejects(readPublicEditionEvidence(input(new AbortController().signal)), /byte budget/);
      assert.equal(cancelled, 1);
      assert.equal(requests, body === 'fingerprint' ? 1 : body === 'manifest' ? 2 : 3);
    });
  }
}

for (const phase of ['headers', 'body']) {
  test(`genuine Node fetch terminates a local HTTP ${phase} stall`, async t => {
    const originalFetch = globalThis.fetch, controller = new AbortController();
    let entered;
    const started = new Promise(resolve => {entered = resolve;});
    const server = createServer((request, response) => {
      if (phase === 'body') {response.writeHead(200, {'content-type': 'application/json'}); response.write('{');}
      else entered();
    });
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    t.after(() => {server.closeAllConnections(); server.close();});
    mockedFetch(t, async (url, options) => {
      const response = await originalFetch(`http://127.0.0.1:${server.address().port}${new URL(url).pathname}`, options);
      // The fixture changes only the transport coordinate. Keep the genuine
      // Node response stream while presenting the public URL being received.
      Object.defineProperty(response, 'url', {value: url});
      if (phase === 'body') {
        const getReader = response.body.getReader.bind(response.body);
        response.body.getReader = (...args) => {
          const reader = getReader(...args), read = reader.read.bind(reader);
          let reads = 0;
          reader.read = (...readArgs) => {
            const pending = read(...readArgs);
            // The first read consumes the server's opening byte. The second
            // is genuinely waiting on the body the server never completes.
            if (++reads === 2) entered();
            return pending;
          };
          return reader;
        };
      }
      return response;
    });
    const pending = readPublicEditionEvidence(input(controller.signal));
    await started; controller.abort(new Error('fixture deadline'));
    await assert.rejects(pending, /fixture deadline/);
  });
}

test('the actual receiver shares the caller deadline, leaves custody pending and stops the batch', {timeout:500},async t=>{
  const directory=mkdtempSync(join(tmpdir(),'koios-receiving-budget-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
  const roots=lineRoots(directory);
  for(const candidateId of ['one','two'])openEdition(roots,{candidateId,slug:'fixture-story',state:'rendered',draftedAt:'2026-10-18T00:00:00Z'});
  const controller=new AbortController();let custodyReads=0,entered;
  const started=new Promise(resolve=>{entered=resolve;});
  mockedFetch(t,async(url,options)=>{assert.equal(options.signal,controller.signal);entered();return new Promise(()=>{});});
  const pending=receivePublicEditions({roots},{signal:controller.signal,
    readBinding:()=>{custodyReads++;return {slug:'fixture-story',projectedSha256,receiptSha256:'receipt'};}});
  await started;controller.abort(new Error('fixture deadline'));
  const result=await pending;
  assert.equal(result.released,0);assert.equal(custodyReads,1);
  assert.ok(editions(roots).every(edition=>edition.state==='rendered'));
});
