// Test transport/process boundaries only. The release script and carrier are real.
// No public request, listener, Wrangler process, or replacement verifier is used.
import childProcess from 'node:child_process';
import {appendFileSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {syncBuiltinESMExports} from 'node:module';

const root=process.cwd();
const fixture=JSON.parse(readFileSync(join(root,'transport.json'),'utf8'));
const record=value=>appendFileSync(join(root,'calls.jsonl'),`${JSON.stringify(value)}\n`);
// The transport is synthetic; accelerate only its JavaScript retry backoff.
const realSetTimeout=globalThis.setTimeout;
globalThis.setTimeout=(fn,ms,...args)=>realSetTimeout(fn,Math.min(ms,5),...args);
let baselineAttempts=0;

// Fail closed before any provider command, including preview cleanup, can spawn.
for(const name of ['spawnSync','spawn','execFileSync','execFile','execSync','exec','fork']){
 childProcess[name]=(...args)=>{
  record({kind:'forbidden-process',name,program:String(args[0])});
  throw new Error(`release-site fixture refuses child_process.${name}`);
 };
}
syncBuiltinESMExports();

globalThis.fetch=async(input,options={})=>{
 const url=new URL(String(input));
 const baseline=options.headers?.['cache-control']==='no-cache';
 if(baseline)baselineAttempts++;
 record({kind:'fetch',url:url.href,redirect:options.redirect??null,baseline});
 if(baseline&&fixture.scenario==='baseline-header-retry'&&baselineAttempts===1)throw new DOMException('synthetic header timeout','TimeoutError');
 if(!baseline&&fixture.scenario==='audit-timeout'&&url.pathname===fixture.missingPath)throw new DOMException('synthetic audit timeout','TimeoutError');
 if(url.origin!=='https://koios.news'||url.username||url.password||url.search||url.hash){
  throw new Error(`release-site fixture refuses URL ${url.href}`);
 }
 let status=200,body,location;
 if(url.pathname===fixture.missingPath){
  status=fixture.scenario==='wrong-404-status'?200:404;
  body=Buffer.from(fixture.assets['404.html'],'base64');
  if(fixture.scenario==='wrong-404-body')body=Buffer.from('synthetic incorrect 404');
 }else if(url.pathname==='/old'){
  if(options.redirect!=='manual')throw new Error('redirect probe must be manual');
  status=301;body=Buffer.alloc(0);
  location=fixture.scenario==='wrong-redirect'?'/wrong/':'/posts/example/';
 }else{
  const file=url.pathname==='/'?'index.html'
   :url.pathname==='/404'?'404.html'
   :url.pathname==='/posts/example/'?'posts/example/index.html'
   :url.pathname==='/manifest.json'?'manifest.json'
   :url.pathname==='/robots.txt'?'robots.txt':undefined;
  if(file===undefined)throw new Error(`release-site fixture refuses unknown route ${url.pathname}`);
  body=Buffer.from(file==='manifest.json'?fixture.manifest:fixture.assets[file],'base64');
  if(file==='robots.txt')body=Buffer.from('User-agent: *\n# synthetic provider-managed observation\n');
  if(file==='posts/example/index.html'&&fixture.scenario==='corrupt-article'){
   body=Buffer.from(body);body[body.length-1]^=1;
  }
 }
 const headers={'content-length':String(body.length)};
 if(location!==undefined)headers.location=location;
 const response=new Response(body,{status,headers});
 Object.defineProperty(response,'url',{value:url.href});
 if(baseline&&(fixture.scenario==='baseline-body-exhausted'||fixture.scenario==='baseline-body-retry'&&baselineAttempts===1)){
  response.arrayBuffer=async()=>{record({kind:'body-timeout',attempt:baselineAttempts});throw new DOMException('synthetic body timeout','TimeoutError');};
 }
 return response;
};
