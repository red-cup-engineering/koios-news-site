import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {setTimeout as pause} from 'node:timers/promises';
import {withEditorialLock} from '../src/news-line/execution-lock.mjs';
test('Cloud reporting waits for a mutation and can proceed at its next stage boundary',async()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-lock-')),context={roots:{root}},order=[];
 let entered,release;
 const firstEntered=new Promise(resolve=>entered=resolve),continueFirst=new Promise(resolve=>release=resolve);
 try{
 const first=withEditorialLock(context,async()=>{order.push('stage-start');entered();await continueFirst;order.push('stage-end');});
 await firstEntered;
 const report=withEditorialLock(context,async()=>{order.push('report');});
 await pause(30);assert.deepEqual(order,['stage-start']);
 release();await Promise.all([first,report]);
 assert.deepEqual(order,['stage-start','stage-end','report']);
 }finally{release?.();rmSync(root,{recursive:true,force:true});}
});
