/**
 * One Koios newsroom pulse, composed from its two owners: the source broker takes the wires'
 * fresh arrivals (its cursor skips what earlier pulses took), and FeltOS Content Mill
 * analyzes them into selected stories, bought claim extractions and one pulse settlement.
 */
import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { admitSetOfFeedArrivals, loadCursor, normalizeFeedList, saveCursor } from "@red-cup-engineering/communicating/messaging/newswire/feed-arrivals";
import { defaultDataRoot, newsroomDayAnalyze } from "@red-cup-engineering/content-mill-newsroom-services-section";
import { newsroomDayDraft } from "@red-cup-engineering/content-mill-newsroom-services-section/manuscript";
import { purchaseClaimExtraction } from "@red-cup-engineering/content-mill-newsroom-services-section/claims";
import { acquirePublicWebSources } from "@causeway-services/web-source-acquisition/acquire";
import { resolveSectionWires } from "@red-cup-engineering/content-mill-newsroom-services-section/intake";
import { dispatchInferenceAsConfiguredCustomer } from "@red-cup-engineering/computer-inference-engine/dispatch/inference-dispatch";
import {declaredPropertyInputs} from '@causeway-services/koios-news-site/build';

export async function newsroomDay({ maxStories = 10, maxSourcesPerStory, environment = process.env } = {}) {
  const propertyPath = environment.KOIOS_NEWS_PROPERTY;
  if (!propertyPath) throw new TypeError("koios-newsroom-day: KOIOS_NEWS_PROPERTY must name the property record");
  const property = JSON.parse(readFileSync(resolve(propertyPath), "utf8"));
  const dataRoot = resolve(environment.KOIOS_NEWSROOM_DATA_ROOT ?? defaultDataRoot(property.name));
  const houseFeedsPath = environment.KOIOS_NEWS_HOUSE_FEEDS
    ?? declaredPropertyInputs(property,dirname(resolve(propertyPath)),{environment}).sourceFeedsPath;
  if (!houseFeedsPath) {
    throw new TypeError("koios-newsroom-day: property.content.sourceFeeds must name the feed directory");
  }
  const houseFeeds = new Map(normalizeFeedList(JSON.parse(readFileSync(houseFeedsPath, "utf8"))).map((feed) => [feed.id, feed]));
  const { feeds } = resolveSectionWires(property, houseFeeds);
  const cursorPath = join(dataRoot, "state", "feed-arrivals-cursor.json");
  const dispatch = (request, options) => dispatchInferenceAsConfiguredCustomer(request, { ...options, environment });
  const { events, cursor } = await admitSetOfFeedArrivals({ feeds, cursor: loadCursor(cursorPath) });
  const summary = await newsroomDayAnalyze({
    property,
    customerActor: property.inference?.customerActor,
    dataRoot,
    maxStories,
    ...(maxSourcesPerStory === undefined ? {} : { maxSourcesPerStory }),
    houseFeedsPath,
    sourceArrivals: [...events],
    purchase: (lead, options) => purchaseClaimExtraction(lead, { ...options, dispatch }),
    acquireSource: async (lead, instant) => {
      const delivery = await acquirePublicWebSources({
        purpose: "journalistic-source-research", urls: [lead.url],
      }, instant);
      return delivery;
    },
    purchaseJournalRoot: environment.INFERENCE_PURCHASE_ROOT,
  });
  const draft = await newsroomDayDraft({
    property, dataRoot, maxCandidates: maxStories,
    dispatch,
    purchaseJournalRoot: environment.INFERENCE_PURCHASE_ROOT,
  });
  // The cursor advances after both Content Mill stages have settled.
  saveCursor(cursorPath, cursor);
  return { ...summary, draft };
}
