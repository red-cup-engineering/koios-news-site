#!/usr/bin/env node
/** Isolated demonstration using actual public observations; no release or payment. */
import assert from 'node:assert/strict';
import { mkdirSync, readFileSync, writeFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { parseArgs } from 'node:util';
import { readMarketPlay } from '@red-cup-engineering/mandate-portfolio-allocation-service/play';
import { createResearchPublication, researchObservationMoves } from '@red-cup-engineering/mandate-portfolio-allocation-service/research-publication';
import { marketGame } from '@red-cup-engineering/mandate-portfolio-allocation-service/market-game';
import { createRulePlayer, hashPosition } from '@red-cup-engineering/gaming/running/rules';
import { createPaidBriefing, publishCurrentPaidBriefing, admitCurrentPaidBriefing, readCurrentPaidBriefing } from '@causeway-services/koios-news-intelligence-briefing/paid-briefing';
import { admitMarketResearch, writeResearchWire } from '../src/market-research.mjs';
import { readNewsroom } from '../src/newsroom-records.mjs';
import { createNewswire, loadWireBundles } from '../src/news/cable/wire.mjs';
import { newsLineContext } from '../src/news-line/context.mjs';

const { values } = parseArgs({ options: Object.fromEntries(['record', 'assignment', 'directory'].map(k => [k, { type: 'string' }])) });
const root = values.directory; mkdirSync(root, { recursive: false, mode: 0o700 });
const meta = statSync(values.assignment); if (!meta.isFile() || meta.size > 1048576) throw new RangeError('bounded research assignment required');
const { state } = await readMarketPlay(values.record), at = new Date().toISOString();
const packet = createResearchPublication(state, JSON.parse(readFileSync(values.assignment, 'utf8')), at);
const context = newsLineContext({ environment: { ...process.env, KOIOS_NEWSROOM_DATA_ROOT: join(root, 'newsroom') } });
const admitted = admitMarketResearch({ packet, observations: state.observations, section: 'business-markets',
  property: context.property, dataRoot: context.dataRoot, at });
const wireDir = join(root, 'wire');
await writeResearchWire({ packet, storeDir: wireDir, resourceUrl: 'https://filum.561.group/market-research/' });
const wire = createNewswire({ name: packet.producer.wire, baseUrl: 'https://filum.561.group/market-research/', storeDir: wireDir,
  definition: { title: packet.title, description: packet.question } });
const [stored] = await loadWireBundles(wireDir);
const served = await wire.handle('/items/' + stored.subject + '.json');
assert.equal(served.status, 200);
assert.equal(JSON.parse(served.body).claims.find(claim => claim.id === 'research-packet').proposition.object.id, packet.id);
const sources = packet.observations.map(row => row.source);
const references = Object.fromEntries(sources.map(url => [url, { id: url, title: url, URL: url, type: 'webpage' }]));
const issue = { title: packet.title, dek: packet.question, sections: [{ heading: 'Demonstration of measured fields',
  'body-markdown': packet.facts.map(fact => fact.label + ': ' + fact.value + (fact.unit ? ' ' + fact.unit : '') + '.').join('\n\n'), sources }], references };
const briefing = createPaidBriefing({ issue, research: packet, issuedAt: at, id: 'demonstration:' + packet.id });
let current; const env = { KOIOS_INTELLIGENCE_BRIEFINGS: {
  put: async (_key, body) => { current = body; }, get: async () => ({ size: Buffer.byteLength(current), text: async () => current }),
} };
await publishCurrentPaidBriefing(briefing, env);
const query = {}; await admitCurrentPaidBriefing(query, env);
await publishCurrentPaidBriefing(createPaidBriefing({ issue, issuedAt: at, id: 'later-demonstration' }), env);
const delivered = await readCurrentPaidBriefing(query, env);
assert.equal(delivered.research.id, packet.id, 'concurrent current publication must not alter the admitted purchase');
const returned = researchObservationMoves(delivered, at), player = createRulePlayer(marketGame);
const record = returned.map((intent, seq) => { const row = { seq, intent, ts: Date.parse(at) }; player.replayEntry(row); return row; });
writeFileSync(join(root, 'returned-play.jsonl'), record.map(row => JSON.stringify(row)).join('\n') + '\n', { flag: 'wx' });
const replay = await readMarketPlay(join(root, 'returned-play.jsonl'));
assert.equal(hashPosition(replay.state), player.stateHash());
const tampered = structuredClone(packet); tampered.facts[0].value = 'altered';
assert.throws(() => researchObservationMoves(tampered, at), /content address/);
const claims = readNewsroom(context.dataRoot, 'claim');
assert.equal(claims.length, packet.facts.length);
assert.ok(claims.every(row => row.record.content.quote.includes(':')));
writeFileSync(join(root, 'research.json'), JSON.stringify(packet, null, 2) + '\n', { flag: 'wx' });
writeFileSync(join(root, 'paid-briefing-demonstration.json'), JSON.stringify(delivered, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ mode: 'isolated demonstration; no editorial acceptance, live release, payment or trading',
  ...admitted, wireStatus: served.status, samePacketAfterPublicationRace: true, returnedObservations: returned.length,
  replay: player.stateHash(), root }, null, 2));
