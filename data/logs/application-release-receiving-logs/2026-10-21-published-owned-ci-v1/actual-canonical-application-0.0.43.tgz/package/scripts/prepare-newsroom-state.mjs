#!/usr/bin/env node
// Receive the meaningful publication state into the current store generation.
// Earlier semantic journals stay in original custody; they cannot be opened
// by the new store or be treated as fresh reporting and active authority.
import {mkdirSync,readdirSync,lstatSync,readFileSync,writeFileSync,copyFileSync,existsSync,realpathSync} from 'node:fs';
import {join,resolve,dirname,relative} from 'node:path';
import {createHash} from 'node:crypto';
import {parsePost} from '@causeway-services/koios-news-site/build';

const [original,target,...extra]=process.argv.slice(2);
if(!original||!target||extra.length)throw new Error('Expected original newsroom root and new state directory');
const source=realpathSync(original),destination=resolve(target);
if(existsSync(destination)||destination===source||destination.startsWith(source+'/')||source.startsWith(destination+'/'))throw new Error('State receiving requires a separate new directory');
if(realpathSync(dirname(destination))!==dirname(destination))throw new Error('State parent must be an actual custody directory');
const selected=[];
function select(part){
 const path=join(source,part),stat=lstatSync(path);
 if(stat.isSymbolicLink())throw new Error('Publication custody cannot be a symlink');
 if(stat.isDirectory()){for(const name of readdirSync(path).sort())select(join(part,name));return;}
 if(!stat.isFile()||stat.size>32*1024*1024||selected.length>=20000)throw new Error('Publication custody exceeds its file bound');
 const bytes=readFileSync(path),sha256=createHash('sha256').update(bytes).digest('hex');
 selected.push({path:part,bytes:bytes.length,sha256});
}
select('line/publication-replay');
select('line/keys');
const published=readdirSync(join(source,'line/publication-replay/published'));
if(!published.length)throw new Error('Original published ledger is empty');
for(const name of published){
 if(!/^[a-z0-9]+(?:-[a-z0-9]+)*\.md$/.test(name))throw new Error('Unexpected published article');
 if(parsePost(readFileSync(join(source,'line/publication-replay/published',name),'utf8'),name).draft!==false)throw new Error('Published ledger contains an unpublished manuscript');
}
// Released identities keep stable URLs, dates and correction lineage. Returned
// work stays with its old evidence; it is neither silently lost nor requeued
// under a new store without fresh source and manuscript admission.
for(const name of readdirSync(join(source,'line/editions'))){
 if(!name.endsWith('.json'))continue;
 const record=JSON.parse(readFileSync(join(source,'line/editions',name),'utf8'));
 if(record.state==='released')select(join('line/editions',name));
}
mkdirSync(destination,{mode:0o700});
for(const entry of selected){
 const output=join(destination,entry.path);
 if(relative(destination,output).startsWith('..'))throw new Error('Invalid publication path');
 mkdirSync(dirname(output),{recursive:true,mode:0o700});
 copyFileSync(join(source,entry.path),output);
 for(const file of [join(source,entry.path),output])if(createHash('sha256').update(readFileSync(file)).digest('hex')!==entry.sha256)throw new Error('Publication state changed during receiving');
}
const receipt={kind:'koios.news.state-receiving/v1',originalRoot:source,stateRoot:destination,originalsPreserved:true,publishedArticles:published.length,files:selected,receivedAt:new Date().toISOString()};
writeFileSync(join(destination,'state-receiving.json'),JSON.stringify(receipt,null,2)+'\n',{mode:0o600,flag:'wx'});
console.log(JSON.stringify({stateRoot:destination,publishedArticles:published.length,files:selected.length,originalsPreserved:true}));
