import {resolveInferenceCashControl} from "@red-cup-engineering/computer-inference-engine/dispatch/inference-cash-control";
import {admitCloudflareFreeInvocation} from '@red-cup-engineering/computer-inference-engine/openai/cloudflare-free-tier-admission';
import {createHash} from 'node:crypto';
import {googleToken,googleJson} from '../scripts/google-client.mjs';
import {writeJsonAtomic} from './news-line/editions.mjs';
import {canonicalJson} from '@red-cup-engineering/json-services-section/canonical-json';
import {existsSync} from 'node:fs';
import {loadDirectEndpointProviderDescriptors,directEndpointAdmissionReasons,isDirectEndpointZeroCashEligible} from '@red-cup-engineering/computer-inference-engine/dispatch/direct-endpoint-provider';

const GOOGLE_GENERATIVE_ORIGIN='https://generativelanguage.googleapis.com';

// Google free-tier admission is account-state-dependent, so renew its
// credential-bound no-billing lease. Providers whose exact model is
// contractually zero-cash are admitted by the shared inference catalog and
// must not be forced through Google's account observer.
export function requiresPrivateAccountObservation(descriptor){
 try{return [GOOGLE_GENERATIVE_ORIGIN,'https://api.cloudflare.com'].includes(new URL(descriptor.endpoint).origin);}
 catch{return false;}
}

// Recover the existing account observer's useful effect: follow the actual
// credential's authoritative parent, then observe its billing attachment.
// A checked-in model description cannot renew this evidence.
export async function observeInferenceAccount(descriptor,{request,now=()=>Date.now(),environment=process.env}={}){
 if(new URL(descriptor.endpoint).origin==='https://api.cloudflare.com'){
  const admitted=await admitCloudflareFreeInvocation({endpoint:descriptor.endpoint,env:environment});
  const facts={type:'CloudflareFreeInferenceAccountObservation',accountIdentity:'accounts/'+admitted.account,observedAt:new Date(now()).toISOString(),billingEnabled:false,billingAccountBound:false,cashCost:admitted.cashCost,paidOverage:admitted.paidOverage};
  return {...facts,evidenceIdentity:'ni:///sha-256;'+createHash('sha256').update(canonicalJson(facts)).digest('base64url'),credentialSha256:createHash('sha256').update(descriptor.apiKey).digest('hex')};
 }
 if(!requiresPrivateAccountObservation(descriptor))throw new Error('Koios account observation requires its actual Google or Cloudflare endpoint');
 const key=descriptor.apiKey;
 if(!key)throw new Error('Koios Google provider credential is missing');
 if(!request){
  const token=await googleToken(['https://www.googleapis.com/auth/cloud-platform'],{keyFile:environment.GOOGLE_APPLICATION_CREDENTIALS});
  request=url=>googleJson(token,url);
 }
 try{
  const lookup=await request('https://apikeys.googleapis.com/v2/keys:lookupKey?keyString='+encodeURIComponent(key));
  if(!/^projects\/[1-9][0-9]*\/locations\/[A-Za-z0-9_-]+$/.test(lookup.parent??'')||!lookup.name)throw new Error('Google returned no live API key parent');
  const accountIdentity=lookup.parent.split('/').slice(0,2).join('/');
  const billing=await request(`https://cloudbilling.googleapis.com/v1/${accountIdentity}/billingInfo`);
  if(typeof billing.billingEnabled!=='boolean')throw new Error('Google returned no billing state');
  const facts={type:'GoogleApiKeyAccountObservation',accountIdentity,observedAt:new Date(now()).toISOString(),billingEnabled:billing.billingEnabled,billingAccountBound:typeof billing.billingAccountName==='string'&&billing.billingAccountName.length>0};
  return {...facts,evidenceIdentity:'ni:///sha-256;'+createHash('sha256').update(canonicalJson(facts)).digest('base64url'),credentialSha256:createHash('sha256').update(key).digest('hex')};
 }catch(e){throw new Error('Google inference account observation failed: '+e.message.replaceAll(key,'<redacted>').slice(0,500));}
}

/** A private Google lease cannot become a single point of failure for truly
 * independent, separately admitted zero-cash writers. Default refresh stays
 * strict; only a caller with an independently admitted provider may request a
 * partial observation. Failures are recorded by type, never by raw credential-
 * bearing provider error. An unobserved or billed Google lease is NOT carried
 * into the entitlement file, including when yesterday's lease was valid.
 */
export async function refreshInferenceAccounts(descriptors,destination,{observe=observeInferenceAccount,allowPartial=false}={}){
 if(!destination)throw new Error('Koios private account evidence destination is missing');
 const rows=[],refusals=[];
 for(const d of descriptors){
  if(!requiresPrivateAccountObservation(d))continue;
  let observation;
  try{observation=await observe(d);}
  catch(error){
   if(!allowPartial)throw error;
   refusals.push({provider:d.provider,model:d.model,reason:'private-account-observation-unavailable'});
   continue;
  }
  if(observation?.billingEnabled!==false||observation?.billingAccountBound!==false){
   if(!allowPartial)throw new Error('Inference billing is attached or not disproved; the newsroom requires zero cash and no paid overage');
   refusals.push({provider:d.provider,model:d.model,reason:'private-account-zero-cash-unverified'});
   continue;
  }
  const instant=Date.parse(observation.observedAt);
  if(!Number.isFinite(instant)){
   if(!allowPartial)throw new Error('Google inference account observation has no valid timestamp');
   refusals.push({provider:d.provider,model:d.model,reason:'private-account-observation-invalid'});
   continue;
  }
  rows.push({...observation,type:'ProviderAccountEntitlementObservation',providerIdentity:d.provider,endpoint:d.endpoint,model:d.model,validUntil:new Date(instant+3600000).toISOString(),cashCost:'zero',paidOverage:'forbidden'});
 }
 // Atomically replace stale account-specific entitlements; no earlier Google
 // lease survives a failed fresh reading, even when other providers can work.
 writeJsonAtomic(destination,rows);
 return allowPartial?{rows,refusals}:rows;
}

export function admittedZeroCashProviderRows(rows){
 if(!Array.isArray(rows))throw new TypeError('Koios inference provider rows must be an array');
 return rows.filter(row=>Array.isArray(row?.reasons)&&row.reasons.length===0);
}

export function assessZeroCashWriterFailover(rows,{minimum=2}={}){
 if(!Number.isSafeInteger(minimum)||minimum<1)throw new TypeError('minimum admitted writer providers must be a positive integer');
 const admitted=admittedZeroCashProviderRows(rows);
 const providerCount=new Set(admitted.map(row=>row.provider)).size;
 return {
  admitted,
  providerCount,
  minimum,
  ok:providerCount>=minimum,
  degraded:providerCount>0&&providerCount<minimum,
  unavailable:providerCount===0,
 };
}

export function requireZeroCashWriterFailover(rows,{minimum=2,allowDegraded=false}={}){
 const assessment=assessZeroCashWriterFailover(rows,{minimum});
 if(assessment.unavailable||(!allowDegraded&&!assessment.ok)){
  const requirement=allowDegraded?'at least 1 admitted zero-cash provider':'at least '+minimum+' admitted zero-cash providers';
  throw new Error(`Koios.News writer failover requires ${requirement}; found ${assessment.providerCount}`);
 }
 return assessment;
}

/** Consumer admission at the selected stage's effect boundary.
 * Read the shared provider's current credential-bound lease on every writer
 * turn. Renew private account evidence only when it is missing or no longer
 * admitted; a delivery-only startup check is never a writer capability.
 */
export async function requireNewsroomWriterAdmission(environment=process.env,{observe}={}){
 const zeroCashOnly=resolveInferenceCashControl(environment).cashCost==='zero';
 const destination=environment.DIRECT_ENDPOINT_ACCOUNT_ENTITLEMENTS;
 const options={configPath:environment.DIRECT_ENDPOINT_PROVIDER_CONFIG};
 const evidencePresent=Boolean(destination&&existsSync(destination));
 let descriptors=loadDirectEndpointProviderDescriptors(environment,{
  ...options,...(!evidencePresent?{accountEntitlements:[]}:{}),
 });
 if(!descriptors.length)throw new Error('The configured Koios provider did not resolve through its catalog');
 // The shared dispatcher reads a configured evidence path. Materialize its
 // empty observation set too; contract-free providers never call the private
 // account observer, but must not inherit a missing-file dispatch failure.
 let privateAccountRefusals=[];
 if((destination&&!evidencePresent)||descriptors.some(descriptor=>requiresPrivateAccountObservation(descriptor)&&!isDirectEndpointZeroCashEligible(descriptor))){
  // Free independent endpoints require no Google API-key billing probe. Their
  // live quota, credential and per-attempt admission are still checked by the
  // owning dispatcher. Only their actual admission licenses partial refresh.
  const allowPartial=descriptors.some(descriptor=>!requiresPrivateAccountObservation(descriptor)
   && directEndpointAdmissionReasons(descriptor,{zeroCashOnly}).length===0);
  const refresh=await refreshInferenceAccounts(descriptors,destination,{observe:observe??(descriptor=>observeInferenceAccount(descriptor,{environment})),allowPartial});
  privateAccountRefusals=allowPartial?refresh.refusals:[];
  descriptors=loadDirectEndpointProviderDescriptors(environment,options);
 }
 const rows=descriptors.map(descriptor=>({provider:descriptor.provider,model:descriptor.model,reasons:directEndpointAdmissionReasons(descriptor,{zeroCashOnly})}));
 const failover=requireZeroCashWriterFailover(rows,{minimum:2,allowDegraded:true});
 return {inferenceProviders:rows,writerFailover:{minimum:failover.minimum,admitted:failover.providerCount,admittedModels:failover.admitted.length,degraded:failover.degraded},
  ...(privateAccountRefusals.length?{privateAccountRefusals}:{})};
}
