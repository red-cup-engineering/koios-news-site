import {test} from 'node:test';
import assert from 'node:assert/strict';
import {articleQuality} from '../src/article-quality.mjs';
import {editorNotesOf,returnedWriterEditions} from '../src/news-line/criteria.mjs';

test('a structural refusal without an assessor delivery supplies the next writer order',()=>{
 const quality=articleQuality('## Development\n'+Array(684).fill('reported').join(' '),{claims:null,evidenceRequired:false});
 assert.equal(quality.ok,false);
 let reads=0;
 const notes=editorNotesOf([{storyId:'held-story',quality}],{read(){reads++;throw Error('No assessor was hired');}});
 assert.equal(reads,0);
 assert.equal(notes['held-story'].length,1);
 assert.match(notes['held-story'][0],/insufficient-reporting-depth/);
 assert.match(notes['held-story'][0],/"words":684/);
 assert.match(notes['held-story'][0],/commissioned editorialProduct/);
});

test('structural observations and independently selected repairs share one deduplicated order',()=>{
 const edition={storyId:'held-story',quality:{ok:false,failures:['missing-context-sections'],words:728,sections:1},deliveryPath:'held-delivery'};
 const notes=editorNotesOf([edition,edition],{read:()=>({object:{toolSelection:{requiredRepairs:['Explain the supported response.']}}})});
 assert.equal(notes['held-story'].length,2);
 assert.match(notes['held-story'][0],/missing-context-sections/);
 assert.equal(notes['held-story'][1],'Explain the supported response.');
});

test('an unreadable delivery cannot erase a held structural refusal or invent assessor instructions',()=>{
 const notes=editorNotesOf([{storyId:'held-story',quality:{ok:false,failures:['insufficient-reporting-depth'],words:667},deliveryPath:'unreadable'}],{read(){throw Error('Unavailable');}});
 assert.equal(notes['held-story'].length,1);
 assert.match(notes['held-story'][0],/"words":667/);
 assert.deepEqual(editorNotesOf([{storyId:'accepted',quality:{ok:true,failures:[]}}]),{});
});

test('historical editions cannot permanently suppress the next funded writer repair',()=>{
 const returned=Object.freeze({state:'returned',storyId:'same-story',candidateId:'latest-return',failureLayer:'writer-model',quality:{ok:false,failures:['insufficient-reporting-depth'],words:684}});
 for(const count of [0,2,3,100]){
  const history=Array.from({length:count},(_,i)=>Object.freeze({state:'released',storyId:'same-story',candidateId:'history-'+i}));
  const orders=returnedWriterEditions(Object.freeze([...history,returned]));
  assert.deepEqual(orders,[returned]);
  assert.match(editorNotesOf(orders)['same-story'][0],/"words":684/);
 }
});

test('writer reallocation preserves source-work and independent publication boundaries',()=>{
 const base={storyId:'same-story',candidateId:'return',state:'returned',failureLayer:'writer-model'};
 for(const change of [{state:'accepted'},{state:'queued'},{state:'released'},{state:'drafted'},{failureLayer:'sources'},{failureLayer:'assignment'},{revisedAs:'held-successor'}])
  assert.deepEqual(returnedWriterEditions([{...base,...change}]),[]);
 for(const failureLayer of ['writer-model','instructions','draft-repair'])assert.deepEqual(returnedWriterEditions([{...base,failureLayer}]),[{...base,failureLayer}]);
});
