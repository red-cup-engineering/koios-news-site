
import { ACTOR, digest, niSuffix, record } from "./boundary.mjs";
import { ACTIVITYSTREAMS_CONTEXT } from "@red-cup-engineering/activitypub-services-section/activitystreams";
import { admitSourceStatement } from "@red-cup-engineering/signcell/source-statement";
import { sourceStatementCells } from "@red-cup-engineering/signcell/source-statement";

export { ACTOR, digest } from "./boundary.mjs";

const STOPWORDS = new Set([
  "about", "after", "amid", "and", "are", "for", "from", "how", "into",
  "its", "new", "not", "of", "on", "over", "the", "to", "under", "when", "with",
]);

function validInstant(value) {
  return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$/u.test(value) && !Number.isNaN(Date.parse(value));
}

async function rejection(activity, reason, code, instant) {
  const result = Object.freeze({
    "@context": ACTIVITYSTREAMS_CONTEXT,
    type: "Reject",
    actor: ACTOR,
    target: activity?.actor,
    object: activity,
    published: instant,
    summary: reason,
    code,
  });
  await record("koios-provider-event", { contract: "ni:///sha-256;IqbDn9g94vxuccRscpcVHMWUfJ_jBGLflkwOzgJOdTo", recordedAt: instant, kind: "provider.refusal", code, reason, activityDigest: digest(activity) });
  return result;
}

function object(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value : undefined;
}

function strings(value) {
  return Array.isArray(value) && value.every((entry) => typeof entry === "string") ? value : undefined;
}

function positiveInteger(value) {
  return Number.isInteger(value) && value > 0 ? value : undefined;
}

function words(value) {
  return [...new Set(String(value).toLowerCase().split(/[^a-z0-9]+/u).filter((word) => word.length > 2 && !STOPWORDS.has(word)))];
}

function demandFrom(activity) {
  const source = object(activity?.object)?.sourceActivity;
  const demand = object(source)?.object;
  if (object(source)?.type !== "Create" || object(demand)?.type !== "LicensedEditorialStateDemand") return undefined;
  return { source, demand };
}

function inspectDemand(demand) {
  const assignment = object(demand?.assignment);
  const packet = object(demand?.researchPacket);
  const genreRequirements = object(demand?.genreRequirements);
  const targetWords = object(genreRequirements?.targetWords);
  const sectionPurposes = strings(genreRequirements?.sectionPurposes);
  const writerPromptLaws = strings(demand?.writerPromptLaws);
  const assignmentUrls = strings(assignment?.sourceUrls);
  const packetUrls = strings(packet?.sourceUrls);
  if (!assignment || !packet || !assignmentUrls || !packetUrls) {
    return { error: { code: "invalid-demand", reason: "assignment and research packet with source URL arrays are required", failureLayer: "contract", requiredMove: "repair-demand-carrier", replayFrom: "contract-solicitation" } };
  }
  for (const field of ["assignmentId", "term", "beat", "summary", "angle"]) {
    if (typeof assignment[field] !== "string" || assignment[field].trim() === "") {
      return { error: { code: "invalid-assignment", reason: `assignment.${field} is required`, failureLayer: "assignment", requiredMove: "repair-assignment-carrier", replayFrom: "assignment" } };
    }
  }
  if (typeof demand.genreId !== "string" || demand.genreId.trim() === "" || typeof demand.genreLawDigest !== "string" || typeof demand.publicationPolicyDigest !== "string") {
    return { error: { code: "missing-law", reason: "genre-law and publication-policy digests are required", failureLayer: "contract", requiredMove: "attach-exact-law-digests", replayFrom: "contract-solicitation" } };
  }
  if (!genreRequirements
    || !targetWords
    || positiveInteger(targetWords.minimum) === undefined
    || positiveInteger(targetWords.maximum) === undefined
    || positiveInteger(genreRequirements.minimumDistinctAssertions) === undefined
    || positiveInteger(genreRequirements.minimumLeadAssertions) === undefined
    || positiveInteger(genreRequirements.minimumIndependentSources) === undefined
    || positiveInteger(genreRequirements.maximumWordsPerAssertion) === undefined
    || positiveInteger(genreRequirements.minimumSections) === undefined
    || !sectionPurposes
    || sectionPurposes.length < genreRequirements.minimumSections
    || !writerPromptLaws
    || targetWords.maximum < targetWords.minimum) {
    return { error: { code: "invalid-genre-requirements", reason: "the exact genre evidence budget is required and must carry positive word and assertion bounds", failureLayer: "contract", requiredMove: "attach-exact-genre-evidence-budget", replayFrom: "contract-solicitation" } };
  }
  if (assignmentUrls.length === 0 || assignmentUrls.some((url) => !packetUrls.includes(url))) {
    return { error: { code: "unadmitted-source", reason: "every assignment source URL must be admitted by the research packet", failureLayer: "source-admission", requiredMove: "admit-or-remove-unlicensed-source", replayFrom: "source-admission" } };
  }
  if (!Array.isArray(packet.intakeSources) || !Array.isArray(packet.claims) || !Array.isArray(packet.sourceStatements)) {
    return { error: { code: "invalid-packet", reason: "research packet must carry intake sources, provider claims, and addressed source statements", failureLayer: "sources", requiredMove: "rebuild-research-packet", replayFrom: "research-packet" } };
  }
  return { assignment, packet, assignmentUrls, genreRequirements, sectionPurposes, writerPromptLaws };
}

function refused(code, reason, diagnosis) {
  return Object.freeze({
    status: "refused",
    code,
    reason,
    diagnosis: Object.freeze(diagnosis),
  });
}

function sourceAssertions(packet, assignmentUrls) {
  const admitted = packet.sourceStatements.map((cell) => admitSourceStatement(cell));
  if (admitted.some((result) => !result.ok)) return undefined;
  const cells = admitted.map((result) => result.value);
  const sources = packet.intakeSources.filter((source) => object(source) && typeof source.url === "string");
  const expected = [];
  for (const source of sources) {
    const summaryClaim = packet.claims.find((value) => {
      const claim = object(value);
      return claim?.sourceUrl === source.url && claim?.predicate === "summary" && claim?.status !== "refuted";
    });
    if (typeof source.summary !== "string" || object(summaryClaim)?.object !== source.summary) return undefined;
    if (typeof source.evidenceDigest !== "string" || typeof source.path !== "string" || !source.path.endsWith(niSuffix(source.evidenceDigest))) return undefined;
    expected.push(...sourceStatementCells({
      sourceSubject: source.subject, sourceUrl: source.url, sourceTitle: source.title,
      summary: source.summary,
      ...(source.published === undefined ? {} : { sourcePublished: source.published }),
      ...(source.assertedAt === undefined ? {} : { sourceAssertedAt: source.assertedAt }),
      evidenceDigest: source.evidenceDigest,
    }));
  }
  if (expected.length !== cells.length || expected.some((cell, index) => cell.id !== cells[index].id)) return undefined;
  return Object.freeze(cells
    .filter((cell) => assignmentUrls.includes(cell.content.sourceUrl))
    .map((cell) => Object.freeze({ id: cell.id, ...cell.content })));
}

export function formLicensedEditorialState(demand, instant = new Date().toISOString()) {
  if (!validInstant(instant)) throw new Error(`explicit UTC instant required: ${instant}`);
  const inspected = inspectDemand(demand);
  if (inspected.error) return refused(inspected.error.code, inspected.error.reason, {
    failureLayer: inspected.error.failureLayer,
    requiredMove: inspected.error.requiredMove,
    replayFrom: inspected.error.replayFrom,
  });
  const { assignment, packet, assignmentUrls, genreRequirements, sectionPurposes, writerPromptLaws } = inspected;
  const assertions = sourceAssertions(packet, assignmentUrls);
  if (assertions === undefined) return refused("invalid-source-statements", "source statement cells do not match the admitted packet evidence", {
    failureLayer: "sources", requiredMove: "rebuild-research-packet", replayFrom: "research-packet",
  });
  const lead = packet.intakeSources.find((value) => object(value)?.url === assignmentUrls[0]);
  const required = words(assignment.term);
  const leadEvidence = lead ? `${lead.title ?? ""} ${lead.summary ?? ""}`.toLowerCase() : "";
  const missingTerms = required.filter((word) => !leadEvidence.includes(word));
  if (!lead || missingTerms.length > 0) {
    return refused(
      "assignment-exceeds-lead-source",
      `the lead admitted source does not carry the whole assignment lens; unsupported terms: ${missingTerms.join(", ") || "unknown"}`,
      {
        failureLayer: "assignment",
        requiredMove: "narrow-assignment-to-lead-event-or-acquire-matching-source",
        replayFrom: "assignment",
        evidence: Object.freeze({ unsupportedTerms: Object.freeze(missingTerms) }),
        ...(lead === undefined ? {} : { suggestedAssignment: Object.freeze({
          term: String(lead.title),
          summary: `Report the event “${String(lead.title)}” from the admitted lead source.`,
          angle: "Establish the reported event first. Add systems interpretation only where the admitted source warrants it.",
          sourceUrls: Object.freeze([String(lead.url)]),
        }) }),
      },
    );
  }
  const leadTitle = String(lead.title ?? "").toLowerCase();
  const titleAnchors = required.filter((word) => leadTitle.includes(word));
  const requiredTitleAnchors = Math.min(required.length, Math.max(1, Math.ceil(required.length / 2)));
  if (titleAnchors.length < requiredTitleAnchors) {
    return refused(
      "assignment-lacks-event-spine",
      `the assignment terms occur only in broad source context; the lead report title anchors ${titleAnchors.length} of ${required.length} distinctive terms`,
      {
        failureLayer: "assignment",
        requiredMove: "form-assignment-from-lead-reported-event",
        replayFrom: "assignment",
        evidence: Object.freeze({ titleAnchorCount: titleAnchors.length, distinctiveTermCount: required.length }),
        suggestedAssignment: Object.freeze({
          term: String(lead.title),
          summary: `Report the event “${String(lead.title)}” from the admitted lead source.`,
          angle: "Establish the reported event first. Add systems interpretation only where the admitted source warrants it.",
          sourceUrls: Object.freeze([String(lead.url)]),
        }),
      },
    );
  }
  const leadClaims = assertions.filter((claim) => claim.sourceUrl === assignmentUrls[0]);
  if (leadClaims.length < 3 || assertions.length < 3) {
    return refused(
      "reporting-needed",
      "the admitted sources do not carry three distinct source assertions for a reported-analysis spine",
      { failureLayer: "sources", requiredMove: "acquire-additional-reporting", replayFrom: "source-acquisition" },
    );
  }
  const requiredSources = genreRequirements.minimumIndependentSources;
  // The license permits a candidate with enough retrieved source origins for
  // review. It does not infer independence from distinct URLs; the exact-text
  // assessor must judge lineage before any editorial acceptance.
  if (assignmentUrls.length < requiredSources) {
    return refused(
      "independent-sourcing-insufficient",
      `${demand.genreId} requires at least ${requiredSources} admitted source candidates before independent lineage review`,
      {
        failureLayer: "sources",
        requiredMove: "acquire-current-source-candidates",
        replayFrom: "source-acquisition",
        evidence: Object.freeze({ admittedSourceCount: assignmentUrls.length, sourceIndependence: packet.sourceIndependence?.status ?? "unassessed", minimumIndependentSources: requiredSources }),
      },
    );
  }
  const minimumDistinctAssertions = genreRequirements.minimumDistinctAssertions;
  const minimumLeadAssertions = genreRequirements.minimumLeadAssertions;
  const maximumWordsPerAssertion = genreRequirements.maximumWordsPerAssertion;
  const targetMinimumWords = genreRequirements.targetWords.minimum;
  const targetMaximumWords = genreRequirements.targetWords.maximum;
  const licensedMaximumWords = Math.min(targetMaximumWords, assertions.length * maximumWordsPerAssertion);
  const evidenceDeficits = [
    ...(assertions.length < minimumDistinctAssertions
      ? [`carries ${assertions.length} distinct assertions but requires ${minimumDistinctAssertions}`]
      : []),
    ...(leadClaims.length < minimumLeadAssertions
      ? [`carries ${leadClaims.length} lead-source assertions but requires ${minimumLeadAssertions}`]
      : []),
    ...(licensedMaximumWords < targetMinimumWords
      ? [`licenses at most ${licensedMaximumWords} words, below the ${targetMinimumWords}-word floor`]
      : []),
  ];
  if (assertions.length < minimumDistinctAssertions
    || leadClaims.length < minimumLeadAssertions
    || licensedMaximumWords < targetMinimumWords) {
    return refused(
      "evidence-budget-insufficient",
      `the admitted evidence budget is insufficient: ${evidenceDeficits.join("; ")}`,
      {
        failureLayer: "sources",
        requiredMove: "acquire-fuller-lead-reporting-or-narrow-commissioned-genre",
        replayFrom: "research-packet",
        evidence: Object.freeze({
          distinctAssertionCount: assertions.length,
          leadAssertionCount: leadClaims.length,
          minimumDistinctAssertions,
          minimumLeadAssertions,
          maximumWordsPerAssertion,
          targetMinimumWords,
          licensedMaximumWords,
        }),
      },
    );
  }
  const contextClaims = assertions.filter((claim) => claim.sourceUrl !== assignmentUrls[0]);
  const plannedClaims = [...leadClaims, ...contextClaims];
  const minimumSections = genreRequirements.minimumSections;
  const sections = sectionPurposes.slice(0, minimumSections).map((purpose, index) => {
    const start = Math.floor((plannedClaims.length * index) / minimumSections);
    const end = Math.floor((plannedClaims.length * (index + 1)) / minimumSections);
    return Object.freeze({ id: `passage-${index + 1}`, purpose, claimIds: plannedClaims.slice(start, end).map(({ id }) => id) });
  }).filter((section) => section.claimIds.length > 0);
  if (sections.length < minimumSections) {
    return refused(
      "reporting-needed",
      `the evidence cannot license ${minimumSections} nonempty ${demand.genreId} passages`,
      { failureLayer: "sources", requiredMove: "acquire-additional-reporting", replayFrom: "source-acquisition" },
    );
  }
  // The service exchange carries observation time; the licensed evidence state
  // is content addressed so later assessment can reuse the same commission.
  const state = Object.freeze({
    kind: "koios-news.licensed-editorial-state",
    version: 1,
    assignment: Object.freeze({
      assignmentId: assignment.assignmentId,
      term: assignment.term,
      beat: assignment.beat,
      demandStatus: "attention-pressure-not-evidence",
    }),
    law: Object.freeze({
      genreLawDigest: demand.genreLawDigest,
      publicationPolicyDigest: demand.publicationPolicyDigest,
      invariant: "no public factual commitment absent from admitted source evidence",
    }),
    assertions: Object.freeze(assertions),
    plan: Object.freeze({
      genre: demand.genreId,
      evidenceBudget: Object.freeze({
        targetWords: Object.freeze({ minimum: targetMinimumWords, maximum: targetMaximumWords }),
        licensedMaximumWords,
        distinctAssertionCount: assertions.length,
        leadAssertionCount: leadClaims.length,
        declaredPrimarySourceCount: packet.intakeSources.filter((source) => source.primary === true).length,
        maximumWordsPerAssertion,
        sourceIndependence: "unassessed-attributed",
        status: "cleared",
      }),
      headline: Object.freeze({
        subject: assignment.term,
        claimIds: leadClaims.slice(0, 2).map(({ id }) => id),
        law: "intensify relevance, never certainty; preserve material attribution, modality, scope, uncertainty, and correction state",
      }),
      ledeClaimIds: leadClaims.slice(0, 2).map(({ id }) => id),
      sections: Object.freeze(sections),
      interpretation: Object.freeze({
        requestedAngle: assignment.angle,
        authority: "editorial-purpose-only",
        law: "systems interpretation may organize supported assertions but may not supply facts, causes, motives, consequences, trends, or analogies",
      }),
      writerPromptLaws: Object.freeze(writerPromptLaws),
    }),
    prohibitions: Object.freeze([
      "do not treat the assignment, beat, requested angle, reader demand, or search term as evidence",
      "do not combine assertions from different events into one causal or thematic factual claim",
      "do not drop attribution or strengthen source modality",
      "do not introduce a factual sentence that cannot name its licensing claim IDs",
    ]),
    correctionPolicy: packet.accountableAttention?.correctionSurfacePolicy ?? "invalidate and regenerate every dependent circulation surface",
  });
  return Object.freeze({ status: "licensed", state, stateDigest: digest(state) });
}

export async function solicitLicensedEditorialState(activity, instant = new Date().toISOString()) {
  if (!validInstant(instant)) throw new Error(`explicit UTC instant required: ${instant}`);
  if (activity?.["@context"] !== ACTIVITYSTREAMS_CONTEXT || activity?.type !== "Offer" || activity?.target !== ACTOR || object(activity?.object)?.type !== "ServiceSolicitation") {
    return rejection(activity, "solicitation must be an ActivityStreams Offer<ServiceSolicitation> addressed to this provider", "invalid-solicitation", instant);
  }
  const found = demandFrom(activity);
  if (!found) return rejection(activity, "solicitation carries no licensed-editorial-state demand", "invalid-demand", instant);
  const inspected = inspectDemand(found.demand);
  if (inspected.error) return rejection(activity, inspected.error.reason, inspected.error.code, instant);
  const demandDigest = digest(found.demand);
  const offer = Object.freeze({
    "@context": ACTIVITYSTREAMS_CONTEXT,
    id: `urn:koios-news-service-section:offer:${niSuffix(demandDigest)}`,
    type: "Offer",
    actor: ACTOR,
    target: activity.actor,
    published: instant,
    object: Object.freeze({
      type: "ServiceOffer",
      service: "licensed-editorial-state",
      demandDigest,
      sourceActivity: found.source,
      capability: Object.freeze({ type: "AttenuatedCapability", effect: "form-licensed-editorial-state", demandDigest }),
      price: Object.freeze({ amount: 0, currency: "USD" }),
    }),
  });
  await record("koios-provider-event", { contract: "ni:///sha-256;IqbDn9g94vxuccRscpcVHMWUfJ_jBGLflkwOzgJOdTo", recordedAt: instant, kind: "provider.offer", offerId: offer.id, demandDigest });
  return offer;
}

export async function invokeLicensedEditorialState(activity, instant = new Date().toISOString()) {
  if (!validInstant(instant)) throw new Error(`explicit UTC instant required: ${instant}`);
  const contract = object(activity?.object);
  const offer = object(contract?.offer);
  const offerObject = object(offer?.object);
  if (activity?.["@context"] !== ACTIVITYSTREAMS_CONTEXT || activity?.type !== "Accept" || activity?.target !== ACTOR || contract?.type !== "ServiceContract" || offer?.actor !== ACTOR || offerObject?.service !== "licensed-editorial-state") {
    return rejection(activity, "invocation must accept this provider's exact licensed-editorial-state offer", "invalid-invocation", instant);
  }
  const source = object(offerObject.sourceActivity);
  const demand = object(source?.object);
  if (!demand || digest(demand) !== offerObject.demandDigest || object(offerObject.capability)?.demandDigest !== offerObject.demandDigest) {
    return rejection(activity, "offer demand or capability digest changed", "changed-demand", instant);
  }
  const result = formLicensedEditorialState(demand, instant);
  const exchangeId = niSuffix(digest({ offer: offer.id, instant })).slice(0, 24);
  const providerExchange = Object.freeze({
    exchangeId,
    provider: "koios-news-service-section",
    service: "licensed-editorial-state",
    price: Object.freeze({ amount: 0, currency: "USD" }),
    demandDigest: offerObject.demandDigest,
    resultDigest: digest(result),
    disposition: result.status,
    recordedAt: instant,
  });
  const response = Object.freeze({
    "@context": ACTIVITYSTREAMS_CONTEXT,
    type: result.status === "licensed" ? "Accept" : "Reject",
    actor: ACTOR,
    target: activity.actor,
    published: instant,
    object: Object.freeze({ type: "LicensedEditorialStateDelivery", result, providerExchange }),
  });
  await record("koios-provider-event", { contract: "ni:///sha-256;IqbDn9g94vxuccRscpcVHMWUfJ_jBGLflkwOzgJOdTo", recordedAt: instant, kind: "provider.delivery", ...providerExchange });
  return response;
}

const invokedAs = process.argv[1]?.split("/").at(-1);
if (import.meta.main) {
  const binCommand = invokedAs === "solicit-licensed-editorial-state" ? "solicit-service" : invokedAs === "invoke-licensed-editorial-state" ? "invoke-service" : undefined;
  const command = binCommand ?? process.argv[2];
  const instant = (binCommand === undefined ? process.argv[3] : process.argv[2]) ?? new Date().toISOString();
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  const activity = JSON.parse(Buffer.concat(chunks).toString("utf8"));
  const result = command === "solicit-service"
    ? await solicitLicensedEditorialState(activity, instant)
    : command === "invoke-service"
      ? await invokeLicensedEditorialState(activity, instant)
      : await rejection(activity, `unknown command: ${command}`, "unknown-command", instant);
  process.stdout.write(`${JSON.stringify(result)}\n`);
}
