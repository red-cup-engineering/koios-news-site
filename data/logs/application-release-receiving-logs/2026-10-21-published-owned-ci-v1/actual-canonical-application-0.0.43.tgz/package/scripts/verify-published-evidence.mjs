import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {parsePost} from '@causeway-services/koios-news-site/build';
import {resolve} from 'node:path';
import {verifyManuscriptEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {verifyAssessmentReceipt} from '@causeway-services/editorial-publication-authority';
import {verifyCapturedAssessment} from '../src/news-line/publication-evidence.mjs';
import {replaceDraftFlag} from '../src/offline-publication.mjs';
export function verifyPublishedEvidence({slug,dataRoot=resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT??'data'),archiveRoot=dataRoot}={}){
if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug??''))throw new Error('Use an existing published article slug');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const publishedSource=readFileSync(join(dataRoot,'line/publication-replay/published',slug+'.md'),'utf8');
const sourceSha256=sha(publishedSource),root=join(archiveRoot,'line/publication-evidence',slug,sourceSha256);
const text=name=>readFileSync(join(root,name),'utf8'),json=name=>JSON.parse(text(name));
const manuscriptSource=text('manuscript.md'),receiptSource=text('receipt.json'),receipt=JSON.parse(receiptSource),publication=json('publication.json');
if(text('published.md')!==publishedSource||publication.sourceSha256!==sourceSha256||publication.manuscriptSha256!==sha(manuscriptSource)||publication.receiptSha256!==sha(receiptSource))throw new Error('Published version differs from its captured acceptance');
if(replaceDraftFlag(manuscriptSource,slug+'.md')!==publishedSource)throw new Error('Published bytes are not the accepted manuscript promotion');
verifyAssessmentReceipt({receiptSource,assessmentKeys:json('assessment-keys.json'),manuscriptSource,manuscriptSlug:slug,now:receipt.issuedAt});
const capturedEvidence=json('evidence.json');
verifyCapturedAssessment({demand:json('demand.json'),evidence:capturedEvidence,receipt,review:json('review.json'),manuscriptSource});
const evidence=verifyManuscriptEvidence(capturedEvidence,parsePost(manuscriptSource,slug+'.md').body);
return {slug,sourceSha256,acceptedAt:receipt.issuedAt,historicalAcceptance:true,...evidence};
}
if(import.meta.main){
const {newsLineContext}=await import('../src/news-line/context.mjs');
const context=newsLineContext();
console.log(JSON.stringify(verifyPublishedEvidence({slug:process.argv[2],dataRoot:context.dataRoot,archiveRoot:dirname(context.claimStoreDir)})));
}
