/** Repository discussions are reporting inputs, including edits on closed issues. */
export const EDITORIAL_FEEDBACK_QUERY = `query {
  repository(owner: "causeway-services", name: "koios-news") {
    issues(first: 100, orderBy: {field: UPDATED_AT, direction: DESC}) {
      totalCount
      pageInfo { hasNextPage }
      nodes {
        number url title body state updatedAt author { login }
        comments(last: 100) {
          totalCount
          pageInfo { hasPreviousPage }
          nodes { databaseId url body createdAt updatedAt author { login } }
        }
      }
    }
  }
}`;

export function editorialFeedbackFrom(response) {
  if (response.errors?.length) throw new Error(response.errors.map(row => row.message).join('; '));
  const held = response.data?.repository?.issues;
  if (!Array.isArray(held?.nodes)) throw new Error('GitHub editorial discussions were not returned');
  const issues = held.nodes.map(({comments, ...issue}) => ({
    ...issue,
    comments: comments.nodes,
    commentCount: comments.totalCount,
    earlierCommentsOmitted: comments.pageInfo.hasPreviousPage,
  }));
  const observation = {issues, coverage: {
    totalIssues: held.totalCount,
    observedIssues: issues.length,
    earlierIssuesOmitted: held.pageInfo.hasNextPage,
  }};
  if (held.pageInfo.hasNextPage || issues.some(issue => issue.earlierCommentsOmitted))
    throw Object.assign(new Error('The bounded GitHub discussion snapshot omits older issues or comments; inspect the linked discussions before treating editorial requests as covered.'), {observation});
  return observation;
}
