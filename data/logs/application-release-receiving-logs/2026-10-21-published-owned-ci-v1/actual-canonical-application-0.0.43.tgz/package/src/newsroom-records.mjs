/** Koios uses the Content Mill's record, telling and immutable-body custody contract. */
export {newsroomType,recordNewsroom,readNewsroom} from '@red-cup-engineering/content-mill-newsroom-services-section/records';
