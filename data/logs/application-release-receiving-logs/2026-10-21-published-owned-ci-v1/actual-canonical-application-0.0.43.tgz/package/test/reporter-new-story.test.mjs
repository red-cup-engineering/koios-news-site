import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,existsSync,readdirSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {readNewsroom,recordNewsroom} from '../src/newsroom-records.mjs';
import {semanticId} from '@red-cup-engineering/computer-content-address-engineering-services-section/semiotic-content-address';
import {createTypedMark} from '@red-cup-engineering/signcell/typed-mark';
import {sourceEvidenceType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {admitSourceEvidence,recordSourceEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {admitReporterManuscript} from '@red-cup-engineering/content-mill-newsroom-services-section/manuscript';
import {submitArticle} from '../src/news-line/submissions.mjs';
import {reportArticle} from '../src/news-line/reporting.mjs';
import {lineRoots,editionOf,openEdition,advanceEdition} from '../src/news-line/editions.mjs';

const at='2026-10-10T07:00:00.000Z',digest=semanticId;
const story=(name='fixture')=>'news-property.story:'+Buffer.from(JSON.stringify({v:{feed:'fixture-wire',title:name}})).toString('base64url');
const put=(root,category,record,told)=>recordNewsroom(root,category,record,{told});
function fixture(t){
 const root=mkdtempSync(join(tmpdir(),'koios-reporter-new-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
 const context={dataRoot:root,roots:lineRoots(root),propertyContentDir:join(root,'content'),property:{origin:'https://koios.news',content:{postsDirectory:'posts'},sections:[{slug:'world',title:'World',wires:['fixture-wire'],minimumIndependentSources:3}],editorialProductProfile:'standard-news/v1'}};
 mkdirSync(join(context.propertyContentDir,'posts'),{recursive:true});
 const sources=[],claims=[];
 for(let host=0;host<3;host++){
  const url=`https://outlet${host}.example/report`,quotes=Array.from({length:4},(_,n)=>`Agency ${host} recorded finding ${n} in district ${host}.`),text=quotes.join('\n'),lead={id:story(),url};
  const source=admitSourceEvidence(lead,{type:'PublicWebSource',requestedUrl:url,finalUrl:url,text,textDigest:digest(text),responseDigest:digest(text),rights:'public-access-observed',acquiredAt:at,networkRequests:1,responseBytes:Buffer.byteLength(text)});
  recordSourceEvidence(root,source,at);sources.push(source);
  for(let n=0;n<4;n++){
   const quote=quotes[n],claim=admitClaimEvidence({storyId:story(),section:'world',sourceId:lead.id,sourceUrl:url,sourceEvidenceId:source.id,host:new URL(url).hostname,subject:`Agency ${host}`,predicate:'recorded',object:`finding ${n} in district ${host}`,quote,quoteStart:text.indexOf(quote),quoteEnd:text.indexOf(quote)+quote.length},source);
   put(root,'claim',claim);claims.push(claim);
  }
 }
 const words='The documentary record identifies the observation and preserves its exact scope. This synthetic test paragraph contains no real reporting and makes no claim about an actual event. Its length exercises the commissioned deterministic floor while the cited fixture remains available for the separate editorial review that would be required before any public release. The test never grants that review or publication authority.';
 const proposal={slug:'fixture-new-development',storyId:story(),title:'Documented fixture development changes the coastal research plan',dek:'A synthetic article exercises the existing reporting admission route.',paragraphs:claims.map((claim,index)=>({text:words,heading:index%4===0?['What changed','Documented context','Next evidence'][index/4]:'',claimEvidenceIds:[claim.id]}))};
 return {context,root,sources,claims,proposal};
}
function open(context,fields){openEdition(context.roots,{candidateId:'fixture:'+Math.random(),storyId:story('other'),section:'world',slug:'other-slug',state:'drafted',draftedAt:at,...fields});}
function post(title='Documented fixture development changes the coastal research plan',section='world'){return `---\ntitle: ${JSON.stringify(title)}\ndate: 2026-10-01\nsection: ${section}\ndraft: true\n---\n# Fixture\n\nBody\n`;}

test('NEW held story enters drafted custody without invented publication history',t=>{
 const f=fixture(t),result=submitArticle(f.context,{...f.proposal,firstPublished:'1999-01-01',section:'invented',admitted:true},{at});
 assert.equal(result.state,'drafted');assert.equal(result.quality.assertions,12);assert.equal(result.quality.sourceHosts,3);
 const edition=editionOf(f.context.roots,result.candidateId);assert.equal(edition.section,'world');assert.equal(Object.hasOwn(edition,'firstPublished'),false);
 const source=readFileSync(result.draftPath,'utf8');assert.match(source,/\ndraft: true\n/);assert.match(source,/\ndate: 2026-10-10\n/);assert.doesNotMatch(source,/modified:/);
 assert.equal(existsSync(join(f.context.roots.publication,'published',f.proposal.slug+'.md')),false);
 assert.deepEqual(readdirSync(f.context.roots.queue),[]);assert.deepEqual(readdirSync(f.context.roots.grants),[]);
});
test('exact known retry retains candidate and receipt-bound address after release',t=>{
 const f=fixture(t),first=submitArticle(f.context,f.proposal,{at}),edition=editionOf(f.context.roots,first.candidateId);
 advanceEdition(f.context.roots,edition,'released',at,{releasedAt:at});
 assert.equal(submitArticle(f.context,f.proposal,{at:'2026-10-11T07:00:00.000Z'}).state,'released');
 assert.equal(readdirSync(f.context.roots.editions).length,1);
});
test('exact retry rejects candidate/address disagreement',t=>{
 const f=fixture(t),first=submitArticle(f.context,f.proposal,{at}),edition=editionOf(f.context.roots,first.candidateId);
 openEdition(f.context.roots,{...edition,slug:'different'});
 assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/already bound/);
});
test('unknown, non-newsroom and ambiguous anchor identities are refused',t=>{
 const f=fixture(t);
 assert.throws(()=>submitArticle(f.context,{...f.proposal,storyId:story('unknown')},{at}),/no held/);
 assert.throws(()=>submitArticle(f.context,{...f.proposal,storyId:'invented'},{at}),/existing newsroom/);
 f.context.property.sections.push({...f.context.property.sections[0],slug:'ambiguous'});
 assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/exactly one/);
});
test('an opposed used claim refuses the genuine manuscript evidence join',t=>{
 const f=fixture(t);put(f.root,'claim',f.claims[0],{for:true,against:true});
 assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/absent, opposed or differently assigned/);
});
test('a counterfeit source text digest cannot establish NEW identity',t=>{
 const f=fixture(t),source=f.sources[0],bad=createTypedMark(sourceEvidenceType,{...source.content,textDigest:'invented-digest'}).value;
 put(f.root,'source-evidence',bad);
 const claim=admitClaimEvidence({...f.claims[0].content,storyId:story('counterfeit'),sourceEvidenceId:bad.id},bad);put(f.root,'claim',claim);
 assert.throws(()=>submitArticle(f.context,{...f.proposal,storyId:story('counterfeit')},{at}),/no held/);
});
test('cross-story claim IDs and unsafe prose cannot become a reporter manuscript',t=>{
 const f=fixture(t),other=admitClaimEvidence({...f.claims[0].content,storyId:story('other')},f.sources[0]);put(f.root,'claim',other);
 const cross={...f.proposal,paragraphs:[{...f.proposal.paragraphs[0],claimEvidenceIds:[other.id]},...f.proposal.paragraphs.slice(1)]};
 assert.throws(()=>submitArticle(f.context,cross,{at}),/absent, opposed or differently assigned/);
 assert.throws(()=>submitArticle(f.context,{...f.proposal,title:'Read https://unreviewed.example'},{at}),/links, markup/);
});
test('quality counts only used claims and enforces the stricter desk source floor',t=>{
 const f=fixture(t),thin={...f.proposal,paragraphs:f.proposal.paragraphs.map(p=>({...p,claimEvidenceIds:[f.claims[0].id]}))};
 assert.throws(()=>submitArticle(f.context,thin,{at}),/failed admission/);
 f.context.property.sections[0].minimumIndependentSources=4;assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/for its desk/);
 f.context.property.sections[0].minimumIndependentSources='3';assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/must be positive/);
});
test('published or corpus slugs cannot be taken by a NEW story',t=>{
 const f=fixture(t),path=join(f.context.propertyContentDir,'posts',f.proposal.slug+'.md');writeFileSync(path,post().replace('draft: true','draft: false'));
 assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/nondraft publication input/);rmSync(path);
 mkdirSync(join(f.context.roots.publication,'published'),{recursive:true});writeFileSync(join(f.context.roots.publication,'published',f.proposal.slug+'.md'),post());
 assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/already exists/);
});
test('another story cannot take a pending slug and a story cannot take another address',t=>{
 const f=fixture(t);open(f.context,{slug:f.proposal.slug});assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/belongs to another/);
 for(const file of readdirSync(f.context.roots.editions))rmSync(join(f.context.roots.editions,file));
 open(f.context,{storyId:f.proposal.storyId,slug:'existing-address',state:'returned'});assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/original article address/);
});
test('legacy authoritative desk and active pending headlines prevent duplicates',t=>{
 const f=fixture(t);mkdirSync(join(f.context.roots.publication,'published'),{recursive:true});
 writeFileSync(join(f.context.roots.publication,'published','legacy.md'),post(f.proposal.title,'wrong'));
 f.context.property.content.legacyPublishedSections={legacy:'world'};assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/nearly duplicates/);
 rmSync(join(f.context.roots.publication,'published','legacy.md'));
 const draftPath=join(f.context.dataRoot,'pending.md');writeFileSync(draftPath,post());open(f.context,{draftPath});
 assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/nearly duplicates/);
});
test('a refused historical headline alone cannot poison new admission',t=>{
 const f=fixture(t),draftPath=join(f.context.dataRoot,'refused.md');writeFileSync(draftPath,post());open(f.context,{draftPath,state:'refused'});
 assert.equal(submitArticle(f.context,f.proposal,{at}).state,'drafted');
});
test('a shared source cannot erase a separately assigned story identity',t=>{
 const f=fixture(t),other=story('anchor');
 for(let index=0;index<f.claims.length;index++)put(f.root,'claim',admitClaimEvidence({...f.claims[index].content,storyId:other},f.sources[Math.floor(index/4)]));
 open(f.context,{storyId:other,state:'released',releasedAt:at});
 assert.equal(submitArticle(f.context,f.proposal,{at}).state,'drafted');
});
test('declared contextual sources do not merge unrelated reporter assignments',t=>{
 const f=fixture(t),other=story('anchor');
 for(let index=0;index<f.claims.length;index++)put(f.root,'claim',admitClaimEvidence({...f.claims[index].content,storyId:other},f.sources[Math.floor(index/4)]));
 for(const source of f.sources)put(f.root,'reporting-source',{sourceEvidenceId:source.id});
 open(f.context,{storyId:other,state:'released',releasedAt:at});
 assert.equal(submitArticle(f.context,f.proposal,{at}).state,'drafted');
});
test('the canonical story survives shared-evidence deduplication',t=>{
 const f=fixture(t),other=story('same-event-alias');
 for(let index=0;index<f.claims.length;index++)put(f.root,'claim',admitClaimEvidence({...f.claims[index].content,storyId:other},f.sources[Math.floor(index/4)]));
 open(f.context,{storyId:f.proposal.storyId,slug:f.proposal.slug,state:'returned'});
 assert.equal(submitArticle(f.context,f.proposal,{at}).state,'drafted');
});
test('later event alias cannot invalidate an exact known retry',t=>{
 const f=fixture(t),first=submitArticle(f.context,f.proposal,{at}),other=story('earlier-anchor');
 for(let index=0;index<f.claims.length;index++)put(f.root,'claim',admitClaimEvidence({...f.claims[index].content,storyId:other},f.sources[Math.floor(index/4)]));
 open(f.context,{storyId:other,state:'released',releasedAt:at,draftedAt:'2026-10-09T01:00:00.000Z'});
 assert.equal(submitArticle(f.context,f.proposal,{at}).candidateId,first.candidateId);
});
test('journal-only interrupted submission conservatively refuses replay',t=>{
 const f=fixture(t),{candidate}=admitReporterManuscript({root:f.root,storyId:f.proposal.storyId,section:'world',proposal:f.proposal,at});put(f.root,'manuscript-candidate',candidate);
 assert.throws(()=>submitArticle(f.context,f.proposal,{at}),/reconcile the interrupted/);
 assert.equal(readdirSync(f.context.roots.editions).length,0);
});
test('slug-only revision retains its existing article date and custody path',t=>{
 const f=fixture(t);mkdirSync(join(f.context.roots.publication,'published'),{recursive:true});writeFileSync(join(f.context.roots.publication,'published',f.proposal.slug+'.md'),post());
 open(f.context,{storyId:f.proposal.storyId,slug:f.proposal.slug,state:'released',releasedAt:at});
 const {storyId,...proposal}=f.proposal,result=submitArticle(f.context,proposal,{at});
 assert.equal(editionOf(f.context.roots,result.candidateId).firstPublished,'2026-10-01');assert.match(readFileSync(result.draftPath,'utf8'),/modified: 2026-10-10/);
});
test('NEW claims mode cannot silently buy automatic extraction',async t=>{
 const f=fixture(t);await assert.rejects(reportArticle(f.context,{slug:f.proposal.slug,storyId:f.proposal.storyId,urls:['https://outlet0.example/report']}),/reviewed reporter sources/);
});
