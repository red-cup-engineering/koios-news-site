import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { semanticId } from "@red-cup-engineering/computer-content-address-engineering-services-section/semiotic-content-address";
import { each, put } from "@red-cup-engineering/semiotic-eavt-services-section/store";
import { ACTIVITYSTREAMS_CONTEXT } from "@red-cup-engineering/activitypub-services-section/activitystreams";
import { KOIOS_SERVICE_ENTERPRISE, resolveKoiosServiceActor } from "./service-identity.mjs";

export const ACTOR = resolveKoiosServiceActor();
export const ENTERPRISE = KOIOS_SERVICE_ENTERPRISE;
export const ACCOUNT = "eip155:31337:0x55397286728b70d86a139fe8263c2d63c5d6770c";
export const ROOT = resolve(fileURLToPath(new URL("..", import.meta.url)));

export function digest(value, objectKind = "koios-news.record") {
  return semanticId({type:objectKind,value});
}

export function niSuffix(value) {
  if (!/^ni:\/\/\/sha-256;[A-Za-z0-9_-]{43}$/u.test(value ?? "")) throw new Error("semantic identity must be an RFC 6920 SHA-256 ni URI");
  return value.slice("ni:///sha-256;".length);
}

function dataRoot() {
  return resolve(process.env.KOIOS_NEWS_DATA_ROOT ?? ROOT);
}

/** The records of a store type held under `root`. */
export function records(type, root = dataRoot()) {
  return [...each(resolve(root), type)].map(({ record: held }) => held);
}

/** Puts one record of a store type under `root`; the address that holds it. */
export function record(type, value, root = dataRoot()) {
  return put(resolve(root), type, value);
}
