import {createHash,randomUUID} from 'node:crypto';
import {readNewsroom,recordNewsroom} from '../newsroom-records.mjs';
import {acquirePublicWebSources,normalizePublicUrl} from '@causeway-services/web-source-acquisition/acquire';
import {admitSourceEvidence,recordSourceEvidence,recordSourceObstruction} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {purchaseClaimExtraction,claimRows,recordPurchaseReceipt,assayReporterClaims} from '@red-cup-engineering/content-mill-newsroom-services-section/claims';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {recordClaim} from '@red-cup-engineering/content-mill-newsroom-services-section/settlement';
import {editions} from './editions.mjs';
import {existingArticleAssignment} from './existing-article.mjs';
import {storyAnchor,storyDesk} from './desk.mjs';
import {heldJournalCells} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {sourceEvidenceType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {newReporterAssignment,assertNewReporterEvent,assertNewReporterAddress} from './reporter-assignment.mjs';

/** An originating wire document remains event-bearing on every reporting retry. */
function isStorySource(source,root){
  try{return storyAnchor(source.content.leadId,root)?.url===source.content.requestedUrl;}catch{return false;}
}

/** Acquire additional reporting for an existing article without editing its accepted bytes. */
export async function reportArticle(context,{slug,storyId,urls,reporterSources,refreshSources=false,at=new Date().toISOString()},ports={}) {
  if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug??'')) throw new Error('An existing article slug is required');
  if(!Array.isArray(urls)||urls.length<1||urls.length>6) throw new Error('Research requires one to six public source URLs');
  if(typeof refreshSources!=='boolean')throw new TypeError('Source refresh must be an explicit boolean');
  const requested=[...new Set(urls.map(normalizePublicUrl))];
  const root=context.dataRoot;
  const edition=storyId===undefined?existingArticleAssignment(context,slug,{releasedEditions:(ports.editions??editions)(context.roots,'released')}):newReporterAssignment(context,{slug,storyId},{reporterSources,at});
  if(storyId!==undefined){
    if(!Array.isArray(reporterSources)||reporterSources.length!==requested.length||requested.some(url=>!reporterSources.some(source=>normalizePublicUrl(source.url)===url)))throw new Error('NEW reporting requires reviewed reporter sources; it never buys extraction');
    assertNewReporterEvent(context,edition);
    assertNewReporterAddress(context,edition);
  }
  const desk=storyDesk(context.property,edition.storyId,edition.section,context.dataRoot);
  const held=new Set(readNewsroom(root,'claim').map(x=>x.record?.id));
  const results=[],turnId=randomUUID();
  for(const url of requested) {
    const lead={id:'koios.reporting:'+createHash('sha256').update(JSON.stringify([edition.storyId,url])).digest('hex'),url,title:`Additional reporting for ${slug}`,summary:null};
    const supplied=reporterSources?.find(item=>normalizePublicUrl(item.url)===url);
    const matches=cell=>cell.content.requestedUrl===url&&cell.content.textDigest===supplied?.expectedTextDigest;
    const heldSources=supplied?[...heldJournalCells(root,"source-evidence",sourceEvidenceType).values()].filter(matches):[];
    // Settle against the precise source assayed for first-claim admission. On
    // retries, prefer this story's originating carrier over another lead's copy.
    let source=refreshSources?undefined:(edition.initialClaimEntries?.map(entry=>entry.source).find(matches)
      ??heldSources.find(cell=>cell.content.leadId===edition.storyId)
      ??heldSources[0]),delivery;
    try {if(!source){delivery=await (ports.acquire??acquirePublicWebSources)({purpose:'journalistic-source-research',urls:[url]},at);source=admitSourceEvidence(lead,delivery);}}
    catch(error) {const reason=delivery?.obstructions?.find(x=>x.requestedUrl===url)?.reason??String(error.message);recordSourceObstruction(root,lead,reason,at);results.push({url,claims:0,obstruction:reason});continue;}
    if(delivery)recordSourceEvidence(root,source,at,delivery);
    // Only background documents are contextual. Originating wire documents
    // must still join duplicate events, including after a reporting retry.
    if(!isStorySource(source,root))recordNewsroom(root,'reporting-source',{type:'KoiosArticleReportingSource',storyId:edition.storyId,slug,sourceEvidenceId:source.id,researchedAt:at});
    if(supplied&&supplied.expectedTextDigest!==source.content.textDigest)throw new Error(`Reporter source changed since review: ${url}`);
    const purchase=supplied?assayReporterClaims({...lead,id:source.content.leadId,url:source.content.requestedUrl},source,supplied.claims):await (ports.purchase??purchaseClaimExtraction)(lead,{maximumClaims:24,freeLaneOnly:context.property.cadence?.freeLaneOnly===true,customerActor:context.property.inference.customerActor,sourceEvidence:source,reportingFocus:edition.title??(edition.storyId.startsWith("news-property.published:")?null:storyAnchor(edition.storyId,context.dataRoot)?.title)??slug});
    (ports.receipt??recordPurchaseReceipt)(purchase,{root:context.purchaseJournalRoot,turnId,actor:context.property.inference.customerActor,recordedAt:at});
    let added=0;
    for(const row of claimRows(purchase,{storyId:edition.storyId,section:desk.slug},source)) {
      const claim=admitClaimEvidence(row,source);
      if(held.has(claim.id))continue;
      recordClaim(root,claim,at);held.add(claim.id);added++;
    }
    results.push({url,sourceEvidenceId:source.id,claims:added,claimsRefused:purchase.claimsRefused??null,groundingProblems:purchase.assay?.problems??[],outcome:purchase.outcome,admitted:purchase.admitted});
  }
  return {slug,storyId:edition.storyId,section:desk.slug,results,claimsAdded:results.reduce((n,x)=>n+x.claims,0),publication:'Research only; a new manuscript still requires independent assessment and publication authority.'};
}

