import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readdirSync,rmSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {sourceArrivalFromObservation} from '@red-cup-engineering/communicating/messaging/newswire/source-arrival';
import {newsroomDayAcquireSourcesOnly} from '@red-cup-engineering/content-mill-newsroom-services-section';
import {projectArrivalsToStore} from '@red-cup-engineering/content-mill-newsroom-services-section/intake';
import {semanticId} from '@red-cup-engineering/computer-content-address-engineering-services-section/semiotic-content-address';
import {createTypedMark} from '@red-cup-engineering/signcell/typed-mark';
import {sourceEvidenceType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {admitSourceEvidence,recordSourceEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {readNewsroom,recordNewsroom} from '../src/newsroom-records.mjs';
import {lineRoots,openEdition} from '../src/news-line/editions.mjs';
import {reportArticle} from '../src/news-line/reporting.mjs';
import {newReporterAssignment} from '../src/news-line/reporter-assignment.mjs';

const at='2026-10-13T08:00:00.000Z',digest=semanticId;
const quote='Agency Delta scheduled coastal research for October 14.';
async function fixture(t){
 const root=mkdtempSync(join(tmpdir(),'koios-first-claims-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
 const property={name:'Koios.News',origin:'https://koios.news',content:{postsDirectory:'posts'},sections:[{slug:'world',title:'World',wires:['fixture-wire'],minimumIndependentSources:3,quotaPerDay:20}],inference:{customerActor:'urn:test:koios-reporter'},cadence:{freeLaneOnly:true},editorialProductProfile:'standard-news/v1'};
 const context={dataRoot:root,roots:lineRoots(root),purchaseJournalRoot:join(root,'inference-purchases'),propertyContentDir:join(root,'content'),property};
 mkdirSync(join(context.propertyContentDir,'posts'),{recursive:true});
 const feed={id:'fixture-wire',url:'https://wire.example/rss',kind:'rss'},url='https://outlet.example/coastal-study';
 const event=sourceArrivalFromObservation({feed,item:{externalId:'first-source',url,title:'Agency Delta schedules coastal research',published:at},observedAt:at});
 const houseFeedsPath=join(root,'feeds.json');writeFileSync(houseFeedsPath,JSON.stringify([feed]));
 let acquisitions=0;
 const summary=await newsroomDayAcquireSourcesOnly({property,dataRoot:root,now:new Date(at),houseFeedsPath,sourceArrivals:[event],maxStories:1,
  acquireSource:async lead=>{acquisitions++;return {type:'PublicWebSource',requestedUrl:lead.url,finalUrl:url,text:quote,textDigest:digest(quote),responseDigest:digest(quote),rights:'public-access-observed',acquiredAt:at,networkRequests:1,responseBytes:Buffer.byteLength(quote)};},
  purchase:()=>{throw new Error('Source-only fixture must not purchase claims');},recordReceipt:()=>{throw new Error('Source-only fixture must not record a purchase');},
 });
 assert.equal(acquisitions,1);assert.equal(summary.sources.acquired,1);assert.equal(summary.claims.admitted,0);assert.equal(summary.claims.purchaseCount,0);
 const source=readNewsroom(root,'source-evidence')[0].record,storyId=source.content.leadId;
 const valid={subject:'Agency Delta',predicate:'scheduled',object:'coastal research for October 14',quote};
 const packet={slug:'coastal-research-scheduled',storyId,urls:[url],reporterSources:[{url,expectedTextDigest:source.content.textDigest,claims:[valid]}],at};
 const ports={acquire:()=>{throw new Error('Held reporter source must not be fetched again');},purchase:()=>{throw new Error('Reporter must not purchase extraction');}};
 return {context,root,source,storyId,url,packet,ports,feed,event};
}
function noPublication(f){
 assert.deepEqual(readdirSync(f.context.roots.editions),[]);assert.deepEqual(readdirSync(f.context.roots.queue),[]);assert.deepEqual(readdirSync(f.context.roots.grants),[]);
 assert.equal(existsSync(join(f.context.roots.publication,'published',f.packet.slug+'.md')),false);assert.equal(existsSync(f.context.purchaseJournalRoot),false);
 if(Object.hasOwn(globalThis,'__koiosQualificationGuardCalls'))assert.deepEqual(globalThis.__koiosQualificationGuardCalls,[]);
}
test('source-only acquisition can receive its first reviewed claim without a model or invented assignment',async t=>{
 const f=await fixture(t);assert.equal(readNewsroom(f.root,'claim').length,0);
 const result=await reportArticle(f.context,f.packet,f.ports);assert.equal(result.claimsAdded,1);assert.equal(result.storyId,f.storyId);
 const claim=readNewsroom(f.root,'claim')[0].record;assert.equal(claim.content.sourceEvidenceId,f.source.id);assert.equal(claim.content.storyId,f.storyId);assert.equal(claim.content.quote,quote);noPublication(f);
});
test('source-only first-claim retry is idempotent through the ordinary held-claim route',async t=>{
 const f=await fixture(t);assert.equal((await reportArticle(f.context,f.packet,f.ports)).claimsAdded,1);assert.equal((await reportArticle(f.context,f.packet,f.ports)).claimsAdded,0);assert.equal(readNewsroom(f.root,'claim').length,1);noPublication(f);
});
test('source-only evidence alone cannot license manuscript assignment',async t=>{
 const f=await fixture(t);assert.throws(()=>newReporterAssignment(f.context,f.packet),/no held/);noPublication(f);
});
test('a claimed story identity without its constituted arrival is refused before writing',async t=>{
 const f=await fixture(t);const missing=mkdtempSync(join(tmpdir(),'koios-missing-story-'));t.after(()=>rmSync(missing,{recursive:true,force:true}));f.context.dataRoot=missing;await assert.rejects(reportArticle(f.context,f.packet,f.ports),/existing newsroom|no held/);assert.equal(readNewsroom(f.root,'claim').length,0);noPublication(f);
});
test('mismatched reviewed source digest refuses first claims',async t=>{
 const f=await fixture(t);f.packet.reporterSources[0].expectedTextDigest=digest('different bytes');await assert.rejects(reportArticle(f.context,f.packet,f.ports),/no held/);assert.equal(readNewsroom(f.root,'claim').length,0);noPublication(f);
});
test('opposed captured source cannot establish first-claim assignment',async t=>{
 const f=await fixture(t);recordNewsroom(f.root,'source-evidence',f.source,{told:{for:true,against:true}});await assert.rejects(reportArticle(f.context,f.packet,f.ports),/no held/);assert.equal(readNewsroom(f.root,'claim').length,0);noPublication(f);
});
test('counterfeit captured text digest is refused despite matching packet',async t=>{
 const f=await fixture(t);recordNewsroom(f.root,'source-evidence',f.source,{told:{for:true,against:true}});
 const bad=createTypedMark(sourceEvidenceType,{...f.source.content,textDigest:digest('counterfeit')}).value;recordNewsroom(f.root,'source-evidence',bad);f.packet.reporterSources[0].expectedTextDigest=bad.content.textDigest;
 await assert.rejects(reportArticle(f.context,f.packet,f.ports),/no held/);assert.equal(readNewsroom(f.root,'claim').length,0);noPublication(f);
});
test('ungrounded first claims cannot establish an assignment or leave contextual-source custody',async t=>{
 const f=await fixture(t);f.packet.reporterSources[0].claims[0].quote='Invented statement';await assert.rejects(reportArticle(f.context,f.packet,f.ports),/no held/);assert.equal(readNewsroom(f.root,'claim').length,0);assert.equal(readNewsroom(f.root,'reporting-source').length,0);noPublication(f);
});
test('one document may supply claims to a separately constituted event without granting publication',async t=>{
 const f=await fixture(t),otherEvent=sourceArrivalFromObservation({feed:f.feed,item:{externalId:'earlier',url:f.url,title:'Earlier coastal research coverage',published:at},observedAt:at});
 const other=projectArrivalsToStore([otherEvent],f.root,new Map([['fixture-wire',['world']]]))[0].id;
 recordNewsroom(f.root,'claim',admitClaimEvidence({storyId:other,section:'world',sourceId:f.source.content.leadId,sourceUrl:f.url,sourceEvidenceId:f.source.id,host:new URL(f.url).hostname,...f.packet.reporterSources[0].claims[0],quoteStart:0,quoteEnd:quote.length},f.source));
 openEdition(f.context.roots,{candidateId:'earlier-candidate',storyId:other,section:'world',slug:'existing-coastal-report',state:'released',releasedAt:at,draftedAt:at});
 assert.equal((await reportArticle(f.context,f.packet,f.ports)).claimsAdded,1);assert.equal(readNewsroom(f.root,'claim').length,2);assert.equal(readNewsroom(f.root,'reporting-source').length,0);assert.deepEqual(globalThis.__koiosQualificationGuardCalls??[],[]);
});

test('a distinct source-only arrival retains its own evidence and no publication authority',async t=>{
 const f=await fixture(t);
 assert.equal((await reportArticle(f.context,f.packet,f.ports)).claimsAdded,1);
 openEdition(f.context.roots,{candidateId:'first-candidate',storyId:f.storyId,section:'world',slug:f.packet.slug,state:'released',releasedAt:at,draftedAt:at});
 const event=sourceArrivalFromObservation({feed:f.feed,item:{externalId:'duplicate-arrival',url:f.url,title:'Agency Delta coastal study announced again',published:at},observedAt:at});
 const second=projectArrivalsToStore([event],f.root,new Map([['fixture-wire',['world']]]))[0];
 const source=admitSourceEvidence({id:second.id,url:f.url},{type:'PublicWebSource',...f.source.content});
 assert.notEqual(source.id,f.source.id);recordSourceEvidence(f.root,source,at);
 const packet={...f.packet,storyId:second.id,slug:'second-coastal-study'};
 assert.equal((await reportArticle(f.context,packet,f.ports)).claimsAdded,1);
 assert.equal(readNewsroom(f.root,'claim').length,2);
 assert.deepEqual(readdirSync(f.context.roots.queue),[]);
});
test('invalid assignment timestamp cannot open the source-only freshness window',async t=>{
 const f=await fixture(t);f.packet.at='not-a-date';
 await assert.rejects(reportArticle(f.context,f.packet,f.ports),/time|date|no held/i);
 assert.equal(readNewsroom(f.root,'claim').length,0);assert.equal(readNewsroom(f.root,'reporting-source').length,0);
});
test('ordinary expired source-only arrival remains refused',async t=>{
 const f=await fixture(t);f.packet.at='2026-10-15T08:00:00.000Z';
 await assert.rejects(reportArticle(f.context,f.packet,f.ports),/no held/);
 assert.equal(readNewsroom(f.root,'claim').length,0);assert.equal(readNewsroom(f.root,'reporting-source').length,0);
});

test('first claims settle against the exact anchor source admitted by assignment even when another held carrier has identical bytes',async t=>{
 const f=await fixture(t);
 // Constitute a second real story with the same document. Choose the later
 // held carrier as this test's assignment, so the first URL+digest match is
 // always the other story, independently of journal iteration or hash order.
 const competing=sourceArrivalFromObservation({feed:f.feed,item:{externalId:'competing-source',url:f.url,title:'Another assignment for the coastal source',published:at},observedAt:at});
 const [story]=projectArrivalsToStore([competing],f.root,new Map([[f.feed.id,['world']]]));
 const cell=admitSourceEvidence({id:story.id,url:f.url},{type:'PublicWebSource',...f.source.content});
 recordSourceEvidence(f.root,cell,at);
 const matches=readNewsroom(f.root,'source-evidence').map(row=>row.record).filter(row=>row.content.requestedUrl===f.url&&row.content.textDigest===f.source.content.textDigest);
 assert.equal(matches.length,2);
 const [shadow,anchor]=matches;
 assert.notEqual(shadow.content.leadId,anchor.content.leadId);
 f.source=anchor;f.storyId=anchor.content.leadId;f.packet.storyId=f.storyId;
 assert.notEqual(shadow.id,f.source.id,'the competing first match must belong to the other story');
 const assignment=newReporterAssignment(f.context,f.packet,{reporterSources:f.packet.reporterSources,at});
 assert.deepEqual(assignment.initialClaimEntries.map(entry=>entry.source.id),[f.source.id]);
 const result=await reportArticle(f.context,f.packet,f.ports);
 assert.equal(result.claimsAdded,1);assert.equal(result.results[0].sourceEvidenceId,f.source.id);
 assert.equal(readNewsroom(f.root,'claim')[0].record.content.sourceEvidenceId,f.source.id);
});

test('a previously opposed exact claim cannot be used as provisional bootstrap evidence',async t=>{
 const f=await fixture(t);
 const assignment=newReporterAssignment(f.context,f.packet,{reporterSources:f.packet.reporterSources,at});
 const [entry]=assignment.initialClaimEntries;
 recordNewsroom(f.root,'claim',entry.cell,{told:{for:true,against:true}});
 assert.throws(()=>newReporterAssignment(f.context,f.packet,{reporterSources:f.packet.reporterSources,at}),/no held|opposed/);
});

test('NEW claims route cannot rename an observed prior-publication identity',async t=>{
 const f=await fixture(t),oldSlug='already-published';
 const observed='news-property.published:'+Buffer.from(JSON.stringify({origin:f.context.property.origin,slug:oldSlug})).toString('base64url');
 f.context.property.content.legacyPublishedSections={[oldSlug]:'world'};
 writeFileSync(join(f.context.propertyContentDir,'posts',oldSlug+'.md'),'Existing prior article');
 const claim=admitClaimEvidence({storyId:observed,section:'world',sourceId:f.source.content.leadId,sourceUrl:f.url,sourceEvidenceId:f.source.id,host:new URL(f.url).hostname,...f.packet.reporterSources[0].claims[0],quoteStart:0,quoteEnd:quote.length},f.source);
 recordNewsroom(f.root,'claim',claim);
 await assert.rejects(reportArticle(f.context,{...f.packet,storyId:observed,slug:'renamed-old-publication'},f.ports),/existing newsroom|published|revision|NEW/i);
});

test('held-claim retry preserves its origin while separate arrivals retain distinct evidence',async t=>{
 const f=await fixture(t);
 assert.equal((await reportArticle(f.context,f.packet,f.ports)).claimsAdded,1);
 const retry=await reportArticle(f.context,f.packet,f.ports);
 assert.equal(retry.claimsAdded,0);assert.equal(retry.results[0].sourceEvidenceId,f.source.id);
 assert.equal(readNewsroom(f.root,'reporting-source').length,0);
 openEdition(f.context.roots,{candidateId:'retried-candidate',storyId:f.storyId,section:'world',slug:f.packet.slug,state:'released',releasedAt:at,draftedAt:at});
 const event=sourceArrivalFromObservation({feed:f.feed,item:{externalId:'duplicate-after-retry',url:f.url,title:'Agency Delta coastal study repeated after retry',published:at},observedAt:at});
 const second=projectArrivalsToStore([event],f.root,new Map([['fixture-wire',['world']]]))[0];
 recordSourceEvidence(f.root,admitSourceEvidence({id:second.id,url:f.url},{type:'PublicWebSource',...f.source.content}),at);
 assert.equal((await reportArticle(f.context,{...f.packet,storyId:second.id,slug:'duplicate-after-retry'},f.ports)).claimsAdded,1);
 assert.equal(readNewsroom(f.root,'claim').length,2);assert.equal(readNewsroom(f.root,'reporting-source').length,0);
 assert.deepEqual(globalThis.__koiosQualificationGuardCalls??[],[]);
});
test('held-claim retry prefers the canonical carrier over newly held shadow sources',async t=>{
 const f=await fixture(t);assert.equal((await reportArticle(f.context,f.packet,f.ports)).claimsAdded,1);
 let first;
 for(let i=0;i<20;i++){
  recordSourceEvidence(f.root,admitSourceEvidence({id:'new-shadow-'+i,url:f.url},{type:'PublicWebSource',...f.source.content,finalUrl:'https://elsewhere.example/same-text'}),at);
  first=readNewsroom(f.root,'source-evidence').map(row=>row.record).find(cell=>cell.content.requestedUrl===f.url&&cell.content.textDigest===f.source.content.textDigest);
  if(first.id!==f.source.id)break;
 }
 assert.notEqual(first.id,f.source.id);
 const retry=await reportArticle(f.context,f.packet,f.ports);
 assert.equal(retry.claimsAdded,0);assert.equal(retry.results[0].sourceEvidenceId,f.source.id);
 assert.equal(readNewsroom(f.root,'claim').length,1);assert.equal(readNewsroom(f.root,'reporting-source').length,0);noPublication(f);
});
