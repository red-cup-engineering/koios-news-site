import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {
  KOIOS_NODE_ACCOUNT,
  KOIOS_NEWSROOM_SCHEDULE_ID,
  KOIOS_PUBLICATION_SCHEDULE_ID,
  koiosNodeScheduleDeclarations,
} from "../src/node-schedules.mjs";
import {KOIOS_SERVICE_ENTERPRISE} from "../src/service-identity.mjs";

const newsroomFirstDueAt="2026-10-13T02:00:00.000Z";
const publicationFirstDueAt="2026-10-13T03:00:00.000Z";

test("owned property cadence drives the complete existing Koios editorial and publishing service line",()=>{
  const property=JSON.parse(readFileSync(new URL("../config/koios-news-property.json", import.meta.url),"utf8"));
  assert.equal(property.cadence.dailyArticleTarget,20);
  assert.equal(property.cadence.pulseIntervalMinutes,15);
  const schedules=koiosNodeScheduleDeclarations({newsroomFirstDueAt,publicationFirstDueAt,
    pulseIntervalMinutes:property.cadence.pulseIntervalMinutes});
  assert.equal(schedules.length,2);
  assert.equal(KOIOS_NODE_ACCOUNT,KOIOS_SERVICE_ENTERPRISE);
  assert.deepEqual(schedules.map(s=>s.id),[KOIOS_NEWSROOM_SCHEDULE_ID,KOIOS_PUBLICATION_SCHEDULE_ID]);
  assert.equal(schedules[0].verb,"koios-news-cycle");
  assert.equal(schedules[0].everySeconds,15*60);
  assert.equal(schedules[0].firstDueAt,newsroomFirstDueAt);
  assert.equal(schedules[0].account,KOIOS_NODE_ACCOUNT);
  assert.equal(schedules[1].verb,"koios-news-status");
  assert.equal(schedules.filter(s=>s.verb==="koios-news-cycle").length,1);
  assert.ok(schedules.every(s=>s.verb!=="koios-routine-publication"),
    "a second automatic publisher must never consume the main line authority queue");
  assert.equal(schedules[1].everySeconds,24*60*60);
  assert.ok(Object.isFrozen(schedules));
});
test("cadence and first-due times refuse invalid deployment inputs",()=>{
  const inputs={newsroomFirstDueAt,publicationFirstDueAt};
  for(const bad of [0,1.5,-15,"15",null,NaN,Number.MAX_SAFE_INTEGER]){
    assert.throws(()=>koiosNodeScheduleDeclarations({...inputs,pulseIntervalMinutes:bad}),/cadence/);
  }
  assert.equal(koiosNodeScheduleDeclarations({...inputs,pulseIntervalMinutes:5})[0].everySeconds,300);
  assert.equal(koiosNodeScheduleDeclarations({...inputs,pulseIntervalMinutes:60})[0].everySeconds,3600);
  assert.throws(()=>koiosNodeScheduleDeclarations({...inputs,newsroomFirstDueAt:"tomorrow"}),/ISO 8601/);
  assert.throws(()=>koiosNodeScheduleDeclarations({...inputs,publicationFirstDueAt:"2026-10-13T03:00:00Z"}),/canonical UTC/);
});


test('the existing publication recurrence receives independent work through the same leased service line',()=>{
 const inputs={newsroomFirstDueAt,publicationFirstDueAt,pulseIntervalMinutes:15,newsroomJob:{deployment:'koios-news',job:'newsroom-cycle'},publicationJob:{deployment:'koios-news',job:'editorial-delivery'}};
 const rows=koiosNodeScheduleDeclarations(inputs);assert.equal(rows.length,2);assert.equal(rows[1].id,KOIOS_PUBLICATION_SCHEDULE_ID);
 assert.equal(rows[1].verb,'node-job-run');assert.deepEqual(rows[1].input,inputs.publicationJob);assert.equal(rows[1].everySeconds,900);
 assert.throws(()=>koiosNodeScheduleDeclarations({...inputs,publicationJob:inputs.newsroomJob}),/distinct native job/u);
 for(const invalid of [{},null,{deployment:'koios-news',job:'../other'}])assert.throws(()=>koiosNodeScheduleDeclarations({...inputs,publicationJob:invalid}),/publicationJob/u);
 assert.equal(koiosNodeScheduleDeclarations({...inputs,pulseIntervalMinutes:1})[1].everySeconds,60);
 assert.equal(koiosNodeScheduleDeclarations({...inputs,pulseIntervalMinutes:61})[1].everySeconds,3660);
});


test('slow inference duties have independent native jobs under the same clock',()=>{
 const options={newsroomFirstDueAt,publicationFirstDueAt,newsroomJob:{deployment:'koios-news',job:'newsroom-cycle'},publicationJob:{deployment:'koios-news',job:'editorial-delivery'},inferenceStageJobs:{draft:{deployment:'koios-news',job:'editorial-drafting'},assess:{deployment:'koios-news',job:'editorial-assessment'}}};
 const rows=koiosNodeScheduleDeclarations(options);assert.equal(rows.length,4);assert.equal(new Set(rows.map(x=>x.input.job)).size,4);assert.ok(rows.every(x=>x.everySeconds===900));assert.ok(rows.every(x=>x.verb==='node-job-run'));
 assert.throws(()=>koiosNodeScheduleDeclarations({...options,inferenceStageJobs:{publish:{}}}),/existing draft and assess/u);
});
