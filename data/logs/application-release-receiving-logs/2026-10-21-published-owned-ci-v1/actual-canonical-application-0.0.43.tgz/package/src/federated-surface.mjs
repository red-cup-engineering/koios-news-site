import { authorizationFromStanding } from "@red-cup-engineering/computer-system-engine/rpc/dispatch";
import { createOperationCatalog } from "@red-cup-engineering/computer-system-engine/rpc/operation";

import { koiosNewsOperations } from "./operations.mjs";

export const KOIOS_FEDERATED_VERBS = Object.freeze([
  "koios-service-section",
  "koios-settle-message",
]);

/**
 * Operations Koios intentionally exposes at its inter-enterprise boundary.
 *
 * The offered research/editorial services remain encoded inside exact
 * ActivityStreams solicit/accept exchanges handled by koios-settle-message.
 * Newsroom, queue, schedule, audit and publication operations are omitted
 * from this catalog entirely rather than relying on a transport to hide them.
 */
export function koiosFederatedOperations() {
  const byVerb = new Map(koiosNewsOperations().map((item) => [item.verb, item]));
  const selected = KOIOS_FEDERATED_VERBS.map((verb) => {
    const item = byVerb.get(verb);
    if (item === undefined) throw new Error(`Koios federated boundary is missing declared operation: ${verb}`);
    return item;
  });
  return Object.freeze(selected);
}

/**
 * Compose the protocol-facing Koios service surface.
 *
 * "Held" here means these two boundary operations exist as public service
 * affordances. It does not grant the caller newsroom or publication authority:
 * settle-message still admits only the exact ActivityStreams service contracts
 * advertised by service-section.mjs, and no other Koios operation is present.
 *
 * Transport authentication/rate policy belongs to the eventual network host and
 * is intentionally not fabricated by this pure composition layer.
 */
export function createKoiosFederatedSurface() {
  const operations = koiosFederatedOperations();
  const authorize = authorizationFromStanding(
    new Map(operations.map((item) => [item.ref, "held"])),
    "koios-federated-service-boundary",
  );
  return Object.freeze({
    operations,
    catalog: createOperationCatalog(operations),
    authorize,
  });
}
