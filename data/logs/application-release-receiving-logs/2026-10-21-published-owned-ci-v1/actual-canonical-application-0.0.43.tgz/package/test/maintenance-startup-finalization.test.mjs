import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,copyFileSync,rmSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
import {once} from 'node:events';
const root=fileURLToPath(new URL('..',import.meta.url));
const held={kind:'koios.news.observed-feedback/v1',observedAt:'2026-10-12T06:34:00.000Z',sensors:{newsroom:{status:'unavailable',observedAt:'2026-10-12T06:33:00.000Z'},cloudMaintenance:{status:'running',observedAt:'2026-10-12T06:34:00.000Z',unit:{LoadState:'loaded',ActiveState:'activating',Result:'success'}}},articles:[{slug:'held'}]};
function fixture(snapshot=JSON.stringify(held)){
 const dir=mkdtempSync(join(tmpdir(),'koios-startup-')),home=join(dir,'home'),runtime=join(dir,'runtime'),data=join(dir,'data'),bin=join(dir,'bin');
 for(const p of [join(home,'.local/state'),join(home,'work/koios-news-maintenance/.git'),join(home,'work/koios-news-maintenance/data'),join(runtime,'deploy'),join(runtime,'scripts'),join(runtime,'node_modules'),join(data,'feedback'),bin])mkdirSync(p,{recursive:true});
 // Execute the actual owning shell with only its fixed host directory relocated.
 // The actual cloud checkout has an initialized data submodule before publisher admission.
 // Every git/node/codex effect is an isolated fixture boundary, never a live API.
 const source=process.env.KOIOS_MAINTENANCE_TEST_SOURCE??join(root,'deploy/maintain-newsroom.sh');
 writeFileSync(join(runtime,'deploy/maintain-newsroom.sh'),readFileSync(source,'utf8').replaceAll('/home/emsenn',home));
 copyFileSync(join(root,'deploy/maintenance-finalization.sh'),join(runtime,'deploy/maintenance-finalization.sh'));
 writeFileSync(join(runtime,'deploy/maintenance-duty.txt'),'isolated fixture duty\n');
 copyFileSync(join(root,'scripts/finish-maintenance-feedback.mjs'),join(runtime,'scripts/finish-maintenance-feedback.mjs'));
 copyFileSync(join(root,'scripts/publish-feedback.mjs'),join(runtime,'scripts/publish-feedback-preflight.mjs'));
 copyFileSync(join(root,'scripts/push-data.mjs'),join(runtime,'scripts/push-data.mjs'));
 // The genuine recorder CLI and publisher process supervisor run unchanged.
 // Only the existing publisher subprocess boundary is replaced by a marker.
 writeFileSync(join(runtime,'scripts/publish-feedback.mjs'),`import{appendFileSync}from'node:fs';import{join}from'node:path';if(process.cwd()!==${JSON.stringify(join(home,'work/koios-news-maintenance'))})throw Error('publisher reached wrong carrier');appendFileSync(join(process.env.KOIOS_NEWSROOM_DATA_ROOT,'published'),'called\\n');`);
 writeFileSync(join(bin,'git'),'#!/usr/bin/bash\nif [[ "$1" == fetch && "$FIXTURE_STAGE" == git-fetch ]] || [[ "$1" == clone && "$FIXTURE_STAGE" == git-clone ]]; then exit "$FIXTURE_EXIT"; fi\nexit 0\n',{mode:0o755});
 writeFileSync(join(bin,'mkdir'),'#!/usr/bin/bash\nif [[ "$FIXTURE_STAGE" == prepare-directory ]]; then exit "$FIXTURE_EXIT"; fi\nexec /usr/bin/mkdir "$@"\n',{mode:0o755});
 writeFileSync(join(bin,'gh'),'#!/usr/bin/bash\nif [[ "$*" == "api user" ]]; then printf \'{"login":"fixture-owner"}\\n\'; else exit 95; fi\n',{mode:0o755});
 writeFileSync(join(bin,'node'),`#!/usr/bin/bash\ncase "$1" in\n */finish-maintenance-feedback.mjs) exec ${JSON.stringify(process.execPath)} "$@" ;;\n */collect-feedback.mjs) stage=collect ;;\n */research-standards.mjs) stage=standards ;;\n */publish-feedback.mjs) stage=publish ;;\n *) exit 99 ;;\nesac\nif [[ "$stage" == publish && "$FIXTURE_STAGE" == missing-standards ]]; then exec ${JSON.stringify(process.execPath)} ${JSON.stringify(join(runtime,"scripts/publish-feedback-preflight.mjs"))}; fi\nif [[ "$stage" == "$FIXTURE_STAGE" ]]; then exit "$FIXTURE_EXIT"; fi\nexit 0\n`,{mode:0o755});
 writeFileSync(join(bin,'codex'),'#!/usr/bin/bash\nif [[ "$FIXTURE_STAGE" == codex ]]; then exit "$FIXTURE_EXIT"; fi\nexit 0\n',{mode:0o755});
 if(snapshot!==null)writeFileSync(join(data,'feedback/latest.json'),snapshot);
 return {dir,home,runtime,data,bin};
}
function run(f,stage,exit='42'){
 if(stage==='git-clone')rmSync(join(f.home,'work/koios-news-maintenance/.git'),{recursive:true,force:true});
 return spawnSync('/usr/bin/bash',[join(f.runtime,'deploy/maintain-newsroom.sh')],{env:{PATH:f.bin+':/usr/bin:/bin',HOME:f.home,KOIOS_NEWSROOM_DATA_ROOT:f.data,FIXTURE_STAGE:stage,FIXTURE_EXIT:exit},encoding:'utf8',timeout:5000});
}
for(const stage of ['prepare-directory','git-clone','git-fetch','collect','standards','publish','codex'])test(`actual owning script records ${stage} failure without freshening prior facts`,()=>{
 const f=fixture();try{
  const result=run(f,stage);assert.equal(result.status,42,result.stderr);assert.equal(result.signal,null);
  const snapshot=JSON.parse(readFileSync(join(f.data,'feedback/latest.json'),'utf8'));
  assert.equal(snapshot.sensors.cloudMaintenance.attempt?.exitCode,42,result.stderr);
  assert.equal(snapshot.sensors.cloudMaintenance.attempt?.status,'failed');
  assert.equal(snapshot.observedAt,held.observedAt);assert.deepEqual(snapshot.articles,held.articles);assert.deepEqual(snapshot.sensors.newsroom,held.sensors.newsroom);
  assert.equal(snapshot.sensors.cloudMaintenance.unitObservedAt,held.sensors.cloudMaintenance.observedAt);
  if(stage==='codex'||stage==='standards')assert.equal(readFileSync(join(f.data,'published'),'utf8'),'called\ncalled\n','the initial publication and completed finalization are separate effects');
  else assert.equal(existsSync(join(f.data,'published')),false,'incomplete startup must not replay publication');
 }finally{rmSync(f.dir,{recursive:true,force:true});}
});
test('a successful actual owning script retains its zero exit and reports once',()=>{
 const f=fixture();try{const result=run(f,'none','0');assert.equal(result.status,0,result.stderr);assert.equal(JSON.parse(readFileSync(join(f.data,'feedback/latest.json'),'utf8')).sensors.cloudMaintenance.attempt.exitCode,0);assert.equal(readFileSync(join(f.data,'published'),'utf8'),'called\ncalled\n');}finally{rmSync(f.dir,{recursive:true,force:true});}
});
for(const snapshot of [null,'invalid JSON','{}'])test(`incomplete feedback ${snapshot??'missing'} preserves original failure and uncertainty`,()=>{
 const f=fixture(snapshot);try{
  const result=run(f,'collect');assert.equal(result.status,42,result.stderr);assert.equal(existsSync(join(f.data,'published')),false);
  const path=join(f.data,'feedback/latest.json');if(snapshot===null)assert.equal(existsSync(path),false);else assert.equal(readFileSync(path,'utf8'),snapshot);
  assert.match(result.stderr,/original work exit 42 is preserved/);
 }finally{rmSync(f.dir,{recursive:true,force:true});}
});
test('unsuccessful lock acquisition runs no finalizer and never fabricates an attempt',async()=>{
 const f=fixture();let locker;
 try{
  locker=spawn('/usr/bin/bash',['-c',`exec 9>${JSON.stringify(join(f.home,'.local/state/koios-news-maintenance.lock'))}; flock -x 9; echo LOCKED; read -r waiting`],{stdio:['pipe','pipe','pipe']});
  await once(locker.stdout,'data');const result=run(f,'collect');assert.equal(result.status,0,result.stderr);assert.equal(result.stdout,'');assert.equal(existsSync(join(f.data,'published')),false);assert.deepEqual(JSON.parse(readFileSync(join(f.data,'feedback/latest.json'),'utf8')),held);
 }finally{if(locker){const done=once(locker,'close');locker.stdin.end();await done;}rmSync(f.dir,{recursive:true,force:true});}
});

test('actual initial publisher missing standards stops once at the prepared data carrier',()=>{
 const f=fixture();try{
  const result=run(f,'missing-standards');assert.equal(result.status,1,result.stderr);assert.match(result.stderr,/ENOENT/);
  const heldPath=join(f.data,'feedback/latest.json');
  assert.equal(JSON.parse(readFileSync(heldPath,'utf8')).sensors.cloudMaintenance.attempt.exitCode,1);
  assert.equal(existsSync(join(f.data,'published')),false,'finalization must not replay a partly attempted initial publication');
  const prepared=join(f.home,'work/koios-news-maintenance/data/feedback/latest.json');
  assert.deepEqual(JSON.parse(readFileSync(prepared,'utf8')),held,'the genuine initial publisher used checkout/data and copied only the old observation');
 }finally{rmSync(f.dir,{recursive:true,force:true});}
});
test('genuine record-only CLI never starts even a missing publisher and refuses arbitrary modes',()=>{
 const f=fixture();try{
  rmSync(join(f.runtime,'scripts/publish-feedback.mjs'));
  const invoke=mode=>spawnSync(process.execPath,[join(f.runtime,'scripts/finish-maintenance-feedback.mjs'),'42','2026-10-12T00:00:00Z','123',mode],{env:{KOIOS_NEWSROOM_DATA_ROOT:f.data},encoding:'utf8',timeout:5000});
  assert.equal(invoke('record-only').status,0);
  const path=join(f.data,'feedback/latest.json'),completed=readFileSync(path,'utf8');assert.equal(JSON.parse(completed).sensors.cloudMaintenance.attempt.exitCode,42);
  const invalid=invoke('../arbitrary-publisher');assert.equal(invalid.status,1);assert.equal(readFileSync(path,'utf8'),completed);assert.equal(invalid.stderr.includes('arbitrary-publisher'),false);
 }finally{rmSync(f.dir,{recursive:true,force:true});}
});
