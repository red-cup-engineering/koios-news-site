// source-roll - configured newscable intake plus local wire-store evidence.
//
// A publication may classify its sources editorially, but the roll itself is
// cable substrate: read the newscable config, resolve each wire's local store,
// and report what configured sources and stored evidence exist.

import { schemaFrom } from "@red-cup-engineering/json-schema-services-section/contracts";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { dirname, join, resolve } from "node:path";

import { jsonToTerm } from "@red-cup-engineering/computer-data-engineering-services-section/semiotic-expression-notation/json-codec";
import { requireJsonValue } from "@red-cup-engineering/json-services-section";
import { DEFAULT_WIRE_STORE, NEWSCABLE_CONFIG_BLOCK, assertNewscableBlock } from "./discovery.mjs";

export const SourceRollSourceSchema = Object.freeze({
  "type": "object",
  "properties": {
    "kind": {
      "const": "producing-content.source-roll.source"
    },
    "wire": {
      "type": "string",
      "minLength": 1
    },
    "beat": {
      "type": "string",
      "minLength": 1
    },
    "adapter": {
      "type": "string",
      "minLength": 1
    },
    "url": {
      "type": "string"
    },
    "query": {
      "type": "string"
    },
    "domain": {
      "type": "string"
    },
    "max": {
      "type": "number"
    },
    "sourceKind": {
      "type": "string",
      "minLength": 1
    },
    "sourceClass": {
      "type": "string",
      "minLength": 1
    },
    "editorialRole": {
      "type": "string",
      "minLength": 1
    },
    "wireItemCount": {
      "type": "number"
    },
    "latestWireItemAt": {
      "type": "string"
    }
  },
  "required": [
    "kind",
    "wire",
    "beat",
    "adapter",
    "sourceKind",
    "sourceClass",
    "editorialRole",
    "wireItemCount"
  ],
  "additionalProperties": false
});

export const SourceRollWireSchema = Object.freeze({
  "type": "object",
  "properties": {
    "kind": {
      "const": "producing-content.source-roll.wire"
    },
    "name": {
      "type": "string",
      "minLength": 1
    },
    "title": {
      "type": "string",
      "minLength": 1
    },
    "description": {
      "type": "string"
    },
    "sourceCount": {
      "type": "number"
    },
    "wireItemCount": {
      "type": "number"
    },
    "latestWireItemAt": {
      "type": "string"
    },
    "sources": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "kind": {
            "const": "producing-content.source-roll.source"
          },
          "wire": {
            "type": "string",
            "minLength": 1
          },
          "beat": {
            "type": "string",
            "minLength": 1
          },
          "adapter": {
            "type": "string",
            "minLength": 1
          },
          "url": {
            "type": "string"
          },
          "query": {
            "type": "string"
          },
          "domain": {
            "type": "string"
          },
          "max": {
            "type": "number"
          },
          "sourceKind": {
            "type": "string",
            "minLength": 1
          },
          "sourceClass": {
            "type": "string",
            "minLength": 1
          },
          "editorialRole": {
            "type": "string",
            "minLength": 1
          },
          "wireItemCount": {
            "type": "number"
          },
          "latestWireItemAt": {
            "type": "string"
          }
        },
        "required": [
          "kind",
          "wire",
          "beat",
          "adapter",
          "sourceKind",
          "sourceClass",
          "editorialRole",
          "wireItemCount"
        ],
        "additionalProperties": false
      }
    }
  },
  "required": [
    "kind",
    "name",
    "title",
    "sourceCount",
    "wireItemCount",
    "sources"
  ],
  "additionalProperties": false
});

export const SourceRollSchema = Object.freeze({
  "$id": "producing-content/cable/source-roll",
  "type": "object",
  "properties": {
    "kind": {
      "const": "producing-content.source-roll"
    },
    "configPath": {
      "type": "string",
      "minLength": 1
    },
    "generatedAt": {
      "type": "string",
      "minLength": 1
    },
    "wireCount": {
      "type": "number"
    },
    "sourceCount": {
      "type": "number"
    },
    "wireItemCount": {
      "type": "number"
    },
    "wires": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "kind": {
            "const": "producing-content.source-roll.wire"
          },
          "name": {
            "type": "string",
            "minLength": 1
          },
          "title": {
            "type": "string",
            "minLength": 1
          },
          "description": {
            "type": "string"
          },
          "sourceCount": {
            "type": "number"
          },
          "wireItemCount": {
            "type": "number"
          },
          "latestWireItemAt": {
            "type": "string"
          },
          "sources": {
            "type": "array",
            "items": {
              "type": "object",
              "properties": {
                "kind": {
                  "const": "producing-content.source-roll.source"
                },
                "wire": {
                  "type": "string",
                  "minLength": 1
                },
                "beat": {
                  "type": "string",
                  "minLength": 1
                },
                "adapter": {
                  "type": "string",
                  "minLength": 1
                },
                "url": {
                  "type": "string"
                },
                "query": {
                  "type": "string"
                },
                "domain": {
                  "type": "string"
                },
                "max": {
                  "type": "number"
                },
                "sourceKind": {
                  "type": "string",
                  "minLength": 1
                },
                "sourceClass": {
                  "type": "string",
                  "minLength": 1
                },
                "editorialRole": {
                  "type": "string",
                  "minLength": 1
                },
                "wireItemCount": {
                  "type": "number"
                },
                "latestWireItemAt": {
                  "type": "string"
                }
              },
              "required": [
                "kind",
                "wire",
                "beat",
                "adapter",
                "sourceKind",
                "sourceClass",
                "editorialRole",
                "wireItemCount"
              ],
              "additionalProperties": false
            }
          }
        },
        "required": [
          "kind",
          "name",
          "title",
          "sourceCount",
          "wireItemCount",
          "sources"
        ],
        "additionalProperties": false
      }
    },
    "byClass": {
      "type": "object",
      "additionalProperties": {
        "type": "number"
      }
    },
    "bySourceKind": {
      "type": "object",
      "additionalProperties": {
        "type": "number"
      }
    },
    "constraints": {
      "type": "array",
      "items": {
        "type": "string"
      }
    }
  },
  "required": [
    "kind",
    "configPath",
    "generatedAt",
    "wireCount",
    "sourceCount",
    "wireItemCount",
    "wires",
    "byClass",
    "bySourceKind",
    "constraints"
  ],
  "title": "CableSourceRoll",
  "additionalProperties": false
});

export const sourceRollCarrier = schemaFrom(SourceRollSchema);

const DEFAULT_CLASSIFICATION = Object.freeze({
  sourceKind: "unknown",
  sourceClass: "unknown",
  editorialRole: "Configured intake source; classification has not been curated yet.",
});

function isRecord(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function text(value, fallback = "") {
  return typeof value === "string" && value.trim() !== "" ? value.trim() : fallback;
}

function optionalText(value) {
  const string = text(value);
  return string === "" ? undefined : string;
}

function optionalInteger(value) {
  return typeof value === "number" && Number.isInteger(value) && value >= 0 ? value : undefined;
}

function domainOf(url) {
  if (url === undefined) return undefined;
  try {
    return new URL(url).hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return undefined;
  }
}

function readConfig(configPath) {
  const parsed = JSON.parse(readFileSync(configPath, "utf8"));
  if (!isRecord(parsed)) throw new TypeError("source roll config must be a JSON object");
  const block = parsed[NEWSCABLE_CONFIG_BLOCK];
  if (block !== undefined) assertNewscableBlock(block);
  return parsed;
}

function wireStoreStats(storeDir) {
  if (!existsSync(storeDir)) return Object.freeze({ count: 0 });
  let count = 0;
  let latest = 0;
  for (const entry of readdirSync(storeDir, { withFileTypes: true })) {
    if (!entry.isFile() || !entry.name.endsWith(".json")) continue;
    count += 1;
    const mtime = statSync(join(storeDir, entry.name)).mtimeMs;
    if (mtime > latest) latest = mtime;
  }
  return Object.freeze({
    count,
    ...(latest === 0 ? {} : { latestAt: new Date(latest).toISOString() }),
  });
}

function increment(counts, key) {
  counts[key] = (counts[key] ?? 0) + 1;
}

export function sourceRollReading(options) {
  const configPath = options.configPath;
  const config = readConfig(configPath);
  const cable = isRecord(config[NEWSCABLE_CONFIG_BLOCK]) ? config[NEWSCABLE_CONFIG_BLOCK] : {};
  const cableDir = dirname(resolve(configPath));
  const rawWires = Array.isArray(cable["wires"]) ? cable["wires"] : [];
  const byClass = {};
  const bySourceKind = {};
  const classify = options.classify ?? (() => DEFAULT_CLASSIFICATION);
  const wires = rawWires.flatMap((rawWire) => {
    if (!isRecord(rawWire)) return [];
    const name = text(rawWire["name"], "unnamed-wire");
    const storeDir = resolve(cableDir, text(rawWire["store"], join(DEFAULT_WIRE_STORE, name)));
    const store = wireStoreStats(storeDir);
    const rawSources = Array.isArray(rawWire["sources"]) ? rawWire["sources"] : [];
    const sources = rawSources.flatMap((rawSource) => {
      if (!isRecord(rawSource)) return [];
      const url = optionalText(rawSource["url"]);
      const query = optionalText(rawSource["query"]);
      const domain = domainOf(url);
      const classification = classify({ wire: name, source: rawSource, ...(domain === undefined ? {} : { domain }) });
      increment(byClass, classification.sourceClass);
      increment(bySourceKind, classification.sourceKind);
      return [{
        kind: "producing-content.source-roll.source",
        wire: name,
        beat: name,
        adapter: text(rawSource["adapter"], "unknown"),
        ...(url === undefined ? {} : { url }),
        ...(query === undefined ? {} : { query }),
        ...(domain === undefined ? {} : { domain }),
        ...(optionalInteger(rawSource["max"]) === undefined ? {} : { max: optionalInteger(rawSource["max"]) }),
        sourceKind: classification.sourceKind,
        sourceClass: classification.sourceClass,
        editorialRole: classification.editorialRole,
        wireItemCount: store.count,
        ...(store.latestAt === undefined ? {} : { latestWireItemAt: store.latestAt }),
      }];
    });
    return [{
      kind: "producing-content.source-roll.wire",
      name,
      title: text(rawWire["title"], name),
      ...(optionalText(rawWire["description"]) === undefined ? {} : { description: optionalText(rawWire["description"]) }),
      sourceCount: sources.length,
      wireItemCount: store.count,
      ...(store.latestAt === undefined ? {} : { latestWireItemAt: store.latestAt }),
      sources: [...sources],
    }];
  });
  return sourceRollCarrier.assert({
    kind: "producing-content.source-roll",
    configPath,
    generatedAt: (options.now ?? (() => new Date().toISOString()))(),
    wireCount: wires.length,
    sourceCount: wires.reduce((sum, wire) => sum + wire.sourceCount, 0),
    wireItemCount: wires.reduce((sum, wire) => sum + wire.wireItemCount, 0),
    wires: [...wires],
    byClass: Object.freeze(byClass),
    bySourceKind: Object.freeze(bySourceKind),
    constraints: [...(options.constraints ?? [
      "This is configured intake, not an endorsement of every item a source publishes.",
      "The wire store is append-only and idempotent; present counts describe locally owned evidence bundles.",
    ])],
  }, "producing-content source roll");
}

export function sourceRollTerm(input) {
  return jsonToTerm(requireJsonValue(sourceRollCarrier.assert(input), "producing-content source roll"));
}
