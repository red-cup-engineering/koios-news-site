import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,rmSync,existsSync,copyFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {setTimeout as pause} from 'node:timers/promises';
import {completedMaintenanceFeedback,finishMaintenanceFeedback,maintenanceUnitObservation,maintenanceFailureCode,publishMaintenanceFeedback} from '../scripts/finish-maintenance-feedback.mjs';

const root=fileURLToPath(new URL('..',import.meta.url)),start='2026-10-11T02:57:10Z',finish='2026-10-11T03:05:00.000Z';
const unit={LoadState:'loaded',ActiveState:'activating',Result:'success',ExecMainStatus:'0',ExecMainExitTimestamp:''};
const initial=()=>({kind:'koios.news.observed-feedback/v1',observedAt:start,sensors:{cloudMaintenance:{status:'running',observedAt:start,unit:{...unit}},newsroom:{status:'unavailable',observedAt:start,reason:'draft: stage-threw'}},articles:[{slug:'held',words:120}]});
const options={exitCode:0,startedAt:start,finishedAt:finish,processId:123};

test('activating is running, not a completed successful attempt',()=>{
 assert.deepEqual(maintenanceUnitObservation(unit),{status:'running',unit});
 assert.equal(maintenanceUnitObservation({...unit,ActiveState:'inactive',ExecMainExitTimestamp:finish}).status,'observed');
 assert.throws(()=>maintenanceUnitObservation({...unit,ActiveState:'failed',Result:'exit-code',ExecMainStatus:'42'}),error=>error.observation.unit.ExecMainStatus==='42');
});
test('completion binds bounded process facts while preserving separate prior unit and other sensor times',()=>{
 const before=initial(),result=completedMaintenanceFeedback(before,options),sensor=result.sensors.cloudMaintenance;
 assert.equal(sensor.status,'observed');assert.equal(sensor.attempt.exitCode,0);assert.equal(sensor.attempt.status,'succeeded');
 assert.equal(sensor.attempt.startedAt,start);assert.equal(sensor.attempt.finishedAt,finish);assert.equal(sensor.observedAt,finish);
 assert.deepEqual(sensor.unit,unit);assert.equal(sensor.unitObservedAt,start);assert.equal(sensor.unit.ActiveState,'activating');
 assert.equal(result.observedAt,start);assert.deepEqual(result.sensors.newsroom,before.sensors.newsroom);assert.deepEqual(result.articles,before.articles);
 assert.equal(before.sensors.cloudMaintenance.status,'running');assert.equal(sensor.reason,undefined);
 assert.match(sensor.attempt.id,/^koios-maintenance:[a-f0-9]{32}$/);
 assert.equal(completedMaintenanceFeedback(before,options).sensors.cloudMaintenance.attempt.id,sensor.attempt.id);
 assert.notEqual(completedMaintenanceFeedback(before,{...options,processId:124}).sensors.cloudMaintenance.attempt.id,sensor.attempt.id);
});
test('nonzero and timeout exits remain failed outcomes even when the earlier unit result was success',()=>{
 for(const exitCode of [1,42,124,129,130,137,143,255]){
  const sensor=completedMaintenanceFeedback(initial(),{...options,exitCode}).sensors.cloudMaintenance;
  assert.equal(sensor.status,'unavailable');assert.equal(sensor.attempt.status,'failed');assert.equal(sensor.attempt.exitCode,exitCode);
  assert.match(sensor.reason,new RegExp('exited '+exitCode+' at'));assert.equal(sensor.unit.Result,'success');assert.equal(sensor.unitObservedAt,start);
 }
});
test('invalid outcome inputs are refused without accepting unbounded output or secret-bearing errors',()=>{
 for(const exitCode of [-1,256,1.5,NaN,'0'])assert.throws(()=>completedMaintenanceFeedback(initial(),{...options,exitCode}));
 for(const patch of [{startedAt:'yesterday'},{finishedAt:'2026-10-10T00:00:00Z'},{processId:0},{processId:'123'}])assert.throws(()=>completedMaintenanceFeedback(initial(),{...options,...patch}));
 assert.throws(()=>completedMaintenanceFeedback({},options));
 assert.equal(maintenanceFailureCode(new Error('credential-or-session-output')), 'record-or-publication-failed');
 assert.equal(maintenanceFailureCode({code:'arbitrary-secret',name:'arbitrary-secret'}),'record-or-publication-failed');
 assert.equal(maintenanceFailureCode({code:'ENOSPC'}),'ENOSPC');
 assert.equal(maintenanceFailureCode(new SyntaxError('private malformed JSON')),'SyntaxError');
 const sensor=completedMaintenanceFeedback({...initial(),sensors:{cloudMaintenance:{...initial().sensors.cloudMaintenance,stdout:'private stdout',reason:'private prior reason',unit:{...unit,Secret:'private unit field'}}}},options).sensors.cloudMaintenance;
 assert.equal(JSON.stringify(sensor).includes('private'),false);
});
test('actual atomic recording precedes the injected publication seam and survives publication failure',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'koios-final-observation-')),path=join(dir,'latest.json');
 try{
  writeFileSync(path,JSON.stringify(initial()));let calls=0;
  await finishMaintenanceFeedback({feedbackRoot:dir,exitCode:42,startedAt:start,processId:123,now:()=>finish,publish:()=>{calls++;assert.equal(JSON.parse(readFileSync(path)).sensors.cloudMaintenance.attempt.exitCode,42);}});
  assert.equal(calls,1);
  await assert.rejects(finishMaintenanceFeedback({feedbackRoot:dir,exitCode:124,startedAt:start,processId:123,now:()=>finish,publish:()=>{throw new Error('publication fixture failed');}}),/publication fixture failed/);
  assert.equal(JSON.parse(readFileSync(path)).sensors.cloudMaintenance.attempt.exitCode,124);
  writeFileSync(path,'invalid JSON');let published=false;
  await assert.rejects(finishMaintenanceFeedback({feedbackRoot:dir,exitCode:0,startedAt:start,processId:123,now:()=>finish,publish:()=>{published=true;}}));
  assert.equal(published,false);assert.equal(readFileSync(path,'utf8'),'invalid JSON');
 }finally{rmSync(dir,{recursive:true,force:true});}
});

function fixture(){
 const dir=mkdtempSync(join(tmpdir(),'koios-final-shell-')),runtime=join(dir,'runtime'),data=join(dir,'data');
 mkdirSync(join(runtime,'scripts'),{recursive:true});mkdirSync(join(data,'feedback'),{recursive:true});
 writeFileSync(join(data,'feedback','latest.json'),JSON.stringify(initial()));
 // The actual recorder/finalizer runs. This isolated publisher seam only writes a local marker.
 writeFileSync(join(runtime,'scripts','finish-maintenance-feedback.mjs'),`import{finishMaintenanceFeedback,maintenanceFailureCode}from ${JSON.stringify(pathToFileURL(join(root,'scripts','finish-maintenance-feedback.mjs')).href)};import{appendFileSync}from'node:fs';import{join}from'node:path';try{await finishMaintenanceFeedback({feedbackRoot:join(process.env.KOIOS_NEWSROOM_DATA_ROOT,'feedback'),exitCode:Number(process.argv[2]),startedAt:process.argv[3],processId:Number(process.argv[4]),publish:()=>{appendFileSync(join(process.env.KOIOS_NEWSROOM_DATA_ROOT,'published'),'called\\n');if(process.env.FIXTURE_PUBLISH_FAIL)throw Error('fixture publisher refusal');}});}catch(error){console.error(maintenanceFailureCode(error));process.exitCode=1;}`);
 return{dir,runtime,data};
}
function shell(f,work,{failPublish=false,beforeBegin='',detached=false}={}){
 const script=`set -euo pipefail\nexec 9>${JSON.stringify(join(f.dir,'lock'))}\nflock -n 9 || exit 0\nsource ${JSON.stringify(join(root,'deploy','maintenance-finalization.sh'))}\n${beforeBegin}\nbegin_maintenance_finalization ${JSON.stringify(f.runtime)}\nprintf 'READY\\n'\n${work}\n`;
 const child=spawn('/usr/bin/bash',['--noprofile','--norc','-c',script],{env:{PATH:dirname(process.execPath)+':/usr/bin:/bin',KOIOS_NEWSROOM_DATA_ROOT:f.data,...(failPublish?{FIXTURE_PUBLISH_FAIL:'1'}:{})},stdio:['pipe','pipe','pipe'],timeout:5000,killSignal:'SIGKILL',detached});
 let stdout='',stderr='';child.stdout.on('data',data=>stdout+=data);child.stderr.on('data',data=>stderr+=data);
 const done=once(child,'close').then(([code,signal])=>({code,signal,stdout,stderr}));
 const ready=new Promise((resolve,reject)=>{child.stdout.on('data',()=>{if(stdout.includes('READY\n'))resolve();});child.once('error',reject);child.once('close',()=>{if(!stdout.includes('READY\n'))reject(new Error('Fixture exited before work was ready'));});});
 ready.catch(()=>{});
 return{child,done,ready};
}
for(const [name,work,expected]of [['normal','true',0],['work failure','false',1],['specific work failure','exit 42',42],['timeout','timeout --signal=TERM --kill-after=1s 0.05s sleep 5',124]])test('actual shell finalization preserves '+name,async()=>{
 const f=fixture();try{const result=await shell(f,work).done;assert.equal(result.code,expected,result.stderr);assert.equal(result.signal,null);const snapshot=JSON.parse(readFileSync(join(f.data,'feedback','latest.json')));assert.equal(snapshot.sensors.cloudMaintenance.attempt.exitCode,expected);assert.equal(readFileSync(join(f.data,'published'),'utf8'),'called\n');}finally{rmSync(f.dir,{recursive:true,force:true});}
});
for(const original of [0,42])test('finalizer publication failure never masks original exit '+original,async()=>{
 const f=fixture();try{const result=await shell(f,'exit '+original,{failPublish:true}).done;assert.equal(result.code,original);assert.match(result.stderr,new RegExp('original work exit '+original+' is preserved'));assert.equal(JSON.parse(readFileSync(join(f.data,'feedback','latest.json'))).sensors.cloudMaintenance.attempt.exitCode,original);}finally{rmSync(f.dir,{recursive:true,force:true});}
});
for(const [signal,expected]of [['SIGHUP',129],['SIGINT',130],['SIGTERM',143]])test('caught '+signal+' records its conventional exit without publishing work output',async()=>{
 const f=fixture();try{const run=shell(f,'read -r waiting');await run.ready;run.child.kill(signal);const result=await run.done;assert.equal(result.code,expected,result.stderr);assert.equal(JSON.parse(readFileSync(join(f.data,'feedback','latest.json'))).sensors.cloudMaintenance.attempt.exitCode,expected);}finally{rmSync(f.dir,{recursive:true,force:true});}
});
test('lock-not-acquired and pre-work failure produce no completed-attempt report',async()=>{
 const f=fixture();let locker;
 try{
  const early=await shell(f,'true',{beforeBegin:'exit 7'}).done;assert.equal(early.code,7);assert.equal(existsSync(join(f.data,'published')),false);
  locker=spawn('/usr/bin/bash',['-c',`exec 9>${JSON.stringify(join(f.dir,'lock'))}; flock -x 9; echo LOCKED; read -r waiting`],{stdio:['pipe','pipe','pipe']});
  await once(locker.stdout,'data');const result=await shell(f,'exit 42').done;assert.equal(result.code,0);assert.equal(result.stdout,'');assert.equal(existsSync(join(f.data,'published')),false);assert.equal(JSON.parse(readFileSync(join(f.data,'feedback','latest.json'))).sensors.cloudMaintenance.attempt,undefined);
 }finally{if(locker){const done=once(locker,'close');locker.stdin.end();await done;}rmSync(f.dir,{recursive:true,force:true});}
});
test('owning script registers finalization before optional diagnostic publishing, preserving editorial repair on API denial',()=>{
 const script=readFileSync(join(root,'deploy','maintain-newsroom.sh'),'utf8'),publisher=readFileSync(join(root,'scripts','publish-feedback.mjs'),'utf8'),collector=readFileSync(join(root,'scripts','collect-feedback.mjs'),'utf8');
 assert.ok(script.indexOf('flock -n 9 || exit 0')<script.indexOf('begin_maintenance_finalization'));
 assert.ok(script.indexOf('begin_maintenance_finalization')<script.indexOf('node "$runtime"/scripts/collect-feedback.mjs'));
 assert.match(script,/begin_maintenance_finalization "\\$runtime" record-only/);
 assert.ok(script.includes('if (( publication_failure == 0 )); then maintenance_publication_mode=publish; fi'));
 assert.ok(script.indexOf('begin_maintenance_finalization')<script.indexOf('node "$runtime"/scripts/publish-feedback.mjs'));
 assert.ok(script.indexOf('node "$runtime"/scripts/publish-feedback.mjs')<script.indexOf('timeout --signal=TERM'));
 assert.match(script,/publication_failure=0/);
 assert.match(script,/if \(\( publication_failure \)\); then exit/);
 assert.ok(script.indexOf('begin_maintenance_finalization')<script.indexOf('timeout --signal=TERM'));
 assert.match(publisher,/<!-- koios-feedback:\$\{name\} -->/);assert.match(publisher,/failure\.observedAt\?\?snapshot\.observedAt/);
 assert.match(collector,/return maintenanceUnitObservation\(values\)/);
});

function actualCliFixture(publisherSource){
 const f=fixture();
 copyFileSync(join(root,'scripts','finish-maintenance-feedback.mjs'),join(f.runtime,'scripts','finish-maintenance-feedback.mjs'));
 writeFileSync(join(f.runtime,'scripts','publish-feedback.mjs'),publisherSource);
 return f;
}
test('actual recorder CLI suppresses publisher stdout and stderr before its bounded failure summary',async()=>{
 const secret='SYNTHETIC-UNTRUSTED-PUBLISHER-OUTPUT';
 const f=actualCliFixture(`console.log('${secret}');console.error('${secret}');process.exitCode=7;`);
 try{
  const result=await shell(f,'exit 42').done;
  assert.equal(result.code,42);assert.equal((result.stdout+result.stderr).includes(secret),false);
  assert.match(result.stderr,/Final maintenance feedback failed/);
  assert.equal(JSON.parse(readFileSync(join(f.data,'feedback','latest.json'))).sensors.cloudMaintenance.attempt.exitCode,42);
 }finally{rmSync(f.dir,{recursive:true,force:true});}
});
for(const group of [false,true])for(const signal of ['SIGHUP','SIGINT','SIGTERM'])test('final-phase '+signal+' to '+(group?'the process group':'the shell')+' preserves completed work exit42',async()=>{
 const f=actualCliFixture(`import{writeFileSync}from'node:fs';import{join}from'node:path';writeFileSync(join(process.env.KOIOS_NEWSROOM_DATA_ROOT,'publisher-running'),'ready');await new Promise(resolve=>setTimeout(resolve,600));`);
 let run;
 try{
  run=shell(f,'exit 42',{detached:true});
  const marker=join(f.data,'publisher-running'),deadline=Date.now()+4000;
  while(!existsSync(marker)&&Date.now()<deadline)await pause(10);
  assert.equal(existsSync(marker),true,'fixture publisher never reached its final-phase seam');
  if(group)process.kill(-run.child.pid,signal);else run.child.kill(signal);
  const result=await run.done;
  assert.equal(result.code,42,result.stderr);assert.equal(result.signal,null);
  assert.equal(JSON.parse(readFileSync(join(f.data,'feedback','latest.json'))).sensors.cloudMaintenance.attempt.exitCode,42);
 }finally{
  if(run?.child.exitCode===null&&run.child.signalCode===null){try{process.kill(-run.child.pid,'SIGKILL');}catch{}await run.done;}
  rmSync(f.dir,{recursive:true,force:true});
 }
});

function descendantPublisher(directory,{leaveNormally=false}={}){
 const grandchild=`import{writeFileSync}from'node:fs';process.on('SIGTERM',()=>{});writeFileSync(${JSON.stringify(join(directory,'descendant-ready'))},String(process.pid));setTimeout(()=>writeFileSync(${JSON.stringify(join(directory,'late-write'))},'unexpected'),1000);`;
 return `import{writeFileSync}from'node:fs';import{spawn,execFileSync}from'node:child_process';writeFileSync(${JSON.stringify(join(directory,'publisher-pid'))},String(process.pid));${leaveNormally?`const child=spawn(process.execPath,['--input-type=module','-e',${JSON.stringify(grandchild)}],{stdio:'ignore'});child.unref();await new Promise(resolve=>setTimeout(resolve,200));`:`execFileSync(process.execPath,['--input-type=module','-e',${JSON.stringify(grandchild)}],{stdio:'ignore'});`}`;
}
async function awaitMarker(path){
 const deadline=Date.now()+4000;
 while(!existsSync(path)&&Date.now()<deadline)await pause(10);
 assert.equal(existsSync(path),true,'isolated publisher descendant never became ready');
}
const signalListenerCounts=()=>['SIGHUP','SIGINT','SIGTERM'].map(signal=>process.listenerCount(signal));
test('publisher hard timeout kills its TERM-resistant descendant and restores signal listeners',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'koios-final-timeout-')),publisherPath=join(dir,'publish.mjs'),counts=signalListenerCounts();
 try{
  writeFileSync(publisherPath,descendantPublisher(dir));
  const publication=assert.rejects(publishMaintenanceFeedback({publisherPath,timeoutMs:500}),/publication-timeout/);
  await awaitMarker(join(dir,'descendant-ready'));await publication;
  assert.deepEqual(signalListenerCounts(),counts);
  await pause(1100);assert.equal(existsSync(join(dir,'late-write')),false);
 }finally{rmSync(dir,{recursive:true,force:true});}
});
test('normally exited publisher cannot leave its descendant running past finalization',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'koios-final-success-')),publisherPath=join(dir,'publish.mjs'),counts=signalListenerCounts();
 try{
  writeFileSync(publisherPath,descendantPublisher(dir,{leaveNormally:true}));
  const publication=publishMaintenanceFeedback({publisherPath,timeoutMs:3000});
  await awaitMarker(join(dir,'descendant-ready'));await publication;
  assert.deepEqual(signalListenerCounts(),counts);
  await pause(1100);assert.equal(existsSync(join(dir,'late-write')),false);
 }finally{rmSync(dir,{recursive:true,force:true});}
});
for(const signal of [null,'SIGHUP','SIGINT','SIGTERM'])test('actual CLI cleans publisher descendants after '+(signal?'enclosing '+signal:'publisher leader death')+' before releasing the maintenance lock',async()=>{
 const f=actualCliFixture('');let run;
 try{
  writeFileSync(join(f.runtime,'scripts','publish-feedback.mjs'),descendantPublisher(f.data));
  run=shell(f,'exit 42',{detached:true});await awaitMarker(join(f.data,'descendant-ready'));
  const checkLock=()=>{
   const child=spawn('/usr/bin/flock',['-n',join(f.dir,'lock'),'true'],{stdio:'ignore'});
   return once(child,'close').then(([code])=>code);
  };
  assert.equal(await checkLock(),1,'maintenance lock must remain held during publication');
  if(signal)process.kill(-run.child.pid,signal);else process.kill(Number(readFileSync(join(f.data,'publisher-pid'),'utf8')),'SIGTERM');
  const result=await run.done;assert.equal(result.code,42,result.stderr);assert.equal(result.signal,null);
  assert.equal(JSON.parse(readFileSync(join(f.data,'feedback','latest.json'))).sensors.cloudMaintenance.attempt.exitCode,42);
  assert.equal(await checkLock(),0,'maintenance lock should release after group cleanup');
  await pause(1100);assert.equal(existsSync(join(f.data,'late-write')),false);
 }finally{
  if(run?.child.exitCode===null&&run.child.signalCode===null){try{process.kill(-run.child.pid,'SIGKILL');}catch{}await run.done;}
  rmSync(f.dir,{recursive:true,force:true});
 }
});
