/**
 * Contradiction, read where evidence is analyzed. Two sources about the same event contradict when
 * they assert propositions with the same subject and predicate whose objects cannot both hold: the
 * same quantity in the same unit with different values, or one object the negation of the other (a
 * negated predicate or a negated object). Each such source's evidence is then told AGAINST by the
 * other, beside the telling FOR it already holds, so its claim reads as a told-both FOUR cell.
 * Objects that merely differ in prose are not contradictions: nothing says they exclude each other.
 * Units that differ are not comparable, so they are not contradictions either.
 *
 * `contradictionsOf` is pure over a story group's extracted propositions; `tellContradictions` is
 * the journal act (idempotent: evidence already told against is never told again).
 */
import { claimEvidenceType } from "@red-cup-engineering/content-mill-newsroom-services-section/carriers";
import { admitTypedMark } from "@red-cup-engineering/signcell/typed-mark";
import { readNewsroom, recordNewsroom } from "../newsroom-records.mjs";

const SCALES = new Map([["thousand", 1e3], ["k", 1e3], ["million", 1e6], ["m", 1e6], ["mn", 1e6], ["billion", 1e9], ["bn", 1e9], ["b", 1e9], ["trillion", 1e12], ["tn", 1e12]]);
const UNIT_ALIASES = new Map([["percent", "%"], ["per cent", "%"], ["pct", "%"], ["dollar", "usd"], ["us dollar", "usd"], ["$", "usd"], ["us$", "usd"], ["euro", "eur"], ["€", "eur"], ["pound", "gbp"], ["£", "gbp"]]);
const CURRENCY_SYMBOLS = new Map([["$", "usd"], ["us$", "usd"], ["€", "eur"], ["£", "gbp"]]);
const NEGATIONS = ["did not ", "does not ", "do not ", "was not ", "were not ", "is not ", "are not ", "has not ", "have not ", "had not ", "will not ", "would not ", "didn't ", "doesn't ", "wasn't ", "isn't ", "hasn't ", "won't ", "never ", "not ", "no "];
const NUMBER = /^(\d{1,3}(?:,\d{3})+|\d+)(\.\d+)?$/u;

const words = (text) => String(text ?? "").normalize("NFKC").toLowerCase().replace(/\s+/gu, " ").trim().replace(/[.,;:!]+$/u, "").trim();

/** A quantity {value, unit} when the whole object is one number with an optional scale and unit; otherwise null. */
function quantityOf(text) {
  let rest = words(text);
  let unit = "";
  for (const [symbol, name] of CURRENCY_SYMBOLS) if (rest.startsWith(symbol)) { unit = name; rest = rest.slice(symbol.length).trim(); break; }
  const match = /^(\S+?)(?:\s*(%|[a-z][a-z .'-]*))?$/u.exec(rest);
  if (!match) return null;
  const digits = NUMBER.exec(match[1]);
  if (!digits) return null;
  let value = Number(`${digits[1].replaceAll(",", "")}${digits[2] ?? ""}`);
  const tail = (match[2] ?? "").trim().split(" ").filter(Boolean);
  if (tail.length > 0 && SCALES.has(tail[0])) value *= SCALES.get(tail.shift());
  const spelled = tail.join(" ");
  const named = UNIT_ALIASES.get(spelled) ?? spelled.replace(/(?<=[a-z]{3})s$/u, "");
  return { value: Number(value.toPrecision(12)), unit: unit || (UNIT_ALIASES.get(named) ?? named) };
}

/** The proposition's text with its polarity: a leading negation marker is stripped and flips polarity. */
function polarityOf(text) {
  let rest = words(text);
  let negative = false;
  for (let changed = true; changed;) {
    changed = false;
    for (const marker of NEGATIONS) if (rest.startsWith(marker)) { rest = rest.slice(marker.length).trim(); negative = !negative; changed = true; break; }
  }
  return { text: rest, negative };
}

/** One proposition in comparable form. */
export function normalizeProposition({ subject, predicate, object }) {
  const claim = polarityOf(predicate);
  const objectPolarity = polarityOf(object);
  return {
    subject: words(subject), predicate: claim.text,
    negative: claim.negative !== objectPolarity.negative,
    object: quantityOf(objectPolarity.text) ?? { text: objectPolarity.text },
  };
}

const sameObject = (a, b) => ("text" in a ? "text" in b && a.text === b.text : !("text" in b) && a.value === b.value && a.unit === b.unit);
const comparableQuantities = (a, b) => !("text" in a) && !("text" in b) && a.unit === b.unit;

/** Whether two propositions about one event cannot both hold. */
export function contradicts(left, right) {
  const a = normalizeProposition(left), b = normalizeProposition(right);
  if (a.subject !== b.subject || a.predicate !== b.predicate || a.subject === "" || a.predicate === "") return false;
  if (a.negative !== b.negative) return sameObject(a.object, b.object);
  return comparableQuantities(a.object, b.object) && !sameObject(a.object, b.object);
}

/**
 * The contradictions among evidence rows, grouped by story: `{evidenceId, storyId, section,
 * sourceEvidenceId, subject, predicate, object}` in, one `{storyId, section, evidenceIds: [a, b]}`
 * (ids sorted) out per contradicting pair of evidence from different sources, sorted by ids.
 */
export function contradictionsOf(rows) {
  const groups = new Map();
  for (const row of rows) groups.set(`${row.section}\u0000${row.storyId}`, [...(groups.get(`${row.section}\u0000${row.storyId}`) ?? []), row]);
  const pairs = new Map();
  for (const group of groups.values()) {
    for (let i = 0; i < group.length; i += 1) for (let j = i + 1; j < group.length; j += 1) {
      const [a, b] = [group[i], group[j]];
      if (a.sourceEvidenceId === b.sourceEvidenceId || a.evidenceId === b.evidenceId || !contradicts(a, b)) continue;
      const evidenceIds = [a.evidenceId, b.evidenceId].sort();
      pairs.set(evidenceIds.join("\u0000"), { storyId: a.storyId, section: a.section, evidenceIds });
    }
  }
  return [...pairs.values()].sort((x, y) => (x.evidenceIds.join() < y.evidenceIds.join() ? -1 : 1));
}

/**
 * Tell contradicting evidence against, in the newsroom journal: every admitted claim row for a
 * proposition another source contradicts gets a row told against (and not for, the telling for
 * it stands in its own row), with the contradicting evidence as the relation's object.
 * @returns {{claims: number, contradictions: number, told: number}}
 */
export function tellContradictions(root) {
  const rows = readNewsroom(root, "claim");
  const records = new Map();
  const opposed = new Set();
  for (const { record, told } of rows) {
    const admitted = admitTypedMark(claimEvidenceType, record);
    if (!admitted.ok) continue;
    records.set(admitted.value.id, admitted.value);
    if (told?.against === true) opposed.add(admitted.value.id);
  }
  const found = contradictionsOf([...records.values()].map(({ id, content }) => ({ evidenceId: id, ...content })));
  const counterpart = new Map();
  for (const { evidenceIds: [a, b] } of found) {
    if (!counterpart.has(a)) counterpart.set(a, b);
    if (!counterpart.has(b)) counterpart.set(b, a);
  }
  let told = 0;
  for (const [id, other] of [...counterpart].sort(([x], [y]) => (x < y ? -1 : 1))) {
    if (opposed.has(id)) continue;
    recordNewsroom(root, "claim", records.get(id), { told: { for: false, against: true } });
    told += 1;
  }
  return { claims: records.size, contradictions: found.length, told };
}
