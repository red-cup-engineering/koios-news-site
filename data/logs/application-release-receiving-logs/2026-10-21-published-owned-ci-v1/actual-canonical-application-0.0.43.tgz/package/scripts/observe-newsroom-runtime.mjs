import {readFileSync,openSync,fstatSync,readSync,closeSync,constants} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {newsroomFeedback} from './newsroom-feedback.mjs';

// A fixed read-only composition of the owner's existing feedback projector.
// No runtime collector, repair, publisher, arbitrary path or command is invoked.
const feedbackRoot='/home/emsenn/.local/state/561-group/news-property/Koios.News/feedback';
const units=['koios-newsroom.service','koios-maintenance.service'];
const fields=['LoadState','ActiveState','Result','ExecMainStatus','ExecMainStartTimestampMonotonic'];
const states={
 LoadState:['loaded','not-found','bad-setting','error','masked','stub','merged'],
 ActiveState:['active','reloading','inactive','failed','activating','deactivating','maintenance','refreshing'],
 Result:['success','resources','timeout','exit-code','signal','core-dump','watchdog','start-limit-hit','oom-kill','protocol','exec-condition'],
};
const instant=value=>typeof value==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(value)&&Number.isFinite(Date.parse(value))&&new Date(value).toISOString()===(value.length===20?value.slice(0,-1)+'.000Z':value)?value:null;
const integer=value=>Number.isSafeInteger(value)&&value>=0?value:null;
const decimal=value=>typeof value==='string'&&/^\d{1,16}$/.test(value)?integer(Number(value)):null;
const errorCode=error=>['ENOENT','EACCES','EPERM','EFBIG','ETIMEDOUT','ENOBUFS','ELOOP','ENOTSUP'].includes(error?.code)?error.code:error instanceof SyntaxError?'invalid-json':'observation-unavailable';

export function maintenanceFacts(snapshot){
 if(snapshot?.kind!=='koios.news.observed-feedback/v1')return {status:'unavailable',code:'invalid-feedback'};
 const prior=snapshot.sensors?.cloudMaintenance,attempt=prior?.attempt;
 const exitCode=integer(attempt?.exitCode),startedAt=instant(attempt?.startedAt),finishedAt=instant(attempt?.finishedAt);
 const validAttempt=attempt?.kind==='koios.news.maintenance-attempt-outcome/v1'&&exitCode!==null&&exitCode<=255&&startedAt&&finishedAt&&Date.parse(finishedAt)>=Date.parse(startedAt);
 return {status:'observed',snapshotObservedAt:instant(snapshot.observedAt),sensorObservedAt:instant(prior?.observedAt),
  attempt:validAttempt?{startedAt,finishedAt,exitCode,status:exitCode===0?'succeeded':'failed'}:null};
}

export function unitFacts(output,uptimeSeconds){
 const values=Object.fromEntries(String(output).split('\n').filter(line=>line.includes('=')).map(line=>{const at=line.indexOf('=');return [line.slice(0,at),line.slice(at+1)];}));
 const facts=Object.fromEntries(Object.entries(states).map(([name,allowed])=>[name,allowed.includes(values[name])?values[name]:null]));
 const status=decimal(values.ExecMainStatus),started=decimal(values.ExecMainStartTimestampMonotonic),uptime=Number.isFinite(uptimeSeconds)&&uptimeSeconds>=0?uptimeSeconds:null;
 return {...facts,ExecMainStatus:status!==null&&status<=255?status:null,
  processAgeSeconds:started!==null&&started>0&&uptime!==null&&uptime*1000000>=started?Math.floor(uptime-started/1000000):null};
}

export function readFeedbackSnapshot(name,{directory=feedbackRoot}={}){
 if(!['newsroom.json','latest.json'].includes(name))throw new TypeError('Only the two fixed feedback carriers may be observed');
 const limit=2*1024*1024;
 const fd=openSync(directory+'/'+name,constants.O_RDONLY|constants.O_NOFOLLOW|constants.O_NONBLOCK);
 try{
  const stat=fstatSync(fd);
  if(!stat.isFile())throw Object.assign(new Error(),{code:'ENOTSUP'});
  if(stat.size>limit)throw Object.assign(new Error(),{code:'EFBIG'});
  // Keep the same descriptor and cap even a file that grows after fstat.
  const bytes=Buffer.alloc(limit+1);let size=0;
  while(size<bytes.length){const n=readSync(fd,bytes,size,bytes.length-size,null);if(n===0)break;size+=n;}
  if(size>limit)throw Object.assign(new Error(),{code:'EFBIG'});
  return JSON.parse(bytes.subarray(0,size).toString('utf8'));
 }finally{closeSync(fd);}
}
function showUnit(unit){
 return execFileSync('systemctl',['--user','show',unit,'--property='+fields.join(',')],{encoding:'utf8',timeout:10000,maxBuffer:16384,stdio:['ignore','pipe','ignore']});
}

/** Closed-vocabulary, content-addressed classification of the existing
 * systemd journal. This reading cannot echo provider output, credentials,
 * free-form shell errors, source documents, or a user-selected unit/path.
 * A fingerprint distinguishes repeated exact error carriers without exporting
 * their bytes. All conclusions are only diagnostics, not a recovery permit.
 */
const journalPatterns=Object.freeze([
 ['data-checkout-dirty',/Data observation checkout contains uncommitted changes/iu],
 ['data-commits-unreconciled',/Local unpublished data commits need exact reconciliation/iu],
 ['data-source-fetch-failed',/Pinned Koios (?:content|data) source fetch failed/iu],
 ['package-module-missing',/ERR_MODULE_NOT_FOUND|Cannot find package|Cannot find module/iu],
 ['auth-transport-failed',/Permission denied \(publickey\)|Authentication failed|could not read Username/iu],
 ['git-worktree-conflict',/Your local changes to the following files|would be overwritten by checkout|not a git repository/iu],
 ['git-remote-failed',/fatal: unable to access|Could not resolve host|Failed to connect to github\.com/iu],
 ['github-api-unavailable',/GraphQL API rate limit|HTTP 403|HTTP 401|gh: error connecting/iu],
 ['provider-inference-unavailable',/inference-obstructed|provider-outage|provider-refusal/iu],
 ['standards-research-unavailable',/research-standards\.mjs.*(?:Error|failed)/iu],
 ['maintenance-timeout',/timeout:|timed out|SIGTERM/iu],
 ['maintenance-exception',/\b(?:Error|TypeError|ReferenceError|SyntaxError):/u],
]);
const maintenancePhase=Object.freeze([
 ['checkout','deploy/maintain-newsroom.sh'],
 ['feedback-collection','scripts/collect-feedback.mjs'],
 ['standards-research','scripts/research-standards.mjs'],
 ['feedback-publishing','scripts/publish-feedback.mjs'],
 ['editorial-agent','codex exec'],
 ['maintenance-finalization','scripts/finish-maintenance-feedback.mjs'],
]);
function maintenanceJournal(){
 return execFileSync('journalctl',['--user','--unit=koios-maintenance.service','--since','15 minutes ago',
  '--output=json','--no-pager','--lines=90'],{encoding:'utf8',timeout:8000,maxBuffer:512*1024,
  stdio:['ignore','pipe','ignore']});
}
export function maintenanceJournalFacts(source){
 const logs=String(source).split('\n').filter(Boolean).slice(-90);
 const observed=[],phases=new Set();
 for(const line of logs){
  if(line.length>12000)continue;
  let item;try{item=JSON.parse(line);}catch{continue;}
  const message=typeof item.MESSAGE==='string'?item.MESSAGE:'';
  if(!message||message.length>8000)continue;
  for(const [phase,needle] of maintenancePhase)if(message.includes(needle))phases.add(phase);
  const classification=journalPatterns.find(([,pattern])=>pattern.test(message))?.[0];
  if(!classification)continue;
  const fingerprint=createHash('sha256').update(message).digest('hex').slice(0,20);
  if(observed.some(row=>row.fingerprint===fingerprint))continue;
  observed.push({classification,fingerprint});
 }
 return {status:'observed',messagesInspected:logs.length,phases:[...phases],errors:observed.slice(-16),
  // Error classifications are testimony from past lines, not current service
  // condition or proof the last invocation failed for that exact reason.
  diagnosticOnly:true};
}

export function observeNewsroomRuntime({read=readFeedbackSnapshot,show=showUnit,readJournal=maintenanceJournal,now=()=>new Date().toISOString(),uptime=()=>Number(readFileSync('/proc/uptime','utf8').split(' ')[0])}={}){
 const observedAt=instant(now());if(!observedAt)throw new TypeError('Explicit UTC observation time required');
 const result={kind:'koios.news.read-only-runtime-observation/v1',observedAt,units:{}};
 let uptimeSeconds=null;try{uptimeSeconds=uptime();}catch{}
 for(const unit of units){try{result.units[unit]={status:'observed',...unitFacts(show(unit),uptimeSeconds)};}catch(error){result.units[unit]={status:'unavailable',code:errorCode(error)};}}
 try{result.newsroom=newsroomFeedback(read('newsroom.json'),observedAt);}catch(error){result.newsroom={status:'unavailable',code:errorCode(error)};}
 try{result.maintenance=maintenanceFacts(read('latest.json'));}catch(error){result.maintenance={status:'unavailable',code:errorCode(error)};}
 // Reading the bounded journal is warranted only when the exact unit has
 // demonstrably failed, never for a healthy or unobserved system.
 const state=result.units['koios-maintenance.service'];
 if(state?.ActiveState==='failed'&&state?.Result==='exit-code'){
  try{result.maintenanceJournal=maintenanceJournalFacts(readJournal());}
  catch(error){result.maintenanceJournal={status:'unavailable',code:errorCode(error)};}
 }
 return result;
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 if(process.argv.length!==2){console.error('This observation accepts no arguments.');process.exitCode=2;}
 else try{process.stdout.write(JSON.stringify(observeNewsroomRuntime(),null,2)+'\n');}catch{console.error('Runtime observation unavailable.');process.exitCode=1;}
}
