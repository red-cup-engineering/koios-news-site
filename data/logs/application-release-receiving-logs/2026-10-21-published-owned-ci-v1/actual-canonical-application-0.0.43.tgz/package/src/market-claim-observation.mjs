/**
 * The OTHER direction of Koios' existing market research wire: a released
 * ClaimStateBundle becomes an observation of the shared market game.
 *
 * A release is evidence of publication, not independent verification of the
 * financial thesis. FOUR contradictions, original assertion force, correction
 * lineage and both clocks remain intact. This produces no probability, quote,
 * strategy, order, account operation, or implied permission to trade.
 */
import { assertClaimStateBundle, effectiveClaims } from './news/topology/claim.mjs';
import { canonicalJson } from "@red-cup-engineering/json-services-section/canonical";
import { sha256Bytes } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/portable-sha256";
import { utf8Bytes } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/portable-bytes";

const clock = value => typeof value === 'string' && Number.isFinite(Date.parse(value));
const text = value => typeof value === 'string' && value.trim().length > 0;

/** A public, already released Koios claim bundle as one ordinary game move. */
export function releasedClaimsAsMarketObservation({ bundle, edition, publicationUrl, sourceEvidenceIds, observedAt } = {}) {
  assertClaimStateBundle(bundle);
  if (!Array.isArray(bundle.claims) || !bundle.claims.length || bundle.claims.length > 128 ||
      !edition || edition.state !== 'released' || !text(edition.releaseManifest) ||
      !text(edition.candidateId) || !clock(edition.releasedAt) ||
      !clock(observedAt) || Date.parse(observedAt) < Date.parse(edition.releasedAt) ||
      !Array.isArray(sourceEvidenceIds) || !sourceEvidenceIds.length ||
      sourceEvidenceIds.length > 128 || sourceEvidenceIds.some(value => !text(value)) ||
      new Set(sourceEvidenceIds).size !== sourceEvidenceIds.length)
    throw new TypeError('released-sourced-claim-observation-required');
  let url;
  try { url = new URL(publicationUrl); } catch { throw new TypeError('public-newsroom-url-required'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.hash)
    throw new TypeError('public-newsroom-url-required');
  for (const claim of bundle.claims) {
    if (!clock(claim.time.asserted) || Date.parse(claim.time.asserted) > Date.parse(edition.releasedAt) ||
        !text(claim.provenance?.citation) || !text(claim.force) || !text(claim.status))
      throw new TypeError('publication-cannot-precede-its-cited-claims');
  }
  // Keep the whole bounded claim evidence, including corrected and retracted
  // tellings. effectiveClaimIds is only an index, NOT a replacement history.
  const value = {
    kind: 'koios-public-claim-state-evidence',
    subject: bundle.subject,
    claims: bundle.claims,
    effectiveClaimIds: effectiveClaims(bundle).map(claim => claim.id).sort(),
    release: { candidateId: edition.candidateId, manifest: edition.releaseManifest,
      releasedAt: edition.releasedAt },
    sourceEvidenceIds: [...sourceEvidenceIds].sort(),
    probabilityEstablished: false,
    financiallyActionable: false,
  };
  if (new TextEncoder().encode(JSON.stringify(value)).length > 131072)
    throw new RangeError('bounded-public-claim-evidence-required');
  const observation = {
    id: sha256Bytes(utf8Bytes(canonicalJson({ source: url.href, value }))),
    source: url.href, availableAt: edition.releasedAt, observedAt,
    value,
  };
  return Object.freeze({ kind: 'observe', observation: Object.freeze(observation),
    tradeEligible: false, orderEffect: false });
}
