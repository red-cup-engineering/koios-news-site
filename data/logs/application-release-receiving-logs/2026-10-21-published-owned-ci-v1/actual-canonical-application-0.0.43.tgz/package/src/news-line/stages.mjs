/**
 * The Koios news line's stage handlers. Each is a batch drain over durable state, so a
 * stage with nothing to do completes and the cycle moves; work a stage leaves behind is
 * taken by the same stage of a later cycle. Each composes the owner of its step:
 *
 *   intake    the source broker takes the wires' fresh arrivals (its cursor skips taken ones)
 *   analyze   Content Mill selects stories, acquires sources, and buys claim extraction
 *   draft     Content Mill executes returned repairs and drafts grounded manuscripts as draft posts
 *   assess    Independent Editorial Assessment is hired per manuscript and signs acceptances
 *   authorize the editor-in-chief's standing policy grants publication; issues are queued
 *   render    routine publication spends each issue's authority and records it in the published ledger
 *   release   the property is built from its declared inputs (the ledger among them) at release
 *             time, and the Cloudflare carrier previews, probes, and releases that build
 *   feedback  the line measures itself and retires superseded candidates and builds
 */
import { spawnSync } from "node:child_process";
import {readPublicEditionEvidence} from "./public-receiving.mjs";
import { articleQuality,qualityFailureLayer } from "../article-quality.mjs";
import { storyAnchor, storyDesk } from "./desk.mjs";
import {treatmentForStory,assertEditionTreatment} from "./editorial-agency.mjs";
import { nearDuplicateHeadline } from "./editorial-deduplication.mjs";
import {preferUnpublishedWriterOrders, isPendingExactEditorialRepair, draftHasExpired} from "./throughput-feedback.mjs";
import {observedArticleAssignments} from "./existing-article.mjs";
import { sign } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import { basename, join } from "node:path";
import { fileURLToPath } from "node:url";

import { admitSetOfFeedArrivals, loadCursor, normalizeFeedList, saveCursor } from "@red-cup-engineering/communicating/messaging/newswire/feed-arrivals";
import { newsroomDayAnalyze } from "@red-cup-engineering/content-mill-newsroom-services-section";
import { newsroomDayDraft, reviseManuscriptCandidate, assignedClaims } from "@red-cup-engineering/content-mill-newsroom-services-section/manuscript";
import { dispatchInferenceAsConfiguredCustomer } from "@red-cup-engineering/computer-inference-engine/dispatch/inference-dispatch";
import { resolveSectionWires } from "@red-cup-engineering/content-mill-newsroom-services-section/intake";
import { heldJournalCells, manuscriptEvidenceFromJournal } from "@red-cup-engineering/content-mill-newsroom-services-section/evidence";
import {purchaseClaimExtraction,claimRows,recordPurchaseReceipt} from "@red-cup-engineering/content-mill-newsroom-services-section/claims";
import { admitClaimEvidence } from "@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence";
import { claimEvidenceType, manuscriptCandidateType, sourceEvidenceType } from "@red-cup-engineering/content-mill-newsroom-services-section/carriers";
import { readNewsroom, recordNewsroom } from "../newsroom-records.mjs";
import {withFileLock} from "@red-cup-engineering/semiotic-eavt-services-section/store";
import { acquirePublicWebSources } from "@causeway-services/web-source-acquisition/acquire";
import { ACTIVITYSTREAMS_CONTEXT } from "@red-cup-engineering/activitypub-services-section/activitystreams";
import { ACTOR as ASSESSOR, digest as assessmentDigest, invokeEditorialAssessment, solicitEditorialAssessment } from "@causeway-services/independent-editorial-assessment/contract";
import { GRANT_KIND } from "@causeway-services/editorial-publication-authority";
import { listPublishedLedgerEntries, writeRoutinePublication, consumedPublicationSource } from "../offline-publication.mjs";
import { canonicalJson } from "@red-cup-engineering/json-services-section/canonical";
import { sha256Digest, sha256Hex } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity";
import { parsePost } from "@causeway-services/koios-news-site/build";
import {releaseWebsite} from "@causeway-services/koios-news-site/release";

import { formRoutineIssue, verifyRoutineIssue } from "../routine-issue-formation.mjs";
import { draftMarketOf, tellEditorOutcome } from "./outcomes.mjs";
import { sourcingDemandOf, sourcingLeadsFor } from "./sourcing.mjs";
import {editorNotesOf,returnedWriterEditions} from './criteria.mjs';
import { tellContradictions } from "./contradiction.mjs";
import { newsLineContext } from './context.mjs';
export { newsLineContext } from './context.mjs';
import { boundedDraftDispatch, configuredDraftWriterTimeoutMs } from "./draft-dispatch.mjs";
import {publicationHold} from './publication-holds.mjs';
import {receivePreparedArticleIssues,analyzeEditorialCommissions,verifiedEditorialCommissions} from './commissioned-reporting.mjs';
import {requireNewsroomWriterAdmission} from '../inference-account.mjs';
import { publishReleasedMarketResearch } from '../market-research-release.mjs';
import { advanceEdition, editionOf, editions, officeKey, openEdition, readJson, slugFor, writeJsonAtomic } from "./editions.mjs";

const PACKAGE_ROOT = fileURLToPath(new URL("../..", import.meta.url));
const CUSTOMER = "urn:ame:koios-news";

const plusSeconds = (at, seconds) => new Date(Date.parse(at) + seconds * 1000).toISOString();
const quoted = (text) => JSON.stringify(String(text).replace(/\s+/gu, " ").trim());
const errorText = (error) => String(error?.message ?? error).slice(0, 500);

// ---------------------------------------------------------------- intake / analyze

async function intake(context, { at }) {
  const { property, houseFeedsPath, dataRoot, roots } = context;
  const commissions=await receivePreparedArticleIssues(context,{at});
  const houseFeeds = new Map(normalizeFeedList(readJson(houseFeedsPath)).map((feed) => [feed.id, feed]));
  const { feeds } = resolveSectionWires(property, houseFeeds);
  const cursorPath = join(dataRoot, "state", "feed-arrivals-cursor.json");
  const { events, cursor, obstructions } = await admitSetOfFeedArrivals({ feeds, cursor: loadCursor(cursorPath) });
  // The line holds the arrivals durably before the broker's cursor moves past them.
  // Batches are named by instant and content: a retried intake never overwrites a held batch.
  if (events.length > 0) writeJsonAtomic(join(roots.arrivals, `${at.replace(/[-:.]/gu, "")}-${sha256Hex(canonicalJson(events)).slice(0, 12)}.json`), events);
  saveCursor(cursorPath, cursor);
  const wires = { feeds: feeds.length, arrivals: events.length, commissions, obstructedFeeds: obstructions.map(({ feedId, reason }) => `${feedId}: ${reason}`).slice(0, 12) };
  if (feeds.length > 0 && obstructions.length === feeds.length && commissions.received.length===0) return { status: "blocked", code: "every-wire-unreachable", reason: obstructions[0].reason, ...wires };
  return { status: "complete", ...wires };
}

async function analyze(context, { at, acquisitionOnly = false }) {
  const { property, dataRoot, roots, houseFeedsPath, config, purchaseJournalRoot } = context;
  const commissions=await analyzeEditorialCommissions(context,{at,acquisitionOnly});
  if(commissions.requiresSourceRefresh?.length)return {status:'blocked',code:'source-capture-policy-obsolete',phase:'claim-extraction',reason:'Refresh legacy source prefixes before buying extraction for an incomplete commissioned document.',commissions};
  const pending = readdirSync(roots.arrivals).filter((name) => name.endsWith(".json")).sort();
  if (pending.length === 0) return { status: "complete", arrivals: 0, commissions, ...(acquisitionOnly?{sourceEvidenceOnly:true}:{}) };
  // A missing zero-cash entitlement cannot prevent a reporter from receiving
  // authentic public-source evidence. Request the named optional Content Mill
  // capability at this effect boundary. An older pinned supplier cannot silently
  // ignore a new option and dispatch inference without admission.
  let analyzeWith = newsroomDayAnalyze;
  if (acquisitionOnly) {
    const supplier = await import("@red-cup-engineering/content-mill-newsroom-services-section");
    if (typeof supplier.newsroomDayAcquireSourcesOnly !== "function") {
      return { status: "blocked", code: "source-only-capability-unavailable",
        reason: "The admitted Content Mill lacks independent source-evidence acquisition; no provider call was attempted." };
    }
    analyzeWith = supplier.newsroomDayAcquireSourcesOnly;
  }
  const sourceArrivals = pending.flatMap((name) => readJson(join(roots.arrivals, name)));
  const summary = await analyzeWith({
    property, dataRoot, now: new Date(at), customerActor: property.inference?.customerActor,
    maxStories: config.batches.maxStoriesPerPulse, houseFeedsPath, sourceArrivals,
    purchase:(lead,options)=>purchaseClaimExtraction(lead,{...options,dispatch:(request,settings)=>dispatchInferenceAsConfiguredCustomer({...request,objective:request.objective+'\n\n'+context.editorialMethods.researching},{...settings,environment:context.environment})}),
    acquireSource: (lead, instant) => acquirePublicWebSources({ purpose: "journalistic-source-research", urls: [lead.url] }, instant),
    ...(purchaseJournalRoot ? { purchaseJournalRoot } : {}),
  });
  // Keep the exact arrivals pending until a qualified provider has actually
  // attempted claim extraction. The source-only path retains evidence in the
  // existing Content Mill journal; it does not close the claim-work frontier.
  const wireClaimsObstructed=!acquisitionOnly&&summary.claims?.purchaseCount>0&&summary.claims.admitted===0;
  const claimsObstructed=wireClaimsObstructed&&commissions.heldClaims===0;
  if (!acquisitionOnly&&!wireClaimsObstructed) for (const name of pending)
    renameSync(join(roots.arrivals, name), join(roots.analyzed, name));
  const contradictions = tellContradictions(dataRoot);
  return { status: claimsObstructed?'blocked':'complete', arrivals: sourceArrivals.length,
    ...(claimsObstructed?{code:'claim-extraction-obstructed',phase:'claim-extraction',reason:'Source acquisition completed but no source-bound claim was admitted; original arrivals remain pending for reporting.'}:{}),
    analysis: numbersOf(summary), commissions, contradictions,
    sourceObstructions: summary.sources?.obstructions ?? [],
    ...(acquisitionOnly ? { sourceEvidenceOnly: true } : {}) };
}

function numbersOf(value, depth = 0) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (Array.isArray(value)) return value.length;
  if (depth > 1 || value === null || typeof value !== "object") return undefined;
  const out = {};
  for (const [key, child] of Object.entries(value)) { const n = numbersOf(child, depth + 1); if (n !== undefined && (typeof n === "number" || Object.keys(n).length)) out[key] = n; }
  return out;
}

// ---------------------------------------------------------------- draft

function takenSlugs(context) {
  const taken = new Set();
  const posts = join(context.propertyContentDir, context.property.content?.postsDirectory ?? "posts");
  if (existsSync(posts)) for (const name of readdirSync(posts)) if (name.endsWith(".md")) taken.add(name.slice(0, -3));
  for (const entry of listPublishedLedgerEntries(context.roots.publication)) taken.add(basename(entry.relative ?? "", ".md"));
  for (const edition of editions(context.roots)) taken.add(edition.slug);
  return taken;
}

/**
 * The stories the property has published, by story id: the slug of the latest released edition and
 * the day its ledger post was first published, so a later draft of the story updates that article.
 */
function publishedStories(context, all) {
  const published = new Map(listPublishedLedgerEntries(context.roots.publication).map((entry) => [basename(entry.relative, ".md"), entry.path]));
  const stories = new Map();
  for (const edition of all.filter((item) => item.state === "released" && published.has(item.slug))
    .sort((left, right) => left.releasedAt.localeCompare(right.releasedAt))) {
    const post = parsePost(readFileSync(published.get(edition.slug), "utf8"), `${edition.slug}.md`);
    stories.set(edition.storyId, { slug: edition.slug, date: post.date, title: post.title, section: edition.section });
  }
  const releasedSlugs=new Set([...stories.values()].map(row=>row.slug));
  for(const observed of observedArticleAssignments(context))if(!releasedSlugs.has(observed.slug))stories.set(observed.storyId,{slug:observed.slug,date:observed.firstPublished});
  return stories;
}

/**
 * The draft post carries the candidate's exact manuscript as its body: the evidence law binds those
 * bytes. An update to a published story keeps the day it was first published and says when it changed.
 */
export function draftPost({ candidate, desk, slug, at, firstPublished, treatment = null }) {
  const { title, dek, manuscript } = candidate.content;
  const section = desk.slug;
  const deskTitle = desk?.title ?? section;
  return [
    "---",
    `title: ${quoted(title)}`,
    `date: ${firstPublished ?? at.slice(0, 10)}`,
    ...(firstPublished ? [`modified: ${at}`] : []),
    "draft: true",
    `author: ${quoted(treatment ? treatment.character.byline : `Koios.News ${deskTitle} Desk`)}`,
    `section: ${quoted(section)}`,
    ...(treatment ? [
      `editorialProductProfile: ${quoted(treatment.productId)}`,
      `koiosCharacter: ${quoted(treatment.characterId)}`,
      `koiosRegister: ${quoted(treatment.registerId)}`,
      `koiosTreatmentDigest: ${quoted(treatment.selectionDigest)}`,
      `koiosCommissionDigest: ${quoted(treatment.authenticatedCommissionDigest)}`,
    ] : []),
    `dek: ${quoted(dek)}`,
    `description: ${quoted(dek)}`,
    `summary: ${quoted(dek)}`,
    `categories: ${JSON.stringify([deskTitle])}`,
    `license: "CC BY 4.0"`,
    "---",
    manuscript.trimEnd(),
    "",
  ].join("\n");
}

const MAX_SOURCING_DEMANDS = 6;
const MAX_CLAIMS_PER_LEAD = 24;

/**
 * Source shortage as demand: every story group with fewer distinct source hosts than its desk
 * requires is recorded as a sourcing demand (once per distinct demand) and met, within the turn's
 * bounds, by adopting into the story the claims of another host's source that the wires already
 * yielded for the same event. Returns what it did; what it could not meet stays a demand.
 */
export async function meetSourcingDemands(context, at) {
  const { property, dataRoot } = context;
  const claims = assignedClaims(dataRoot,(id,section)=>storyDesk(property,id,section,dataRoot).slug,at).map(entry=>entry.cell);
  if (claims.length === 0) return { demands: 0, adopted: 0, unmet: [] };
  const sources = heldJournalCells(dataRoot, "source-evidence", sourceEvidenceType);
  const drafted = new Set([...heldJournalCells(dataRoot, "manuscript-candidate", manuscriptCandidateType).values()].map((cell) => `${cell.content.section}\u0000${cell.content.storyId}`));
  const groups = new Map();
  for (const cell of claims) {
    const key = `${cell.content.section}\u0000${cell.content.storyId}`;
    groups.set(key, [...(groups.get(key) ?? []), cell]);
  }
  const known = new Set(readNewsroom(dataRoot, "sourcing-demand").map(({ record }) => record?.id));
  const held = new Set(claims.map((cell) => cell.id));
  const demands = [];
  for (const [key, cells] of [...groups].sort(([a], [b]) => a.localeCompare(b))) {
    if (drafted.has(key)) continue;
    const [section, storyId] = key.split("\u0000");
    const desk = property.sections.find((item) => item.slug === section);
    if (!desk) continue;
    const demand = sourcingDemandOf({ storyId, section, claims: cells.map((cell) => cell.content), minimumSources: desk.minimumIndependentSources ?? 2 });
    if (demand) demands.push({ demand, key, fresh: !known.has(demand.id) });
  }
  demands.sort((a, b) => Number(b.fresh) - Number(a.fresh));
  let adopted = 0;
  const unmet = [];
  for (const { demand, key, fresh } of demands.slice(0, MAX_SOURCING_DEMANDS)) {
    if (fresh) recordNewsroom(dataRoot, "sourcing-demand", demand);
    const pool = claims.filter((cell) => `${cell.content.section}\u0000${cell.content.storyId}` !== key).map((cell) => cell.content);
    const leads = sourcingLeadsFor(demand, pool);
    let gained = 0;
    for (const lead of leads) {
      const source = sources.get(lead.sourceEvidenceId);
      if (!source) continue;
      // A word-overlap match discovers a possible source, never a claim assignment.
      // Hire the existing source-bound extractor for this actual event and assay
      // its exact quotations before any claim enters the destination story.
      const item={id:source.content.leadId,url:source.content.requestedUrl,title:storyAnchor(demand.storyId,dataRoot).title};
      const purchase=await purchaseClaimExtraction(item,{sourceEvidence:source,maximumClaims:MAX_CLAIMS_PER_LEAD,
        customerActor:property.inference.customerActor,freeLaneOnly:property.cadence?.freeLaneOnly===true,reportingFocus:item.title,
        dispatch:(request,settings)=>dispatchInferenceAsConfiguredCustomer(request,{...settings,environment:context.environment})});
      recordPurchaseReceipt(purchase,{root:context.purchaseJournalRoot,turnId:purchase.workLotId,actor:property.inference.customerActor,recordedAt:at});
      if(!purchase.admitted)continue;
      recordNewsroom(dataRoot,'reporting-source',{type:'KoiosArticleReportingSource',storyId:demand.storyId,
        sourceEvidenceId:source.id,researchedAt:at,workLotId:purchase.workLotId,method:'source-bound-event-focused-extraction'});
      let added = 0;
      for (const row of claimRows(purchase,{storyId:demand.storyId,section:demand.section},source)) {
        try {
          const adoption = admitClaimEvidence(row, source);
          if (held.has(adoption.id)) continue;
          recordNewsroom(dataRoot, "claim", adoption);
          held.add(adoption.id); added += 1;
        } catch { /* a claim that no longer verifies against its source licenses nothing */ }
      }
      if (added > 0) gained += 1;
      adopted += added;
    }
    if (gained < demand.needed) unmet.push({ storyId: demand.storyId, section: demand.section, needed: demand.needed - gained });
  }
  return { demands: demands.length, adopted, unmet: unmet.slice(0, 12) };
}

/** A reporter's unbound NEW candidate must not acquire an automatic address. */
export function reporterSubmissionCustodyBlock(context) {
  const { dataRoot, roots } = context;
  const standing = publishedStories(context, editions(roots));
  const candidates = [...heldJournalCells(dataRoot, "manuscript-candidate", manuscriptCandidateType).values()]
    .filter((candidate) => candidate.content.workLotId.startsWith("urn:koios:reporter-submission:")
      && !editionOf(roots, candidate.id) && !standing.has(candidate.content.storyId))
    .map((candidate) => ({ candidateId: candidate.id, storyId: candidate.content.storyId }))
    .sort((left, right) => left.candidateId.localeCompare(right.candidateId));
  if (candidates.length === 0) return null;
  return {
    status: "blocked",
    code: "reporter-submission-custody-incomplete",
    reason: "A NEW reporter manuscript is held without edition custody; reconcile its exact submitted address before drafting resumes.",
    candidates,
  };
}

async function draft(context, { at, existingOnly = false }) {
  // Check before repairs, sourcing or writer dispatch: otherwise another candidate
  // for the orphaned story could be produced before the adoption loop sees it.
  const custodyBlock = reporterSubmissionCustodyBlock(context);
  if (custodyBlock) return custodyBlock;
  const { property, dataRoot, roots, config, purchaseJournalRoot } = context;
  const revisions = executeReturnedRevisions(context, at);
  // A story short of source hosts is a demand, met from the wires' claims before it is drafted.
  const sourcing = await meetSourcingDemands(context, at);
  // Adopted claims join stories that other sources already told: contradictions among them are told before drafting.
  const contradictions = tellContradictions(dataRoot);
  // Held writer repairs enter the same bounded candidate pulse and account procurement
  // as new writing. Historical editions do not permanently retire a reporting duty.
  const all = editions(roots);
  const returnedEditions=returnedWriterEditions(all);
  const returnedCandidateIds=returnedEditions.map(edition=>edition.candidateId);
  // One story, one article: a story the property has published keeps its address, and what is
  // drafted for it later is that article's next version, never a second article.
  const standing = publishedStories(context, all);
  const editorNotes=editorNotesOf(returnedEditions);
  const draftWriterTimeoutMs = configuredDraftWriterTimeoutMs(context);
  // Allocate bounded writer capacity to genuine new reporting while the
  // source-observed daily NEW-publication count is below its explicit target.
  // The line's ready-publication selection already processes accepted revisions
  // before any draft: this preference cannot overtake ready editorial releases.
  const preferUnpublishedStories = preferUnpublishedWriterOrders(newsLineMetrics(context, at));
  // Receiving previously written, evidence-bound manuscripts and executing
  // exact independently selected repairs needs no model purchase. When the
  // writer's zero-cash admission fails, do that existing work anyway; only
  // starting a NEW model inference is forbidden. Assessment and publication
  // remain governed by their original independent authority gates.
  const commissions=verifiedEditorialCommissions(context);
  const drafted = existingOnly
    ? { writingAttempts: 0, candidates: [], refusals: [] }
    : await newsroomDayDraft({
    property, dataRoot, now: new Date(at), maxCandidates: config.batches.maxCandidatesPerPulse ?? null, returnedCandidateIds, editorNotes,
    preferUnpublishedStories,
    concurrency: property.cadence?.purchaseConcurrency ?? null,
    criteria:({section,storyId})=>{
      const assignment=commissions.get(storyId);
      const operativeBrief=assignment?.body.split(/^## Prior decision history/mu)[0].trim();
      const commissioned=assignment?[JSON.stringify({work:'fulfil-authenticated-editorial-commission',issueUrl:assignment.issueUrl,author:assignment.author,sourceBodyDigest:assignment.bodyDigest,operativeBriefDigest:sha256Digest(operativeBrief),operativeBrief,law:'Follow the current direction. Treat explicitly superseded text as history. Preserve the commissioned genre, position and prepared draft where admitted evidence supports it. The draft is an assignment, never proof of its factual claims.'})]:[];
      const treatment=treatmentForStory(context,{section,storyId});
      if(treatment)return [
        ...commissioned,
        context.editorialMethods.writing,
        JSON.stringify({work:"prepare-sourced-editorial-work",subdesk:treatment.subdeskId,office:treatment.officeId,
          agencySelection:treatment.agencyCandidate,commissionDigest:treatment.authenticatedCommissionDigest}),
        JSON.stringify(treatment.character),
        JSON.stringify(treatment.register),
        JSON.stringify(readJson(join(PACKAGE_ROOT,'lib/agency/duties/prepare-sourced-editorial-work.json')))
      ];
      return [...commissioned,context.editorialMethods.writing,
        JSON.stringify(readJson(join(PACKAGE_ROOT,'lib/agency/offices',`koios-${section}-desk-editor.json`))),
        JSON.stringify(readJson(join(PACKAGE_ROOT,'lib/agency/characters',`koios-${section}-desk.json`))),
        JSON.stringify(readJson(join(PACKAGE_ROOT,'policy/agency/duties/forming-a-reported-manuscript.json')))];
    },
    editorialTreatmentForStory:({section,storyId})=>treatmentForStory(context,{section,storyId}),
    mayDraftStory:({storyId})=>!publicationHold(context,null,at,storyId),
    sectionForStory: (storyId, section) => storyDesk(property,storyId,section,dataRoot).slug, anchorStoryIds: [...standing.keys()],
    dispatch: (request, options) => boundedDraftDispatch(
      (demand, settings) => dispatchInferenceAsConfiguredCustomer(demand, { ...settings, environment: context.environment }),
      request, { ...options, timeoutMs: draftWriterTimeoutMs }),
    ...(purchaseJournalRoot ? { purchaseJournalRoot } : {}),
  });
  const received=receiveDraftedManuscripts(context,{at});
  return { status: "complete", revisions, sourcing, contradictions, writingAttempts: drafted.writingAttempts, drafted: drafted.candidates.length, refusals: drafted.refusals.map(({ storyId, section, reason, directLaneRefusals }) => ({ storyId, section, reason, ...(directLaneRefusals ? {directLaneRefusals} : {}) })), ...received };
}

/** Receive already settled Content Mill manuscripts independently of provider waits. */
export function receiveDraftedManuscripts(context,{at=new Date().toISOString()}={}) {
 return withFileLock(join(context.roots.root,'edition-adoption.lock'),()=>{
 const {dataRoot,roots,property}=context;
 const all=editions(roots),standing=publishedStories(context,all),commissions=verifiedEditorialCommissions(context);
  const taken = takenSlugs(context);
  const opened = [];
  // One event, one article: a candidate not anchored to a published story whose headline nearly
  // repeats a standing or just-drafted headline of the same desk is refused, never drafted twice.
  const headlines = [...standing.values()].filter((story) => story.title !== undefined && story.section !== undefined);
  const duplicatesRefused = [];
  for (const candidate of heldJournalCells(dataRoot, "manuscript-candidate", manuscriptCandidateType).values()) {
    if (editionOf(roots, candidate.id)) continue;
    const published = standing.get(candidate.content.storyId);
    const desk = storyDesk(property, candidate.content.storyId, candidate.content.section,dataRoot);
    if (!published) {
      const duplicate = headlines.find((story) =>
        story.section === desk.slug
        && nearDuplicateHeadline(story.title, candidate.content.title));
      if (duplicate) {
        const refusedSlug = slugFor(candidate.content.title, taken, candidate.id);
        openEdition(roots, {
          candidateId: candidate.id,
          storyId: candidate.content.storyId,
          section: desk.slug,
          slug: refusedSlug,
          state: "refused",
          draftedAt: at,
          updatedAt: at,
          attempts: 0,
          reason: "near-duplicate-headline",
          duplicateOf: duplicate.slug,
          provider: candidate.content.provider ?? null,
          model: candidate.content.model ?? null,
        });
        duplicatesRefused.push({ slug: refusedSlug, duplicateOf: duplicate.slug });
        continue;
      }
    }
    const assigned=all.find(row=>row.storyId===candidate.content.storyId&&typeof row.slug==='string');
    const commissioned=commissions.get(candidate.content.storyId);
    const slug = published?.slug ?? assigned?.slug ?? commissioned?.slug ?? slugFor(candidate.content.title, taken, candidate.id);
    if(commissioned&&!published&&!assigned&&taken.has(slug))throw Error('Commissioned article address is already reserved: '+slug);
    taken.add(slug);
    const contentDir = join(roots.drafts, `${slug}.${sha256Hex(candidate.id).slice(0,10)}`); mkdirSync(contentDir, { recursive: true, mode: 0o700 });
    const draftPath = join(contentDir, `${slug}.md`);
    const selected=treatmentForStory(context,{storyId:candidate.content.storyId,section:desk.slug});
    writeFileSync(draftPath, draftPost({ candidate, desk, slug, at, firstPublished: published?.date, treatment:selected }), { mode: 0o600 });
    parsePost(readFileSync(draftPath, "utf8"), `${slug}.md`);
    openEdition(roots, { candidateId: candidate.id, storyId: candidate.content.storyId, section: desk.slug, slug, contentDir, draftPath, state: "drafted", draftedAt: at, attempts: 0, provider: candidate.content.provider ?? null, model: candidate.content.model ?? null,
      // The draft's inference delivery: its lot and receipt, and the market coordinate the editor's verdict teaches routing under.
      workLotId: candidate.content.workLotId ?? null, exchangeId: candidate.content.exchangeId ?? null, market: draftMarketOf(context.environment, candidate.content) ?? null,
      ...(selected ? {treatmentDigest:selected.selectionDigest,commissionDigest:selected.authenticatedCommissionDigest,
        editorialProductId:selected.productId,characterId:selected.characterId,subdeskId:selected.subdeskId} : {}),
      ...(published ? { firstPublished: published.date } : {}) });
    headlines.push({ title: candidate.content.title, section: desk.slug, slug });
    opened.push(slug);
  }
 return {editionsOpened:opened.length,duplicatesRefused};
 });
}

// ---------------------------------------------------------------- assess

/**
 * Select editorial assessments without letting released-article revision traffic
 * consume every slot. A revision has firstPublished; a new public article does not.
 * When new copy exists, the oldest new article owns the first slot. Remaining
 * capacity preserves requested-revision priority and FIFO order.
 */
export function selectAssessmentBatch(editions, limit) {
  if (!Number.isSafeInteger(limit) || limit < 0) throw new TypeError("assessment batch limit must be a non-negative integer");
  if (limit === 0) return [];
  const fifo = (a,b) => a.draftedAt.localeCompare(b.draftedAt) || a.candidateId.localeCompare(b.candidateId);
  const fresh = [...editions].sort(fifo);
  const news = fresh.filter((edition) => !edition.firstPublished);
  if (news.length === 0) return fresh
    .sort((a,b) => Number(Boolean(b.provider === "urn:ame:koios-cloud-editor")) - Number(Boolean(a.provider === "urn:ame:koios-cloud-editor")) || fifo(a,b))
    .slice(0, limit);
  const first = news[0];
  const rest = fresh.filter((edition) => edition !== first)
    .sort((a,b) => {
      const requested = (edition) => Boolean(edition.firstPublished && edition.provider === "urn:ame:koios-cloud-editor");
      return Number(requested(b)) - Number(requested(a)) || fifo(a,b);
    });
  return [first, ...rest].slice(0, limit);
}

/** Execute a revision request's repair tools; the revision keeps the edition's slug and draft carrier. */
function reviseEdition(context, edition, selection, selectionDigest, at) {
  const { property, dataRoot, roots } = context;
  if (!Array.isArray(selection.repairTools) || selection.repairTools.length === 0 || typeof selectionDigest !== "string") return null;
  const desk = property.sections.find((section) => section.slug === edition.section);
  const revised = reviseManuscriptCandidate({ dataRoot, candidateId: edition.candidateId, repairTools: selection.repairTools,
    selectionDigest, minimumSources: desk?.minimumIndependentSources ?? 2, now: new Date(at) });
  if (!revised.ok) return revised;
  const selected=assertEditionTreatment(context,edition);
  writeFileSync(edition.draftPath, draftPost({ candidate: revised.candidate, desk, slug: edition.slug, at, firstPublished: edition.firstPublished, treatment:selected }), { mode: 0o600 });
  parsePost(readFileSync(edition.draftPath, "utf8"), `${edition.slug}.md`);
  openEdition(roots, { candidateId: revised.candidate.id, storyId: edition.storyId, section: edition.section, slug: edition.slug,
    contentDir: edition.contentDir, draftPath: edition.draftPath, state: "drafted", draftedAt: at, attempts: 0,
    revision: (edition.revision ?? 0) + 1, revises: edition.candidateId, provider: edition.provider, model: edition.model,
    workLotId: edition.workLotId ?? null, exchangeId: edition.exchangeId ?? null, market: edition.market ?? null,
    ...(edition.treatmentDigest ? {treatmentDigest:edition.treatmentDigest,commissionDigest:edition.commissionDigest,
      editorialProductId:edition.editorialProductId,characterId:edition.characterId,subdeskId:edition.subdeskId} : {}),
    ...(edition.firstPublished ? { firstPublished: edition.firstPublished } : {}) });
  return revised;
}

/** A revision request's bounded repairs are executed exactly once, by whichever cycle first holds it. */
export function executeReturnedRevisions(context, at) {
  const { roots } = context;
  return editions(roots, "returned").filter(isPendingExactEditorialRepair).map((edition) => {
    const judgment = readJson(edition.deliveryPath).object ?? {};
    const revised = reviseEdition(context, edition, judgment.toolSelection ?? {}, judgment.toolSelectionDigest, at);
    advanceEdition(roots, edition, "returned", at, revised?.ok ? { revisedAs: revised.candidate.id } : { revisionRefused: revised?.reason ?? "no-repair-tools" });
    return { slug: edition.slug, revised: revised?.ok ?? false, ...(revised?.ok ? {} : { reason: revised?.reason ?? "no-repair-tools" }) };
  });
}

function assessmentDemand(context, edition, manuscriptSource) {
  const { property, dataRoot, config, contract } = context;
  const desk = property.sections.find((section) => section.slug === edition.section) ?? {};
  const evidence = manuscriptEvidenceFromJournal({ dataRoot, candidateId: edition.candidateId, manuscriptBody: parsePost(manuscriptSource, `${edition.slug}.md`).body });
  const pageMetadata=new Map(readNewsroom(dataRoot,"source-page-metadata").map(({record})=>record)
    .sort((a,b)=>a.observedAt.localeCompare(b.observedAt)).map(record=>[record.sourceEvidenceId,record.declared]));
  const specialist=assertEditionTreatment(context,edition);
  const editorialProduct=specialist?.editorialProduct??desk.editorialProduct??property.editorialProduct;
  const quality=articleQuality(manuscriptSource, {candidate:evidence.candidate.content, claims:evidence.claims, property,editorialProduct});
  const assignment=readNewsroom(dataRoot,'editorial-commission').map(({record})=>record)
    .filter(record=>record.storyId===edition.storyId&&record.slug===edition.slug&&record.author==='emsenn'&&typeof record.body==='string'&&sha256Digest(record.body)===record.bodyDigest)
    .sort((a,b)=>b.receivedAt.localeCompare(a.receivedAt))[0];
  const standards = {
    dutyContext:{method:context.editorialMethods.editing,
      office:readJson(join(PACKAGE_ROOT,'lib/agency/offices/koios-standards-editor.json')),
      character:readJson(join(PACKAGE_ROOT,'lib/agency/characters/koios-standards-editor.json')),
      duty:readJson(join(PACKAGE_ROOT,'policy/agency/duties/judging-accountable-publication.json'))},
    ...(assignment?{assignment:{issueUrl:assignment.issueUrl,author:assignment.author,body:assignment.body,bodyDigest:assignment.bodyDigest}}:{}),
    reportingOutreach:readNewsroom(dataRoot,'reporting-outreach').map(x=>x.record)
      .filter(row=>row.type==='KoiosArticleReportingOutreach'&&row.version===1&&row.slug===edition.slug),
    desk: edition.section, genre: desk.genre ?? "news", minimumIndependentSources: desk.minimumIndependentSources ?? 2,
    distinctSourceHosts: quality.sourceHosts,
    claimCount: evidence.claims.length, paragraphCount: evidence.candidate.content.paragraphs.length,
    everyParagraphCitesAdmittedClaims: evidence.candidate.content.paragraphs.every((paragraph) => paragraph.claimEvidenceIds.length > 0),
    editorialProduct,
    ...(specialist ? {writerAssignment:{
      subdesk:specialist.subdeskId,character:specialist.characterId,office:specialist.officeId,
      responsibleDesk:edition.section,register:specialist.registerId,
      readerQuestion:specialist.readerQuestion,commissionDigest:specialist.authenticatedCommissionDigest,
      nativeAgencyDuty:specialist.agencyCandidate.duty,skill:specialist.agencyCandidate.skill,
      admissionStatus:'candidate-not-publication-authority'
    }} : {}),
    qualityReviewRequired: editorialProduct?.requireSourceComparison === true,
    quality,
    standingPolicy: config.standingPolicy.rule,
    // The editor must read the originating documents, not just the writer's
    // selected quote fragments, to judge omissions, chronology and independence.
    sourceDocuments: evidence.sources.map(source=>({sourceEvidenceId:source.id,...source.content,observedPageMetadata:pageMetadata.get(source.id)??null})),
  };
  const witnessed = evidence.claims.map((claim) => ({ claimId: claim.id, sourceUrl: claim.content.sourceUrl, subject: claim.content.subject, predicate: claim.content.predicate, object: claim.content.object, quote: claim.content.quote }));
  const run = { line: "koios-news", storyId: edition.storyId, candidateId: edition.candidateId };
  const pipeline = [{ stage: "draft", by: edition.provider, using: edition.model }];
  const demand = {
    type: "EditorialAssessmentDemand", slug: edition.slug,
    manuscript: { bytes: manuscriptSource, digest: assessmentDigest(manuscriptSource) },
    editorialContext: { standards, run, evidence: witnessed, pipeline, digest: assessmentDigest({ standards, run, evidence: witnessed, pipeline }) },
    authorities: {
      publicationPolicyDigest: assessmentDigest(config.standingPolicy),
      genreLawDigest: assessmentDigest({ genre: standards.genre, minimumIndependentSources: standards.minimumIndependentSources }),
      editorialDutyDigest: assessmentDigest(contract),
    },
    executionMode: "live",
  };
  return demand;
}

function solicitation(demand) {
  const sourceActivity = { "@context": ACTIVITYSTREAMS_CONTEXT, id: `urn:source:${assessmentDigest(demand)}`, type: "Create", actor: CUSTOMER, object: demand };
  const body = { type: "ServiceSolicitation", demand: `urn:demand:${assessmentDigest(demand)}`, sourceActivity };
  return { "@context": ACTIVITYSTREAMS_CONTEXT, id: `urn:solicitation:${assessmentDigest(sourceActivity)}`, type: "Offer", actor: CUSTOMER, target: ASSESSOR, object: body };
}

function serviceContract(offer) {
  return { "@context": ACTIVITYSTREAMS_CONTEXT, type: "Accept", actor: CUSTOMER, target: ASSESSOR, object: {
    type: "ServiceContract", offer,
    capability: { type: "Capability", issuer: CUSTOMER, holder: ASSESSOR, invocationTarget: ASSESSOR, parentOffer: offer.id,
      allowedActions: ["invoke-service", ...offer.object.effects],
      attenuation: { demandDigest: offer.object.demandDigest, providerScope: offer.object.scope, customerTerritoryMutation: false } },
  } };
}

/** The editor's verdict on a draft, told at the source into the node's one outcome journal; a failure to tell never undoes the verdict. */
function tellVerdict(context, edition, state, at) {
  try { return tellEditorOutcome(context.environment, edition, state, at, { reason: edition.reason, failureLayer: edition.failureLayer }); }
  catch (error) { return { told: 0, reason: `tell-failed: ${errorText(error)}` }; }
}

async function assess(context, { at }, { requireAdmission = requireNewsroomWriterAdmission, solicit = solicitEditorialAssessment, invoke = invokeEditorialAssessment } = {}) {
  const { roots, config, policyDigest } = context;
  const assessor = officeKey(roots, "independent-editorial-assessment");
  // Freshness belongs to the exact submitted manuscript, not the oldest
  // historically refused candidate sharing its story ID. A freshly researched
  // manuscript may be independently assessed after an earlier draft expired.
  // The editor still checks source-event currentness, evidence and the
  // unchanged article-quality/authority gates; this is only an assessor-queue
  // deadline, never a waiver of publication or journalism standards.
  const all = editions(roots);
  const stale = [], fresh = [];
  for (const edition of all.filter((row) => row.state === "drafted"))
    (draftHasExpired(edition, at, config.freshness.storySeconds) ? stale : fresh).push(edition);
  for (const edition of stale) advanceEdition(roots, edition, "refused", at, { reason: "story-went-stale" });
  // New public articles must not be starved by revision traffic. Revisions are still
  // FIFO and keep priority within the remaining capacity, but when any new article
  // is waiting the batch reserves its first slot for the oldest new article.
  const batch = selectAssessmentBatch(fresh, config.batches.maxAssessmentsPerTurn ?? fresh.length);
  let admission;
  async function assessOne(edition) {
    let selected;
    try { selected=assertEditionTreatment(context,edition); }
    catch(error){
      const returned=advanceEdition(roots,edition,"returned",at,{reason:"specialist-agency-or-commission-changed: "+errorText(error),failureLayer:"assignment"});
      return {slug:edition.slug,outcome:"returned",reason:returned.reason,told:tellVerdict(context,returned,"returned",at)};
    }
    const manuscriptSource = readFileSync(edition.draftPath, "utf8");
    const records = `${edition.slug}.${sha256Hex(edition.candidateId).slice(0,10)}${edition.revision ? `.r${edition.revision}` : ""}`;
    const record = (name, value) => { const path = join(roots.assessments, `${records}.${name}.json`); writeJsonAtomic(path, value); return path; };
    let offer, delivery;
    // Observable structural failures need writing, not expensive replay or another assessor attempt.
    const surfaceQuality=articleQuality(manuscriptSource,{claims:null,property:context.property,evidenceRequired:false,
      section:edition.section,editorialProduct:selected?.editorialProduct});
    if(!surfaceQuality.ok){
      const returned=advanceEdition(roots,edition,"returned",at,{reason:"article-depth-insufficient",failureLayer:"writer-model",quality:surfaceQuality});
      return {slug:edition.slug,outcome:"returned",quality:surfaceQuality,told:tellVerdict(context,returned,"returned",at)};
    }
    try {
      const demand = assessmentDemand(context, edition, manuscriptSource);
      const quality=demand.editorialContext.standards.quality;
      if(!quality.ok){
        const returned=advanceEdition(roots,edition,"returned",at,{reason:"article-depth-insufficient",failureLayer:qualityFailureLayer(quality),quality});
        return {slug:edition.slug,outcome:"returned",quality,told:tellVerdict(context,returned,"returned",at)};
      }
      // Share this batch's account refresh instead of racing independent
      // replacements of the same entitlement file. Shared inference still
      // admits each actual provider request against current account capacity.
      try { await (admission ??= requireAdmission(context.environment)); }
      catch(error) { throw Object.assign(new Error(errorText(error)),{code:"inference-obstructed"}); }
      offer = await solicit(solicitation(demand), at);
      if (offer.type !== "Offer") throw Object.assign(new Error(offer.object?.reason ?? "assessment solicitation refused"), { code: offer.object?.code });
      const contract = serviceContract(offer); record("contract", contract);
      delivery = await invoke(contract, at, { environment: context.environment, assessmentSigning: {
        assessmentId: `koios-assessment-${sha256Hex(`${edition.candidateId}\u0000${at}`).slice(0, 32)}`,
        expiresAt: plusSeconds(at, config.authority.assessmentReceiptSeconds), issuerKeyId: assessor.keyId, policyDigest, privateKey: assessor.privateKey,
      } });
    } catch (error) {
      if(String(error.message).startsWith("manuscript evidence:")){
        const returned=advanceEdition(roots,edition,"returned",at,{reason:errorText(error),failureLayer:"sources"});
        return {slug:edition.slug,outcome:"returned",reason:returned.reason,failureLayer:"sources",told:tellVerdict(context,returned,"returned",at)};
      }
      delivery = { type: "Reject", object: { code: error.code ?? "assessment-threw", reason: errorText(error) } };
    }
    const deliveryPath = record(`delivery-${edition.attempts + 1}`, delivery);
    if (delivery.type === "Accept" && delivery.assessmentReceipt) {
      const evidence = manuscriptEvidenceFromJournal({dataRoot:context.dataRoot,candidateId:edition.candidateId,manuscriptBody:parsePost(manuscriptSource, `${edition.slug}.md`).body});
      const quality=articleQuality(manuscriptSource,{candidate:evidence.candidate.content,claims:evidence.claims,property:context.property,
        section:edition.section,editorialProduct:selected?.editorialProduct});
      if(!quality.ok){
        const returned=advanceEdition(roots,edition,"returned",at,{deliveryPath,reason:"article-depth-insufficient",failureLayer:qualityFailureLayer(quality),quality});
        return {slug:edition.slug,outcome:"returned",quality,told:tellVerdict(context,returned,"returned",at)};
      }
      const receiptPath = join(roots.assessments, `${records}.receipt.json`);
      writeFileSync(receiptPath, delivery.assessmentReceipt, { mode: 0o600 });
      const accepted = advanceEdition(roots, edition, "accepted", at, { receiptPath, deliveryPath, policyDigest:context.policyDigest, assessmentKeysPath: assessor.keyMapPath, toolSelectionDigest: delivery.object.toolSelectionDigest, receiptExpiresAt: plusSeconds(at, config.authority.assessmentReceiptSeconds) });
      return { slug: edition.slug, outcome: "accepted", told: tellVerdict(context, accepted, "accepted", at) };
    }
    const selection = delivery.type === "Accept" ? delivery.object?.toolSelection : undefined;
    if (selection) {
      // A completed judgment other than acceptance returns the manuscript; the draft stage executes its repairs.
      const returned = advanceEdition(roots, edition, "returned", at, { deliveryPath, reason: selection.tool, failureLayer: selection.failureLayer ?? null });
      return { slug: edition.slug, outcome: "returned", tool: selection.tool, failureLayer: selection.failureLayer ?? null, told: tellVerdict(context, returned, "returned", at) };
    } else if (delivery.object?.code === "inference-obstructed") {
      // No lane held capacity: a market wait, not a judgment, so it spends no attempt; freshness bounds it.
      advanceEdition(roots, edition, "drafted", at, { reason: "inference-obstructed", obstructedAt: at });
      return { slug: edition.slug, outcome: "obstructed", code: "inference-obstructed" };
    } else {
      // This is an unsuccessful service delivery, not an editorial verdict.
      // Record its cost/attempt history; a lifetime counter cannot retire the
      // manuscript before its actual editorial window or a substantive decision.
      advanceEdition(roots, edition, "drafted", at, { attempts: (edition.attempts ?? 0) + 1, reason: delivery.object?.code ?? "assessment-obstructed" });
      return { slug: edition.slug, outcome: "obstructed", code: delivery.object?.code ?? null };
    }
  }
  // The shared inference owner admits provider/account capacity. A slow
  // manuscript must not serialize independent judgments or structural returns.
  // Each callback persists its own settled edition before the batch finishes.
  const outcomes = await Promise.all(batch.map(async edition => {
    const identity = { slug: edition.slug, candidateId: edition.candidateId, storyId: edition.storyId };
    try { return { ...identity, ...await assessOne(edition) }; }
    catch (error) { return { ...identity, outcome: "obstructed", code: error.code ?? "assessment-stage-threw", reason: errorText(error) }; }
  }));
  const obstructed = outcomes.filter((outcome) => outcome.outcome === "obstructed");
  if (outcomes.length > 0 && obstructed.length === outcomes.length) return { status: "blocked", code: "assessment-inference-obstructed", reason: obstructed[0].code, outcomes };
  return { status: "complete", assessed: outcomes.length, stale: stale.map((edition) => edition.slug), outcomes };
}

// ---------------------------------------------------------------- authorize

/** The editor-in-chief's standing publication grant for the policy, reused while it has hours left. */
function standingGrant(context, at) {
  const { roots, config, policyDigest } = context;
  const authority = officeKey(roots, "editor-in-chief");
  const usable = readdirSync(roots.grants).filter((name) => name.endsWith(".json")).map((name) => ({ path: join(roots.grants, name), grant: readJson(join(roots.grants, name)) }))
    .filter(({ grant }) => grant.issuerKeyId === authority.keyId && grant.scope?.policyDigest === policyDigest && Date.parse(grant.expiresAt) - Date.parse(at) > 6 * 3600 * 1000)
    .sort((a, b) => b.grant.expiresAt.localeCompare(a.grant.expiresAt));
  if (usable.length > 0) return { path: usable[0].path, keyMapPath: authority.keyMapPath, grantId: usable[0].grant.grantId, expiresAt: usable[0].grant.expiresAt };
  const unsigned = { expiresAt: plusSeconds(at, config.authority.standingGrantSeconds), grantId: `koios-standing-${at.slice(0, 13).replace(/\D/gu, "")}-${sha256Hex(`${policyDigest}\u0000${at}`).slice(0, 12)}`, issuedAt: at, issuerKeyId: authority.keyId, kind: GRANT_KIND, scope: { policyDigest, type: "standing-policy" } };
  const signature = sign(null, Buffer.from(canonicalJson(unsigned), "utf8"), authority.privateKey).toString("base64url");
  const path = join(roots.grants, `${unsigned.grantId}.json`);
  writeFileSync(path, `${canonicalJson({ ...unsigned, signature })}\n`, { mode: 0o600, flag: "wx" });
  return { path, keyMapPath: authority.keyMapPath, grantId: unsigned.grantId, expiresAt: unsigned.expiresAt };
}

async function authorize(context, { at }) {
  const { roots, dataRoot, contract } = context;
  const accepted = editions(roots, "accepted");
  if (accepted.length === 0) return { status: "complete", queued: 0 };
  const grant = standingGrant(context, at);
  const outcomes = [];
  for (const edition of accepted) {
    let selected;
    try{selected=assertEditionTreatment(context,edition);}
    catch(error){
      advanceEdition(roots,edition,"returned",at,{reason:"specialist-agency-or-commission-changed: "+errorText(error),failureLayer:"assignment"});
      outcomes.push({slug:edition.slug,outcome:"returned",reason:errorText(error)});
      continue;
    }
    const hold=publicationHold(context,edition.slug,at,edition.storyId);
    if(hold){outcomes.push({slug:edition.slug,outcome:'held',notBefore:hold.notBefore,reason:hold.reason});continue;}
    if(edition.policyDigest!==context.policyDigest){advanceEdition(roots,edition,"drafted",at,{attempts:0,reason:"editorial-requirements-changed"});outcomes.push({slug:edition.slug,outcome:"reassess"});continue;}
    if (Date.parse(edition.receiptExpiresAt) <= Date.parse(at) + 3600 * 1000) {
      advanceEdition(roots, edition, "drafted", at, { attempts: 0, reason: "assessment-receipt-expiring" });
      outcomes.push({ slug: edition.slug, outcome: "reassess" });
      continue;
    }
    const manuscriptSource = readFileSync(edition.draftPath, "utf8");
    const evidence=manuscriptEvidenceFromJournal({dataRoot,candidateId:edition.candidateId,manuscriptBody:parsePost(manuscriptSource, `${edition.slug}.md`).body});
    const quality=articleQuality(manuscriptSource,{candidate:evidence.candidate.content,claims:evidence.claims,property:context.property,
      section:edition.section,editorialProduct:selected?.editorialProduct});
    if(!quality.ok){advanceEdition(roots,edition,"returned",at,{reason:"article-depth-insufficient",failureLayer:qualityFailureLayer(quality),quality});outcomes.push({slug:edition.slug,outcome:"returned",quality});continue;}
    const admissionPath = join(roots.admissions, `${edition.slug}.json`);
    writeJsonAtomic(admissionPath, { slug: edition.slug, manuscriptDigest: sha256Digest(manuscriptSource), disposition: "accept", publishable: true, serviceAccepted: true, contract: contract.providerContract, selectedTool: "submit_editorial_acceptance", toolSelectionValidated: true, toolSelectionDigest: edition.toolSelectionDigest });
    const jobId = `koios-${sha256Hex(`${edition.candidateId}\u0000${grant.grantId}`).slice(0, 32)}`;
    try {
      const issue = formRoutineIssue({
        admissionPath, assessmentReceiptPath: edition.receiptPath, assessmentKeysPath: edition.assessmentKeysPath,
        authorityGrantPath: grant.path, authorityKeysPath: grant.keyMapPath, authorityReplayRoot: roots.publication,
        candidateName: jobId, dataRoot, candidateId: edition.candidateId, contentDir: edition.contentDir, draftPath: edition.draftPath,
        formationReplayRoot: roots.formation, jobId, manuscriptSlug: edition.slug, now: at, queueRoot: roots.queue,
      });
      advanceEdition(roots, edition, "queued", at, { admissionPath, jobPath: issue.jobPath, grantId: grant.grantId, grantExpiresAt: grant.expiresAt, authorityKeysPath: grant.keyMapPath });
      outcomes.push({ slug: edition.slug, outcome: "queued" });
    } catch (error) {
      advanceEdition(roots, edition, "refused", at, { reason: `issue-formation: ${errorText(error)}` });
      outcomes.push({ slug: edition.slug, outcome: "refused", reason: errorText(error) });
    }
  }
  return { status: "complete", grantId: grant.grantId, outcomes };
}

// ---------------------------------------------------------------- render

async function render(context, { at }) {
  const { roots, config, property, propertyContentDir, claimStoreDir, houseFeedsPath } = context;
  const eligible = editions(roots, "queued").filter(edition=>!publicationHold(context,edition.slug,at,edition.storyId));
  const batch = eligible.slice(0, config.batches.maxRendersPerTurn ?? eligible.length);
  const outcomes = [];
  for (const edition of batch) {
    const hold=publicationHold(context,edition.slug,at,edition.storyId);
    if(hold){outcomes.push({slug:edition.slug,outcome:'held',notBefore:hold.notBefore,reason:hold.reason});continue;}
    if(edition.policyDigest!==context.policyDigest){
      advanceEdition(roots,edition,"drafted",at,{reason:"editorial-policy-changed-before-publication"});
      outcomes.push({slug:edition.slug,outcome:"reassess",reason:"editorial-policy-changed-before-publication"});
      continue;
    }
    try {
      const selected=assertEditionTreatment(context,edition);
      const source=readFileSync(edition.draftPath,"utf8");
      const evidence=manuscriptEvidenceFromJournal({dataRoot:context.dataRoot,candidateId:edition.candidateId,manuscriptBody:parsePost(source, `${edition.slug}.md`).body});
      const quality=articleQuality(source,{candidate:evidence.candidate.content,claims:evidence.claims,property,
        section:edition.section,editorialProduct:selected?.editorialProduct});
      if(!quality.ok){advanceEdition(roots,edition,"returned",at,{reason:"article-depth-insufficient",failureLayer:qualityFailureLayer(quality),quality});outcomes.push({slug:edition.slug,outcome:"returned",quality});continue;}
      const job = readJson(edition.jobPath);
      const written = writeRoutinePublication({
        ...job, property, propertyContentDir, claimStoreDir, sourceFeedsPath: houseFeedsPath, authorityKeysPath: edition.authorityKeysPath, assessmentKeysPath: edition.assessmentKeysPath,
        authorityNow: at, issueProvenance: {...verifyRoutineIssue(job),
          ...(selected?{editorialTreatment:selected}:{} )}, outputDir: join(roots.candidates, job.candidateName), replayRoot: roots.publication,
      });
      advanceEdition(roots, edition, "rendered", at, { candidateDir: written.outputDir, consumptionId: written.consumptionId, renderedAt: at });
      outcomes.push({ slug: edition.slug, outcome: "rendered" });
    } catch (error) {
      const expired = Date.parse(edition.grantExpiresAt) <= Date.parse(at);
      // An operational failure cannot revoke an independent editorial
      // acceptance. Preserve custody for the next bounded publication pulse;
      // expired authority must still be renewed before any write succeeds.
      advanceEdition(roots, edition, expired ? "accepted" : "queued", at, { renderAttempts: (edition.renderAttempts ?? 0) + 1, reason: `render: ${errorText(error)}` });
      outcomes.push({ slug: edition.slug, outcome: expired ? "reauthorize" : "retry", reason: errorText(error) });
    }
  }
  const failed = outcomes.filter((outcome) => !["rendered","held"].includes(outcome.outcome));
  const rendered=outcomes.filter(outcome=>outcome.outcome==='rendered').length;
  if (failed.length > 0 && rendered===0) return { status: "blocked", code: "render-failed", reason: failed[0].reason, outcomes };
  return { status: "complete", rendered, outcomes };
}

// ---------------------------------------------------------------- release
/** Bind a release attempt to exact pending custody, including same-instant arrivals. */
export function renderedEditionSetIdentity(rows) {
  return sha256Hex(canonicalJson(rows.map(row => row.candidateId).sort()));
}

/** Observe independently published editions before selecting more work.
 * Network observation holds no mutation lock. Exact row transitions use the shared store lock.
 * No writer inference, Git push,
 * publication authority or provider mutation belongs in this monitor. */
export async function receivePublicEditions(context, {at=new Date().toISOString(),
  pending=editions(context.roots,'rendered'),observedCandidates=new Set(),
  signal=AbortSignal.timeout(30000),readBinding=consumedPublicationSource,observe=readPublicEditionEvidence}={}) {
  const {roots}=context;
  let released=0;
  const receivingSignal = signal;
  for (const edition of pending) {
    if (receivingSignal.aborted) break;
    if(observedCandidates.has(edition.candidateId))continue;
    try {
      const binding=readBinding({outputDir:edition.candidateDir,replayRoot:roots.publication,consumptionId:edition.consumptionId});
      if(binding.slug!==edition.slug)continue;
      const observed = await observe({slug: edition.slug, projectedSha256: binding.projectedSha256, signal: receivingSignal});
      if (!observed) continue;
      receivingSignal.throwIfAborted();
      const current=editionOf(roots,edition.candidateId);
      if(current?.state==='released'&&current.releasedSourceSha256===binding.projectedSha256&&current.publicationReceiptSha256===binding.receiptSha256){observedCandidates.add(edition.candidateId);continue;}
      if(current?.state!=='rendered'||current.consumptionId!==edition.consumptionId||current.candidateDir!==edition.candidateDir)continue;
      advanceEdition(roots, current, "released", at, {releasedAt: at, publicFingerprint: observed.fingerprint.sha256, releasedSourceSha256:binding.projectedSha256, publicationReceiptSha256:binding.receiptSha256, releaseManifest: sha256Hex(observed.manifestBytes), publicArticleUrl: observed.article.url, publicArticleSha256: observed.article.sha256, publicArticleBytes: observed.article.bytes});
      released++;observedCandidates.add(edition.candidateId);
    } catch { /* The next cloud pulse retries observation without spending authority again. */ }
  }
  if(pending.length>0&&pending.every(edition=>observedCandidates.has(edition.candidateId)))
    rmSync(join(roots.releases,'obstruction.json'),{force:true});
  return {released,observedCandidates};
}

/** The LAGOON-operated FeltOS job publishes through the received website program. */
async function release(context, { at }) {
  const { roots, dataRoot } = context;
  const pending = editions(roots, 'rendered');
  const attemptedRenderedIdentity = renderedEditionSetIdentity(pending);
  if(pending.length===0)return {status:'complete',released:0,attemptedRenderedIdentity,delivery:'native-feltos'};
  const result = spawnSync(process.execPath, [join(PACKAGE_ROOT, "scripts", "sync-publication-data.mjs")], {
    cwd: PACKAGE_ROOT, env: context.environment, encoding: "utf8", timeout: 120000,
  });
  if (result.status !== 0) {
    const obstruction = {type: "KoiosNewsReleaseObstructed", at, reason: (result.stderr || result.stdout).slice(-1000)};
    writeJsonAtomic(join(roots.releases, "obstruction.json"), obstruction);
    return {status: "blocked", released: 0, obstruction, attemptedRenderedIdentity};
  }
  let released = 0;
  const observedCandidates=new Set();
  released+=(await receivePublicEditions(context,{at,pending,observedCandidates})).released;
  if(observedCandidates.size<pending.length){
    const obstruct=(code,reason,diagnosticPath)=>{
      const obstruction={type:'KoiosNewsReleaseObstructed',at,code,reason,
        ...(typeof diagnosticPath==='string'?{diagnosticPath}:{})};
      writeJsonAtomic(join(roots.releases,'obstruction.json'),obstruction);
      return {status:'blocked',released,obstruction,attemptedRenderedIdentity,delivery:'native-feltos'};
    };
    if(!context.environment.CLOUDFLARE_API_TOKEN)return obstruct('publication-credential-unavailable','The native website publication credential is unavailable; received public editions retain their exact acknowledgements.');
    const website=readJson(join(PACKAGE_ROOT,'config/website-release.json'));
    const received=readJson(join(PACKAGE_ROOT,'package.json'));
    if(website.source.repository!=='causeway-services/koios.news'||website.source.directory!=='services/website'||
      received.dependencies[website.package.name]!==website.package.version)
      return obstruct('website-composition-mismatch','Native website composition differs from its received program.');
    const output=join(roots.releases,'native-'+attemptedRenderedIdentity);
    try{
      const build=spawnSync(process.execPath,[join(PACKAGE_ROOT,'scripts/build-public-site.mjs'),'--out',join(output,'public')],{
        cwd:PACKAGE_ROOT,env:context.environment,encoding:'utf8',timeout:null,
      });
      if(build.status!==0)return obstruct('native-website-build-failed','The received website build did not complete; publication custody is retained.');
      await releaseWebsite({candidateDir:join(output,'public'),receipts:join(output,'receipts'),revision:website.source.revision});
    }catch(error){return obstruct('native-website-release-failed','The native website release did not settle; inspect its retained release diagnostics.',error?.diagnosticPath);}
    released+=(await receivePublicEditions(context,{at,pending,observedCandidates})).released;
  }
  rmSync(join(roots.releases, "obstruction.json"), {force: true});
  return {status: "complete", released, attemptedRenderedIdentity, delivery: "native-feltos", research: await publishReleasedMarketResearch(context, at)};
}

export function newsLineMetrics(context, at = new Date().toISOString()) {
  const all = editions(context.roots), day = Date.parse(at) - 24 * 3600 * 1000;
  const releasedToday = all.filter((edition) => edition.state === "released" && Date.parse(edition.releasedAt) >= day);
  const newArticlesToday = releasedToday.filter((edition) => !edition.firstPublished);
  const revisionsToday = releasedToday.filter((edition) => Boolean(edition.firstPublished));
  const latencies = newArticlesToday.map((edition) => Date.parse(edition.releasedAt) - Date.parse(edition.draftedAt)).sort((a, b) => a - b);
  const byState = Object.fromEntries(["drafted", "accepted", "returned", "queued", "rendered", "released", "refused"].map((state) => [state, all.filter((edition) => edition.state === state).length]));
  const assessed = all.filter((edition) => ["accepted", "queued", "rendered", "released", "returned"].includes(edition.state) || edition.history?.some((step) => step.state === "accepted"));
  return {
    type: "KoiosNewsLineMetrics", at,
    articlesLast24h: newArticlesToday.length,
    revisionsLast24h: revisionsToday.length,
    dailyArticleTarget: context.property.cadence?.dailyArticleTarget ?? null,
    draftToReleaseMedianMinutes: latencies.length ? Math.round(latencies[Math.floor(latencies.length / 2)] / 60000) : null,
    deskCoverageLast24h: Object.fromEntries(context.property.sections.map((section) => [section.slug, newArticlesToday.filter((edition) => edition.section === section.slug).length])),
    editorialAcceptanceRate: assessed.length ? Number((assessed.filter((edition) => edition.state !== "returned").length / assessed.length).toFixed(3)) : null,
    returnedByFailureLayer: all.filter((edition) => edition.state === "returned").reduce((counts, edition) => ({ ...counts, [edition.failureLayer ?? "unknown"]: (counts[edition.failureLayer ?? "unknown"] ?? 0) + 1 }), {}),
    editions: byState,
    publishedLedger: listPublishedLedgerEntries(context.roots.publication).length,
    releaseObstruction: existsSync(join(context.roots.releases, "obstruction.json")) ? readJson(join(context.roots.releases, "obstruction.json")) : null,
  };
}

async function feedback(context, { at }) {
  const { roots } = context;
  const metrics = newsLineMetrics(context, at);
  writeJsonAtomic(join(roots.root, "metrics.json"), metrics);
  // A released edition's render candidate has done its work (authority spent, post in the ledger);
  // production is served from release builds, and only the newest released one is worth keeping.
  let retired = 0;
  for (const edition of editions(roots, "released")) {
    if (edition.candidateDir && existsSync(edition.candidateDir)) { rmSync(edition.candidateDir, { recursive: true, force: true }); retired += 1; }
  }
  const releasedBuilds = existsSync(roots.releases) ? readdirSync(roots.releases, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && /^[0-9a-f]{12}$/u.test(entry.name))
    .map((entry) => join(roots.releases, entry.name)) : [];
  const newest = releasedBuilds.filter((dir) => existsSync(join(dir, "release.json")))
    .sort((a, b) => statSync(join(a, "release.json")).mtimeMs - statSync(join(b, "release.json")).mtimeMs).at(-1);
  for (const dir of releasedBuilds) {
    // A build that never published a preview, or whose preview is retired, is no longer referenced.
    const settled = !existsSync(join(dir, "preview.json")) || existsSync(join(dir, "retired.json"));
    if (dir !== newest && settled && existsSync(join(dir, "public"))) { rmSync(join(dir, "public"), { recursive: true, force: true }); retired += 1; }
  }
  for (const entry of existsSync(roots.releases) ? readdirSync(roots.releases) : []) {
    if (entry.startsWith(".build-")) { rmSync(join(roots.releases, entry), { recursive: true, force: true }); retired += 1; }
  }
  return { status: "complete", metrics, candidatesRetired: retired };
}

export const STAGES = Object.freeze(["intake", "analyze", "draft", "assess", "authorize", "render", "release", "feedback"]);

/** Handlers bound to one line context, in the AOE service line's handler shape. */
export function newsLineHandlers(context = newsLineContext(), { assessment } = {}) {
  const bind = (stage) => (turn) => stage(context, turn);
  return Object.freeze({ intake: bind(intake), analyze: bind(analyze), draft: bind(draft), assess: turn => assess(context, turn, assessment), authorize: bind(authorize), render: bind(render), release: bind(release), feedback: bind(feedback) });
}


