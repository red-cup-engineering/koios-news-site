import {setDefaultResultOrder} from "node:dns";
// The cloud server’s IPv6 API route stalls; prefer its working IPv4 route.
setDefaultResultOrder("ipv4first");
export async function cloudflareJson(url,{method='GET',headers={},body,description='Cloudflare API',timeoutMs=30000}={}){
 let response;
 try{
  response=await fetch(url,{method,headers:{accept:'application/json',...headers},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(timeoutMs)});
 }catch(e){
  if(e.name==='AbortError'||e.name==='TimeoutError')throw new Error(`${description} request timed out after ${timeoutMs}ms`);
  throw new Error(`${description} request failed: ${e.message}`);
 }
 const text=await response.text();
 const contentType=response.headers.get('content-type')??'';
 let json;
 if(text&&contentType.toLowerCase().includes('json')){
  try{json=JSON.parse(text);}catch(e){throw new Error(`${description} returned invalid JSON: ${e.message}`);}
 }else if(text){
  const snippet=text.replace(/\s+/g,' ').slice(0,160);
  throw new Error(`${description} returned non-JSON HTTP ${response.status} (${contentType||'no content-type'}): ${snippet}`);
 }else json={};
 if(!response.ok){
  const messages=json.errors?.map(x=>x.message).filter(Boolean).join('; ');
  throw new Error(`${description} HTTP ${response.status}: ${messages||json.message||response.statusText}`);
 }
 return json;
}
