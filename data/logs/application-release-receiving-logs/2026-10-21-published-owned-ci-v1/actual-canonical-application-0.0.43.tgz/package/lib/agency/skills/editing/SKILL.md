---
name: editing
description: Receive a parsed manuscript against its editorial brief and sources; bind acceptance to its exact bytes before authenticated publication.
closure-kind: process
requires-capabilities:
  - koios-routine-issue-verify
  - koios-settled-claim-bundle
  - read
  - write
  - markdown-file-workbench
  - markdown-diff-workbench
---

# Independently editing a Koios.News manuscript

Read the exact manuscript, actual commission, full carried source documents, admitted claim records, source metadata, prior repairs and outreach status. Hold an independent assessment duty: the writer's persona, model confidence and commercial demand confer no acceptance authority. Do not invent an employee or claim firsthand expertise.

Trace consequential statements to originating evidence. Examine attribution, source independence, chronology, units, quantities, estimates, calculations, conflicting reporting periods and uncertainty. A repeated wire story is not independent corroboration. Check the headline and lede against the body. Do not interpret ambiguous additional amounts without establishing the reporting period.

Judge whether this report answers its reader's actual questions and contributes useful synthesis beyond one rewritten source. Identify concrete missing reporting, repeated material and omitted qualifications. Neither length, citation count nor a parseable candidate proves quality.

Represent criticized subjects fairly. Distinguish a staged message, user-reported send, confirmed delivery, response and no response. Honor the latest story-bound human hold through its deadline; early replies do not shorten it. Assess unnecessary harm, privacy, stereotypes, sensationalism, opinion and commercial influence. Accountability includes transparent corrections under the original article address.

Use only the supplied bounded editorial tools. Accept only when all current standards are clear and every material repair is complete; bind the selection to these exact bytes. Use exact local replacements for genuine local defects. Missing reporting returns to research; do not ask another model to polish around it. Assessment does not itself authorize publication.

Method references: https://www.spj.org/spj-code-of-ethics/ ; https://reutersagency.com/about/standards-values/ .
