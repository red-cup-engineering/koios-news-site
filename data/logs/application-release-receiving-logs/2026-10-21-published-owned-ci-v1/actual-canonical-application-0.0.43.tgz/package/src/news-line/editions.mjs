/**
 * The Koios news line's custody: where each edition's bytes live between stages, the
 * edition records that carry a manuscript from draft to release, and the node-held
 * Ed25519 keys of the two offices that sign along the way (the independent assessor
 * and the editor-in-chief's standing publication authority).
 *
 * Everything here is operational state under the newsroom data root, never inside a
 * source checkout. The line's journal is the evidence; edition records are its working set.
 */
import { createPublicKey, generateKeyPairSync, createPrivateKey } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, renameSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { sha256Hex } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity";
import { withFileLock } from "@red-cup-engineering/semiotic-eavt-services-section/store";
import { canonicalJson } from "@red-cup-engineering/json-services-section/canonical";

/** Every root the line writes, created on first use. */
export function lineRoots(dataRoot) {
  const root = join(dataRoot, "line");
  const roots = {
    root,
    feedback: join(dataRoot, "feedback"),
    arrivals: join(root, "arrivals"),
    analyzed: join(root, "arrivals", "analyzed"),
    drafts: join(root, "drafts"),
    editions: join(root, "editions"),
    assessments: join(root, "assessments"),
    admissions: join(root, "admissions"),
    keys: join(root, "keys"),
    grants: join(root, "authority", "grants"),
    queue: join(root, "queue"),
    formation: join(root, "formation"),
    // One publication replay root: its published/ ledger accumulates every issue and its
    // consumed/ records are the ones issue formation checks before queueing.
    publication: join(root, "publication-replay"),
    candidates: join(root, "candidates"),
    releaseReplay: join(root, "release-replay"),
    releases: join(root, "releases"),
  };
  for (const path of Object.values(roots)) mkdirSync(path, { recursive: true, mode: 0o700 });
  mkdirSync(join(roots.publication, "consumed"), { recursive: true, mode: 0o700 });
  return Object.freeze(roots);
}

export const EDITION_STATES = Object.freeze([
  "drafted", "accepted", "returned", "queued", "rendered", "released", "refused",
]);

const editionFile = (roots, candidateId) => join(roots.editions, `${sha256Hex(candidateId).slice(0, 40)}.json`);

export function writeJsonAtomic(path, value, mode = 0o600) {
  const temporary = `${path}.${process.pid}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, { mode });
  renameSync(temporary, path);
}

export function readJson(path) { return JSON.parse(readFileSync(path, "utf8")); }

export function editionOf(roots, candidateId) {
  const path = editionFile(roots, candidateId);
  return existsSync(path) ? readJson(path) : null;
}

export function editions(roots, state) {
  const all = readdirSync(roots.editions).filter((name) => name.endsWith(".json")).map((name) => readJson(join(roots.editions, name)));
  return (state === undefined ? all : all.filter((edition) => edition.state === state))
    .sort((a, b) => a.draftedAt.localeCompare(b.draftedAt) || a.candidateId.localeCompare(b.candidateId));
}

/** Advance one edition: its state changes and the transition joins its history. */
export function advanceEdition(roots, edition, state, at, fields = {}) {
  if (!EDITION_STATES.includes(state)) throw new TypeError(`unknown edition state ${state}`);
  return withFileLock(editionFile(roots, edition.candidateId)+'.lock',()=>{
  const current=editionOf(roots,edition.candidateId);
  const expectedCurrent=current&&{...current};
  // Legacy callers retain the original freshly opened row without its stored
  // initial history. All state, version and other fields still participate.
  if(expectedCurrent&&!Object.hasOwn(edition,'history'))delete expectedCurrent.history;
  if(!current||canonicalJson(expectedCurrent)!==canonicalJson(edition)){
    const error=new Error('Edition changed before its state transition: '+edition.candidateId);
    error.code='editorial-edition-conflict';throw error;
  }
  const next = { ...current, ...fields, state, updatedAt: at, history: [...(current.history ?? []), { state, at, ...(fields.reason ? { reason: fields.reason } : {}) }] };
  writeJsonAtomic(editionFile(roots, edition.candidateId), next);
  return next;
  });
}

export function openEdition(roots, edition) {
  return withFileLock(editionFile(roots,edition.candidateId)+'.lock',()=>{
    const current=editionOf(roots,edition.candidateId);
    if(current)return current;
    const opened={...edition,history:[{state:edition.state,at:edition.draftedAt}]};
    writeJsonAtomic(editionFile(roots,edition.candidateId),opened);return opened;
  });
}

/**
 * One office's node-held Ed25519 key: generated once, private key 0600, and a key map
 * `{keyId: raw public key base64url}` beside it in the shape the authority verifiers read.
 * When `$CREDENTIALS_DIRECTORY/koios-<office>.pem` exists the host signs with that issuer key instead.
 */
export function officeKey(roots, office) {
  const directory = join(roots.keys, office);
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  const privatePath = join(directory, "ed25519.pem"), keyMapPath = join(directory, "keys.json");
  const credential = process.env.CREDENTIALS_DIRECTORY ? join(process.env.CREDENTIALS_DIRECTORY, `koios-${office}.pem`) : undefined;
  if (credential && existsSync(credential)) {
    // The issuer's key, held as a systemd credential on the host that signs; it is read in place and never copied.
    const privateKey = createPrivateKey(readFileSync(credential, "utf8"));
    const x = createPublicKey(privateKey).export({ format: "jwk" }).x;
    const keyId = `koios_${office.replace(/[^A-Za-z0-9]/gu, "_")}_${sha256Hex(x).slice(0, 16)}`;
    if (!existsSync(keyMapPath) || readJson(keyMapPath)[keyId] !== x) writeJsonAtomic(keyMapPath, { [keyId]: x }, 0o644);
    return Object.freeze({ keyId, privateKey, keyMapPath });
  }
  if (!existsSync(privatePath)) {
    const pair = generateKeyPairSync("ed25519");
    writeFileSync(privatePath, pair.privateKey.export({ format: "pem", type: "pkcs8" }), { mode: 0o600, flag: "wx" });
  }
  const privateKey = createPrivateKey(readFileSync(privatePath, "utf8"));
  const x = createPublicKey(privateKey).export({ format: "jwk" }).x;
  const keyId = `koios_${office.replace(/[^A-Za-z0-9]/gu, "_")}_${sha256Hex(x).slice(0, 16)}`;
  if (!existsSync(keyMapPath) || readJson(keyMapPath)[keyId] !== x) writeJsonAtomic(keyMapPath, { [keyId]: x }, 0o644);
  return Object.freeze({ keyId, privateKey, keyMapPath });
}

/** A URL-safe slug from a headline, unique against every slug already taken. */
export function slugFor(title, taken, salt) {
  const words = title.toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/gu, "")
    .replace(/[^a-z0-9]+/gu, " ").trim().split(/\s+/u).filter(Boolean);
  let slug = "";
  for (const word of words) { if ((slug ? `${slug}-${word}` : word).length > 72) break; slug = slug ? `${slug}-${word}` : word; }
  slug ||= "koios-report";
  return taken.has(slug) ? `${slug}-${sha256Hex(salt).slice(0, 6)}` : slug;
}
