import test from "node:test";
import assert from "node:assert/strict";
import {selectAssessmentBatch} from "../src/news-line/stages.mjs";

const revision=(id,at,provider="urn:ame:koios-cloud-editor")=>({candidateId:id,draftedAt:at,firstPublished:"2026-10-03",provider});
const fresh=(id,at)=>({candidateId:id,draftedAt:at,provider:"urn:ame:koios-cloud-writer"});

test("one-slot assessment capacity cannot be monopolized by revisions",()=>{
  const selected=selectAssessmentBatch([
    revision("old-revision","2026-10-09T00:00:00Z"),
    fresh("new-story","2026-10-10T00:00:00Z"),
  ],1);
  assert.deepEqual(selected.map(x=>x.candidateId),["new-story"]);
});

test("remaining slots keep requested revision priority after one new article",()=>{
  const selected=selectAssessmentBatch([
    fresh("newer-story","2026-10-10T01:00:00Z"),
    revision("requested-revision","2026-10-09T00:00:00Z"),
    fresh("oldest-new-story","2026-10-10T00:00:00Z"),
  ],2);
  assert.deepEqual(selected.map(x=>x.candidateId),["oldest-new-story","requested-revision"]);
});

test("revision-only queues preserve requested-revision priority and FIFO",()=>{
  const selected=selectAssessmentBatch([
    revision("later","2026-10-10T02:00:00Z"),
    revision("earlier","2026-10-10T01:00:00Z"),
    revision("nonrequested","2026-10-09T00:00:00Z","other"),
  ],2);
  assert.deepEqual(selected.map(x=>x.candidateId),["earlier","later"]);
});

test("zero capacity selects nothing",()=>assert.deepEqual(selectAssessmentBatch([fresh("x","2026-10-10T00:00:00Z")],0),[]));
test("invalid capacity refuses",()=>assert.throws(()=>selectAssessmentBatch([], -1),/non-negative integer/));
