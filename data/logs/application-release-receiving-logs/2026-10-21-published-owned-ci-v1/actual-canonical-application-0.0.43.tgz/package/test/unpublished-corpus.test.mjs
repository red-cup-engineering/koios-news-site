import test from "node:test";
import assert from "node:assert/strict";
import {mkdtempSync,mkdirSync,writeFileSync,rmSync,symlinkSync,readFileSync} from "node:fs";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {inspectHeldManuscript,observeUnpublishedCorpus} from "../src/news-line/unpublished-corpus.mjs";

const clock=new Date("2026-10-13T18:00:00.000Z");
function markdown(date="2026-10-12",text="An account. ".repeat(400)){
 return ["---","title: A held draft","date: "+date,"draft: true","koios:","  gates_clear: false",
  "references:","  - URL: https://a.example/source","  - URL: https://www.b.example/source",
  "  - URL: https://c.example/source","---","## Reporting",text,""].join("\n");
}
function fixture(run){
 const root=mkdtempSync(join(tmpdir(),"koios-census-")),dirs={};
 for(const label of ["posts","reporters","claims","published"]){
  dirs[label]=join(root,label);mkdirSync(dirs[label],{recursive:true});
 }
 try{return run(dirs);}finally{rmSync(root,{recursive:true,force:true});}
}
function census(d){return observeUnpublishedCorpus({postsDir:d.posts,reporterDir:d.reporters,
 claimsDir:d.claims,publishedDir:d.published,observedAt:clock});}

test("one held article and one archived claim are not a published or accepted article",()=>fixture(d=>{
 writeFileSync(join(d.posts,"new-story.md"),markdown());
 mkdirSync(join(d.claims,"science"));writeFileSync(join(d.claims,"science","lead.json"),"{}");
 const result=census(d);
 assert.equal(result.manuscriptFiles,1);
 assert.equal(result.unpublishedNewSlugFiles,1);
 assert.equal(result.explicitlyMarkedDraft,1);
 assert.equal(result.sourceClaimArchiveFiles,1);
 assert.equal(result.publishedLedgerFiles,0);
 assert.equal(result.declaredGates.false,1);
 assert.equal(result.citedHostCountBuckets["3-plus"],1);
 assert.equal(result.editorialAcceptance,"unverified");
 assert.equal(result.releaseAuthorization,"not-implied");
 assert.equal(result.sourceIndependence,"unverified");
}));

test("a held draft on a public slug counts as revision demand, not a new release",()=>fixture(d=>{
 writeFileSync(join(d.posts,"already-public.md"),markdown("2025-02-17"));
 writeFileSync(join(d.published,"already-public.md"),"signed historically");
 const result=census(d);
 assert.equal(result.unpublishedNewSlugFiles,0);
 assert.equal(result.draftFilesRevisingPublicSlug,1);
 assert.equal(result.publishedLedgerFiles,1);
 assert.equal(result.manuscriptDatesWithinSevenDays,0);
}));

test("separate reporter manuscripts never masquerade as accepted editions",()=>fixture(d=>{
 writeFileSync(join(d.reporters,"reporter.md"),markdown());
 const result=census(d);
 assert.equal(result.separateReporterManuscripts,1);
 assert.equal(result.manuscriptFiles,0);
 assert.equal(result.editorialAcceptance,"unverified");
}));

test("missing roots and symlinks fail closed rather than reporting empty inventory",()=>fixture(d=>{
 assert.throws(()=>observeUnpublishedCorpus({postsDir:"/does-not-exist",claimsDir:d.claims,publishedDir:d.published}),/ENOENT/);
 assert.throws(()=>observeUnpublishedCorpus({postsDir:d.posts,claimsDir:"/does-not-exist",publishedDir:d.published}),/ENOENT/);
 symlinkSync(join(d.posts,"missing.md"),join(d.posts,"bad.md"));
 assert.throws(()=>census(d),/Nonregular manuscript/);
}));

test("an unparseable draft has no fictional source, clearance or release",()=>{
 const result=inspectHeldManuscript("Some text without frontmatter",clock);
 assert.equal(result.metadata,"missing");
 assert.equal(result.draft,"unknown");
 assert.equal(result.declaredReferenceHosts,0);
 assert.equal(result.datedWithinWindow,false);
});

test("the deployed maintenance collector owns the census, not a parallel scheduled reporter",()=>{
 const source=readFileSync(new URL("../scripts/collect-feedback.mjs",import.meta.url),"utf8");
 assert.match(source,/await sensor\('unpublishedCorpus'/u);
 assert.match(source,/observeUnpublishedCorpus\(/u);
 assert.doesNotMatch(source,/await sensor\('unpublishedCorpus'[\s\S]*?publishArticle\(/u);
});
