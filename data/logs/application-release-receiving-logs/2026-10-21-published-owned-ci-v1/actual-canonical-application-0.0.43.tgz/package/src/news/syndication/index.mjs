// Syndication intake — Koios's adapters that fetch a configured source (arXiv,
// RSS or Atom, a newswire's JSON Feed) and read it into syndication items. The
// readers are the serialized-content web feed's; fetching with retry is the
// HTTP section's.

import { parseArxivAtom, parseFeed, parseJsonFeed } from "@red-cup-engineering/computer-serialized-content-engineering-services-section/web-feed";
import { fetchText } from "@red-cup-engineering/http-services-section/fetch-text";

const ARXIV_API = "http://export.arxiv.org/api/query";

// ---------- arXiv ----------

/** The arXiv API query URL for a configured intake. */
export function arxivQueryUrl({ query, max = 10, sortBy = "submittedDate", sortOrder = "descending" }) {
  if (!query) throw new TypeError("arxiv source needs a query");
  const params = new URLSearchParams({
    search_query: query,
    start: "0",
    max_results: String(max),
    sortBy,
    sortOrder,
  });
  return `${ARXIV_API}?${params}`;
}

/** Fetch and parse one arXiv intake. */
export async function fetchArxiv(params, io = {}) {
  const fetchOptions = {};
  if (io.fetchImpl) fetchOptions.fetchImpl = io.fetchImpl;
  if (params.retries !== undefined) fetchOptions.retries = params.retries;
  const xml = await fetchText(arxivQueryUrl(params), fetchOptions);
  return parseArxivAtom(xml);
}

// ---------- RSS / Atom ----------

/** Fetch and parse one feed intake (`url` preferred, `query` accepted). */
export async function fetchFeed(params, io = {}) {
  const url = params.url ?? params.query;
  if (!url) throw new TypeError("rss source needs a url or query");
  const fetchOptions = {};
  if (io.fetchImpl) fetchOptions.fetchImpl = io.fetchImpl;
  if (params.retries !== undefined) fetchOptions.retries = params.retries;
  return Object.freeze(parseFeed(await fetchText(url, fetchOptions)).slice(0, params.max ?? 20));
}

// ---------- JSON Feed (newswire surface) ----------

/**
 * Fetch and parse a JSON Feed from a newswire's /feed.json surface.
 * `url` is the wire's base URL (e.g. "http://127.0.0.1:18810/newswires/collapse-climate/");
 * the adapter appends "feed.json". Each item maps to a SyndicationItem whose
 * `source` is the wire URL so provenance carries forward.
 */
export async function fetchJsonFeed(
  params,
  io = {},
) {
  const base = params.url;
  if (!base) throw new TypeError("newswire source needs a url (the wire's base URL)");
  const feedUrl = base.replace(/\/?$/, "/") + "feed.json";
  const fetchOptions = {};
  if (io.fetchImpl) fetchOptions.fetchImpl = io.fetchImpl;
  if (params.retries !== undefined) fetchOptions.retries = params.retries;
  const text = await fetchText(feedUrl, fetchOptions);
  let items;
  try {
    items = parseJsonFeed(text, { source: base });
  } catch {
    throw new Error(`newswire feed.json is not a JSON Feed: ${feedUrl}`);
  }
  return Object.freeze(items.slice(0, params.max ?? 20));
}

// ---------- adapter registry ----------

/** The arXiv syndication adapter: type "arxiv", fetching via fetchArxiv. */
export const arxivAdapter = Object.freeze({
  type: "arxiv",
  fetch: (params, io) => fetchArxiv(params, io),
});

/** The RSS/Atom syndication adapter: type "rss", fetching via fetchFeed. */
export const rssAdapter = Object.freeze({
  type: "rss",
  fetch: (params, io) => fetchFeed(params, io),
});

/**
 * The newswire JSON Feed syndication adapter: type "newswire", fetching via
 * fetchJsonFeed.
 */
export const newswireAdapter = Object.freeze({
  type: "newswire",
  fetch: (params, io) => fetchJsonFeed(params, io),
});

/** The default adapter registry. Consumers extend by spreading. */
export const syndicationAdapters = Object.freeze({ arxiv: arxivAdapter, rss: rssAdapter, newswire: newswireAdapter });
