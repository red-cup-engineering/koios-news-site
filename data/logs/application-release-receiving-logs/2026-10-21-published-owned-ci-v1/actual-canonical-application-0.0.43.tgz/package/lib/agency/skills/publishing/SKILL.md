---
name: publishing
description: "Carry an independently accepted manuscript through publication authority, rendering and public delivery using the Koios FeltOS news cycle."
closure-kind: process
requires-capabilities:
  - koios-news-cycle
  - koios-news-status
  - koios-routine-issue
  - koios-routine-issue-verify
  - koios-routine-queue-job
  - koios-routine-publication
  - koios-production-audit
  - koios-settle-message
  - koios-service-section
---

# Publishing a Koios.News issue

Publication begins only after the editing skill has accepted the exact manuscript.

1. Form the routine issue job from the admitted draft, its assessment receipt, its authority grant and the settled-claim bundle bound to the manuscript's bytes.
2. Verify the job against its files before it enters the queue.
3. Take the next job for the current pulse; the replay root binds the occurrence to the job, so a retry never advances the queue or rebinds a manuscript.
4. Let the native FeltOS `koios-news-cycle` carry accepted editions through authorization, rendering, release and feedback. It runs every 15 minutes. Its retained daily schedule reads status; it does not start a second publisher. Routine issue and publication operations are the cycle's underlying capabilities and recovery tools.
5. Complete delivery at the public article: the released manuscript must match the consumed publication source. Read `koios-news-status` for actual new articles, desk coverage and editorial blockers. A completed clock invocation or an offline candidate alone is not delivery. Repair a blocked stage at its owning source and continue the same editorial work; preserve holds, assessment and authority.
6. Settle messages from hiring publications at the service section's boundary; a replayed message returns its first durable response.
