// Share bounded operating facts on both success and failure. Provider output,
// manuscript bytes, error prose, repair identifiers and filesystem paths stay
// in their original private runtime carriers.
const STAGES = ['intake', 'analyze', 'draft', 'assess', 'authorize', 'render', 'release', 'feedback'];
const STATES = ['complete', 'pending', 'blocked', 'needs-human'];
const CODES = ['stage-threw', 'missing-stage-handler', 'untyped-human-boundary', 'every-wire-unreachable', 'reporter-submission-custody-incomplete', 'inference-obstructed', 'assessment-inference-obstructed', 'render-failed'];
const FAILURE_CLASSES = ['VALIDATION_FAILURE', 'AUTOMATION_DRIFT', 'PROVIDER_OUTAGE', 'LINT_FAILURE', 'CONFIGURATION_FAILURE', 'INSUFFICIENT_MACHINE_CAPABILITY', 'CONTROL_PLANE_DEFECT', 'UNKNOWN_FAILURE_CLASS'];
const EDITION_STATES = ['drafted', 'accepted', 'returned', 'queued', 'rendered', 'released', 'refused'];
const RETURN_LAYERS = ['writer-model', 'sources', 'assignment', 'draft-repair', 'deterministic-gates', 'none'];
const instant = value => {
  if (typeof value !== 'string' || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(value) || !Number.isFinite(Date.parse(value))) return null;
  const canonical = value.length === 20 ? value.slice(0, -1) + '.000Z' : value;
  return new Date(value).toISOString() === canonical ? value : null;
};
const count = value => Number.isSafeInteger(value) && value >= 0 ? value : null;
const member = (values, value) => values.includes(value) ? value : null;
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const rows = value => Array.isArray(value) ? value : [];

/** Exact clock, stage and queue facts; never spread a runtime record into feedback. */
export function newsroomRuntimeFacts(runtime) {
  const status = record(runtime?.status) ? runtime.status : {};
  const live = record(status.live) ? status.live : record(status.metrics) ? status.metrics : {};
  const stages = rows(status.stages).filter(row => record(row) && STAGES.includes(row.stage)).slice(0, STAGES.length)
    .map(row => ({stage: row.stage, status: member(STATES, row.status), lastRun: instant(row.lastRun)}));
  return {
    kind: 'koios.news.runtime-observation/v1',
    observedAt: instant(runtime?.observedAt),
    turns: rows(runtime?.turns).filter(row => record(row) && STAGES.includes(row.stage)).slice(-STAGES.length)
      .map(row => ({stage: row.stage, status: member(STATES, row.status), cycle: count(row.cycle)})),
    status: {
      cycle: count(status.cycle), next: member(STAGES, status.next), lastRun: instant(status.lastRun), stages,
      blockers: rows(status.blockers).slice(0, STAGES.length).map(row => ({
        stage: member(STAGES, row?.stage), status: member(STATES, row?.status),
        code: member(CODES, row?.code) ?? 'unclassified-blocker',
        failureClass: member(FAILURE_CLASSES, row?.failureClass),
        lastRun: stages.find(stage => stage.stage === row?.stage)?.lastRun ?? null,
      })),
      live: {
        at: instant(live.at), articlesLast24h: count(live.articlesLast24h), revisionsLast24h: count(live.revisionsLast24h),
        dailyArticleTarget: count(live.dailyArticleTarget), publishedLedger: count(live.publishedLedger),
        editions: Object.fromEntries(EDITION_STATES.map(state => [state, count(live.editions?.[state])])),
        // Preserve bounded *lifetime* failure-layer counts for newsroom diagnosis.
        // Arbitrary provider and draft labels never leave the private runtime.
        returnedByFailureLayer: Object.fromEntries(RETURN_LAYERS
          .filter(layer => count(live.returnedByFailureLayer?.[layer]) !== null)
          .map(layer => [layer, count(live.returnedByFailureLayer[layer])])),
        releaseObstruction: live.releaseObstruction ? {present: true} : null,
      },
    },
  };
}

/** A fresh collector does not make an old stage outcome fresh or prove liveness. */
export function newsroomFeedback(runtime, observedAt) {
  if (!instant(observedAt)) throw new TypeError('A UTC feedback observation instant is required');
  const facts = newsroomRuntimeFacts(runtime), observation = {observedAt, runtime: facts};
  const unavailable = reason => ({status: 'unavailable', reason, ...observation});
  if (!record(runtime) || runtime.kind !== 'koios.news.runtime-observation/v1' || !record(runtime.status)
      || !Array.isArray(runtime.status.blockers) || !facts.observedAt || !facts.status.lastRun || !facts.status.next) {
    return unavailable('Cloud newsroom execution evidence is missing or invalid. Inspect the retained runtime observation and durable stage.');
  }
  const age = Date.parse(observedAt) - Date.parse(facts.observedAt);
  const stageClockInvalid = rows(runtime.status.stages).some(row => record(row) && STAGES.includes(row.stage) && row.lastRun !== null && row.lastRun !== undefined
    && (!instant(row.lastRun) || Date.parse(row.lastRun) > Date.parse(facts.observedAt)));
  if (age < 0 || Date.parse(facts.status.lastRun) > Date.parse(facts.observedAt) || stageClockInvalid) {
    return unavailable('Cloud newsroom execution evidence has an invalid or future stage timestamp. Inspect its clock before treating publication as healthy.');
  }
  if (age > 90 * 60000) return unavailable(`Cloud newsroom execution is stale: last observed ${facts.observedAt}. Inspect the unit and durable stage before treating publication as healthy.`);
  if (facts.status.blockers.length) return unavailable(`Cloud newsroom stage blocked: ${facts.status.blockers.map(row => `${row.stage ?? 'unknown'}: ${row.code}`).join('; ')}. The public site's successful build does not establish newsroom execution.`);
  if (facts.status.live.releaseObstruction) return unavailable('Cloud newsroom publication-data sync is obstructed. Inspect the retained release-stage outcome; completed turns do not establish delivery.');
  return {status: 'observed', ...observation};
}
