// Public receiving is read-only. Neither a stalled transport nor a stalled body
// may retain the newsroom's editorial lock indefinitely.
import {createHash} from 'node:crypto';

const FINGERPRINT_MAX_BYTES = 64 * 1024;
const MANIFEST_MAX_BYTES = 8 * 1024 * 1024;
const ARTICLE_MAX_BYTES = 8 * 1024 * 1024;
const ORIGIN = 'https://koios.news';
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const isDigest = value => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value);
const availableAt = (response, url) => response.status === 200 && response.redirected !== true &&
  (response.url === '' || response.url === url);

/** Consume the existing renderer's exact artifact and canonical-route bindings.
 * A public manifest is an observation, not a deployment or editorial grant.
 */
function editionArtifacts(manifest, slug, fingerprintBytes) {
  if (manifest?.kind !== 'news-property.build-manifest/v1' ||
      manifest.provenance?.origin !== ORIGIN ||
      !Array.isArray(manifest.artifacts) || !Array.isArray(manifest.routes)) return null;
  const find = (file, maximum) => {
    const rows = manifest.artifacts.filter(row => row?.file === file);
    if (rows.length !== 1) return null;
    const row = rows[0];
    return isDigest(row.sha256) && Number.isSafeInteger(row.bytes) &&
      row.bytes > 0 && row.bytes <= maximum ? row : null;
  };
  const fingerprint = find(`fingerprints/${slug}.json`, FINGERPRINT_MAX_BYTES);
  const article = find(`posts/${slug}/index.html`, ARTICLE_MAX_BYTES);
  if (!fingerprint || !article || fingerprint.bytes !== fingerprintBytes.length ||
      fingerprint.sha256 !== digest(fingerprintBytes)) return null;
  const url = `${ORIGIN}/posts/${slug}/`;
  const routes = manifest.routes.filter(row => row?.url === url);
  if (routes.length !== 1 || routes[0].hash !== article.sha256) return null;
  return {fingerprint, article: {...article, url}};
}

async function readBoundedBody(response, maximum, signal) {
  const declared = response.headers.get('content-length');
  if (declared !== null && /^\d+$/.test(declared) && Number(declared) > maximum) {
    void response.body?.cancel().catch(() => {});
    throw new Error('Public receiving body exceeds its byte budget');
  }
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader(), chunks = [];
  let size = 0, finished = false;
  const cancel = () => { void reader.cancel().catch(() => {}); };
  signal.addEventListener('abort', cancel, {once: true});
  try {
    while (true) {
      signal.throwIfAborted();
      const {done, value} = await reader.read();
      signal.throwIfAborted();
      if (done) { finished = true; break; }
      size += value.byteLength;
      if (size > maximum) throw new Error('Public receiving body exceeds its byte budget');
      chunks.push(Buffer.from(value));
    }
    return Buffer.concat(chunks, size);
  } finally {
    signal.removeEventListener('abort', cancel);
    if (!finished) cancel();
  }
}

/** Read the exact edition's evidence within the caller's shared turn deadline.
 * The terminal race also bounds clients that ignore cancellation. Late results
 * cannot mutate custody: this module only reads and returns evidence.
 */
export async function readPublicEditionEvidence({slug, projectedSha256, signal}) {
  signal.throwIfAborted();
  if (typeof slug !== 'string' || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(slug) ||
      typeof projectedSha256 !== 'string' || !/^sha256:[a-f0-9]{64}$/u.test(projectedSha256)) {
    throw new TypeError('Public receiving requires an exact edition slug and source digest');
  }
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(signal.reason);
    signal.addEventListener('abort', onAbort, {once: true});
  });
  const observation = (async () => {
    const options = {headers: {'cache-control': 'no-cache'}, signal, redirect: 'error'};
    const fingerprintUrl = `${ORIGIN}/fingerprints/${slug}.json`;
    const response = await fetch(fingerprintUrl, options);
    if (signal.aborted) { void response.body?.cancel().catch(() => {}); signal.throwIfAborted(); }
    if (!availableAt(response, fingerprintUrl)) { void response.body?.cancel().catch(() => {}); return null; }
    const fingerprintBytes = await readBoundedBody(response, FINGERPRINT_MAX_BYTES, signal);
    const fingerprint = JSON.parse(fingerprintBytes.toString('utf8'));
    if (fingerprint?.kind !== 'producing-content.article-fingerprint' ||
        fingerprint.facts?.kind !== 'producing-content.article-fingerprint.facts' ||
        fingerprint.facts.slug !== slug || fingerprint.facts.url !== `${ORIGIN}/posts/${slug}` ||
        !isDigest(fingerprint.sha256) || `sha256:${fingerprint.facts.sourceSha256}` !== projectedSha256) return null;
    const manifest = await fetch(`${ORIGIN}/manifest.json`, options);
    if (signal.aborted) { void manifest.body?.cancel().catch(() => {}); signal.throwIfAborted(); }
    if (!availableAt(manifest, `${ORIGIN}/manifest.json`)) { void manifest.body?.cancel().catch(() => {}); return null; }
    const manifestBytes = await readBoundedBody(manifest, MANIFEST_MAX_BYTES, signal);
    const artifacts = editionArtifacts(JSON.parse(manifestBytes.toString('utf8')), slug, fingerprintBytes);
    if (!artifacts) return null;
    signal.throwIfAborted();
    const article = await fetch(artifacts.article.url, options);
    if (signal.aborted) { void article.body?.cancel().catch(() => {}); signal.throwIfAborted(); }
    if (!availableAt(article, artifacts.article.url)) { void article.body?.cancel().catch(() => {}); return null; }
    const articleBytes = await readBoundedBody(article, artifacts.article.bytes, signal);
    if (articleBytes.length !== artifacts.article.bytes || digest(articleBytes) !== artifacts.article.sha256) return null;
    signal.throwIfAborted();
    return {fingerprint, manifestBytes, article: artifacts.article};
  })();
  try { return await Promise.race([observation, aborted]); }
  finally { signal.removeEventListener('abort', onAbort); }
}
