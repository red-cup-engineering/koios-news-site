/**
 * The routine publication a pulse forms: the selected issue job (one fixed manifest, or the next
 * queued job bound to the pulse) written as an offline reader-facing candidate under the output and
 * replay roots the host configures. The environment names are the package's own
 * (config/routine-operation.json); a pulse never selects a host path. The replay root is one
 * publication's: its published-post ledger accumulates every issue and its consumption records are
 * the ones issue formation checks, so it is never split per candidate.
 */
import { lstatSync, readFileSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";
import { planRoutinePublication, writeRoutinePublication } from "./offline-publication.mjs";
import { declaredPropertyInputs } from "@causeway-services/koios-news-site/build";
import { verifyRoutineIssue } from "./routine-issue-formation.mjs";
import { selectRoutineQueueJob } from "./routine-job-queue.mjs";

export const ROUTINE_OPERATION = "form-offline-candidate";
const CONFIG_PATH = new URL("../config/routine-operation.json", import.meta.url).pathname;

function requireString(value, label) {
  if (typeof value !== "string" || value.trim() === "") throw new Error(`${label} must be a nonempty string`);
  return value;
}
function readJson(path, label) { try { return JSON.parse(readFileSync(path, "utf8")); } catch (error) { throw new Error(`${label} is not readable JSON: ${error.message}`); } }
function requireAbsolutePath(value, label) { requireString(value, label); if (!value.startsWith("/")) throw new Error(`${label} must be an absolute path`); return resolve(value); }
function requireRealDirectory(path, label) { try { const stat = lstatSync(path); if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error(); } catch { throw new Error(`${label} must be an existing real directory`); } return path; }
function requireRealFile(path, label) { try { const stat = lstatSync(path); if (stat.isSymbolicLink() || !stat.isFile()) throw new Error(); } catch { throw new Error(`${label} must be an existing real file`); } return path; }
function safeChild(root, name, label) { const candidate = resolve(root, name), rel = relative(root, candidate); if (rel === "" || rel === ".." || rel.startsWith(`..${sep}`)) throw new Error(`${label} escapes its configured root`); return candidate; }

export function canonicalInstant(value, label) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u.test(value) || new Date(value).toISOString() !== value) throw new Error(`${label} must be a canonical UTC timestamp`);
  return value;
}

function operationConfig() {
  const config = readJson(CONFIG_PATH, "package routine-operation config"), required = ["contract", "jobEnvironment", "queueEnvironment", "authorityKeysEnvironment", "assessmentKeysEnvironment", "outputRootEnvironment", "replayRootEnvironment", "propertyEnvironment"];
  if (!config || typeof config !== "object" || Array.isArray(config) || Object.keys(config).length !== required.length || required.some((key) => typeof config[key] !== "string")) throw new Error("package routine-operation config has an invalid shape");
  if (![config.jobEnvironment, config.queueEnvironment, config.authorityKeysEnvironment, config.assessmentKeysEnvironment, config.outputRootEnvironment, config.replayRootEnvironment, config.propertyEnvironment].every((name) => /^[A-Z][A-Z0-9_]*$/u.test(name))) throw new Error("package routine-operation config is invalid");
  return config;
}

/** The job a pulse selects, verified, with its keys and candidate roots; `reserve` binds a queued job to the pulse. */
export function routinePublicationJob({ pulseId, now, reserve = true, environment = process.env }) {
  const config = operationConfig(), fixedJob = environment[config.jobEnvironment], queueRoot = environment[config.queueEnvironment];
  if ((typeof fixedJob === "string" && fixedJob !== "") === (typeof queueRoot === "string" && queueRoot !== "")) throw new Error(`exactly one of ${config.jobEnvironment} or ${config.queueEnvironment} is required`);
  const outputRoot = requireRealDirectory(requireAbsolutePath(environment[config.outputRootEnvironment], `${config.outputRootEnvironment} output root`), `${config.outputRootEnvironment} output root`), replayRoot = requireRealDirectory(requireAbsolutePath(environment[config.replayRootEnvironment], `${config.replayRootEnvironment} replay root`), `${config.replayRootEnvironment} replay root`);
  const queued = queueRoot === undefined || queueRoot === "" ? undefined : selectRoutineQueueJob({ queueRoot: requireAbsolutePath(queueRoot, `${config.queueEnvironment} queue root`), replayRoot, pulseId, reserve });
  const manifestPath = queued === undefined ? requireRealFile(requireAbsolutePath(fixedJob, `${config.jobEnvironment} job manifest`), `${config.jobEnvironment} job manifest`) : queued.manifestPath, job = readJson(manifestPath, "selected routine-publication job manifest");
  if (!job || typeof job !== "object" || Array.isArray(job)) throw new Error("selected routine-publication job manifest has an invalid shape");
  if (job.operation !== ROUTINE_OPERATION) throw new Error("selected routine-publication job manifest names an unsupported operation");
  const issueProvenance = verifyRoutineIssue(job);
  const authorityKeysPath = requireRealFile(requireAbsolutePath(environment[config.authorityKeysEnvironment], `${config.authorityKeysEnvironment} authority keys`), `${config.authorityKeysEnvironment} authority keys`);
  const assessmentKeysPath = requireRealFile(requireAbsolutePath(environment[config.assessmentKeysEnvironment], `${config.assessmentKeysEnvironment} assessment keys`), `${config.assessmentKeysEnvironment} assessment keys`);
  const propertyPath = requireRealFile(requireAbsolutePath(environment[config.propertyEnvironment], `${config.propertyEnvironment} property record`), `${config.propertyEnvironment} property record`);
  const property = readJson(propertyPath, "news property record");
  requireString(property?.content?.root, "news property content root");
  const { contentDir, claimStoreDir, sourceFeedsPath } = declaredPropertyInputs(property, dirname(propertyPath), {environment});
  const propertyContentDir = requireRealDirectory(contentDir, "news property content root");
  return { ...job, property, propertyContentDir, claimStoreDir, sourceFeedsPath, authorityKeysPath, assessmentKeysPath, authorityNow: now, issueProvenance, outputDir: safeChild(outputRoot, job.candidateName, "candidate output"), replayRoot, queueReservation: queued };
}

const queueReservationOf = (job) => job.queueReservation === undefined ? undefined : { jobName: job.queueReservation.jobName, jobSha256: job.queueReservation.jobSha256 };

/** What a pulse would form now, with no effect: the selected job and its publication plan. */
export function previewRoutinePublication({ now, environment = process.env }) {
  const job = routinePublicationJob({ pulseId: undefined, now: canonicalInstant(now, "preview instant"), reserve: false, environment }), plan = planRoutinePublication(job);
  return { type: "KoiosRoutineOperationPreflight", ready: true, jobId: job.jobId, slug: plan.candidate.slug, authorityScope: plan.provenance.authority.scope, authorityValidity: { issuedAt: plan.provenance.authority.issuedAt, expiresAt: plan.provenance.authority.expiresAt }, sourceSha256: plan.candidate.sourceSha256, issueFormationSha256: job.issueProvenance.issueDigest, manuscriptEvidenceSha256: job.issueProvenance.manuscriptEvidenceDigest, executionMode: plan.provenance.runtime.executionMode, queueReservation: queueReservationOf(job), effects: [] };
}

/** Form one pulse's routine publication: select the job, write the offline candidate, record the authority use. */
export function formRoutinePublication({ pulseId, now, environment = process.env }) {
  requireString(pulseId, "pulseId");
  const job = routinePublicationJob({ pulseId, now: canonicalInstant(now, "publication instant"), environment }), written = writeRoutinePublication(job);
  return { type: "KoiosRoutineOperationReceipt", code: "offline-candidate-written", pulseId, operation: ROUTINE_OPERATION, jobId: job.jobId, disposition: written.disposition, slug: written.slug, candidate: written.outputDir, consumptionId: written.consumptionId, issueFormationSha256: job.issueProvenance.issueDigest, manuscriptEvidenceSha256: job.issueProvenance.manuscriptEvidenceDigest, queueReservation: queueReservationOf(job), effects: ["offline-news-property-candidate-written", "publication-authority-use-recorded"], limitations: ["The accepted editorial authority was consumed only for this offline reader-facing property candidate. This operation does not deploy, release, publish, or activate a schedule."] };
}
