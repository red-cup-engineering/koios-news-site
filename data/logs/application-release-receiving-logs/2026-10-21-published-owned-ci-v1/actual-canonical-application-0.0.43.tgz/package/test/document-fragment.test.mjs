import {test} from 'node:test';
import assert from 'node:assert/strict';
import {extractArticleText,normalizePublicUrl} from '@causeway-services/web-source-acquisition/acquire';
test('A cited document contribution retains its speaker and complete body, excluding adjacent voices',()=>{
 const html='<title>Parliamentary record</title><div id="before"><p>Another voice before.</p></div><div class="contribution" id="C2"><div><span>Named member</span><a data-clipboard-text="Short preview">Copy</a></div><div><p>First argument establishing an important and contested position.</p><p>Final qualification omitted from the share preview.</p></div></div><div id="after"><p>Another voice after.</p></div>';
 const text=extractArticleText(html,50000,'#C2').text;
 assert.match(text,/Named member/);assert.match(text,/Final qualification/);
 assert.doesNotMatch(text,/Another voice|Short preview/);
 assert.equal(normalizePublicUrl('https://example.org/record#C2'),'https://example.org/record#C2');
 assert.throws(()=>extractArticleText(html,50000,'#missing'),/fragment missing is absent/);
});
