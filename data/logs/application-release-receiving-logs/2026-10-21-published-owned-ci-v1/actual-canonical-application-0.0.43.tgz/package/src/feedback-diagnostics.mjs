/**
 * A reporter-controlled GitHub issue body is not evidence of collector origin.
 * Only issues written by the authenticated account, with the exact collector
 * title and an initial marker, are eligible for automated issue mutations.
 */
const NAME = /^[A-Za-z][A-Za-z0-9-]*$/;
const MARKER = /^<!-- koios-feedback:([A-Za-z][A-Za-z0-9-]*) -->(?=\s|$)/;

export function diagnosticTitle(name) {
  if (typeof name !== 'string' || !NAME.test(name))
    throw new TypeError('invalid collector diagnostic name');
  return `Repair observed Koios.News ${name} deficiency`;
}

export function diagnosticMarker(name) {
  diagnosticTitle(name);
  return `<!-- koios-feedback:${name} -->`;
}

export function trustedPublisherIdentity(profile) {
  if (!profile || typeof profile.login !== 'string' ||
      !/^[a-z\d](?:[a-z\d-]{0,38})$/i.test(profile.login))
    throw new TypeError('authenticated GitHub publisher login required');
  return new Set([profile.login.toLowerCase()]);
}

export function diagnosticName(issue) {
  if (!issue || typeof issue.body !== 'string' || typeof issue.title !== 'string') return null;
  const match = MARKER.exec(issue.body);
  if (!match || issue.title !== diagnosticTitle(match[1])) return null;
  return match[1];
}

export function isCollectorDiagnostic(issue, trustedAuthors = new Set()) {
  if (!(trustedAuthors instanceof Set) || diagnosticName(issue) === null ||
      typeof issue?.author?.login !== 'string') return false;
  return trustedAuthors.has(issue.author.login.toLowerCase());
}

/** Reject ambiguous matches rather than touching a possibly customer-owned issue. */
export function findCollectorDiagnostic(issues, name, trustedAuthors, { state } = {}) {
  diagnosticTitle(name);
  if (!Array.isArray(issues)) throw new TypeError('complete GitHub issue list required');
  const matches = issues.filter(issue => diagnosticName(issue) === name &&
    isCollectorDiagnostic(issue, trustedAuthors));
  if (matches.length > 1) throw new Error(`ambiguous trusted ${name} diagnostics: ${matches.length}`);
  const prior = matches[0] ?? null;
  if (prior && (!Number.isSafeInteger(prior.number) || prior.number < 1 ||
      !['OPEN', 'CLOSED'].includes(prior.state)))
    throw new TypeError('trusted diagnostic lacks a valid GitHub issue identity/state');
  return prior && (state === undefined || prior.state === state) ? prior : null;
}

/** Produce an all-or-nothing issue selection before any GitHub writes occur. */
export function planDiagnosticIssueActions(issues, failedNames, observedNames, trustedAuthors) {
  if (!Array.isArray(failedNames) || !Array.isArray(observedNames))
    throw new TypeError('diagnostic state lists required');
  const failed = new Set(failedNames);
  if (failed.size !== failedNames.length || new Set(observedNames).size !== observedNames.length ||
      observedNames.some(name => failed.has(name)))
    throw new TypeError('duplicate or contradictory diagnostic states');
  const actions = [];
  for (const name of failedNames) {
    const prior = findCollectorDiagnostic(issues, name, trustedAuthors);
    actions.push({action:'upsert', name, number:prior?.number ?? null, state:prior?.state ?? null});
  }
  for (const name of observedNames) {
    const prior = findCollectorDiagnostic(issues, name, trustedAuthors);
    if (prior?.state === 'OPEN') actions.push({action:'close', name, number:prior.number});
  }
  return actions;
}
