import {existsSync,mkdirSync,readFileSync,writeFileSync,readdirSync,statfsSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {googleToken,googleJson} from './google-client.mjs';
import {articleQuality} from '../src/article-quality.mjs';
import {cloudCapacityObservation,sharedCloudCapacityStartupBlocker} from '../src/cloud-capacity.mjs';
import {cloudflareJson} from '../src/cloudflare-client.mjs';
import {declaredPropertyInputs} from '@causeway-services/koios-news-site/build';
import {EDITORIAL_FEEDBACK_QUERY,editorialFeedbackFrom} from './editorial-feedback.mjs';
import {maintenanceUnitObservation} from './finish-maintenance-feedback.mjs';
import {newsroomFeedback} from './newsroom-feedback.mjs';
import {newArticleThroughputFeedback} from '../src/news-line/throughput-feedback.mjs';
import {observeUnpublishedCorpus} from '../src/news-line/unpublished-corpus.mjs';
import {publisherReadinessFeedback} from '@causeway-services/koios-publisher-readiness-service';
const propertyPath=resolve(process.env.KOIOS_NEWS_PROPERTY??new URL('../config/koios-news-property.json',import.meta.url).pathname);
const property=JSON.parse(readFileSync(propertyPath,'utf8'));
const out=resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT??'data','feedback');mkdirSync(out,{recursive:true});
const at=new Date().toISOString(),day=n=>new Date(Date.now()-n*86400000).toISOString().slice(0,10), sensors={};
async function sensor(name,fn){try{sensors[name]={status:'observed',observedAt:at,...await fn()};}catch(e){sensors[name]={status:'unavailable',observedAt:at,reason:e.message.split('\n')[0].slice(0,600),...e.observation};}}
await sensor('editorialFeedback',async()=>editorialFeedbackFrom(JSON.parse(execFileSync('gh',['api','graphql','-f',`query=${EDITORIAL_FEEDBACK_QUERY}`],{encoding:'utf8',timeout:30000,maxBuffer:16*1024*1024}))));
await sensor('cloudCapacity',async()=>{
 const storage=statfsSync(out),availableBytes=storage.bavail*storage.bsize;
 const assessment=cloudCapacityObservation({availableBytes,totalBytes:storage.blocks*storage.bsize});
 if(assessment.status==='startup-blocked')throw Object.assign(new Error(sharedCloudCapacityStartupBlocker(availableBytes)),{observation:assessment.observation});
 return assessment.observation;
});
await sensor('cloudMaintenance',async()=>{
 const values=Object.fromEntries(execFileSync('systemctl',['--user','show','koios-maintenance.service','--property=LoadState,ActiveState,Result,ExecMainStatus,ExecMainExitTimestamp'],{encoding:'utf8',timeout:10000}).trim().split('\n').map(line=>{const i=line.indexOf('=');return [line.slice(0,i),line.slice(i+1)];}));
 return maintenanceUnitObservation(values);
});
await sensor('recovery',async()=>{
 const path=join(out,'recovery.json');
 if(!existsSync(path))throw new Error('No encrypted cloud newsroom snapshot has been restored, verified and uploaded. Run the admitted koios-recovery.service before treating durable reporting as recoverable.');
 const receipt=JSON.parse(readFileSync(path,'utf8'));
 if(!receipt.restoreVerifiedAt||Date.now()-Date.parse(receipt.at)>48*60*60*1000)throw new Error(`Cloud newsroom recovery is stale: latest verified snapshot ${receipt.at}. Inspect koios-recovery.service and its timer.`);
 const release=JSON.parse(execFileSync('gh',['api',`repos/causeway-services/koios-news-data/releases/tags/${receipt.tag}`],{encoding:'utf8',timeout:30000}));
 const asset=release.assets.find(row=>row.name===receipt.archive);
 if(!asset||asset.size!==receipt.bytes||asset.digest!==`sha256:${receipt.sha256}`)throw new Error('The separate cloud recovery asset is missing or differs from its restored snapshot');
 const runs=JSON.parse(execFileSync("gh",["api","repos/causeway-services/koios-news-data/actions/workflows/verify-recovery.yml/runs?per_page=1"],{encoding:"utf8"})).workflow_runs;
 const latest=runs?.[0];
 if(!latest||latest.conclusion!=="success"||Date.now()-Date.parse(latest.updated_at)>8*24*60*60*1000)throw new Error(`Independent cloud restore is missing, stale or unsuccessful: ${latest?.html_url??"dispatch verify-recovery.yml in koios-news-data"}`);
 return {at:receipt.at,restoreVerifiedAt:receipt.restoreVerifiedAt,independentRestore:latest.html_url,files:receipt.files,bytes:receipt.bytes,releaseUrl:release.html_url};
});
await sensor('newsroom',async()=>{
 const path=join(out,'newsroom.json');
 if(!existsSync(path))throw new Error('The cloud newsroom has not recorded a completed execution. Inspect koios-newsroom.service, including its inference preflight.');
 const runtime=JSON.parse(readFileSync(path,'utf8'));
 return newsroomFeedback(runtime,new Date().toISOString());
});
await sensor('newArticleThroughput',async()=>{
 // A timely running process is not evidence that new reporting is being published.
 // If runtime observation itself is missing, keep the count unknown; do not
 // promote missing data to zero or close any existing throughput deficiency.
 if(sensors.newsroom.status!=='observed')return {status:'unknown',reason:'A timely newsroom execution reading is unavailable; publication throughput is not established.'};
 return newArticleThroughputFeedback(sensors.newsroom.runtime.status.live??sensors.newsroom.runtime.status.metrics);
});
await sensor('unpublishedCorpus',async()=>{
 const inputs=declaredPropertyInputs(property,dirname(propertyPath),{stateRoot:resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT??'data')});
 return observeUnpublishedCorpus({
  postsDir:join(inputs.contentDir,property.content?.postsDirectory??'posts'),
  reporterDir:join(inputs.contentDir,'editorial-context','reporter-manuscripts'),
  claimsDir:resolve(process.env.NEWS_PROPERTY_CLAIM_STORE??join(process.env.KOIOS_NEWSROOM_DATA_ROOT??'data','claims')),
  publishedDir:inputs.publishedPostsDir,
  observedAt:new Date(at),
 });
});
await sensor('searchConsole',async()=>{
 const token=await googleToken(['https://www.googleapis.com/auth/webmasters.readonly']);
 const sites=await googleJson(token,'https://www.googleapis.com/webmasters/v3/sites');
 const property=sites.siteEntry?.find(x=>x.siteUrl==='sc-domain:koios.news')??sites.siteEntry?.find(x=>x.siteUrl==='https://koios.news/');
 if(!property||property.permissionLevel==='siteUnverifiedUser')throw new Error('The cloud Search Console account has no verified Koios.News access. Grant search-reader@five-six-one-group-dev.iam.gserviceaccount.com access to the existing property.');
 const endpoint=`https://www.googleapis.com/webmasters/v3/sites/${encodeURIComponent(property.siteUrl)}`;
 const response=await googleJson(token,`${endpoint}/searchAnalytics/query`,{method:'POST',body:{startDate:day(31),endDate:day(3),dimensions:['page','query'],rowLimit:25000}});
 const sitemaps=await googleJson(token,`${endpoint}/sitemaps`);
 return {property:property.siteUrl,startDate:day(31),endDate:day(3),rows:response.rows??[],sitemaps};
});
await sensor('googleAnalytics',async()=>{
 const token=await googleToken(['https://www.googleapis.com/auth/analytics.readonly']);
 let property=process.env.KOIOS_GA_PROPERTY;
 if(!property){const accounts=await googleJson(token,'https://analyticsadmin.googleapis.com/v1beta/accountSummaries');property=accounts.accountSummaries?.flatMap(a=>a.propertySummaries??[]).find(p=>/koios/i.test(p.displayName))?.property;}
 if(!property)throw new Error('No Koios.News GA4 property is accessible to the cloud account.');
 const report=await googleJson(token,`https://analyticsdata.googleapis.com/v1beta/${property}:runReport`,{method:'POST',body:{dateRanges:[{startDate:day(28),endDate:day(1)}],dimensions:[{name:'pagePath'},{name:'sessionSource'}],metrics:[{name:'screenPageViews'},{name:'engagedSessions'},{name:'userEngagementDuration'}],limit:10000}});
 return {property,report};
});
await sensor('cloudflare',async()=>{
 const token=process.env.CLOUDFLARE_ANALYTICS_TOKEN??process.env.CLOUDFLARE_API_TOKEN;if(!token)throw new Error('Cloudflare analytics credential missing');
 const headers={authorization:`Bearer ${token}`,'content-type':'application/json'};
 const zones=await cloudflareJson('https://api.cloudflare.com/client/v4/zones?name=koios.news',{headers,description:'Cloudflare zones lookup'});const zone=zones.result?.find(x=>x.name==='koios.news');if(!zone)throw new Error('Cloudflare token cannot read the Koios.News zone');
 const query=`query { viewer { zones(filter:{zoneTag:"${zone.id}"}) { httpRequests1dGroups(limit:30,filter:{date_geq:"${day(28)}",date_leq:"${day(1)}"},orderBy:[date_ASC]) { dimensions { date } sum { requests pageViews bytes threats } uniq { uniques } } } } }`;
 const data=await cloudflareJson('https://api.cloudflare.com/client/v4/graphql',{method:'POST',headers,body:{query},description:'Cloudflare GraphQL analytics'});if(data.errors?.length)throw new Error(data.errors.map(x=>x.message).join(';'));
 return {zone:zone.id,measurement:'Edge requests and page views, including bots; not equivalent to engaged readers.',days:data.data.viewer.zones[0]?.httpRequests1dGroups??[]};
});
await sensor('publication',async()=>{const r=await fetch('https://koios.news/manifest.json',{signal:AbortSignal.timeout(30000)});if(!r.ok)throw new Error(`Live manifest HTTP ${r.status}`);const manifest=await r.json();return {manifestSha256:createHash('sha256').update(JSON.stringify(manifest)).digest('hex'),artifacts:manifest.artifacts.length,articleRoutes:manifest.artifacts.filter(x=>/^posts\/[^/]+\/index\.html$/.test(x.file)).map(x=>x.file),canonicalBaseUrl:manifest.canonicalBaseUrl};});
const inputs=declaredPropertyInputs(property,dirname(propertyPath),{stateRoot:resolve(process.env.KOIOS_NEWSROOM_DATA_ROOT??'data')});
const articles=new Map();for(const folder of [join(inputs.contentDir,property.content?.postsDirectory??'posts'),inputs.publishedPostsDir].filter(Boolean))if(existsSync(folder))for(const name of readdirSync(folder).filter(x=>x.endsWith('.md'))){const source=readFileSync(join(folder,name),'utf8');if(/(?:^|\n)draft:\s*true/.test(source))continue;const slug=/\nslug:\s*['"]?([^'"\n]+)/.exec(source)?.[1]??name.replace(/\.md$/,'');articles.set(slug,{slug,path:join(folder,name),...articleQuality(source,{property,claims:null,evidenceRequired:false})});}
await sensor('publisherReadiness',async()=>publisherReadinessFeedback({now:at,providers:property.monetization?.providerRequirements??[],evidence:property.monetization?.publisherEvidence??{}}));
const snapshot={kind:'koios.news.observed-feedback/v1',observedAt:at,sensors,articles:[...articles.values()].sort((a,b)=>a.words-b.words)};
writeFileSync(join(out,'latest.json'),JSON.stringify(snapshot,null,2)+'\n');
console.log(JSON.stringify({observedAt:at,sensors:Object.fromEntries(Object.entries(sensors).map(([k,v])=>[k,{status:v.status,reason:v.reason}])),articles:articles.size,thinArticles:[...articles.values()].filter(x=>x.words<700).length}));
