---
name: writing
description: Draft a Koios.News manuscript using the current news-property parser, then hand its exact bytes to editorial receiving.
closure-kind: process
requires-capabilities:
  - koios-editorial-state
  - koios-settled-claim-bundle
  - read
  - write
  - markdown-file-workbench
---

# Writing a Koios.News manuscript

## Registers and feeling rules

A desk is a beat, not a uniform register. Use the actual commission, admitted evidence and selected genre to decide whether the story needs brisk dispatch, reflective culture criticism, sports analysis, a popular-science explanation or a methods-first investigation. Sports results and celebrity news generally benefit from concise, direct language and early factual payoff; a culture feature may need a more layered critical argument. Tentative Flesch-Kincaid **Grade Level** 5–8 for a short dispatch is a diagnostic, not a gate, and is the opposite direction from Flesch **Reading Ease**. Never distort an attribution, technical term, quote or person's name to hit a reading score.

Study the audience's genre-specific feeling rules without claiming all readers feel alike or deliberately provoking outrage, intimacy or shame. A chosen register cannot change a story's admitted claims or editorial evidence budget. The canonical law is `policy/law/editorial-treatment-catalog.json`; the existing specialist offices, characters and incumbencies live at `lib/agency/`. A named agent's persona text is never an office or an authority grant. Only credit a public specialist byline when the whole signed manuscript and website are independently received.

### Special editorial commission — source-qualified procedure

The owner-authored, open Koios.News GitHub issue must name the actual source URL(s), reader question and an exact machine-readable selection. For example, a factual entertainment briefing may contain this single line (change the reader question and evidence for the real commission):

```text
<!-- koios-editorial-treatment: {"subdesk":"celebrity-and-fandom","registerId":"pop-dispatch","productId":"current-news-brief/v1","formatId":"text-report","readerQuestion":"What did the studio actually announce, and when?"} -->
```

Use the existing `node bin/koios-reporter-submit.mjs commission /path/to/commission.json` in the *admitted cloud newsroom*, supplying `{"issueNumber":ISSUE_NUMBER,"slug":"SOURCE_BOUND_STORY_SLUG","section":"culture-entertainment","sourceUrl":"https://real-source.example/report"}`, with matching source URLs already named by the authenticated issue. The commission operation verifies its original owner, open state, exact URL and declaration before recording a story or purchasing research. The Koios instance adapter calls native Organizing `selectOfficeDutyOperation` to read whether a current AI character actually holds the specialty reporter office and its `prepare-sourced-editorial-work` duty and `writing` skill. The selection is **only an operation candidate**, not a credential, admission or publication authority.

The existing Content Mill writer receives the resolved genre, register, disclosed character and actual office/duty work; independent assessment, signed authorization and the final publication gate must agree on the exact source-bound treatment. Changes to the commission or its source-owned law invalidate a held specialist edition. Unmarked wire arrivals continue through generic desk reporting. The special visual formats remain refused until a separately received TUFTE/newsroom interactive publication lane exists. Do not produce imaginary figures or claim a visual module is installed because a renderer adapter exists in Engineering.


Use the actual desk, authenticated commission, selected genre, admitted claims, full available source context and the independent editor's required repairs. A desk persona determines voice and attention; it cannot create expertise, an interview, eyewitness presence, authority or factual warrant.

Lead with the concrete development. Explain mechanisms, consequences, affected people, relevant history, contrary evidence or response, and the next supported development. Organize specific descriptive sections around reader questions. Select distinct reported detail instead of repeating methodological caveats or adding filler. If the packet cannot sustain the commissioned treatment, return the missing reporting requirement.

Attribute estimates and agency reporting visibly. Preserve reporting periods, units, dates, quantities, conditions and conflicting values. Label your own calculations and show their supported inputs. Distributor and government statements are attributed claims, not independent confirmation. State precisely when a consequential confirmation or response has not been obtained.

Every body paragraph binds to admitted claim IDs; supplied source text cannot license an unadmitted manuscript claim. Never invent quotes, observations, links or interviews. Distinguish news, attributed analysis, opinion and sponsored material. Do not force every story into a single ideological frame. Nik's requested imaginative essay is a specific format, not universal newsroom law.

Deliver exact draft bytes through the existing citation compiler and independent assessment. Parsing and word-count floors do not prove completeness. Do not publish your own draft, shorten a response window, or change publication-state flags. A return reopens the earliest defective layer; carry every required repair to the next attempt.

Method references: https://www.spj.org/spj-code-of-ethics/ ; https://reutersagency.com/about/standards-values/ .
