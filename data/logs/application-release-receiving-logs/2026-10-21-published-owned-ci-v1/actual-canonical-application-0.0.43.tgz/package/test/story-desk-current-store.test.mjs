import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {sourceArrivalFromObservation} from '@red-cup-engineering/communicating/messaging/newswire/source-arrival';
import {projectArrivalsToStore} from '@red-cup-engineering/content-mill-newsroom-services-section/intake';
import {put} from '@red-cup-engineering/semiotic-eavt-services-section/store';
import {storyDesk,storyAnchor} from '../src/news-line/desk.mjs';
const at='2026-10-13T08:00:00Z';
function fixture(t){
 const root=mkdtempSync(join(tmpdir(),'koios-story-desk-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
 const feed={id:'science-wire',url:'https://science.example/feed',kind:'rss'},property={origin:'https://koios.news',sections:[{slug:'science',wires:['science-wire']},{slug:'politics',wires:['politics-wire']}]};
 const event=sourceArrivalFromObservation({feed,item:{externalId:'held-story',url:'https://science.example/story',title:'A source-owned new science story',published:at},observedAt:at});
 const [story]=projectArrivalsToStore([event],root,new Map([['science-wire',['science']]]));return {root,property,story};
}
test('current opaque story identity resolves its actual held anchor feed',t=>{
 const f=fixture(t);assert.equal(f.story.id.startsWith('news-property.story:'),false);
 assert.equal(storyDesk(f.property,f.story.id,'politics',f.root).slug,'science');assert.equal(storyAnchor(f.story.id,f.root).title,f.story.title);
});
test('the same supplier address without its actual store is refused',t=>{
 const f=fixture(t);assert.throws(()=>storyDesk(f.property,f.story.id,'science'),/existing newsroom/);
});
test('another store type cannot manufacture a newsroom assignment',t=>{
 const f=fixture(t),id=put(f.root,'unrelated-record',{feed:'science-wire',url:f.story.url,title:f.story.title});assert.throws(()=>storyDesk(f.property,id,'science',f.root),/existing newsroom/);
});
test('unknown and multiply assigned anchor feeds remain refused',t=>{
 const f=fixture(t);assert.throws(()=>storyDesk({...f.property,sections:[]},f.story.id,'science',f.root),/exactly one/);
 assert.throws(()=>storyDesk({...f.property,sections:[...f.property.sections,{slug:'alias',wires:['science-wire']}]},f.story.id,'science',f.root),/exactly one/);
});
test('retained constituted story IDs preserve their prior feed-based desk',t=>{
 const f=fixture(t),id='news-property.story:'+Buffer.from(JSON.stringify({v:{feed:'science-wire',title:'Retained report'}})).toString('base64url');assert.equal(storyDesk(f.property,id,'politics',f.root).slug,'science');
});
test('observed prior-publication identities retain their explicit configured desk',t=>{
 const f=fixture(t),id='news-property.published:'+Buffer.from(JSON.stringify({origin:'https://koios.news',slug:'historical-story'})).toString('base64url');
 assert.equal(storyDesk({...f.property,content:{legacyPublishedSections:{'historical-story':'science'}}},id,'politics',f.root).slug,'science');
});
