import test from 'node:test';import assert from 'node:assert/strict';import{mkdtempSync,rmSync}from'node:fs';import{tmpdir}from'node:os';import{join}from'node:path';
import{lineRoots,openEdition,editionOf,advanceEdition}from'../src/news-line/editions.mjs';
test('an existing edition cannot be reopened or overwritten by a stale stage result',t=>{
 const root=mkdtempSync(join(tmpdir(),'edition-concurrent-'));t.after(()=>rmSync(root,{recursive:true,force:true}));const roots=lineRoots(root);
 const row={candidateId:'candidate:one',state:'drafted',draftedAt:'2026-10-19T00:00:00.000Z'};
 const first=openEdition(roots,row),released=advanceEdition(roots,first,'released','2026-10-19T00:01:00.000Z',{releasedSourceSha256:'exact-source'});
 assert.deepEqual(openEdition(roots,row),released);
 assert.throws(()=>advanceEdition(roots,first,'returned','2026-10-19T00:02:00.000Z'),{code:'editorial-edition-conflict'});
 assert.deepEqual(editionOf(roots,row.candidateId),released);assert.equal(released.history.length,2);
});


test('the original freshly opened carrier remains a valid first transition input',t=>{
 const root=mkdtempSync(join(tmpdir(),'edition-first-transition-'));t.after(()=>rmSync(root,{recursive:true,force:true}));const roots=lineRoots(root);
 const row={candidateId:'legacy:first',state:'drafted',draftedAt:'2026-10-19T00:00:00.000Z'};openEdition(roots,row);
 const accepted=advanceEdition(roots,row,'accepted','2026-10-19T00:01:00.000Z');assert.equal(accepted.state,'accepted');assert.equal(accepted.history.length,2);assert.equal(accepted.history[0].state,'drafted');
 assert.throws(()=>advanceEdition(roots,row,'returned','2026-10-19T00:02:00.000Z'),{code:'editorial-edition-conflict'});
});
