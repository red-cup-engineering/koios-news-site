/** Deterministic projection of one locked Koios selection snapshot.
 * Events remain the outcome carrier; this module owns no cursor or scheduler.
 */
import { createHash } from 'node:crypto';

/** Fixed scalar tuples name offered work, not mutable retry diagnostics. */
export function custodyIdentity(stage, tuples) {
  const ordered = tuples.map(tuple => tuple.map(value => value ?? null))
    .sort((a, b) => {
      const left = JSON.stringify(a), right = JSON.stringify(b);
      return left < right ? -1 : left > right ? 1 : 0;
    });
  return createHash('sha256').update(JSON.stringify([stage, ordered])).digest('hex');
}

const refused = reason => ({ code: 'selection-history-unverified', reason });

/** Provider reads may reject a cycle before projection is possible. Preserve
 * the caller's exception channel; no invented event can be appended through
 * that same unreadable carrier, and no newsroom handler has run in this turn.
 */
export function readSelectionHistory(readStatus, readEvents) {
  try { return { status: readStatus(), events: readEvents() }; }
  catch (cause) {
    const error = new Error('Koios selection history could not be verified; no newsroom handler ran in this turn.', { cause });
    error.name = 'KoiosSelectionHistoryError';
    error.code = 'selection-history-unverified';
    error.executed = false;
    throw error;
  }
}

/** The provider orders available records but does not certify complete history.
 * Require the connected latest-cycle suffix and its observed prior-cycle boundary.
 * Older missing predecessors are irrelevant; a cut inside this suffix is not.
 */
export function currentCycleEvidence(events, status, stages) {
  if (!events.length) return status.cycle === 1 && status.next === stages[0]
    ? { events: [] } : { obstruction: refused('The empty history disagrees with the service-line cursor.') };
  const byId = new Map(events.map(event => [event.id, event]));
  if (byId.size !== events.length) return { obstruction: refused('Duplicate event identities in the selection history.') };
  const cycle = Math.max(...events.map(event => event.content.cycle));
  const current = events.filter(event => event.content.cycle === cycle);
  const currentIds = new Set(current.map(event => event.id));
  const parents = new Set(current.map(event => event.content.knowledge?.prior));
  const tips = current.filter(event => !parents.has(event.id));
  if (tips.length !== 1) return { obstruction: refused('The current cycle has no unique causal tip.') };
  const reversed = [], seen = new Set();
  let cursor = tips[0];
  while (cursor && currentIds.has(cursor.id)) {
    if (seen.has(cursor.id)) return { obstruction: refused('The current cycle contains a causal loop.') };
    seen.add(cursor.id); reversed.push(cursor);
    const prior = cursor.content.knowledge?.prior;
    if (prior === null) {
      if (cycle !== 1) return { obstruction: refused('A later cycle has no witnessed predecessor boundary.') };
      cursor = null;
    } else {
      cursor = byId.get(prior);
      if (!cursor) return { obstruction: refused('The necessary current-cycle predecessor is unavailable.') };
      if (!currentIds.has(cursor.id) && cursor.content.cycle !== cycle - 1)
        return { obstruction: refused('The current cycle does not join its preceding cycle.') };
    }
  }
  if (seen.size !== current.length) return { obstruction: refused('The current cycle contains a fork or disconnected evidence.') };
  const ordered = reversed.reverse(), latest = new Map(ordered.map(event => [event.content.stage, event.content]));
  const next = stages.find(stage => latest.get(stage)?.status !== 'complete');
  const expectedCycle = next ? cycle : cycle + 1;
  if (status.cycle !== expectedCycle || status.next !== (next ?? stages[0])
    || status.stages.some(row => row.status !== (next ? latest.get(row.stage)?.status ?? 'pending' : 'pending')))
    return { obstruction: refused('The causal suffix disagrees with the supplier current-cycle status.') };
  return { events: ordered };
}

function isProductionAttempt(event) {
  const { stage, execute } = event.content;
  // Intake and analysis have only the source role. A historical draft has no
  // role evidence: it may have been an exact repair, so cannot reset yielding.
  return ['intake', 'analyze'].includes(stage)
    || (stage === 'draft' && execute.workAttempt?.kind === 'production');
}

/** Publication gets one opportunity per pulse independently of model work.
 * Editorial/model repairs still yield until source production changes their
 * opportunity. Delivering accepted work must not require another inference.
 */
export function unattemptedPriority(priorities, events, attemptedStages = new Set()) {
  const boundary = events.findLastIndex(isProductionAttempt);
  const recent = events.slice(boundary + 1);
  return priorities.find(work => !attemptedStages.has(work.stage) &&
    (!recent.some(event => {
    const { stage, status, execute } = event.content;
    const attempt = execute.workAttempt;
    return (attempt?.kind === 'priority' && attempt.stage === work.stage && attempt.identity === work.identity)
      // Older release receipts remain useful, without upgrading unbound errors.
      || (work.stage === 'release' && stage === 'release' && status === 'complete'
        && execute.attemptedRenderedIdentity === work.identity);
  }))) ?? null;
}

/** Priority and source obligations are projected together from this snapshot. */
export function selectKoiosWork({ status, events, stages, priorities, pendingArrivals }, { attemptedStages = new Set() } = {}) {
  const evidence = currentCycleEvidence(events, status, stages);
  if (evidence.obstruction) return attemptedStages.has(status.next)?null:{ stage: status.next, kind: 'refusal', obstruction: evidence.obstruction };
  const history = evidence.events;
  const priority = unattemptedPriority(priorities, history, attemptedStages);
  if (priority) return { ...priority, kind: 'priority' };

  // A completed cycle has no unfinished claim/writer obligation to carry over.
  const current = history.filter(event => event.content.cycle === status.cycle);
  const last = predicate => current.findLastIndex(event => predicate(event.content));
  const intake = last(event => event.stage === 'intake');
  const analyze = last(event => event.stage === 'analyze');
  const draft = last(event => event.stage === 'draft');
  const claims = last(event => event.stage === 'analyze' && event.status === 'complete' && !event.execute.sourceEvidenceOnly);
  const stoppedWriter = last(event => ['analyze', 'draft'].includes(event.stage) && ['writer-admission','claim-extraction'].includes(event.execute.phase));
  let stage;
  if (pendingArrivals && intake > analyze) stage = 'analyze';
  else if (claims > draft) stage = 'draft';
  else if (stoppedWriter > intake) stage = 'intake';
  else stage = status.next;

  // The generic cursor may still name the failed ready work. It does not
  // overrule the exact-custody yield, or a cycle's already spent opportunity.
  if (priorities.some(work => work.stage === stage) && !['intake', 'analyze', 'draft'].includes(stage)) stage = 'intake';
  // A yielded exact repair still occupies the draft handler. Do not relabel
  // that same unchanged retry as ordinary drafting merely to reset yielding.
  if (stage === 'draft' && priorities.some(work => work.stage === 'draft') && claims <= draft) stage = 'intake';
  if (attemptedStages.has(stage)) return null;
  return { stage, kind: ['intake', 'analyze', 'draft'].includes(stage) ? 'production' : 'cursor' };
}

/** Preserve independent provider admission and nested acquisition/repair errors. */
export async function executeWithoutWriter(stage, execute, input, error) {
  const failureOf = failure => ({ name: String(failure?.name ?? 'Error'), code: failure?.code == null ? null : String(failure.code),
    reason: String(failure?.message ?? failure) });
  const writerObstruction = { code: 'inference-obstructed', phase: 'writer-admission', reason: String(error?.message ?? error), cause: failureOf(error) };
  let independentResult;
  try {
    independentResult = await execute({ ...input, ...(stage === 'analyze' ? { acquisitionOnly: true } : { existingOnly: true }) });
  } catch (failure) {
    independentResult = { status: 'blocked', code: 'stage-threw', reason: String(failure?.message ?? failure), cause: failureOf(failure) };
  }
  return { ...independentResult, status: 'blocked', code: 'inference-obstructed', phase: 'writer-admission',
    reason: 'Writer admission remains obstructed; the independent source or held-repair outcome is recorded separately.',
    writerObstruction, independentResult };
}
