import{test}from'node:test';import assert from'node:assert/strict';import{execFileSync}from'node:child_process';import{mkdtempSync,mkdirSync,writeFileSync,rmSync}from'node:fs';import{tmpdir}from'node:os';import{join}from'node:path';import{pushData}from'../scripts/push-data.mjs';
test('A publication committed before a failed push is still delivered next cycle without further manuscript edits',()=>{
 const root=mkdtempSync(join(tmpdir(),'koios-delivery-')),remote=join(root,'remote.git'),data=join(root,'data'),bin=join(root,'bin'),realGit=execFileSync('which',['git'],{encoding:'utf8'}).trim();const oldPath=process.env.PATH;
 const git=(...args)=>execFileSync(realGit,args,{cwd:data,encoding:'utf8',stdio:['pipe','pipe','pipe']}).trim();
 try{
  execFileSync(realGit,['init','--bare','--initial-branch=main',remote],{stdio:'ignore'});execFileSync(realGit,['clone',remote,data],{stdio:'ignore'});git('config','user.name','Publication test');git('config','user.email','publication@example.invalid');writeFileSync(join(data,'README.md'),'publication');git('add','.');git('commit','-m','Initialize');git('push','-u','origin','main');
  writeFileSync(join(data,'accepted.md'),'Exact accepted reporting');git('add','.');git('commit','-m','Accept reporting');
  mkdirSync(bin);const marker=join(root,'failed-once');writeFileSync(join(bin,'git'),`#!/bin/sh\nif [ "$1" = push ] && [ ! -f '${marker}' ]; then touch '${marker}'; echo 'transport interrupted' >&2; exit 1; fi\nexec '${realGit}' "$@"\n`,{mode:0o755});process.env.PATH=bin+':'+oldPath;
  assert.throws(()=>pushData(data),/transport interrupted/);assert.equal(git('status','--porcelain'),'');assert.notEqual(git('rev-parse','HEAD'),git('rev-parse','origin/main'));
  assert.equal(pushData(data).published,true);assert.equal(execFileSync(realGit,['--git-dir',remote,'show','main:accepted.md'],{encoding:'utf8'}),'Exact accepted reporting');
 }finally{process.env.PATH=oldPath;rmSync(root,{recursive:true,force:true});}
});
