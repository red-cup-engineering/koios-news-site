import test from 'node:test';
import assert from 'node:assert/strict';
import {cloudflareJson} from '../src/cloudflare-client.mjs';

test('Cloudflare JSON client reports non-JSON responses with HTTP evidence',async()=>{
 const originalFetch=globalThis.fetch;
 globalThis.fetch=async()=>new Response('<!DOCTYPE html><title>Denied</title>',{
  status:403,
  headers:{'content-type':'text/html; charset=utf-8'}
 });
 try{
  await assert.rejects(
   cloudflareJson('https://api.cloudflare.com/client/v4/graphql',{description:'Cloudflare GraphQL analytics'}),
   /Cloudflare GraphQL analytics returned non-JSON HTTP 403 \(text\/html; charset=utf-8\): <!DOCTYPE html><title>Denied<\/title>/
  );
 }finally{
  globalThis.fetch=originalFetch;
 }
});

test('Cloudflare JSON client reports Cloudflare error messages',async()=>{
 const originalFetch=globalThis.fetch;
 globalThis.fetch=async()=>new Response(JSON.stringify({errors:[{message:'permission denied'}]}),{
  status:403,
  headers:{'content-type':'application/json'}
 });
 try{
  await assert.rejects(
   cloudflareJson('https://api.cloudflare.com/client/v4/graphql',{description:'Cloudflare GraphQL analytics'}),
   /Cloudflare GraphQL analytics HTTP 403: permission denied/
  );
 }finally{
  globalThis.fetch=originalFetch;
 }
});

test('Cloudflare JSON client reports request timeouts with call site',async()=>{
 const originalFetch=globalThis.fetch;
 globalThis.fetch=async()=>{throw Object.assign(new Error('The operation was aborted due to timeout'),{name:'TimeoutError'});};
 try{
  await assert.rejects(
   cloudflareJson('https://api.cloudflare.com/client/v4/graphql',{description:'Cloudflare GraphQL analytics',timeoutMs:10}),
   /Cloudflare GraphQL analytics request timed out after 10ms/
  );
 }finally{
  globalThis.fetch=originalFetch;
 }
});
