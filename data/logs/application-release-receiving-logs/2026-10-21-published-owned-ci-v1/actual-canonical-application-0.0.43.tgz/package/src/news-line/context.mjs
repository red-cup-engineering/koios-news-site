import {editorialProductFor} from "../article-quality.mjs";
/** Configuration can be read without loading every newsroom executor. */
import {readFileSync} from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { canonicalJson } from "@red-cup-engineering/json-services-section/canonical";
import { sha256Digest } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity";
import { declaredPropertyInputs, propertyStateRoot } from "@causeway-services/koios-news-site/build";
import { lineRoots, readJson } from './editions.mjs';
const PACKAGE_ROOT = fileURLToPath(new URL('../..', import.meta.url));
const CONTRACT_INTERFACE = join(PACKAGE_ROOT, 'policy', 'management', 'contracts', 'independent-editorial-assessment.json');

/** The line's configuration, its property record, and the newsroom data root they name. */
export function newsLineContext({ environment = process.env } = {}) {
  const configPath = join(PACKAGE_ROOT, "config", "news-line.json"), config = readJson(configPath);
  const propertyPath = resolve(environment.KOIOS_NEWS_PROPERTY ?? resolve(dirname(configPath), config.property));
  const rawProperty = readJson(propertyPath);
  const property = {...rawProperty, editorialProduct:editorialProductFor(rawProperty),
    sections:rawProperty.sections.map(desk=>({...desk,editorialProduct:editorialProductFor(rawProperty,{section:desk.slug})}))};
  const dataRoot = resolve(environment.KOIOS_NEWSROOM_DATA_ROOT ?? propertyStateRoot(property, environment));
  const roots = lineRoots(dataRoot);
  // The line keeps the property's published-post ledger; the property record declares it, so every
  // builder of the property (this line's release, the operator's build script) reads the same one.
  const propertyInputs = declaredPropertyInputs(property, dirname(propertyPath), { stateRoot: dataRoot, environment });
  if (propertyInputs.publishedPostsDir !== join(roots.publication, "published")) {
    throw new Error(`property record must declare content.publishedPosts as the line's ledger (${join("line", "publication-replay", "published")})`);
  }
  const { contentDir: propertyContentDir, claimStoreDir, sourceFeedsPath: houseFeedsPath } = propertyInputs;
  const editorialTreatmentCatalog=readJson(join(PACKAGE_ROOT,'policy/law/editorial-treatment-catalog.json'));
  const editorialProductLaw=readJson(join(PACKAGE_ROOT,'policy/law/editorial-product-commissions.json'));
  const policySource = canonicalJson({standingPublication:config.standingPolicy,editorialProduct:property.editorialProduct,
    deskEditorialProducts:property.sections.map(({slug,editorialProduct})=>({section:slug,editorialProduct})),
    editorialTreatmentCatalog,editorialProductLaw});
  return Object.freeze({
    config, property, propertyPath, propertyInputs, propertyContentDir, claimStoreDir, houseFeedsPath, dataRoot, roots,
    editorialTreatmentCatalog,editorialProductLaw,treatmentCache:new Map(),agencyCache:{current:null},
    purchaseJournalRoot: environment.INFERENCE_PURCHASE_ROOT ?? join(dataRoot, "inference-purchases"),
    policyDigest: sha256Digest(policySource),
    contract: readJson(CONTRACT_INTERFACE),
    editorialMethods:Object.fromEntries(['researching','writing','editing'].map(name=>[name,readFileSync(join(PACKAGE_ROOT,'lib/agency/skills',name,'SKILL.md'),'utf8')])),
    environment,
  });
}

