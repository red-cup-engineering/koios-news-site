/** Market observations enter the existing newsroom as source-grounded claims. */
import { recordNewsroom } from "./newsroom-records.mjs";
import { semanticId as digest } from "@red-cup-engineering/computer-content-address-engineering-services-section/semiotic-content-address";
import { admitSourceEvidence, recordSourceEvidence } from "@red-cup-engineering/content-mill-newsroom-services-section/source-evidence";
import { admitClaimEvidence } from "@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence";
import { parseResearchPublication, selectedValue } from "@red-cup-engineering/mandate-portfolio-allocation-service/research-publication";
import { canonicalJson } from "@red-cup-engineering/json-services-section/canonical";
import { sha256Bytes } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/portable-sha256";
import { utf8Bytes } from "@red-cup-engineering/cryptographic-computer-data-engineering-services-section/portable-bytes";
import { syndicationBundle } from './news/syndication/holography.mjs';
import { writeBundleIfAbsent } from './news/cable/wire.mjs';

function factSpan(raw, key, value) {
  const token = JSON.stringify(key); let offset = 0;
  while (offset < raw.length) {
    const start = raw.indexOf(token, offset); if (start < 0) break;
    let cursor = start + token.length;
    while (/\s/u.test(raw[cursor] ?? '')) cursor++;
    if (raw[cursor++] !== ':') { offset = start + token.length; continue; }
    while (/\s/u.test(raw[cursor] ?? '')) cursor++;
    let end = cursor;
    if (raw[cursor] === '"') {
      end++;
      while (end < raw.length) { if (raw[end] === '\\') { end += 2; continue; } if (raw[end++] === '"') break; }
    } else { while (end < raw.length && !/[\s,}\]]/u.test(raw[end])) end++; }
    try { if (JSON.parse(raw.slice(cursor, end)) === value) return { quote: raw.slice(start, end), quoteStart: start, quoteEnd: end }; } catch {}
    offset = start + token.length;
  }
  throw new TypeError('selected field has no exact source span');
}

/** Validate every source before writing any claim. A packet is never a source retrieval. */
export function admitMarketResearch({ packet, observations, section, property, dataRoot, at }) {
  packet = parseResearchPublication(packet);
  if (!property.sections.some(desk => desk.slug === section)) throw new TypeError('research desk must belong to the property');
  if (!Number.isFinite(Date.parse(at)) || Date.parse(at) < Date.parse(packet.issuedAt)) throw new TypeError('research handoff clock precedes issue');
  const storyId = 'market-research:' + packet.id;
  const sourceCells = new Map();
  for (const reference of packet.observations) {
    const observed = observations[reference.id], retrieval = observed?.retrieval;
    if (!retrieval || sha256Bytes(utf8Bytes(canonicalJson(observed))) !== reference.recordDigest || retrieval.responseDigest !== sha256Bytes(utf8Bytes(canonicalJson(retrieval.text))) ||
        retrieval.requestedUrl !== reference.source || Date.parse(retrieval.acquiredAt) > Date.parse(at) ||
        new TextEncoder().encode(retrieval.text).length > 131072) throw new TypeError('research requires the original bounded retrieval');
    let selected = JSON.parse(retrieval.text);
    for (const key of retrieval.selector) selected = selected[key];
    if (sha256Bytes(utf8Bytes(canonicalJson(selected))) !== sha256Bytes(utf8Bytes(canonicalJson(observed.value)))) throw new TypeError('observed value differs from retrieved selector');
    const source = admitSourceEvidence({ id: reference.id, url: reference.source }, {
      type: 'PublicWebSource', requestedUrl: reference.source, finalUrl: retrieval.finalUrl,
      text: retrieval.text, textDigest: digest(retrieval.text), responseDigest: digest(retrieval.text),
      rights: 'selected-public-facts; source-content-republication-not-granted',
      acquiredAt: retrieval.acquiredAt, networkRequests: 1, responseBytes: retrieval.responseBytes,
    });
    sourceCells.set(reference.id, source);
  }
  const claims = packet.facts.map(fact => {
    const source = sourceCells.get(fact.observationId);
    if (selectedValue(observations[fact.observationId].value, fact.path) !== fact.value) throw new TypeError('fact differs from observed field');
    const { quote, quoteStart, quoteEnd } = factSpan(source.content.text, fact.path.at(-1), fact.value);
    return admitClaimEvidence({ storyId, section, sourceId: source.content.leadId, sourceUrl: source.content.finalUrl,
      sourceEvidenceId: source.id, host: new URL(source.content.finalUrl).hostname,
      subject: fact.subject, predicate: fact.predicate, object: String(fact.value) + (fact.unit ? ' ' + fact.unit : ''),
      quote, quoteStart, quoteEnd }, source);
  });
  const record = { type: 'KoiosMarketResearchAssignment', id: packet.id, storyId, section, packet,
    claimEvidenceIds: claims.map(claim => claim.id), sourceEvidenceIds: [...sourceCells.values()].map(source => source.id) };
  for (const source of sourceCells.values()) recordSourceEvidence(dataRoot, source, at);
  for (const claim of claims) recordNewsroom(dataRoot, 'claim', claim);
  recordNewsroom(dataRoot, 'market-research', record);
  return { storyId, packetId: packet.id, claims: claims.length, sources: sourceCells.size };
}

/** Filum's ordinary wire store and surfaces publish the same research identity. */
export async function writeResearchWire({ packet, storeDir, resourceUrl }) {
  packet = parseResearchPublication(packet);
  const url = new URL(resourceUrl); if (url.protocol !== 'https:') throw new TypeError('research resource requires HTTPS');
  const bundle = syndicationBundle({ title: packet.title + ' [' + packet.id.slice(0, 12) + ']', url: url.href,
    summary: packet.question, published: packet.issuedAt }, { witness: packet.producer.wire, asserted: packet.issuedAt });
  const claims = [...bundle.claims, { id: 'research-packet', proposition: { predicate: 'research-packet', object: packet },
    time: { asserted: packet.issuedAt }, force: 'alleges', provenance: { witness: packet.producer.wire, citation: url.href }, status: 'supported' }];
  return { packetId: packet.id, disposition: await writeBundleIfAbsent(storeDir, { subject: bundle.subject, claims }) };
}
