import {pushData} from "./push-data.mjs";
import {execFileSync,spawnSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import {mkdirSync,readdirSync,copyFileSync,readFileSync,existsSync,mkdtempSync,rmSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {preservePublicationEvidence} from '../src/news-line/publication-evidence.mjs';
import {newsLineContext} from '../src/news-line/context.mjs';
const context=newsLineContext(),cwd=dirname(context.claimStoreDir);
const git=(...args)=>execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
if(resolve(git('rev-parse','--show-toplevel'))!==resolve(cwd))throw new Error('Publication data destination must be its configured Git repository root');
const source=join(context.roots.publication,'published');
const destination=join(cwd,'line/publication-replay/published');mkdirSync(destination,{recursive:true});
for(const name of readdirSync(source).filter(x=>x.endsWith('.md'))){
 const publishedSource=readFileSync(join(source,name),'utf8'),prior=join(destination,name);
 if(!existsSync(prior)||readFileSync(prior,'utf8')!==publishedSource)preservePublicationEvidence({dataRoot:context.dataRoot,destination:cwd,slug:name.slice(0,-3),publishedSource});
 copyFileSync(join(source,name),join(destination,name));
}
git('add','line/publication-replay/published');
const evidenceRoot=join(cwd,'line/publication-evidence');
if(existsSync(evidenceRoot)&&readdirSync(evidenceRoot).length)git('add','line/publication-evidence');
if(git('diff','--cached','--name-only'))git('commit','-m','Publish independently accepted Koios.News articles');
console.log(JSON.stringify(pushData(cwd)));

// Receive the publication-data pointer at the canonical source owner. Native
// FeltOS publishes the received website program in this same release duty.
const parent=mkdtempSync(join(tmpdir(),'koios-publication-parent-'));
const parentGit=(...args)=>execFileSync('git',args,{cwd:parent,encoding:'utf8'}).trim();
try{
 const childRemote=git('remote','get-url','origin');
 if(!/github\.com[:/]causeway-services\/koios-news-data(?:\.git)?$/.test(childRemote))throw new Error('Unexpected publication data owner');
 let childHead;
 parentGit('init','-q');parentGit('remote','add','origin','git@github.com:causeway-services/koios.news.git');
 parentGit('config','user.name','Koios publication');parentGit('config','user.email','koios-publication@users.noreply.github.com');
 let received=false;
 for(let attempt=0;attempt<5;attempt++){
  parentGit('fetch','--depth=1','origin','main');parentGit('checkout','--detach','--force','origin/main');
  git('fetch','origin','main');childHead=git('rev-parse','origin/main');
  const previous=parentGit('rev-parse','HEAD:data');
  const ancestry=spawnSync('git',['merge-base','--is-ancestor',previous,childHead],{cwd,encoding:'utf8'});
  if(ancestry.status!==0)throw new Error('Parent publication input is outside the published data ancestry; preserve and reconcile it');
  parentGit('update-index','--add','--cacheinfo',`160000,${childHead},data`);
  if(!parentGit('diff','--cached','--name-only')){received=true;break;}
  parentGit('commit','-m','Update koios-news-data publication input');
  const result=spawnSync('git',['push','origin','HEAD:main'],{cwd:parent,encoding:'utf8'});
  if(result.status===0){received=true;break;}
  if(!/rejected|fetch first|non-fast-forward/i.test(result.stderr))throw new Error(result.stderr);
 }
 if(!received)throw new Error('Concurrent parent publication input did not settle; retry the existing release duty');
 console.log(JSON.stringify({publicationInputReceived:true,dataCommit:childHead,parentCommit:parentGit('rev-parse','HEAD')}));
}finally{rmSync(parent,{recursive:true,force:true});}
