---
title: "Welsh First Minister pushes for more devolution powers"
date: 2026-10-02
draft: false
author: "Koios.News US Politics Desk"
section: "us-politics"
dek: "Rhun ap Iorwerth says his government has a clear mandate to seek greater authority from Westminster and wants Wales to match Scotland’s status."
description: "Rhun ap Iorwerth says his government has a clear mandate to seek greater authority from Westminster and wants Wales to match Scotland’s status."
summary: "Rhun ap Iorwerth says his government has a clear mandate to seek greater authority from Westminster and wants Wales to match Scotland’s status."
categories: ["US Politics"]
license: "CC BY 4.0"
---
# Welsh First Minister pushes for more devolution powers

Rhun ap Iorwerth says his government has a clear mandate to seek greater authority from Westminster and wants Wales to match Scotland’s status.

According to theguardian.com, Rhun ap Iorwerth told the annual conference that his government had a clear mandate for devolving more powers from Westminster. The same outlet also reported that he asked the Prime Minister to put Wales on equal footing with Scotland as a bare minimum. [Source](https://www.theguardian.com/politics/2026/oct/02/welsh-first-minister-rhun-ap-iorwerth-andy-burnham-devolution-wales-plaid-cymru)

bbc.co.uk reported that the party’s leader said Prime Minister Andy Burnham promised him he would not undermine Wales. [Source](https://www.bbc.co.uk/news/articles/cr0j3jdj64x7o?at_medium=RSS&at_campaign=rss)

bbc.co.uk also reported that First Minister Rhun ap Iorwerth has demanded a new deal for Wales from the UK government that would put the country on an equal footing with Scotland. [Source](https://www.bbc.co.uk/news/articles/cr0j3jdj64x7o?at_medium=RSS&at_campaign=rss)
