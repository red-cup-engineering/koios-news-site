import { induceSurface } from "@red-cup-engineering/computer-system-engine/rpc/induce";
import { routeRequest } from "@red-cup-engineering/computer-web-server/platform-http/operation-serving";

import { koiosFederatedOperations } from "./federated-surface.mjs";

const PACKAGE = "@causeway-services/koios-news-service-section";

/**
 * Pure HTTP/MCP projection of Koios's restricted federated operation set.
 *
 * This opens no socket. The eventual host may bind this router to a listener,
 * but doing so cannot reveal internal newsroom/publication/clock verbs because
 * they are absent from the induced surface itself.
 */
export function createKoiosFederatedHttpProjection() {
  const operations = koiosFederatedOperations();
  const induced = induceSurface(operations, { packageName: PACKAGE });
  return Object.freeze({
    induced,
    route: (request, options = {}) => routeRequest(induced, request, options),
  });
}
