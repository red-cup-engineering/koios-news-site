import {join} from 'node:path';
import {withServiceLineExecution} from '@red-cup-engineering/organizing/work/service-line';

/** Manual reporting joins the shared writer scope; other stages remain independent. */
export function withEditorialLock(context,work) {
 return withServiceLineExecution({service:'koios-news',defaultRun:'autonomous-koios-news-line'},
  {dataRoot:context.roots.root,stage:'draft',legacyExclusiveLock:join(context.roots.root,'editorial-execution.lock')},work);
}
