import { existsSync, readFileSync } from "node:fs";
import path from "node:path";

import { currentSchedules, dueOccurrence } from "@red-cup-engineering/feltos/recurring-work";

import {
  KOIOS_NEWSROOM_SCHEDULE_ID,
  KOIOS_PUBLICATION_SCHEDULE_ID,
} from "./node-schedules.mjs";

export const KOIOS_NODE_STATUS_KIND = "koios.node.status";

const PACKAGE_VERSION = JSON.parse(
  readFileSync(new URL("../package.json", import.meta.url), "utf8"),
).version;

function requireString(value, label) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new TypeError(`${label} must be a non-empty string`);
  }
  return value;
}

function readLastOutcome(clockStateRoot, scheduleId) {
  const file = path.join(clockStateRoot, "last", `${scheduleId}.json`);
  if (!existsSync(file)) return Object.freeze({ value: undefined });
  try {
    return Object.freeze({ value: JSON.parse(readFileSync(file, "utf8")) });
  } catch (error) {
    return Object.freeze({
      error: `last outcome is unreadable: ${error instanceof Error ? error.message : String(error)}`,
    });
  }
}

function readScheduleStatus({ schedule, scheduleId, clockStateRoot, at }) {
  if (!schedule) {
    return Object.freeze({
      id: scheduleId,
      ready: false,
      state: "missing",
      obstruction: "schedule-not-admitted",
    });
  }

  const lastRead = readLastOutcome(clockStateRoot, scheduleId);
  const occurrence = dueOccurrence(schedule, at);
  const nextOccurrence = occurrence === null ? 0 : occurrence + 1;
  const nextDueAt = new Date(
    Date.parse(schedule.firstDueAt) + nextOccurrence * schedule.everySeconds * 1000,
  ).toISOString();

  if (lastRead.error) {
    return Object.freeze({
      id: scheduleId,
      verb: schedule.verb,
      ready: false,
      state: "obstructed",
      firstDueAt: schedule.firstDueAt,
      everySeconds: schedule.everySeconds,
      nextDueAt,
      obstruction: lastRead.error,
    });
  }

  const last = lastRead.value;
  if (occurrence === null) {
    return Object.freeze({
      id: scheduleId,
      verb: schedule.verb,
      ready: true,
      state: "not-due",
      firstDueAt: schedule.firstDueAt,
      everySeconds: schedule.everySeconds,
      nextDueAt,
      ...(last === undefined ? {} : { last }),
    });
  }

  const currentDueAt = new Date(
    Date.parse(schedule.firstDueAt) + occurrence * schedule.everySeconds * 1000,
  ).toISOString();

  if (last?.occurrence === occurrence) {
    return Object.freeze({
      id: scheduleId,
      verb: schedule.verb,
      ready: last.ok === true,
      state: last.ok === true ? "succeeded" : "failed",
      firstDueAt: schedule.firstDueAt,
      everySeconds: schedule.everySeconds,
      currentOccurrence: occurrence,
      currentDueAt,
      nextDueAt,
      last,
      ...(last.ok === true ? {} : { obstruction: last.error ?? "current occurrence failed" }),
    });
  }

  return Object.freeze({
    id: scheduleId,
    verb: schedule.verb,
    ready: false,
    state: "due-without-recorded-outcome",
    firstDueAt: schedule.firstDueAt,
    everySeconds: schedule.everySeconds,
    currentOccurrence: occurrence,
    currentDueAt,
    nextDueAt,
    ...(last === undefined ? {} : { last }),
    obstruction: "current occurrence has no recorded outcome",
  });
}

/**
 * Read the dedicated Koios node's recurring-work health without starting the
 * node, admitting schedules, granting authority, or publishing anything.
 *
 * This readout intentionally reports durable clock state. Process liveness is
 * still a host/service-manager concern.
 */
export function readKoiosNodeStatus({
  dataRoot,
  clockStateRoot,
  now = () => new Date().toISOString(),
} = {}) {
  const root = requireString(dataRoot, "Koios node dataRoot");
  const stateRoot = clockStateRoot === undefined
    ? path.join(root, "data", "state", "clock")
    : requireString(clockStateRoot, "Koios node clockStateRoot");
  const at = now();
  if (typeof at !== "string" || !Number.isFinite(Date.parse(at))) {
    throw new TypeError("Koios node status now() must return an ISO 8601 instant");
  }

  const binding = Object.freeze({ dataRoot: root, clockStateRoot: stateRoot });
  const current = new Map(currentSchedules(binding).map((schedule) => [schedule.id, schedule]));
  const schedules = [
    KOIOS_NEWSROOM_SCHEDULE_ID,
    KOIOS_PUBLICATION_SCHEDULE_ID,
  ].map((scheduleId) => readScheduleStatus({
    schedule: current.get(scheduleId),
    scheduleId,
    clockStateRoot: stateRoot,
    at,
  }));

  const obstructions = schedules
    .filter((schedule) => schedule.ready !== true)
    .map((schedule) => Object.freeze({
      schedule: schedule.id,
      state: schedule.state,
      obstruction: schedule.obstruction,
    }));

  return Object.freeze({
    kind: KOIOS_NODE_STATUS_KIND,
    packageVersion: PACKAGE_VERSION,
    at,
    ready: obstructions.length === 0,
    schedules: Object.freeze(schedules),
    obstructions: Object.freeze(obstructions),
  });
}
