/** Preserve the actual accepted reporting with each immutable published version. */
import {createHash} from 'node:crypto';
import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {editions,lineRoots} from './editions.mjs';
import {parsePost} from '@causeway-services/koios-news-site/build';
import {manuscriptEvidenceFromJournal} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {verifyAssessmentReceipt} from '@causeway-services/editorial-publication-authority';
import {digest as assessmentDigest} from '@causeway-services/independent-editorial-assessment/contract';
import {replaceDraftFlag} from '../offline-publication.mjs';

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const json=path=>JSON.parse(readFileSync(path,'utf8'));
function promoted(source){
 try{return replaceDraftFlag(source,'accepted manuscript');}catch{return null;}
}
export function verifyCapturedAssessment({demand,evidence,receipt,review,manuscriptSource}){
 if(assessmentDigest(demand)!==receipt.providerEvidence.demandDigest||demand.manuscript.bytes!==manuscriptSource||
   demand.editorialContext.run.candidateId!==evidence.candidate.id||assessmentDigest(review)!==receipt.selection.digest)throw new Error('Captured reporting or review differs from the signed editorial demand');
 const witnessed=evidence.claims.map(claim=>({claimId:claim.id,sourceUrl:claim.content.sourceUrl,subject:claim.content.subject,predicate:claim.content.predicate,object:claim.content.object,quote:claim.content.quote}));
 if(assessmentDigest(witnessed)!==assessmentDigest(demand.editorialContext.evidence))throw new Error('Captured claims differ from the independently reviewed claims');
 for(const source of evidence.sources){
  const captured=demand.editorialContext.standards.sourceDocuments.find(row=>row.sourceEvidenceId===source.id);
  if(!captured)throw new Error('Captured source is absent from the reviewed demand');
  const {sourceEvidenceId,observedPageMetadata,...content}=captured;
  if(assessmentDigest(content)!==assessmentDigest(source.content))throw new Error('Captured source differs from its reviewed text');
 }
}
export function preservePublicationEvidence({dataRoot,destination,slug,publishedSource}){
 const sourceSha256=sha(publishedSource),root=join(destination,'line','publication-evidence',slug,sourceSha256);
 if(existsSync(join(root,'publication.json')))return {archived:false,sourceSha256};
 const edition=editions(lineRoots(dataRoot)).reverse().find(row=>row.slug===slug&&['rendered','released'].includes(row.state)&&
   row.receiptPath&&existsSync(row.draftPath)&&promoted(readFileSync(row.draftPath,'utf8'))===publishedSource);
 // Legacy articles retain their recovered evidence; do not fabricate a new acceptance.
 if(!edition)return {archived:false,sourceSha256,reason:'no-current-accepted-edition'};
 const manuscriptSource=readFileSync(edition.draftPath,'utf8'),receiptSource=readFileSync(edition.receiptPath,'utf8');
 const receipt=JSON.parse(receiptSource),allKeys=json(edition.assessmentKeysPath);
 const assessmentKeys={[receipt.issuerKeyId]:allKeys[receipt.issuerKeyId]};
 // An archive proves what was accepted then, not authority to publish again now.
 verifyAssessmentReceipt({receiptSource,assessmentKeys,manuscriptSource,manuscriptSlug:slug,now:receipt.issuedAt});
 const evidence=manuscriptEvidenceFromJournal({dataRoot,candidateId:edition.candidateId,manuscriptBody:parsePost(manuscriptSource,slug+'.md').body});
 const review=json(edition.deliveryPath).object?.toolSelection;
 if(review?.tool!=='submit_editorial_acceptance')throw new Error('Published evidence lacks its actual accepting review');
 const contractPath=edition.deliveryPath.replace(/\.delivery-\d+\.json$/u,'.contract.json');
 const demand=json(contractPath).object.offer.object.sourceActivity.object;
 verifyCapturedAssessment({demand,evidence,receipt,review,manuscriptSource});
 mkdirSync(root,{recursive:true});
 const put=(name,bytes)=>{const temporary=join(root,name+'.tmp');writeFileSync(temporary,bytes);renameSync(temporary,join(root,name));};
 const putJson=(name,value)=>put(name,JSON.stringify(value,null,2)+'\n');
 put('published.md',publishedSource);put('manuscript.md',manuscriptSource);put('receipt.json',receiptSource);
 putJson('evidence.json',evidence);putJson('demand.json',demand);putJson('assessment-keys.json',assessmentKeys);putJson('review.json',review);
 putJson('publication.json',{slug,sourceSha256,candidateId:edition.candidateId,manuscriptSha256:sha(manuscriptSource),
   receiptSha256:sha(receiptSource),acceptedAt:receipt.issuedAt,renderedAt:edition.renderedAt,
   evidenceFiles:['published.md','manuscript.md','receipt.json','evidence.json','demand.json','assessment-keys.json','review.json']});
 return {archived:true,sourceSha256};
}
