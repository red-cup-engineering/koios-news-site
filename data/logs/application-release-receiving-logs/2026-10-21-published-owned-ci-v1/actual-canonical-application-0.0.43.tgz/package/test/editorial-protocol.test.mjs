import {test} from 'node:test';
import assert from 'node:assert/strict';
import {editorialToolSchema} from '@red-cup-engineering/content-mill-newsroom-services-section/assessment';
import {editorialSelectionSchema} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {compileJsonSchema} from '@red-cup-engineering/json-schema-services-section/validation';
import {isClosedJsonSchema} from '@red-cup-engineering/computer-inference-engine/dispatch/direct-endpoint-provider';
import {exchangeOpenAiCompatibleAssistantMessage} from '@red-cup-engineering/computer-inference-engine/openai';
import {runKoiosEditorialAssessmentInference} from '@causeway-services/independent-editorial-assessment/contract';
test('Provider-compatible editorial repair alternatives retain the same closed admission law',()=>{
 const authoritative=compileJsonSchema(editorialSelectionSchema.properties.repairTools),offered=compileJsonSchema(editorialToolSchema().properties.repairTools);
 const examples=[[],[{tool:'replace_exact_body_text',before:'Exact text',after:'Replacement'}],[{tool:'repair_editorial_surfaces'}],[{tool:'repair_editorial_surfaces',after:'Unlicensed field'}],[{tool:'replace_exact_body_text',after:'Missing exact span'}],[{tool:'invent_article'}]];
 const expected=[true,true,true,false,false,false];
 for(const [index,value] of examples.entries()){
  assert.equal(offered.validate(value).valid,authoritative.validate(value).valid);
  assert.equal(offered.validate(value).valid,expected[index]);
 }
 assert.ok(editorialSelectionSchema.properties.repairTools.items.oneOf);
 assert.ok(editorialToolSchema().properties.repairTools.items.anyOf);
 assert.equal(isClosedJsonSchema(editorialToolSchema(true)),true);
 assert.equal(isClosedJsonSchema(editorialToolSchema()),false);
});
test('HTTP provider refusals retain an actionable explanation without retaining the credential',async()=>{
 const key='fixture-sensitive-credential';
 const result=await exchangeOpenAiCompatibleAssistantMessage({model:'fixture',messages:[{role:'user',content:'Test'}]},{providerId:'fixture',chatCompletionsUrl:'https://example.invalid/v1/chat/completions',apiKey:key},async()=>new Response(JSON.stringify([{error:{message:'Schema tool type is missing. Credential '+key}}]),{status:400}));
 assert.equal(result.ok,false);assert.equal(result.cause.status,400);
 assert.match(result.cause.providerMessage,/Schema tool type is missing/);
 assert.ok(!JSON.stringify(result).includes(key));
});

test('Independent assessment delegates supplier selection to the shared newsroom market',async()=>{
 const demand={slug:'fixture',editorialContext:{standards:{},evidence:[]},manuscript:{bytes:'Exact draft'}};
 let dispatched;
 const dispatch=async(input,options)=>{dispatched={input,options};return {outcome:'fixture'};};
 await runKoiosEditorialAssessmentInference(demand,{customerActor:'urn:ame:koios-news',environment:{INFERENCE_CASH_CONTROL:'customer-policy'},dispatch});
 assert.equal(dispatched.options.directDescriptors,undefined);
 assert.equal(dispatched.input.zeroCashOnly,undefined);
 assert.equal(dispatched.input.outputSchema.additionalProperties,false);
});
