import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {newsLineContext} from '../src/news-line/context.mjs';
import {newsLineHandlers,draftPost} from '../src/news-line/stages.mjs';
import {openEdition,editionOf} from '../src/news-line/editions.mjs';
import {admitSourceEvidence,recordSourceEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/source-evidence';
import {admitClaimEvidence} from '@red-cup-engineering/content-mill-newsroom-services-section/claim-evidence';
import {recordClaim} from '@red-cup-engineering/content-mill-newsroom-services-section/settlement';
import {admitReporterManuscript} from '@red-cup-engineering/content-mill-newsroom-services-section/manuscript';
import {recordNewsroom} from '../src/newsroom-records.mjs';
import {digest} from '@causeway-services/web-source-acquisition/acquire';
import {solicitEditorialAssessment} from '@causeway-services/independent-editorial-assessment/contract';

const at='2026-10-19T12:00:00.000Z';
const turnAt='2026-10-19T12:01:00.000Z';
function deferred(){let resolve;const promise=new Promise(r=>{resolve=r;});return{promise,resolve};}
function fixture(t){
 const root=mkdtempSync(join(tmpdir(),'koios-independent-assessment-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
 const context=newsLineContext({environment:{KOIOS_NEWSROOM_DATA_ROOT:root}});
 const previous=process.env.INDEPENDENT_EDITORIAL_ASSESSMENT_DATA_ROOT;process.env.INDEPENDENT_EDITORIAL_ASSESSMENT_DATA_ROOT=join(root,'service');
 t.after(()=>{if(previous===undefined)delete process.env.INDEPENDENT_EDITORIAL_ASSESSMENT_DATA_ROOT;else process.env.INDEPENDENT_EDITORIAL_ASSESSMENT_DATA_ROOT=previous;});
 let sequence=0;
 function hold(slug,{thin=false,missing=false}={}){
  const storyId='urn:fixture:story:'+slug,paragraphs=[];
  if(!thin&&!missing)for(let host=0;host<3;host++){
   const url=`https://fixture-${host}.example/${slug}`,leadId=slug+'-'+host;
   const quotes=Array.from({length:4},(_,fact)=>`Authority ${host} recorded finding ${fact} for ${slug}. `+Array.from({length:60},(_,word)=>`detail-${host}-${fact}-${word}`).join(' ')+'.');
   const text=quotes.join('\n');
   const source=admitSourceEvidence({id:leadId,url},{type:'PublicWebSource',requestedUrl:url,finalUrl:url,text,textDigest:digest(text),responseDigest:digest(text),acquiredAt:at,rights:'public-access-observed',networkRequests:1,responseBytes:Buffer.byteLength(text)});
   recordSourceEvidence(root,source,at);
   recordNewsroom(root,'reporting-source',{type:'KoiosArticleReportingSource',storyId,slug,sourceEvidenceId:source.id,researchedAt:at});
   for(const [fact,quote]of quotes.entries()){
    const start=text.indexOf(quote);
    const claim=admitClaimEvidence({storyId,section:'world',sourceId:leadId,sourceUrl:url,sourceEvidenceId:source.id,host:new URL(url).hostname,subject:'Authority '+host,predicate:'recorded finding '+fact,object:quote,quote,quoteStart:start,quoteEnd:start+quote.length},source);
    recordClaim(root,claim,at);paragraphs.push({text:quote,heading:fact===0?'Findings '+host:'',claimEvidenceIds:[claim.id]});
   }
  }
  const draftPath=join(root,slug+'.md');let candidateId='urn:fixture:'+slug;
  if(thin)writeFileSync(draftPath,'---\ntitle: Thin fixture\ndate: 2026-10-19\ndraft: true\nsection: world\n---\nA short incomplete fixture report.\n');
  else if(!missing){
   const {candidate}=admitReporterManuscript({root,storyId,section:'world',proposal:{title:'Fixture '+slug,dek:'Synthetic independently held reporting.',paragraphs},at});candidateId=candidate.id;recordNewsroom(root,'manuscript-candidate',candidate);
   writeFileSync(draftPath,draftPost({candidate,desk:context.property.sections.find(d=>d.slug==='world'),slug,at}));
  }
  openEdition(context.roots,{candidateId,storyId,section:'world',slug,draftPath,state:'drafted',draftedAt:new Date(Date.parse(at)+sequence++).toISOString(),attempts:0,market:null});
  return()=>editionOf(context.roots,candidateId);
 }
 return{context,hold};
}

test('a slow independent judgment neither delays a second service call nor structural returns',async t=>{
 const f=fixture(t),slow=f.hold('a-slow'),thin=f.hold('b-thin',{thin:true}),fast=f.hold('c-fast');
 const entered=deferred(),release=deferred();let completed=false,admissions=0,fastCalls=0;
 const pending=newsLineHandlers(f.context,{assessment:{requireAdmission:async()=>{admissions++;return{};},solicit:solicitEditorialAssessment,
  invoke:async contract=>{
   const slug=contract.object.offer.object.sourceActivity.object.slug;
   if(slug==='a-slow'){entered.resolve();await release.promise;}else fastCalls++;
   return{type:'Reject',object:{code:'fixture-service-obstructed'}};
  }}}).assess({at:turnAt}).then(result=>{completed=true;return result;});
 // Cleanup releases a failed test as well; no timed cancellation of useful work.
 t.after(()=>release.resolve());
 await Promise.race([entered.promise,pending.then(result=>{throw new Error("Slow service was not reached: "+JSON.stringify(result));})]);
 assert.equal(thin().state,'returned');
 assert.equal(thin().failureLayer,'writer-model');
 await new Promise(setImmediate);
 assert.equal(fastCalls,1,JSON.stringify(fast()));
 assert.equal(completed,false);
 assert.equal(slow().state,'drafted');
 release.resolve();const result=await pending;
 assert.deepEqual(result.outcomes.map(x=>[x.slug,x.outcome]),[['a-slow','obstructed'],['b-thin','returned'],['c-fast','obstructed']]);
 assert.equal(admissions,1);
 assert.deepEqual(result.outcomes.map(x=>x.candidateId),[slow().candidateId,thin().candidateId,fast().candidateId]);
 assert.equal(fast().attempts,1);
 assert.equal(slow().attempts,1);
});

test('one unreadable manuscript cannot abandon independently held later editions',async t=>{
 const f=fixture(t),missing=f.hold('a-missing',{missing:true}),thin=f.hold('b-thin',{thin:true});
 const result=await newsLineHandlers(f.context).assess({at:turnAt});
 assert.equal(missing().state,'drafted');
 assert.equal(thin().state,'returned');
 assert.equal(result.outcomes[0].outcome,'obstructed');
 assert.equal(result.outcomes[0].code,'ENOENT');
 assert.equal(result.outcomes[1].outcome,'returned');
});

test('a shared account obstruction buys no judgments and retires no manuscript',async t=>{
 const f=fixture(t),first=f.hold('a-held'),second=f.hold('b-held');let admissions=0,invocations=0;
 const result=await newsLineHandlers(f.context,{assessment:{
  requireAdmission:async()=>{admissions++;throw new Error('Synthetic current account obstruction');},
  invoke:async()=>{invocations++;throw new Error('Unadmitted inference must not run');},
 }}).assess({at:turnAt});
 assert.equal(admissions,1);assert.equal(invocations,0);
 assert.equal(result.status,'blocked');
 assert.ok(result.outcomes.every(x=>x.outcome==='obstructed'&&x.code==='inference-obstructed'));
 for(const read of [first,second]){assert.equal(read().state,'drafted');assert.equal(read().attempts,0);}
});
