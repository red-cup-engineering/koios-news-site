import {execFileSync} from 'node:child_process';
const auth=Buffer.from('x-access-token:'+process.env.KOIOS_SUBMODULE_TOKEN).toString('base64');
execFileSync('git',['submodule','update','--init','content','data','services/newscable-source-broker'],{
 stdio:'inherit',env:{...process.env,GIT_CONFIG_COUNT:'1',GIT_CONFIG_KEY_0:'http.https://github.com/.extraheader',GIT_CONFIG_VALUE_0:'AUTHORIZATION: basic '+auth}
});
