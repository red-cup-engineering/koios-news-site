// The Koios line's arrivals as source observations: each arrival is a CloudEvent naming the public
// item it observed (data.item.url), when (time), its content identity (id), and its feed (wire).
// Together with Newscable's held bundles they make the index the market's source-observation and
// source-change certificates are read from (newscable-source-broker/source-observation).
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

const jsonFiles = (directory) => { try { return readdirSync(directory).filter((name) => name.endsWith(".json")).map((name) => join(directory, name)); } catch { return []; } };

/** Every arrival the line holds (pending and analyzed) as { url, observedAt, bundleDigest, wire }. */
export function arrivalObservations(roots) {
  const observations = [];
  for (const file of [...jsonFiles(roots.arrivals), ...jsonFiles(roots.analyzed)]) {
    let events;
    try { events = JSON.parse(readFileSync(file, "utf8")); } catch { continue; }
    for (const event of Array.isArray(events) ? events : [events]) {
      const url = event?.data?.item?.url, observedAt = event?.time, id = event?.id;
      if (typeof url !== "string" || !/^https?:\/\//u.test(url) || typeof observedAt !== "string" || typeof id !== "string") continue;
      observations.push({ url, observedAt, bundleDigest: id.split("@")[0], wire: event?.data?.feed?.id ?? "koios-line" });
    }
  }
  return observations;
}
