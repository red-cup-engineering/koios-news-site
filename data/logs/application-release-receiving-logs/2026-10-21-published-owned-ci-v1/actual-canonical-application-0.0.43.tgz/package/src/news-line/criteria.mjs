import {readFileSync} from "node:fs";

/**
 * What the editor required repaired in each story's returned drafts: `storyId` -> required repairs.
 * Preserve observable gate refusals even when assessment was unnecessary.
 * Independent editorial instructions come only from a readable assessor delivery.
 */
export function editorNotesOf(returnedEditions, { read = (path) => JSON.parse(readFileSync(path, "utf8")) } = {}) {
  const notes = {};
  for (const edition of returnedEditions) {
    const quality=edition.quality;
    if(quality?.ok===false&&Array.isArray(quality.failures)&&quality.failures.length){
      const observations=Object.fromEntries(['words','sections','assertions','sourceHosts']
        .filter(key=>Number.isSafeInteger(quality[key])&&quality[key]>=0).map(key=>[key,quality[key]]));
      const repair='The previous manuscript failed the observable article-quality gate: '+JSON.stringify({failures:quality.failures,observed:observations})+'. Repair these failures against the commissioned editorialProduct evidence budget using admitted evidence. Do not pad or invent material.';
      notes[edition.storyId]=[...new Set([...(notes[edition.storyId]??[]),repair])];
    }
    if (typeof edition.deliveryPath !== "string") continue;
    let selection;
    try { selection = read(edition.deliveryPath)?.object?.toolSelection; } catch { continue; }
    const repairs = [...(Array.isArray(selection?.requiredRepairs) ? selection.requiredRepairs : []), ...(typeof selection?.summary === "string" && !selection?.requiredRepairs?.length ? [selection.summary] : [])]
      .filter((item) => typeof item === "string" && item.trim() !== "").map((item) => item.replace(/\s+/gu, " ").trim());
    if (repairs.length) notes[edition.storyId] = [...new Set([...(notes[edition.storyId] ?? []), ...repairs])];
  }
  return notes;
}

/** Writer work is allocated by the existing pulse and inference account budgets.
 * A story's historical edition count is not an inference budget or an authority grant.
 */
export function returnedWriterEditions(editions){
  const layers=new Set(['writer-model','instructions','draft-repair']);
  return editions.filter(edition=>edition.state==='returned'&&!edition.revisedAs&&layers.has(edition.failureLayer));
}
