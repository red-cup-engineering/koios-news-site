import commissions from "../policy/law/editorial-product-commissions.json" with {type:"json"};
import {outsidePublicationHost} from './news-line/source-origins.mjs';
export function editorialProductFor(property={}, {section,profile}={}){
 const desk=section===undefined?undefined:property.sections?.find(row=>row.slug===section);
 if(section!==undefined&&!desk)throw new Error(`Unknown editorial desk ${section}`);
 const name=profile??desk?.editorialProductProfile??property.editorialProductProfile??"standard-news/v1",product=commissions.profiles[name];
 if(!product)throw new Error(`Unknown commissioned editorial product ${name}`);
 return product;
}
export function qualityFailureLayer(quality){return quality.failures.some(x=>["claim-evidence-unavailable","insufficient-distinct-supported-assertions","insufficient-source-origins","too-much-prose-for-evidence","ungrounded-paragraph"].includes(x))?"sources":"writer-model";}
/** Observable admission limits. Independent editorial judgment must still establish usefulness. */
export function articleQuality(source,{candidate,claims=[],property,evidenceRequired=true,section,productProfile,editorialProduct}={}){
 const body=source.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/,'');
 const prose=body.replace(/\[([^\]]+)\]\([^)]+\)/g,'$1').replace(/^#+ .*$/gm,'');
 const words=(prose.match(/[\p{L}\p{N}]+(?:[’'-][\p{L}\p{N}]+)*/gu)??[]).length;
 const sections=(body.match(/^##\s+\S.+$/gm)??[]).length;
 const budget=(editorialProduct??editorialProductFor(property,{section:section??candidate?.section,profile:productProfile})).evidenceBudget;
 const evidenceAvailable=Array.isArray(claims);
 const assertions=evidenceAvailable?new Set(claims.map(x=>{const c=x.content??x;return JSON.stringify([c.subject,c.predicate,c.object]);})).size:null;
 const sourceHosts=evidenceAvailable?new Set(claims.map(x=>outsidePublicationHost((x.content??x).sourceUrl)).filter(Boolean)).size:null;
 const failures=[];
 if(words<budget.targetWords.minimum)failures.push('insufficient-reporting-depth');
 if(sections<budget.minimumSections)failures.push('missing-context-sections');
 if(evidenceRequired&&!evidenceAvailable)failures.push('claim-evidence-unavailable');
 if(evidenceAvailable&&assertions<budget.minimumDistinctAssertions)failures.push('insufficient-distinct-supported-assertions');
 if(evidenceAvailable&&sourceHosts<budget.minimumIndependentSources)failures.push('insufficient-source-origins');
 if(evidenceAvailable&&assertions&&words/assertions>budget.maximumWordsPerAssertion)failures.push('too-much-prose-for-evidence');
 if(candidate&&!candidate.paragraphs.every(p=>p.claimEvidenceIds.length))failures.push('ungrounded-paragraph');
 return {ok:failures.length===0,words,sections,assertions,sourceHosts,evidenceAvailable,failures,independence:'Source hosts are a floor; editor must establish independent originating reporting.'};
}
