import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {recordNewsroom} from '../newsroom-records.mjs';
import {admitReporterManuscript} from '@red-cup-engineering/content-mill-newsroom-services-section/manuscript';
import {heldJournalCells} from '@red-cup-engineering/content-mill-newsroom-services-section/evidence';
import {manuscriptCandidateType} from '@red-cup-engineering/content-mill-newsroom-services-section/carriers';
import {parsePost} from '@causeway-services/koios-news-site/build';
import {sha256Hex} from '@red-cup-engineering/cryptographic-computer-data-engineering-services-section/integrity';
import {articleQuality} from '../article-quality.mjs';
import {editions,editionOf,openEdition,advanceEdition} from './editions.mjs';
import {storyDesk} from './desk.mjs';
import {existingArticleAssignment} from './existing-article.mjs';
import {draftPost} from './stages.mjs';
import {treatmentForStory,assertEditionTreatment} from './editorial-agency.mjs';
import {newReporterAssignment,assertNewReporterEvent,assertNewReporterAddress} from './reporter-assignment.mjs';

export function recoverableRenderRefusal(edition,at){
 return edition?.state==='refused' && /^render: /u.test(edition.reason??'') &&
  edition.history?.some(step=>step.state==='accepted') &&
  Date.parse(edition.receiptExpiresAt??'')>Date.parse(at);
}

/** Submit a reporter's draft for independent assessment; never write the publication ledger. */
export function submitArticle(context,proposal,{at=new Date().toISOString()}={}){
 const {slug}=proposal;
 if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug??''))throw new Error('An existing article slug is required');
 const root=context.dataRoot;
 const isNew=proposal.storyId!==undefined;
 const released=isNew?newReporterAssignment(context,proposal):existingArticleAssignment(context,slug);
 const desk=storyDesk(context.property,released.storyId,released.section,context.dataRoot);
 const selected=treatmentForStory(context,{storyId:released.storyId,section:desk.slug});
 const {candidate,evidence}=admitReporterManuscript({root,storyId:released.storyId,section:desk.slug,proposal,at});
 const quality=articleQuality(candidate.content.manuscript,{candidate:candidate.content,claims:evidence.claims,property:context.property,
   section:desk.slug,editorialProduct:selected?.editorialProduct});
 if(!quality.ok)throw new Error('Reporter manuscript failed admission: '+JSON.stringify(quality));
 if(isNew&&(!Number.isSafeInteger(desk.minimumIndependentSources??2)||(desk.minimumIndependentSources??2)<1))throw new Error('minimumIndependentSources must be positive');
 if(isNew&&quality.sourceHosts<(desk.minimumIndependentSources??2))throw new Error('Reporter manuscript has insufficient distinct source hosts for its desk');
 const prior=editionOf(context.roots,candidate.id);
 if(prior){
  assertEditionTreatment(context,prior);
  if(isNew&&(prior.storyId!==released.storyId||prior.slug!==slug||prior.section!==desk.slug))throw new Error('Reporter candidate is already bound to another story, address or desk');
  if(recoverableRenderRefusal(prior,at)){
   const recovered=advanceEdition(context.roots,prior,'accepted',at,{renderAttempts:0,reason:'recover-render-refusal-after-runtime-repair'});
   return {slug,candidateId:candidate.id,state:recovered.state,quality,publication:'Recovered an independently accepted manuscript for fresh publication authority after a render-stage refusal; accepted bytes were not changed.'};
  }
  return {slug,candidateId:candidate.id,state:prior.state,quality};
 }
 if(isNew){
  if(heldJournalCells(root,'manuscript-candidate',manuscriptCandidateType,[candidate.id]).has(candidate.id))throw new Error('Reporter candidate has journal custody but no edition; reconcile the interrupted submission before retrying');
  assertNewReporterEvent(context,released);
  assertNewReporterAddress(context,released,{title:candidate.content.title,forDraft:true});
 }
 const firstPublished=isNew?undefined:parsePost(readFileSync(join(context.roots.publication,'published',slug+'.md'),'utf8'),slug+'.md').date;
 const contentDir=join(context.roots.drafts,slug+'.'+sha256Hex(candidate.id).slice(0,10));
 mkdirSync(contentDir,{recursive:true,mode:0o700});
 const draftPath=join(contentDir,slug+'.md');
 const source=draftPost({candidate,desk,slug,at,firstPublished,treatment:selected});
 if(isNew)parsePost(source,slug+'.md');
 writeFileSync(draftPath,source,{mode:0o600});
 recordNewsroom(root,'manuscript-candidate',candidate);
 openEdition(context.roots,{candidateId:candidate.id,storyId:released.storyId,section:desk.slug,slug,contentDir,draftPath,state:'drafted',draftedAt:at,attempts:0,provider:'urn:ame:koios-cloud-editor',model:null,workLotId:candidate.content.workLotId,exchangeId:null,market:null,
  ...(selected?{treatmentDigest:selected.selectionDigest,commissionDigest:selected.authenticatedCommissionDigest,
   editorialProductId:selected.productId,characterId:selected.characterId,subdeskId:selected.subdeskId}:{}),
  ...(isNew?{}:{firstPublished})});
 return {slug,candidateId:candidate.id,state:'drafted',quality,draftPath,publication:'Pending independent assessment and publication authority; no accepted article bytes changed.'};
}

