export const KOIOS_SERVICE_ENTERPRISE = "urn:ame:koios-news-service-section";

export const DEFAULT_KOIOS_SERVICE_ACTOR = "https://koios-news-service-section.invalid/activitypub/actor";

/**
 * Resolve the externally visible ActivityStreams actor for the Koios service.
 *
 * Source/tests retain the .invalid actor. A deployed node must provide the full
 * public actor URI explicitly; this package does not guess its route.
 */
export function resolveKoiosServiceActor(environment = process.env) {
  const raw = environment.KOIOS_NEWS_SERVICE_ACTOR ?? DEFAULT_KOIOS_SERVICE_ACTOR;
  if (typeof raw !== "string" || raw.trim() === "") {
    throw new TypeError("KOIOS_NEWS_SERVICE_ACTOR must be a non-empty absolute HTTPS URL");
  }
  let actor;
  try { actor = new URL(raw); }
  catch { throw new TypeError("KOIOS_NEWS_SERVICE_ACTOR must be a non-empty absolute HTTPS URL"); }
  if (actor.protocol !== "https:" || actor.username || actor.password || actor.search || actor.hash) {
    throw new TypeError("KOIOS_NEWS_SERVICE_ACTOR must be an HTTPS URL without credentials, query, or fragment");
  }
  return actor.href;
}
