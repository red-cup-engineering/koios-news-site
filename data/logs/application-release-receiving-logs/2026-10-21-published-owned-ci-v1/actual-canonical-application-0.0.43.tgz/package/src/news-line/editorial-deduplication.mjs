const STOPWORDS = new Set(["a", "an", "and", "at", "for", "in", "of", "on", "the", "to"]);

function headlineTerms(value) {
  return new Set(
    String(value ?? "")
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/gu, "")
      .replace(/[^a-z0-9]+/gu, " ")
      .trim()
      .split(/\s+/u)
      .filter((term) => term.length > 1 && !STOPWORDS.has(term)),
  );
}

/**
 * Conservative same-event headline screen.
 *
 * This is deliberately not a general semantic similarity model. It catches
 * only headlines that share at least four significant terms and at least 80%
 * of the smaller headline's term set. The caller also requires the same desk
 * and never applies the screen to a candidate already anchored to the same
 * newsroom story id.
 */
export function nearDuplicateHeadline(left, right) {
  const a = headlineTerms(left);
  const b = headlineTerms(right);
  if (a.size < 4 || b.size < 4) return false;
  let common = 0;
  for (const term of a) if (b.has(term)) common += 1;
  return common >= 4 && common / Math.min(a.size, b.size) >= 0.8;
}
