---
name: researching
description: Research the actual desk assignment from originating evidence and pass supported claims and reporting gaps to writing.
closure-kind: process
requires-capabilities:
  - koios-research-packet
  - koios-newsroom-day
  - read
  - path-corpus
  - markdown-search-workbench
  - term-intension
  - write
  - utter
  - articulate
---

# Researching a Koios.News assignment

Serve the assigned desk and actual human commission. Reader demand selects attention; it supplies no factual warrant. Start from the admitted wire event or submitted source and recover the complete assignment before selecting an angle. Do not force every desk into Nik's historical collapse essay format.

Read originating documents in full. Record source title, named author, publisher, date, retrieval time, permalink and exact bytes. Seek primary records and affected people. Track original reporting separately from syndication: several hosts carrying one agency are one origin. Model output is never a source.

Extract distinct facts with exact supporting quotations, attribution, dates, units, reporting periods, qualifications and uncertainty. Distinguish a promise from fulfillment, an estimate from a final result, gross receipts from profit, and Friday including previews from a weekend projection. Preserve conflicting estimates; never choose a convenient number or use a vote to settle divergence. A source disagreement is a reporting question.

Identify what readers still need: what changed, how and why, who is affected, relevant context, contrary evidence, response, and next developments. Seek response when criticizing or alleging wrongdoing. Outside messages require human authorization. Record who was contacted, actual send status and response deadline; respect the complete response window, including when an early reply arrives. Do not treat a draft email as sent.

Pass source and claim identities, evidence limits, unresolved questions, the assignment and response windows to the writer. Keep useful acquired sources and completed inference when another source or provider fails. Slow work alone is not bad work. Never fill a gap with invented facts or claim an unanswered outreach occurred.

Method references: https://www.spj.org/spj-code-of-ethics/ ; https://reutersagency.com/about/standards-values/ . These inform method, not claims about an article's subject.
