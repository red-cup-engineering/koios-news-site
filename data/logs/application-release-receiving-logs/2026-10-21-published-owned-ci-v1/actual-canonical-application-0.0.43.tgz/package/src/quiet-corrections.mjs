import { basename } from "node:path";

const QUIET_TITLE_OVERRIDES = Object.freeze({
  "crypto-firms-sue-occ-over-trust-bank-charters": "Community Banks Sue OCC Over Crypto Trust Bank Charters",
});

export function quietTitleOverrideFor(relativePath) {
  if (typeof relativePath !== "string" || relativePath === "") return undefined;
  const slug = basename(relativePath, ".md");
  return QUIET_TITLE_OVERRIDES[slug];
}

export function applyQuietPublishedCorrection(relativePath, source) {
  if (typeof source !== "string") throw new TypeError("published post source must be text");
  const title = quietTitleOverrideFor(relativePath);
  if (title === undefined) return source;

  const lines = source.replace(/\r\n?/gu, "\n").split("\n");
  const close = lines.indexOf("---", 1);
  if (lines[0] !== "---" || close < 0) throw new Error(`${relativePath}: cannot quietly correct malformed front matter`);

  const titleLines = [];
  for (let index = 1; index < close; index += 1) {
    if (/^title:\s*/u.test(lines[index])) titleLines.push(index);
  }
  if (titleLines.length !== 1) throw new Error(`${relativePath}: expected exactly one front-matter title`);

  lines[titleLines[0]] = `title: ${JSON.stringify(title)}`;
  return lines.join("\n");
}
