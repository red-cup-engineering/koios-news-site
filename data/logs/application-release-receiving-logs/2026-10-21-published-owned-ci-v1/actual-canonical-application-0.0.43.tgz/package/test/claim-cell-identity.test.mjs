import test from "node:test";
import assert from "node:assert/strict";
import { cell, address, merge, knowledgeReading } from "@red-cup-engineering/signcell/cell";
import { createTypedMark } from "@red-cup-engineering/signcell/typed-mark";
import { claimEvidenceType } from "@red-cup-engineering/content-mill-newsroom-services-section/carriers";
import { claimIdOf, claimCellsOf, pageClaimCells } from "../src/claim-cells.mjs";

const statement = { subject: "A", predicate: "claims", object: "B" };
function sourceEvidence(tag) {
  const mark = createTypedMark(claimEvidenceType, {
    storyId: "story-1", section: "world",
    sourceId: "source-" + tag, sourceUrl: "https://" + tag + ".example/story",
    sourceEvidenceId: "source-evidence-" + tag, host: tag + ".example",
    ...statement, quote: "A claims B", quoteStart: 0, quoteEnd: 10,
  });
  assert.equal(mark.ok, true, mark.refusal?.message);
  return mark.value;
}

test("public Koios claims are the exact upstream SignCell triple address", () => {
  const expected = address(cell(statement.subject, statement.predicate, statement.object));
  assert.equal(claimIdOf(statement), expected);
  assert.match(expected, /^ni:\/\/\/sha-256;/);
  assert.notEqual(claimIdOf({ subject: "B", predicate: "claims", object: "A" }), expected,
    "a converse is not the same claim");
  assert.notEqual(claimIdOf({ subject: "A", predicate: "claims B", object: "" }), expected,
    "different positional roles cannot identify one another");
});

test("two independent contrary source tellings join into ONE contested SignCell", () => {
  const forSource = sourceEvidence("first");
  const againstSource = sourceEvidence("second");
  const claimRows = [
    { record: forSource, told: { for: true, against: false } },
    { record: againstSource, told: { for: false, against: true } },
  ];
  const readout = claimCellsOf({
    claimRows, candidateRows: [{
      record: { id: "candidate-1", content: {
        storyId: "story-1", claimEvidenceIds: [forSource.id, againstSource.id],
      } },
    }], editions: [{ candidateId: "candidate-1" }],
  });
  assert.equal(readout.skipped, 0);
  assert.equal(readout.cells.length, 1);
  const current = readout.cells[0];
  assert.equal(current.id, claimIdOf(statement));
  assert.equal(current.reading, "stable", "conflicting WIT stays held rather than voting to one side");
  assert.deepEqual(current.sources.for.map(x => x.id), ["source-evidence-first"]);
  assert.deepEqual(current.sources.against.map(x => x.id), ["source-evidence-second"]);
  assert.deepEqual(current.storyIds, ["story-1"]);
  assert.deepEqual(current.editionIds, ["candidate-1"]);
  const native = merge(
    cell("A", "claims", "B", { for: [forSource.id] }),
    cell("A", "claims", "B", { against: [againstSource.id] }),
  );
  assert.equal(knowledgeReading(native), current.reading);
  assert.deepEqual(claimCellsOf({ claimRows: claimRows.toReversed() }), {
    cells: readout.cells.map(c => ({ ...c, editionIds: [] })), skipped: 0,
  }, "original source arrival order must not select a truth pole");
});

test("an invalid or legacy source never creates a claim or a synthetic WIT", () => {
  const readout = claimCellsOf({ claimRows: [{ record: { type: "legacy.claim", value: true } }] });
  assert.equal(readout.skipped, 1);
  assert.deepEqual(readout.cells, []);
});

test("publication cursors must name a member of the exact selected claim projection", () => {
  const a = { id: claimIdOf(statement), reading: "potential", storyIds: ["story-1"] };
  const b = { id: claimIdOf({ ...statement, object: "C" }), reading: "active", storyIds: ["story-2"] };
  const cells = [a, b].sort((x, y) => x.id.localeCompare(y.id));
  const first = pageClaimCells({ cells }, { limit: 1 });
  assert.equal(first.cells.length, 1);
  assert.equal(first.nextCursor, first.cells[0].id);
  const second = pageClaimCells({ cells }, { limit: 1, cursor: first.nextCursor });
  assert.equal(second.cells.length, 1);
  assert.equal(second.nextCursor, null);
  assert.throws(() => pageClaimCells({ cells }, { cursor: "old-jcs-sha256-digest" }), /cursor is absent/);
  assert.throws(() => pageClaimCells({ cells }, { cursor: cells[0].id, story: "not-that-story" }), /cursor is absent/);
});
