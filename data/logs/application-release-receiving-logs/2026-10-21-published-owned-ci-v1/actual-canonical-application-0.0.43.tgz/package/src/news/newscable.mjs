/**
 * organizing-a-newscable - the cable-bundling facet.
 *
 * Newscables bundle newswires. The cable owns the sheath: routing inversion,
 * the cable directory, cable index, robots, sitemap, ingest, and source-roll
 * readings over configured wires.
 */
export {
  DEFAULT_WIRE_STORE,
  NEWSCABLE_CONFIG_BLOCK,
  SourceRollSchema,
  SourceRollSourceSchema,
  SourceRollWireSchema,
  aggregateWires,
  assertNewscableBlock,
  assertNewswireBlock,
  createNewscable,
  ingestCableFromConfig,
  ingestWire,
  readNewscableSiteConfig,
  sourceRollCarrier,
  sourceRollReading,
  sourceRollTerm,

} from "./cable/index.mjs";
