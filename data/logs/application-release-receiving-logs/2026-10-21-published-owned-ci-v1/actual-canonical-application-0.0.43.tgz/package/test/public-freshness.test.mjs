import assert from "node:assert/strict";
import test from "node:test";
import { publicFreshnessFromFeed } from "../src/production-audit.mjs";

const observedAt = new Date("2026-10-02T18:00:00.000Z");
const feed = (at) => `<rss><channel><item><pubDate>${new Date(at).toUTCString()}</pubDate></item></channel></rss>`;

test("public freshness distinguishes fresh, stale, and unobservable feeds", () => {
  const fresh = publicFreshnessFromFeed(feed("2026-10-02T12:00:00.000Z"), observedAt);
  assert.equal(fresh.observed, true);
  assert.equal(fresh.stale, false);

  const stale = publicFreshnessFromFeed(feed("2026-09-30T12:00:00.000Z"), observedAt);
  assert.equal(stale.observed, true);
  assert.equal(stale.stale, true);

  const unknown = publicFreshnessFromFeed("<rss><channel><item /></channel></rss>", observedAt);
  assert.equal(unknown.observed, false);
  assert.equal(unknown.stale, null);
});
