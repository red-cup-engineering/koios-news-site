import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,rmSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';
import {storyDesk} from '../src/news-line/desk.mjs';
import {readPosts} from '@causeway-services/koios-news-site/build';
// The publication is received by building it: the site is rendered into a fresh .public from the content and data this
// package's repository mounts (content, data, sites/koios.news), by the one recipe the package declares (site:build).
rmSync('.public',{recursive:true,force:true});
const build=JSON.parse(execFileSync(process.execPath,['scripts/build-public-site.mjs','--out','.public'],
  {env:{PATH:process.env.PATH??'',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',NODE_DISABLE_COMPILE_CACHE:'1',NEWS_PROPERTY_STATE_ROOT:resolve('data')},encoding:'utf8',timeout:180000,maxBuffer:64*1024*1024}));
assert.ok(Number.isSafeInteger(build.publishedPostCount));
assert.match(build.manifestSha256,/^[a-f0-9]{64}$/);
const property=JSON.parse(readFileSync('config/koios-news-property.json'));
const slug='welsh-first-minister-pushes-for-more-devolution-powers';
const id=feed=>'news-property.story:'+Buffer.from(JSON.stringify({a:'constituted',v:{feed}})).toString('base64url');
test('The anchor feed controls assignment before editorial assessment',()=>{
 assert.equal(storyDesk(property,id('politics-1'),'us-politics').slug,'world');
 assert.equal(storyDesk(property,id('politics-2'),'us-politics').slug,'world');
 assert.equal(storyDesk(property,id('us-politics-2'),'world').slug,'us-politics');
 assert.throws(()=>storyDesk(property,id('unregistered'),'us-politics'),/exactly one/);
});
test('The Wales correction reaches article, feeds, structured data, fingerprint and correction register',()=>{
 const html=readFileSync(`.public/posts/${slug}/index.html`,'utf8');
 assert.match(html,/Koios.News World Desk/);
 assert.match(html,/articleSection[^,}]*World/);
 assert.doesNotMatch(html,/Koios.News US Politics Desk/);
 const fp=JSON.parse(readFileSync(`.public/fingerprints/${slug}.json`));
 assert.equal(fp.facts.section,'World');assert.equal(fp.facts.correctionState,'corrected');
 for(const name of ['feed.xml','feed.atom','feed.json']){
  const text=readFileSync('.public/'+name,'utf8');
  assert.ok(text.includes(slug));
 }
 const corrections=JSON.parse(readFileSync('.public/corrections.json'));
 assert.ok(corrections.corrections.some(x=>x.article.slug===slug&&x.note.includes('Welsh')));
});
test('A changed manuscript cannot silently inherit a prior metadata correction',()=>{
 assert.throws(()=>readPosts('content',property.content.legacyPublishedSections,'posts',undefined,'data/line/publication-replay/published',{[slug]:{...property.content.editorialProjections[slug],priorSourceSha256:'0'.repeat(64)}}),/bind the published source/);
});
test('The recovered OCC headline correction reaches the public article and fingerprint without replacing admitted reporting',()=>{
 const slug='crypto-firms-sue-occ-over-trust-bank-charters',title='Community Banks Sue OCC Over Crypto Trust Bank Charters';
 const post=readPosts('content',property.content.legacyPublishedSections,'posts',undefined,'data/line/publication-replay/published',property.content.editorialProjections).find(x=>x.slug===slug);
 assert.equal(post.title,title);assert.match(post.body,/A group of community banks/);
 assert.equal(post.sourceDigest,property.content.editorialProjections[slug].priorSourceSha256);
 const html=readFileSync(`.public/posts/${slug}/index.html`,'utf8');assert.ok(html.includes(title));
 assert.equal(JSON.parse(readFileSync(`.public/fingerprints/${slug}.json`)).facts.headline,title);
});

test('Explicit article versions retain dated history and reject an unknown body',()=>{
 const configured=property.content.editorialProjections[slug],versionsHeld=Array.isArray(configured)?configured:[configured];
 const raw=readPosts('content',property.content.legacyPublishedSections,'posts',undefined,'data/line/publication-replay/published').find(x=>x.slug===slug);
 const original=versionsHeld.find(x=>x.priorSourceSha256===raw.sourceDigest);
 const future={...original,priorSourceSha256:'f'.repeat(64),note:'A later sourced revision.',corrections:[{date:original.date,note:original.note},{date:'2026-10-08',note:'A later sourced revision.'}]};
 const versions={[slug]:[future,original]};
 const post=readPosts('content',property.content.legacyPublishedSections,'posts',undefined,'data/line/publication-replay/published',versions).find(x=>x.slug===slug);
 assert.equal(post.sourceDigest,original.priorSourceSha256);assert.equal(post.corrections.at(-1).note,original.note);
 assert.throws(()=>readPosts('content',property.content.legacyPublishedSections,'posts',undefined,'data/line/publication-replay/published',{[slug]:[future]}),/bind the published source/);
});
