export const NEWSROOM_STARTUP_MINIMUM_BYTES = 512 * 1024 * 1024;
export const RECOVERY_SNAPSHOT_MINIMUM_BYTES = 1024 * 1024 * 1024;

export function mib(bytes) {
  return Math.floor(bytes / 1024 / 1024);
}

export function cloudCapacityObservation({ availableBytes, totalBytes }) {
  const observation = {
    availableBytes,
    totalBytes,
    minimumWorkingBytes: NEWSROOM_STARTUP_MINIMUM_BYTES,
    recoveryMinimumBytes: RECOVERY_SNAPSHOT_MINIMUM_BYTES,
  };
  if (availableBytes < NEWSROOM_STARTUP_MINIMUM_BYTES) {
    return { status: "startup-blocked", observation };
  }
  if (availableBytes < RECOVERY_SNAPSHOT_MINIMUM_BYTES) {
    return {
      status: "observed",
      observation: {
        ...observation,
        recoveryHeadroom: "low",
        warning: `Recovery snapshotting needs at least 1 GiB available; ${mib(availableBytes)} MiB is available after newsroom startup preflight.`,
      },
    };
  }
  return { status: "observed", observation };
}

export function sharedCloudCapacityStartupBlocker(availableBytes) {
  return `The shared cloud durable-state filesystem has ${mib(availableBytes)} MiB available. Below 512 MiB the newsroom refuses startup to preserve receipts. Repeated standard garbage collection has not provided stable capacity; expand or isolate cloud storage/compute rather than removing reporting or relaxing admission.`;
}

export function newsroomStartupCapacityError() {
  return "Koios newsroom needs at least 512 MiB available on its durable-state filesystem before starting; preserve receipts and recover cloud capacity.";
}
