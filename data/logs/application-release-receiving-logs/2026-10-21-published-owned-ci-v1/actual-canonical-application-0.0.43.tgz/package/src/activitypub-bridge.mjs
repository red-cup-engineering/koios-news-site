import { KOIOS_ACTOR_URI } from "@causeway-services/activitypub-retained-inbox-provider/server";

import { ACTOR } from "./boundary.mjs";
import { settleMessage } from "./service-section.mjs";

/**
 * Bind verified, durably retained ActivityPub arrivals into the Koios
 * inter-enterprise settlement boundary.
 *
 * The retained provider and the service section must name the same actor.
 * Transport verification/retention happens before this callback; business
 * admission remains settleMessage's exact ActivityStreams contract law.
 */
export function createKoiosActivityPubSettlementHandler({
  serviceActor = ACTOR,
  providerActor = KOIOS_ACTOR_URI,
  settle = settleMessage,
  now = () => new Date().toISOString(),
} = {}) {
  if (serviceActor !== providerActor) {
    throw new TypeError(`Koios service actor ${serviceActor} does not match retained ActivityPub actor ${providerActor}`);
  }
  if (typeof settle !== "function") throw new TypeError("Koios ActivityPub bridge requires a settlement function");
  if (typeof now !== "function") throw new TypeError("Koios ActivityPub bridge requires a clock");

  return async (arrival) => {
    const activity = arrival?.jsonLd;
    if (activity === null || typeof activity !== "object" || Array.isArray(activity)) {
      throw new TypeError("Koios ActivityPub bridge requires one verified jsonLd activity");
    }
    return settle(activity, now());
  };
}
