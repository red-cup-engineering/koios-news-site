import {readFileSync} from 'node:fs';
import {homedir} from 'node:os';
import {sign} from 'node:crypto';
import {setTimeout as pause} from 'node:timers/promises';
// These callers perform account/analytics reads or an OAuth token exchange.
// Retry transport and transient HTTP failures; permission errors remain final.
export async function googleRequest(url,options={}, {fetchImpl=fetch,wait=pause}={}){
 for(let attempt=0;attempt<3;attempt++){
  try{
   const response=await fetchImpl(url,{...options,signal:AbortSignal.timeout(10000)});
   if(attempt<2&&[408,429,500,502,503,504].includes(response.status)){
    await response.body?.cancel();
   }else return response;
  }catch(error){
   if(attempt===2)throw error;
  }
  await wait(500*2**attempt+Math.floor(Math.random()*250));
 }
}
export async function googleToken(scopes,{keyFile=process.env.KOIOS_SEARCH_CONSOLE_KEY_FILE??`${homedir()}/.config/sites/search-console-key.json`}={}){
 const key=JSON.parse(readFileSync(keyFile));
 const enc=x=>Buffer.from(JSON.stringify(x)).toString('base64url'),now=Math.floor(Date.now()/1000);
 const body=enc({alg:'RS256',typ:'JWT'})+'.'+enc({iss:key.client_email,scope:scopes.join(' '),aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600});
 const assertion=body+'.'+sign('RSA-SHA256',Buffer.from(body),key.private_key).toString('base64url');
 const result=await(await googleRequest('https://oauth2.googleapis.com/token',{method:'POST',body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion})})).json();
 if(!result.access_token)throw new Error(`Google credential exchange failed: ${result.error}`);
 return result.access_token;
}
export async function googleJson(token,url,{method='GET',body}={}){
 const r=await googleRequest(url,{method,headers:{authorization:`Bearer ${token}`,'content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
 const text=await r.text(),j=text?JSON.parse(text):{};
 if(!r.ok)throw new Error(`Google HTTP ${r.status}: ${j.error?.message??r.statusText}`);
 return j;
}
