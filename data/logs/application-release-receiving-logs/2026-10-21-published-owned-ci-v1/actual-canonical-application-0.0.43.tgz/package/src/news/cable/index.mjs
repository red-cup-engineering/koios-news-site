// The Koios News cable — the wire and the cable, web-free.
//
// Vocabulary, in the literal electrical sense: a NEWSWIRE is a discrete thing
// with its own data — a provenanced claim stream with a masthead, owning its
// store, its item projection, its surfaces, and its production kit. A NEWSCABLE
// is a NEW thing whose data IS newswires — a bundle of wires the way a cable is
// a bundle of wires, adding only the sheath: the routing inversion, the index,
// /cable.json, robots, and sitemap. Claim-state bundles are the canonical
// resources throughout; HTML and feeds are lossy projections, and no projection
// displays a claim stronger than its force.
//
// This is the FORMING + STORE + PRODUCTION KIT, all web-free: the surface
// strings come from the web-feed codec, and the HTML document
// shell is an injected `render` (the cable topology — routing, /cable.json — is
// the news topology (../topology)). HTTP transport (mounting `cable.handle` on a
// listener) is the site's affair; filum supplies the renderer and the App.

export {
  addDays,
  assertedNow,
  computesClaim,
  createNewswire,
  htmlPage,
  loadWireBundles,
  readBundleFile,
  reportWrite,
  resolveDate,
  wireSurfaceUrls,
  writeBundleIfAbsent,

} from "./wire.mjs";

export {
  createNewscable,

} from "./cable.mjs";

export {
  DEFAULT_WIRE_STORE,
  NEWSCABLE_CONFIG_BLOCK,
  assertNewscableBlock,
  assertNewswireBlock,
  aggregateWires,
  readNewscableSiteConfig,

} from "./discovery.mjs";

export {
  auditOf,
  claimLine,
  freshnessOf,
  itemSummary,
  itemTitle,
  projectItem,
  propositionText,
  publishedOf,
  sortReverseChronological,
  updatedOf,

} from "./projection.mjs";

export {
  ingestWire,
  ingestCableFromConfig,

} from "./ingest.mjs";

export {
  SourceRollSchema,
  SourceRollSourceSchema,
  SourceRollWireSchema,
  sourceRollCarrier,
  sourceRollReading,
  sourceRollTerm,

} from "./source-roll.mjs";
