import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {existsSync,mkdtempSync,mkdirSync,openSync,closeSync,statSync,readFileSync,readdirSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const application=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const script=join(application,'scripts','release-site.mjs');
const preload=join(application,'test','fixtures','release-site-fetch.mjs');
const sourceRoot=resolve(process.env.KOIOS_RELEASE_TEST_SOURCE_ROOT??application);
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
function candidateBytes(root){
 const found={};
 const walk=(directory,prefix='')=>{
  for(const entry of readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){
   const relative=prefix+entry.name,path=join(directory,entry.name);
   if(entry.isDirectory())walk(path,`${relative}/`);
   else{assert.equal(entry.isFile(),true,'only fixture files are expected');found[relative]=readFileSync(path).toString('base64');}
  }
 };
 walk(root);return found;
}

function fixture(t,scenario){
 const root=mkdtempSync(join(tmpdir(),'koios-release-audit-'));
 t.after(()=>rmSync(root,{recursive:true,force:true}));
 const candidate=join(root,'.public'),receipts=join(root,'.release');
 mkdirSync(candidate);mkdirSync(receipts);
 const assets={
  '404.html':Buffer.from('<!doctype html><title>Missing</title>'),
  '_headers':Buffer.from('/*\n  X-Content-Type-Options: nosniff\n'),
  '_redirects':Buffer.from('/old /posts/example/ 301\n'),
  'index.html':Buffer.from('<!doctype html><title>Synthetic index</title>'),
  'posts/example/index.html':Buffer.from('<!doctype html><article>Synthetic sealed report</article>'),
  'robots.txt':Buffer.from('User-agent: *\nAllow: /\n'),
 };
 const artifacts=Object.keys(assets).sort((a,b)=>Buffer.compare(Buffer.from(a),Buffer.from(b)))
  .map(file=>({file,sha256:digest(assets[file]),bytes:assets[file].length}));
 let manifest=Buffer.from(`${JSON.stringify({kind:'news-property.build-manifest/v1',
  provenance:{origin:'https://koios.news'},artifacts})}\n`);
 if(scenario==='malformed-manifest')manifest=Buffer.from('{invalid JSON\n');
 for(const [file,bytes] of Object.entries(assets)){
  const path=join(candidate,file);mkdirSync(dirname(path),{recursive:true});writeFileSync(path,bytes);
 }
 writeFileSync(join(candidate,'manifest.json'),manifest);
 if(scenario==='invalid-local-artifact')writeFileSync(join(candidate,'posts/example/index.html'),'unsealed local bytes');
 if(scenario==='unsealed-local-file')writeFileSync(join(candidate,'extra.html'),'not in the manifest');
 const auditPath=join(receipts,'already-live-audit.json');
 if(scenario==='existing-receipt')writeFileSync(auditPath,'immutable prior receipt\n');
 const missingPath=`/__koios_missing_${digest(manifest).slice(0,16)}/`;
 writeFileSync(join(root,'transport.json'),JSON.stringify({scenario,manifest:manifest.toString('base64'),missingPath,
  assets:Object.fromEntries(Object.entries(assets).map(([file,bytes])=>[file,bytes.toString('base64')]))}));
 const env={PATH:dirname(process.execPath),HOME:root,TMPDIR:root,LANG:'C.UTF-8',TZ:'UTC',GITHUB_SHA:'synthetic-test-revision'};
 const before=candidateBytes(candidate);
 const stdoutPath=join(root,'child.stdout'),stderrPath=join(root,'child.stderr');
 const stdoutFd=openSync(stdoutPath,'wx',0o600),stderrFd=openSync(stderrPath,'wx',0o600);
 let result;
 try{result=spawnSync(process.execPath,[
  '--max-old-space-size=128','--no-addons','--no-global-search-paths','--permission',
  `--allow-fs-read=${sourceRoot}`,`--allow-fs-read=${root}`,`--allow-fs-write=${root}`,
  '--import',preload,script,
 ],{cwd:root,env,stdio:['ignore',stdoutFd,stderrFd],timeout:25000});}
 finally{closeSync(stdoutFd);closeSync(stderrFd);}
 for(const path of [stdoutPath,stderrPath])assert.ok(statSync(path).size<=1024*1024,'child output exceeds 1 MiB');
 result.stdout=readFileSync(stdoutPath,'utf8');result.stderr=readFileSync(stderrPath,'utf8');
 const calls=existsSync(join(root,'calls.jsonl'))?readFileSync(join(root,'calls.jsonl'),'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
 assert.equal(result.error,undefined,result.error?.message);
 assert.equal(result.signal,null,`unexpected signal: ${result.signal}`);
 assert.equal(calls.filter(call=>call.kind==='forbidden-process').length,0,'no preview, deployment, readback or cleanup process may be attempted');
 assert.ok(existsSync(candidate),'the release command does not erase candidate bytes');
 assert.deepEqual(candidateBytes(candidate),before,'every candidate byte and path remains unchanged');
 if(scenario==='baseline-body-exhausted'||scenario==='baseline-body-retry'&&result.status!==0)assert.equal(existsSync(join(receipts,'baseline.json')),false);
 else assert.deepEqual(readFileSync(join(receipts,'baseline.json')),manifest);
 for(const name of ['preview.json','probe.json','rollback.json','release.json','authority'])assert.equal(existsSync(join(receipts,name)),false,name);
 const decode=value=>Object.hasOwn(value,'stringValue')?value.stringValue:
  Object.hasOwn(value,'boolValue')?value.boolValue:Object.hasOwn(value,'intValue')?value.intValue:
  value.kvlistValue?Object.fromEntries(value.kvlistValue.values.map(({key,value})=>[key,decode(value)])):
  value.arrayValue?value.arrayValue.values.map(decode):value.doubleValue;
 const progress=result.stderr.split('\n').filter(line=>line.startsWith('{')).map(line=>JSON.parse(line))
  .flatMap(request=>(request.resourceLogs??[]).flatMap(resource=>(resource.scopeLogs??[])
   .flatMap(scope=>scope.logRecords??[]))).map(record=>decode(record.body))
  .filter(row=>row.kind==='koios.website-release-progress/v1');
 return {root,candidate,receipts,manifest,assets,auditPath,missingPath,result,calls,progress};
}

test('an already-live candidate earns a real immutable production audit before success',t=>{
 const f=fixture(t,'good');assert.equal(f.result.status,0,f.result.stderr);assert.ok(f.progress.length>0);assert.equal(f.progress.at(-1).terminal,true);assert.equal(f.progress.at(-1).status,'completed');
 const log=f.result.stdout.trim().split('\n');assert.equal(log.length,1,'the release result is one machine-readable record');
 const summary=JSON.parse(log[0]);assert.deepEqual(summary,{commit:'synthetic-test-revision',
  manifestSha256:digest(f.manifest),publiclyVerified:true,alreadyLive:true,receipt:f.auditPath});
 const receipt=JSON.parse(readFileSync(f.auditPath,'utf8'));
 assert.equal(receipt.kind,'koios.news.cloudflare-production-observation-receipt/v1');
 assert.equal(receipt.candidateManifestSha256,digest(f.manifest));assert.equal(receipt.probe.accepted,true);
 assert.equal(receipt.probe.manifestSha256,digest(f.manifest));assert.equal(receipt.probe.notFound.status,404);
 assert.equal(receipt.probe.notFound.url,`https://koios.news${f.missingPath}`);
 assert.deepEqual(receipt.probe.redirects,[{source:'/old',target:'/posts/example/',status:301}]);
 const ordinary=receipt.probe.artifacts.find(row=>row.file==='posts/example/index.html');
 assert.equal(ordinary.sha256,digest(f.assets['posts/example/index.html']));
 assert.equal(receipt.probe.artifacts.find(row=>row.file==='robots.txt').observation,'cloudflare-managed-content');
 for(const file of ['_headers','_redirects']){
  assert.equal(receipt.probe.artifacts.find(row=>row.file===file).observation,'cloudflare-deployment-config-not-public-asset');
  assert.equal(f.calls.some(call=>call.url===`https://koios.news/${file}`),false);
 }
 assert.ok(f.calls.filter(call=>call.url==='https://koios.news/manifest.json').length>=2,'the auditor reobserves the manifest after equality');
 for(const route of ['/','/404','/posts/example/','/robots.txt','/old',f.missingPath])assert.ok(f.calls.some(call=>call.url===`https://koios.news${route}`),route);
});

for(const [scenario,error] of [
 ['corrupt-article',/served sealed artifact bytes do not match/],
 ['wrong-404-status',/expected 404 status/],
 ['wrong-404-body',/did not serve the candidate 404/],
 ['wrong-redirect',/sealed redirect was not served/],
 ['invalid-local-artifact',/candidate artifact digest does not match/],
 ['unsealed-local-file',/candidate contains files not sealed/],
 ['malformed-manifest',/candidate manifest is not valid JSON/],
 ['existing-receipt',/new immutable production audit receipt path/],
])test(`manifest equality cannot hide ${scenario}`,t=>{
 const f=fixture(t,scenario);assert.notEqual(f.result.status,0);assert.match(f.result.stderr,error);
 assert.equal(f.result.stdout.includes('publiclyVerified'),false);assert.equal(f.result.stdout.includes('already live'),false);
 if(scenario==='existing-receipt')assert.equal(readFileSync(f.auditPath,'utf8'),'immutable prior receipt\n');
 else assert.equal(existsSync(f.auditPath),false,'failed audit must not produce an acceptance receipt');
});

for(const scenario of ['baseline-header-retry','baseline-body-retry'])test(`${scenario} retries only the baseline read before a real immutable audit`,t=>{
 const f=fixture(t,scenario);assert.equal(f.result.status,0,f.result.stderr);
 assert.equal(f.calls.filter(call=>call.kind==='fetch'&&call.baseline).length,2);
 assert.equal(f.progress.at(-1).status,'completed');
 assert.deepEqual(f.progress.at(-1).effects,{preview:'not-attempted',production:'not-attempted'});
 assert.equal(JSON.parse(readFileSync(f.auditPath,'utf8')).probe.accepted,true);
});
test('baseline body timeout exhausts exactly six reads without any provider effect',t=>{
 const f=fixture(t,'baseline-body-exhausted');assert.notEqual(f.result.status,0);assert.match(f.result.stderr,/TimeoutError/);
 assert.equal(f.calls.filter(call=>call.kind==='fetch').length,6);
 assert.equal(f.calls.filter(call=>call.kind==='body-timeout').length,6);
 assert.equal(existsSync(f.auditPath),false);assert.equal(f.result.stdout.includes('publiclyVerified'),false);
 assert.equal(f.progress.at(-1).phase,'baseline-read');assert.equal(f.progress.at(-1).errorClass,'TimeoutError');
 assert.equal(f.progress.at(-1).terminal,true);
 assert.deepEqual(f.progress.at(-1).effects,{preview:'not-attempted',production:'not-attempted'});
});
test('real production audit timeout is distinguished from baseline and any deployment attempt',t=>{
 const f=fixture(t,'audit-timeout');assert.notEqual(f.result.status,0);assert.match(f.result.stderr,/TimeoutError/);
 assert.equal(f.calls.filter(call=>call.kind==='fetch'&&call.baseline).length,1);
 assert.equal(existsSync(f.auditPath),false);assert.equal(f.result.stdout.includes('publiclyVerified'),false);
 assert.equal(f.progress.at(-1).phase,'already-live-audit');assert.equal(f.progress.at(-1).errorClass,'TimeoutError');
 assert.equal(f.progress.at(-1).candidateManifestSha256,digest(f.manifest));
 assert.deepEqual(f.progress.at(-1).effects,{preview:'not-attempted',production:'not-attempted'});
});
