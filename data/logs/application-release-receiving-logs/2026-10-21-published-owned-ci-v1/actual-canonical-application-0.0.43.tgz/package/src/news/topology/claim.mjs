// The enriched claim carrier: claims as capital.
//
// Vocabulary (news_topology_research_memo §4.4, claim_state_capital memo):
// an AssertedClaim is the six-tuple (proposition φ, scope σ, time τ,
// assertion force α, provenance π, editorial status κ) with a stable id —
// the citation handle agent-readable infrastructure requires. Claims are
// not bare triples: the force carries their modality (alleges ≠ confirms ≠
// computes), and modality preservation means no projection may display a
// claim stronger than its force. Time is bitemporal: when the claimed
// thing holds (valid) versus when the claim was asserted.
//
// Laws: provenance is not warrant, and warrant is not truth (W3C VC
// distinction) — π records who/how; κ records the editorial judgment;
// neither implies the other. Correction is propagation, not erasure: a
// correcting claim names what it corrects, the corrected claim is marked
// superseded, and nothing is deleted — retraction is assertion. The
// ClaimStateBundle is the canonical wire resource; NewsClaimSet (index.mts)
// is its documented LOSSY projection, kept for the existing wire surfaces.

/**
 * The assertion force of a claim: its modality - whether the claim alleges,
 * confirms, denies, estimates, quotes, corrects, computes, or interprets. No
 * projection may display a claim stronger than its force.
 */

/**
 * The editorial judgment recorded on a claim: unverified, supported, contested,
 * corrected, or retracted. Distinct from provenance and from truth - it records
 * the editorial standing, not who witnessed the claim.
 */

/**
 * The scope of a claim: the optional event, entity, place, topic, and
 * jurisdiction the claim's proposition is bound to.
 */

/**
 * The bitemporal time of a claim: `valid` is when the claimed state of affairs
 * holds (optional, time-bound), `asserted` is when the claim was asserted
 * (required, since assertions are events).
 */

/**
 * The provenance of a claim: the witness (person, model, or algorithm), the
 * optional method by which it was witnessed, the witness's stated accuracy, and
 * a citation handle. Records who/how, not warrant or truth.
 */

/**
 * The enriched claim carrier: a proposition (predicate and object) bundled with
 * its scope, bitemporal time, assertion force, provenance, and editorial status
 * under a stable citation id. Carries optional `corrects` (the id this claim
 * corrects) and `supersededBy` (set when a later correction names it).
 */

/** The canonical wire resource: a subject's claim-state, in full. */

const ID_PATTERN = /^[a-z0-9]+([.:-][a-z0-9]+)*$/;

/**
 * Asserts that an unknown value is a well-formed ClaimStateBundle: requires a
 * non-empty subject, a claims list, and for each claim a unique lowercase-atom
 * id, a proposition predicate, an asserted time, a force, a witness, and a
 * status. Throws TypeError on the first violation.
 */
export function assertClaimStateBundle(value) {
  if (value === null || typeof value !== "object") throw new TypeError("bundle must be an object");
  const bundle = value;
  if (typeof bundle.subject !== "string" || bundle.subject.length === 0) {
    throw new TypeError("bundle.subject must be a non-empty string");
  }
  if (!Array.isArray(bundle.claims)) throw new TypeError("bundle.claims must be a list");
  const seen = new Set ();
  for (const claim of bundle.claims) {
    if (typeof claim?.id !== "string" || !ID_PATTERN.test(claim.id)) {
      throw new TypeError(`claim id must be lowercase atoms joined by . : - (got ${String(claim?.id)})`);
    }
    if (seen.has(claim.id)) throw new TypeError(`duplicate claim id: ${claim.id}`);
    seen.add(claim.id);
    const proposition = claim.proposition;
    if (!proposition || typeof proposition.predicate !== "string") {
      throw new TypeError(`claim ${claim.id}: proposition.predicate is required`);
    }
    const time = claim.time;
    if (!time || typeof time.asserted !== "string") {
      throw new TypeError(`claim ${claim.id}: time.asserted is required — assertions are events`);
    }
    if (typeof claim.force !== "string") throw new TypeError(`claim ${claim.id}: force is required`);
    const provenance = claim.provenance;
    if (!provenance || typeof provenance.witness !== "string") {
      throw new TypeError(`claim ${claim.id}: provenance.witness is required — no witness, no world`);
    }
    if (typeof claim.status !== "string") throw new TypeError(`claim ${claim.id}: status is required`);
  }
}

/** The claims a correction has not superseded: the bundle's current view. */
export function effectiveClaims(bundle) {
  return Object.freeze(bundle.claims.filter((claim) => claim.supersededBy === undefined));
}

/** Every correction in the bundle, newest first — the corrections feed's source. */
export function correctionClaims(bundle) {
  return Object.freeze(
    bundle.claims
      .filter((claim) => claim.force === "corrects" || claim.corrects !== undefined)
      .slice()
      .sort((a, b) => b.time.asserted.localeCompare(a.time.asserted)),
  );
}

/**
 * Apply a correction: append the correcting claim and mark its target
 * superseded. Nothing is removed — retraction is assertion. Throws
 * TypeError if the target id does not exist or the correction lacks
 * `corrects`.
 */
export function withCorrection(bundle, correction) {
  if (correction.corrects === undefined) throw new TypeError("a correction must name what it corrects");
  const target = bundle.claims.find((claim) => claim.id === correction.corrects);
  if (!target) throw new TypeError(`correction targets unknown claim id: ${correction.corrects}`);
  return Object.freeze({
    subject: bundle.subject,
    claims: Object.freeze([
      ...bundle.claims.map((claim) =>
        claim.id === correction.corrects
          ? Object.freeze({ ...claim, status: "corrected", supersededBy: correction.id })
          : claim,
      ),
      correction,
    ]),
  });
}
