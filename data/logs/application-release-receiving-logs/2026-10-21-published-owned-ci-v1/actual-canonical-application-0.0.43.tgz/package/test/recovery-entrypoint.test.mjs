import {test} from 'node:test';
import {strict as assert} from 'node:assert';
import {mkdtempSync,mkdirSync,writeFileSync,symlinkSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

test('Recovery executes through the cloud package link and stays inert when imported',()=>{
  const root=mkdtempSync(join(tmpdir(),'koios-recovery-entry-'));
  try{
    const program=fileURLToPath(new URL('../scripts/backup-newsroom.mjs',import.meta.url));
    const linked=join(root,'cloud-package.mjs');symlinkSync(program,linked);
    const dataRoot=join(root,'state'),keyPath=join(root,'private.key');
    mkdirSync(join(dataRoot,'line/publication-replay/published'),{recursive:true});
    mkdirSync(join(dataRoot,'feedback'));
    writeFileSync(keyPath,'12'.repeat(32),{mode:0o600});
    writeFileSync(join(dataRoot,'feedback/recovery.json'),JSON.stringify({at:new Date().toISOString()}));
    const env={...process.env,KOIOS_NEWSROOM_DATA_ROOT:dataRoot,KOIOS_BACKUP_KEY_PATH:keyPath};
    const run=(path,args=[],environment=env)=>spawnSync(process.execPath,[path,...args],{env:environment,encoding:'utf8',timeout:10000});
    for(const path of [program,linked]){
      const check=run(path,['check']);assert.equal(check.status,0,check.stderr);
      assert.deepEqual(JSON.parse(check.stdout),{mode:'read-only',ready:true});
      const fresh=run(path);assert.equal(fresh.status,0,fresh.stderr);
      assert.equal(JSON.parse(fresh.stdout).status,'already-captured');
      const missing=run(path,['check'],{...env,KOIOS_BACKUP_KEY_PATH:''});
      assert.notEqual(missing.status,0);assert.match(missing.stderr,/Explicit cloud state/);
    }
    const imported=spawnSync(process.execPath,['--input-type=module','-e',`const m=await import(${JSON.stringify(program)}); console.log(typeof m.createRecoverySnapshot)`],{env:{...env,KOIOS_BACKUP_KEY_PATH:''},encoding:'utf8',timeout:10000});
    assert.equal(imported.status,0,imported.stderr);assert.equal(imported.stdout,'function\n');
  }finally{rmSync(root,{recursive:true,force:true});}
});
